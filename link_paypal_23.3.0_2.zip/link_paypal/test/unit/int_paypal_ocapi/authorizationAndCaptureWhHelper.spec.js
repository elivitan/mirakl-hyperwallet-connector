const { int_paypal_ocapi: { authorizationAndCaptureWhHelperPath } } = require('../path.json');

const { describe, it } = require('mocha');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const CustomObject = () => {};
const paymentInstrument = {};

const authorizationAndCaptureWhHelper = proxyquire(authorizationAndCaptureWhHelperPath, {
    'dw/system/Transaction': dw.system.Transaction,
    'dw/object/CustomObject': CustomObject,
    '*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper': {
        getPaypalPaymentInstrument: () => Object.assign(paymentInstrument, { custom: {} })
    }
});

describe('authorizationAndCaptureWhHelper file', () => {
    describe('updateOrderPaymentStatus', () => {
        const paymentStatus = 'newPaymentStatus';

        it('response should be paymentStatus in order updated if order is instance of CustomObject', () => {
            const order = new CustomObject();

            order.custom = { paymentStatus: 'paymentStatus' };

            authorizationAndCaptureWhHelper.updateOrderPaymentStatus(order, paymentStatus);
            expect(order.custom.paymentStatus).to.equal('newPaymentStatus');
        });

        it('response should be paypalPaymentStatus in paymentInstrument updated if order isn\'t instance of CustomObject', () => {
            const order = {};

            authorizationAndCaptureWhHelper.updateOrderPaymentStatus(order, paymentStatus);
            expect(paymentInstrument.custom.paypalPaymentStatus).to.equal('newPaymentStatus');
        });
    });
});
