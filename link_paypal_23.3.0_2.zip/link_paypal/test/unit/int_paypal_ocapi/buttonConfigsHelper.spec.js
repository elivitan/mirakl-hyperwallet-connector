/* eslint-disable no-underscore-dangle */
const { int_paypal_ocapi: { buttonConfigsHelperPath } } = require('../path.json');

const {
    describe, it, before, after
} = require('mocha');

const { expect } = require('chai');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const getPaypalPaymentInstrument = stub();
const getBillingAgreements = stub();

const buttonConfigsHelper = proxyquire(buttonConfigsHelperPath, {
    'dw/value/Money': dw.value.Money,
    'dw/util/StringUtils': dw.util.StringUtils,
    '*/cartridge/config/paypalPreferences': {
        partnerAttributionId: 'partnerAttributionId',
        paypalStaticImageLink: 'paypalStaticImageLink',
        billingAgreementEnabled: true,
        paypalPdpButtonConfig: 'paypalPdpButtonConfig',
        paypalCartButtonConfig: 'paypalCartButtonConfig',
        paypalMinicartButtonConfig: 'paypalMinicartButtonConfig',
        paypalBillingButtonConfig: 'paypalBillingButtonConfig'
    },
    '*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper': {
        getPaypalPaymentInstrument
    },
    '*/cartridge/models/billingAgreement': () => ({
        getBillingAgreements,
        getDefaultBillingAgreement: () => ({ email: 'email' }),
        isBaLimitReached: () => false,
        isAccountAlreadyExist: () => true
    }),
    '*/cartridge/scripts/paypal/paypalUtils': {
        createSDKUrl: () => 'SDKUrl',
        createBillingSDKUrl: () => 'BillingSDKUrl'
    },
    '*/cartridge/scripts/util/paypalConstants': {
        PAGE_FLOW_CART: 'PAGE_FLOW_CART',
        PAGE_FLOW_PDP: 'PAGE_FLOW_PDP',
        PAGE_FLOW_BILLING: 'PAGE_FLOW_BILLING',
        PAYMENT_METHOD_ID_VENMO: 'PAYMENT_METHOD_ID_VENMO'
    }
});

describe('buttonConfigsHelper file', () => {
    const basket = {};
    const buttonConfigs = {
        partnerAttributionId: 'partnerAttributionId',
        paypalButtonSdkUrl: 'SDKUrl',
        paypalEmail: null,
        showStaticImage: false,
        defaultBAemail: undefined,
        paypalStaticImageLink: 'paypalStaticImageLink',
        billingAgreementEnabled: true
    };

    describe('getGeneralExpressCheckoutBtnConfigs', () => {
        const getGeneralExpressCheckoutBtnConfigs = buttonConfigsHelper.__get__('getGeneralExpressCheckoutBtnConfigs');
        const responseObj = {
            buttonConfigs,
            paypalPaymentInstrument: null
        };

        after(() => {
            getPaypalPaymentInstrument.reset();
            buttonConfigs.defaultBAemail = undefined;
            buttonConfigs.paypalEmail = null;
        });

        it('response should equal responseObj if customer is authenticated & BA is enabled but there\'re no billing agreements', () => {
            customer.authenticated = true;

            expect(getGeneralExpressCheckoutBtnConfigs(basket)).to.deep.equal(responseObj);
        });

        it('response property buttonConfigs should have values for its properties defaultBAemail & paypalEmail if customer is authenticated, BA is enabled & there\'s billing agreements', () => {
            getBillingAgreements.returns({});
            getPaypalPaymentInstrument.returns({ custom: { currentPaypalEmail: 'currentPaypalEmail' } });

            expect(getGeneralExpressCheckoutBtnConfigs(basket)).to.have.property('buttonConfigs').that.includes({
                defaultBAemail: 'email',
                paypalEmail: 'currentPaypalEmail'
            });
        });

        it('response should equal responseObj if customer isn\'t authenticated ', () => {
            customer.authenticated = null;
            getPaypalPaymentInstrument.returns();

            expect(getGeneralExpressCheckoutBtnConfigs(basket)).to.deep.equal(responseObj);
        });
    });

    describe('getPayPalConfigsForPdpPage', () => {
        it('response should be an object containing paypalPdpButtonConfigs besides GeneralExpressCheckoutBtnConfigs', () => {
            expect(buttonConfigsHelper.getPayPalConfigsForPdpPage(basket)).to.deep.equal(Object.assign({ buttonConfig: 'paypalPdpButtonConfig' }, buttonConfigs));
        });
    });

    describe('getPayPalConfigsForCartPages', () => {
        const additionalBtnConfigs = {
            buttonConfig: 'paypalMinicartButtonConfig',
            isPaypalInstrumentExist: false,
            isVenmoUsed: false
        };

        let pageId;

        after(() => {
            getPaypalPaymentInstrument.reset();
        });

        it('response should be an object containing additionalBtnConfigs besides buttonConfigs', () => {
            pageId = 'PAGE_FLOW_MINICART';

            expect(buttonConfigsHelper.getPayPalConfigsForCartPages(basket, pageId)).to.deep.equal(Object.assign(additionalBtnConfigs, buttonConfigs));
        });

        it('response property buttonConfig should equal paypalCartButtonConfig if page flow is CART', () => {
            pageId = 'PAGE_FLOW_CART';

            expect(buttonConfigsHelper.getPayPalConfigsForCartPages(basket, pageId)).to.have.property('buttonConfig', 'paypalCartButtonConfig');
        });

        it('response property buttonConfig should equal paypalCartButtonConfig if page flow is CART', () => {
            getPaypalPaymentInstrument.returns({ custom: { currentPaypalEmail: 'currentPaypalEmail' } });

            expect(buttonConfigsHelper.getPayPalConfigsForCartPages(basket, pageId)).to.have.property('isPaypalInstrumentExist', true);
        });
    });

    describe('getPayPalConfigsForBillingPage', () => {
        const responseObj = {
            paymentAmount: '0 USD',
            paypalEmail: undefined,
            partnerAttributionId: 'partnerAttributionId',
            buttonConfig: 'paypalBillingButtonConfig',
            customerPaypalPaymentInstruments: undefined,
            hasDefaultPaymentMethod: undefined,
            paypalOrderID: '',
            isBALimitReached: undefined,
            payPalButtonSdkUrl: 'BillingSDKUrl',
            isAccountAlreadyExist: false,
            activeBAEmail: undefined,
            activeBAID: undefined,
            isVenmoUsed: false
        };

        basket.currencyCode = 'USD';

        before(() => {
            stub(dw.util.StringUtils, 'formatMoney');
        });

        after(() => {
            dw.util.StringUtils.formatMoney.restore();
            customer.authenticated = null;
        });

        it('response should equal responseObj if customer isn\'t authenticated and there\'s no paypal payment instruments', () => {
            getPaypalPaymentInstrument.returns();
            dw.util.StringUtils.formatMoney.returns('0 USD');

            expect(buttonConfigsHelper.getPayPalConfigsForBillingPage(basket)).to.deep.equal(responseObj);
        });

        it('response properties customerPaypalPaymentInstruments, isBALimitReached & hasDefaultPaymentMethod shouldn\'t be undefined if customer is authenticated', () => {
            customer.authenticated = true;
            getBillingAgreements.returns('BA');

            expect(buttonConfigsHelper.getPayPalConfigsForBillingPage(basket)).to.include({
                customerPaypalPaymentInstruments: 'BA',
                isBALimitReached: false,
                hasDefaultPaymentMethod: true
            });
        });

        it('response properties isAccountAlreadyExist, paypalEmail & isVenmoUsed shouldn\'t be undefined & paymentAmount value updated if customer is authenticated & there\'s PaypalPaymentInstrument', () => {
            getPaypalPaymentInstrument.returns({
                paymentTransaction: { amount: { value: 10 } },
                custom: {
                    currentPaypalEmail: 'currentPaypalEmail',
                    paymentId: 'PAYMENT_METHOD_ID_PAYPAL'
                }
            });
            dw.util.StringUtils.formatMoney.returns('10 USD');

            expect(buttonConfigsHelper.getPayPalConfigsForBillingPage(basket)).to.include({
                paymentAmount: '10 USD',
                isAccountAlreadyExist: true,
                paypalEmail: 'currentPaypalEmail',
                isVenmoUsed: false
            });
        });

        it('response properties activeBAEmail, & activeBAID shouldn\'t be undefined if there\'s active billing agreement', () => {
            getPaypalPaymentInstrument.returns({
                paymentTransaction: { amount: { value: 10 } },
                custom: {
                    PP_API_ActiveBillingAgreement: JSON.stringify({ email: 'email', baID: 'baID' })
                }
            });

            expect(buttonConfigsHelper.getPayPalConfigsForBillingPage(basket)).to.include({
                activeBAEmail: 'email',
                activeBAID: 'baID'
            });
        });

        it('response property hasDefaultPaymentMethod shouldn\'t be undefined if there\'s default payment method in active billing agreement & active BA property saveToProfile is true', () => {
            getPaypalPaymentInstrument.returns({
                paymentTransaction: { amount: { value: 10 } },
                custom: {
                    PP_API_ActiveBillingAgreement: JSON.stringify({
                        email: 'email',
                        baID: 'baID',
                        default: true,
                        saveToProfile: true
                    })
                }
            });

            expect(buttonConfigsHelper.getPayPalConfigsForBillingPage(basket)).to.have.property('hasDefaultPaymentMethod', true);
        });

        it('response property paypalOrderID shouldn\'t be undefined if there\'s paypalOrderID in paypal payment instrument', () => {
            getPaypalPaymentInstrument.returns({
                paymentTransaction: { amount: { value: 10 } },
                custom: { paypalOrderID: 'paypalOrderID' }
            });

            expect(buttonConfigsHelper.getPayPalConfigsForBillingPage(basket)).to.have.property('paypalOrderID', 'paypalOrderID');
        });
    });

    describe('getPayPalButtonConfigsForCurrentPage', () => {
        let pageId;

        it('response should be PayPalConfigsForPdpPage if page flow is PDP', () => {
            pageId = 'PAGE_FLOW_PDP';

            expect(buttonConfigsHelper.getPayPalButtonConfigsForCurrentPage(basket, pageId)).to.have.keys('partnerAttributionId', 'paypalButtonSdkUrl', 'paypalEmail', 'showStaticImage', 'defaultBAemail', 'paypalStaticImageLink', 'billingAgreementEnabled', 'buttonConfig');
        });

        it('response should be PayPalConfigsForBillingPage if page flow is BILLING', () => {
            pageId = 'PAGE_FLOW_BILLING';

            expect(buttonConfigsHelper.getPayPalButtonConfigsForCurrentPage(basket, pageId)).to.have.keys('paymentAmount', 'paypalEmail', 'partnerAttributionId', 'buttonConfig', 'customerPaypalPaymentInstruments', 'hasDefaultPaymentMethod', 'paypalOrderID', 'isBALimitReached', 'payPalButtonSdkUrl', 'isAccountAlreadyExist', 'activeBAEmail', 'activeBAID', 'isVenmoUsed');
        });

        it('response should be PayPalConfigsForCartPages if page flow is CART', () => {
            pageId = 'PAGE_FLOW_CART';

            expect(buttonConfigsHelper.getPayPalButtonConfigsForCurrentPage(basket, pageId)).to.have.keys('partnerAttributionId', 'paypalButtonSdkUrl', 'paypalEmail', 'showStaticImage', 'defaultBAemail', 'paypalStaticImageLink', 'billingAgreementEnabled', 'buttonConfig', 'isPaypalInstrumentExist', 'isVenmoUsed');
        });
    });
});
