/* eslint-disable no-underscore-dangle */
const { int_paypal_ocapi: { billingAgreementHelperPath } } = require('../path.json');

const { describe, it, after } = require('mocha');
const { expect } = require('chai');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const getActiveBillingAgreements = stub();
const billingAgreementList = [];

const billingAgreementHelper = proxyquire(billingAgreementHelperPath, {
    '*/cartridge/models/billingAgreement': () => ({
        getActiveBillingAgreements,
        addBillingAgreement: (data) => billingAgreementList.push(data)
    }),
    '*/cartridge/scripts/util/paypalConstants': {
        PAYMENT_METHOD_ID_PAYPAL: 'PAYMENT_METHOD_ID_PAYPAL'
    }
});

describe('billingAgreementHelper file', () => {
    const paymentInstruments = [{
        UUID: 'UUID_00',
        custom: {
            paypalBillingAgreementToken: 'token',
            paypalBillingAgreementID: 'ba_id_0',
            paypalBillingAgreementEmail: 'email@email.com'
        }
    }, {
        UUID: 'UUID_01',
        custom: {
            paypalBillingAgreementToken: 'token_1',
            paypalBillingAgreementID: 'ba_id_1',
            paypalBillingAgreementEmail: 'email_1@email.com'
        }
    }];

    before(() => {
        customer.profile = {
            wallet: {
                paymentInstruments: { toArray: () => paymentInstruments }
            },
            custom: { PP_API_billingAgreement: null }
        };
    });

    after(() => {
        customer.profile = null;
    });

    describe('isSameBillingAgreement', () => {
        const activeBA = {
            email: 'email',
            default: 'default',
            saveToProfile: true
        };

        const formBA = {
            email: 'email',
            default: 'default',
            saveToProfile: true
        };

        it('response should be true if activeBA equals fromBA', () => {
            expect(billingAgreementHelper.isSameBillingAgreement(activeBA, formBA)).to.be.true;
        });

        it('response should be false if activeBA isn\'t same as fromBA', () => {
            formBA.saveToProfile = false;

            expect(billingAgreementHelper.isSameBillingAgreement(activeBA, formBA)).to.be.false;
        });
    });

    describe('getPaymentInstrumentByBAToken', () => {
        it('response should be payment instrument found by token', () => {
            expect(billingAgreementHelper.getPaymentInstrumentByBAToken('token')).to.have.property('custom').which.includes({ paypalBillingAgreementToken: 'token' });
        });
    });

    describe('getPaymentInstrumentByBAEmail', () => {
        const getPaymentInstrumentByBAEmail = billingAgreementHelper.__get__('getPaymentInstrumentByBAEmail');

        it('response should be payment instrument found by email', () => {
            expect(getPaymentInstrumentByBAEmail('email@email.com')).to.have.property('custom').which.includes({ paypalBillingAgreementEmail: 'email@email.com' });
        });
    });

    describe('getPaymentInstrumentByBillingAgreementID', () => {
        it('response should be payment instrument found by email', () => {
            expect(billingAgreementHelper.getPaymentInstrumentByBillingAgreementID('ba_id_0')).to.have.property('custom').which.includes({ paypalBillingAgreementID: 'ba_id_0' });
        });
    });

    describe('getPaymentInstrumentByUUID', () => {
        const customerPaymentInstrumentsArr = { toArray: () => paymentInstruments };

        it('response should be payment instrument found by email', () => {
            expect(billingAgreementHelper.getPaymentInstrumentByUUID(customerPaymentInstrumentsArr, 'UUID_00')).to.have.property('UUID', 'UUID_00');
        });
    });

    describe('createCustomerPaymentInstrument', () => {
        const customerPaymentInstrument = {
            custom: { PP_API_ActiveBillingAgreement: JSON.stringify({ baID: 'baID', email: 'email' }) }
        };

        const basket = {
            getCustomer: () => ({
                getProfile: () => ({
                    getWallet: () => ({
                        createPaymentInstrument: () => ({ custom: {} })
                    })
                })
            })
        };

        after(() => {
            getActiveBillingAgreements.reset();
            billingAgreementHelper.__ResetDependency__('getPaymentInstrumentByBAEmail');
        });

        it('response should be stringified new BA list saved to customer profile', () => {
            getActiveBillingAgreements.returns({});

            billingAgreementHelper.createCustomerPaymentInstrument(basket, customerPaymentInstrument);
            expect(customer.profile.custom.PP_API_billingAgreement).to.equal('{}');
        });

        it('response should be PP_API_billingAgreement undefined if there\'s no active BA', () => {
            getActiveBillingAgreements.returns();

            billingAgreementHelper.createCustomerPaymentInstrument(basket, customerPaymentInstrument);
            expect(customer.profile.custom.PP_API_billingAgreement).to.be.undefined;
        });

        it('response should be an empty object included into billingAgreementList if PP_API_ActiveBillingAgreement is an empty object', () => {
            customerPaymentInstrument.custom.PP_API_ActiveBillingAgreement = JSON.stringify({});
            billingAgreementHelper.__set__('getPaymentInstrumentByBAEmail', () => ({ custom: {} }));

            billingAgreementHelper.createCustomerPaymentInstrument(basket, customerPaymentInstrument);
            expect(billingAgreementList).to.include({});
        });
    });

    describe('billingAgreementExist', () => {
        it('response should be true if there\'s payment instrument with provided email', () => {
            expect(billingAgreementHelper.billingAgreementExist('email_1@email.com')).to.be.true;
        });

        it('response should be false if there\'s no payment instrument with provided email', () => {
            expect(billingAgreementHelper.billingAgreementExist('email_2@email.com')).to.be.false;
        });
    });
});
