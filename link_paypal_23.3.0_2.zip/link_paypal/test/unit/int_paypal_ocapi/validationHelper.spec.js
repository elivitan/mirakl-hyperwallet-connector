const { int_paypal_ocapi: { validationHelperPath } } = require('../path.json');

const { describe, it } = require('mocha');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const validationHelper = proxyquire(validationHelperPath, {
    '*/cartridge/scripts/paypal/helpers/paypalHelper': {
        getPossiblePayPalPaymentMethodArray: () => ['paypal']
    }
});

describe('validationHelper file', () => {
    describe('validateRequestStringValue', () => {
        let value;

        it('response should be false if value equals to null', () => {
            value = null;

            expect(validationHelper.validateRequestStringValue(value)).to.be.false;
        });

        it('response should be false if value isn\'t a string', () => {
            value = [];

            expect(validationHelper.validateRequestStringValue(value)).to.be.false;
        });

        it('response should be false if value is an empty string', () => {
            value = '';

            expect(validationHelper.validateRequestStringValue(value)).to.be.false;
        });

        it('response should be true if value isn\'t an empty string', () => {
            value = 'value';

            expect(validationHelper.validateRequestStringValue(value)).to.be.true;
        });
    });

    describe('validateOrderAddress', () => {
        const address = {
            firstName: 'firstName',
            lastName: 'lastName',
            address1: 'address1',
            city: 'city',
            countryCode: 'countryCode',
            phone: 'phone',
            postalCode: 'postalCode',
            stateCode: 'stateCode'
        };

        it('response should be true if values for address properties firstName, lastName, address1, city, phone, country/postal/state codes are a string', () => {
            expect(validationHelper.validateOrderAddress(address)).to.be.true;
        });

        it('response should be false if anby of the values for address properties firstName, lastName, address1, city, phone, country/postal/state codes isn\'t a string', () => {
            address.firstName = null;

            expect(validationHelper.validateOrderAddress(address)).to.be.false;
        });
    });

    describe('validatePaymentIdFromRequest', () => {
        let paymentId;

        it('response should be false if paymentId isn\'t a string', () => {
            expect(validationHelper.validatePaymentIdFromRequest(paymentId)).to.be.false;
        });

        it('response should be false if paymentId isn\'t among possible paypal payment methods', () => {
            paymentId = 'venmo';

            expect(validationHelper.validatePaymentIdFromRequest(paymentId)).to.be.false;
        });

        it('response should be true if paymentId is among possible paypal payment methods', () => {
            paymentId = 'paypal';

            expect(validationHelper.validatePaymentIdFromRequest(paymentId)).to.be.true;
        });
    });
});
