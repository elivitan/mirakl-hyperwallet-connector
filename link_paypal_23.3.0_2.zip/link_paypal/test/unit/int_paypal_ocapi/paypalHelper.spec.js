/* eslint-disable no-underscore-dangle */
const { int_paypal_ocapi: { paypalHelperPath } } = require('../path.json');

const {
    describe, it, before, after
} = require('mocha');

const { expect } = require('chai');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const enabledLPMsArray = [];
let billingAgreementDescription;

const paypalHelper = proxyquire(paypalHelperPath, {
    'dw/order/BasketMgr': dw.order.BasketMgr,
    'dw/order/Order': dw.order.Order,
    'dw/order/TaxMgr': dw.order.TaxMgr,
    'dw/order/PaymentMgr': dw.order.PaymentMgr,
    'dw/order/OrderMgr': dw.order.OrderMgr,
    'dw/object/CustomObjectMgr': dw.object.CustomObjectMgr,
    '*/cartridge/config/paypalPreferences': {
        paypalButtonLocation: 'Cart,Billing',
        billingAgreementDescription,
        enabledLPMsArray
    },
    '*/cartridge/scripts/paypal/helpers/addressHelper': {
        getBAShippingAddress: (address) => address,
        createShippingAddress: (address) => address
    },
    '*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper': {
        calculateNonGiftCertificateAmount: (item) => item.price
    },
    '*/cartridge/scripts/util/paypalConstants': {
        PAGE_FLOW_PDP: 'page_flow_pdp',
        PAGE_FLOW_CART: 'page_flow_cart',
        PAGE_FLOW_MINICART: 'page_flow_minicart',
        PAGE_FLOW_BILLING: 'page_flow_billing',
        PROCESSOR_PAYPAL: 'PROCESSOR_PAYPAL',
        PAYMENT_METHOD_ID_PAYPAL: 'PAYMENT_METHOD_ID_PAYPAL',
        PAYMENT_METHOD_ID_VENMO: 'PAYMENT_METHOD_ID_VENMO',
        PAYMENT_METHOD_ID_DEBIT_CREDIT_CARD: 'PAYMENT_METHOD_ID_DEBIT_CREDIT_CARD'
    }
});

describe('paypalHelper file', () => {
    const basket = {
        productLineItems: [],
        giftCertificateLineItems: []
    };

    before(() => {
        Array.map = (a, b) => Array.prototype.map.call(a, b);
        Array.reduce = (a, b) => Array.prototype.reduce.call(a, b);
    });

    after(() => {
        Array.map = () => {};
        Array.reduce = () => ({});
    });

    describe('hasOnlyGiftCertificates', () => {
        const hasOnlyGiftCertificates = paypalHelper.__get__('hasOnlyGiftCertificates');

        after(() => {
            basket.productLineItems = [];
            basket.giftCertificateLineItems = [];
        });

        it('response should be false if basket doesn\'t contain giftCertificateLineItems', () => {
            expect(hasOnlyGiftCertificates(basket)).to.be.false;
        });

        it('response should be true if basket contains giftCertificateLineItems', () => {
            basket.giftCertificateLineItems.push({});

            expect(hasOnlyGiftCertificates(basket)).to.be.true;
        });

        it('response should be false if basket contains productLineItems', () => {
            basket.productLineItems.push({});

            expect(hasOnlyGiftCertificates(basket)).to.be.false;
        });
    });

    describe('getBARestData', () => {
        const isBillingPage = true;
        const responseObj = {
            path: 'v1/billing-agreements/agreement-tokens',
            method: 'POST',
            body: {
                description: '',
                payer: { payment_method: 'PAYPAL' },
                plan: {
                    type: 'MERCHANT_INITIATED_BILLING_SINGLE_AGREEMENT',
                    merchant_preferences: {
                        return_url: '1',
                        cancel_url: '2',
                        accepted_pymt_type: 'INSTANT',
                        skip_shipping_address: false,
                        immutable_shipping_address: true
                    }
                }
            }
        };

        after(() => {
            dw.order.BasketMgr.currentBasket = null;
            basket.giftCertificateLineItems = [];
        });

        it('response should equal responseObj', () => {
            billingAgreementDescription = null;

            expect(paypalHelper.getBARestData(isBillingPage, basket)).to.deep.equal(responseObj);
        });

        it('response property skip_shipping_address in body.plan.merchant_preferences should be true if basket has only gift certificates line itmes', () => {
            basket.giftCertificateLineItems.push({});

            expect(paypalHelper.getBARestData(isBillingPage, basket).body.plan.merchant_preferences).to.have.property('skip_shipping_address', true);
        });

        it('response should be shipping address added from the basket & current basket taken from BasketMgr if none comes as an argument', () => {
            dw.order.BasketMgr.currentBasket = {
                productLineItems: [{}],
                giftCertificateLineItems: [],
                defaultShipment: { getShippingAddress: () => 'ShippingAddress' },
                getDefaultShipment: () => ({ getShippingAddress: () => 'ShippingAddress' })
            };

            expect(paypalHelper.getBARestData(isBillingPage, null)).to.have.property('body').that.includes({
                shipping_address: 'ShippingAddress'
            });
        });
    });

    describe('getUrlPath', () => {
        const credential = { URL: 'url' };
        const path = 'path';

        it('response should be URL created', () => {
            expect(paypalHelper.getUrlPath(credential, path)).to.equal('url/path');
        });

        it('response should be URL created', () => {
            credential.URL = 'url/';

            expect(paypalHelper.getUrlPath(credential, path)).to.equal('url/path');
        });
    });

    describe('getAppliedGiftCertificateTotal', () => {
        const getAppliedGiftCertificateTotal = paypalHelper.__get__('getAppliedGiftCertificateTotal');
        const account = {
            amount: 0,
            add: function(amount) {
                this.amount += amount;
            }
        };

        const giftCertificate = { paymentTransaction: { amount: 20 } };

        it('response should be total amount of gift certificates calculated', () => {
            getAppliedGiftCertificateTotal(account, giftCertificate);
            expect(account.amount).to.equal(20);
        });
    });

    describe('getItemsDescription', () => {
        const getItemsDescription = paypalHelper.__get__('getItemsDescription');
        const productLineItems = [];

        it('response should be an empty string if there\'re no productLineItems', () => {
            expect(getItemsDescription(productLineItems)).to.equal('');
        });

        it('response should be a concatanation of product names with max length of 127 characters', () => {
            productLineItems.push({ productName: 'productName' });

            expect(getItemsDescription(productLineItems)).to.equal('productName');
        });
    });

    describe('getGiftCertificateDescription', () => {
        const getGiftCertificateDescription = paypalHelper.__get__('getGiftCertificateDescription');
        const giftCertificateLineItems = [];

        it('response should be an empty string if there\'re no productLineItems', () => {
            expect(getGiftCertificateDescription(giftCertificateLineItems)).to.equal('');
        });

        it('response should be a concatanation of product names with max length of 127 characters', () => {
            giftCertificateLineItems.push({ lineItemText: 'lineItemText', recipientEmail: 'recipientEmail' });

            expect(getGiftCertificateDescription(giftCertificateLineItems)).to.equal('lineItemText for recipientEmail');
        });
    });

    describe('getPurchaseUnit', () => {
        const lineItem = {
            orderNo: 'order_no',
            price: { value: 100 },
            currencyCode: 'USD',
            defaultShipment: {
                getShippingAddress: () => {}
            },
            productLineItems: [],
            shippingTotalPrice: {
                value: 20,
                subtract: function(amount) {
                    return { value: this.value - amount };
                }
            },
            adjustedShippingTotalPrice: 0,
            merchandizeTotalPrice: {
                value: 100,
                subtract: function(amount) {
                    return { value: this.value - amount };
                },
                add: function(amount) {
                    return { value: this.value + amount };
                }
            },
            adjustedMerchandizeTotalPrice: 0,
            giftCertificateLineItems: [],
            giftCertificatePaymentInstruments: [{ value: 0 }],
            giftCertificateTotalPrice: 0,
            totalTax: { value: 6 }
        };

        const isBillingPage = true;
        const responseObj = {
            description: '',
            amount: {
                currency_code: 'USD',
                value: '100',
                breakdown: {
                    item_total: {
                        currency_code: 'USD',
                        value: '100'
                    },
                    shipping: {
                        currency_code: 'USD',
                        value: '20'
                    },
                    tax_total: {
                        currency_code: 'USD',
                        value: '0'
                    },
                    handling: {
                        currency_code: 'USD',
                        value: '0'
                    },
                    insurance: {
                        currency_code: 'USD',
                        value: '0'
                    },
                    shipping_discount: {
                        currency_code: 'USD',
                        value: '20'
                    },
                    discount: {
                        currency_code: 'USD',
                        value: '0'
                    }
                }
            },
            shipping_preference: 'GET_FROM_FILE'
        };

        after(() => {
            dw.order.TaxMgr.getTaxationPolicy.restore();
            delete dw.order.TaxMgr.TAX_POLICY_GROSS;
        });

        it('response should equal responseObj', () => {
            Object.assign(dw.order.TaxMgr, { TAX_POLICY_GROSS: 'TAX_POLICY_GROSS' });
            stub(dw.order.TaxMgr, 'getTaxationPolicy').returns('TAX_POLICY_GROSS');

            expect(paypalHelper.getPurchaseUnit(lineItem, isBillingPage)).to.deep.equal(responseObj);
        });

        it('response should be tax_total not equaling to 0 if tax policy is NET', () => {
            Object.assign(dw.order.TaxMgr, { TAX_POLICY_GROSS: 'TAX_POLICY_NET' });

            expect(paypalHelper.getPurchaseUnit(lineItem, isBillingPage).amount.breakdown.tax_total).to.include({ value: '6' });
        });

        it('response should include property invoice_id if lineItemSubClass is instance of Order', () => {
            const lineItemSubClass = new dw.order.Order();

            Object.assign(lineItemSubClass, lineItem);

            expect(paypalHelper.getPurchaseUnit(lineItemSubClass, isBillingPage)).to.have.property('invoice_id', 'order_no');
        });

        it('response should include properties shipping & shipping_preference set to SET_PROVIDED_ADDRESS if there\'s default shipping address', () => {
            lineItem.defaultShipment.getShippingAddress = () => 'shipping address';

            expect(paypalHelper.getPurchaseUnit(lineItem, isBillingPage)).to.include({
                shipping: 'shipping address',
                shipping_preference: 'SET_PROVIDED_ADDRESS'
            });
        });

        it('response property shipping_preference shol be set to NO_SHIPPING if only gift certificates are purchased', () => {
            lineItem.giftCertificateLineItems.push({});

            expect(paypalHelper.getPurchaseUnit(lineItem, isBillingPage)).to.have.property('shipping_preference', 'NO_SHIPPING');
        });
    });

    describe('isPaypalButtonEnabled', () => {
        it('response should be false if page flow is PDP', () => {
            expect(paypalHelper.isPaypalButtonEnabled('page_flow_pdp')).to.be.false;
        });

        it('response should be false if argument is missing', () => {
            expect(paypalHelper.isPaypalButtonEnabled()).to.be.false;
        });

        it('response should be true if page flow is BILLING', () => {
            expect(paypalHelper.isPaypalButtonEnabled('billing')).to.be.true;
        });

        it('response should be true if page flow is CART', () => {
            expect(paypalHelper.isPaypalButtonEnabled('cart')).to.be.true;
        });
    });

    describe('isPayPalPaymentMethodActive', () => {
        const isPayPalPaymentMethodActive = paypalHelper.__get__('isPayPalPaymentMethodActive');

        after(() => {
            dw.order.PaymentMgr.activePaymentMethods = null;
        });

        it('response should be true if paypal is among active payment methods', () => {
            dw.order.PaymentMgr.activePaymentMethods = {
                toArray: () => [{ paymentProcessor: { ID: 'PROCESSOR_PAYPAL' } }]
            };

            expect(isPayPalPaymentMethodActive()).to.be.true;
        });

        it('response should be false if paypal isn\'t among active payment methods', () => {
            dw.order.PaymentMgr.activePaymentMethods = {
                toArray: () => [{ paymentProcessor: { ID: 'PROCESSOR_CREDIT' } }]
            };

            expect(isPayPalPaymentMethodActive()).to.be.false;
        });
    });

    describe('isPayPalBtnEnabledOnPdpPage', () => {
        after(() => {
            paypalHelper.__ResetDependency__('isPayPalPaymentMethodActive');
            paypalHelper.__ResetDependency__('isPaypalButtonEnabled');
        });

        it('response should be true if paypal is among active payment methods & paypal button is enabled on PDP page', () => {
            paypalHelper.__set__('isPayPalPaymentMethodActive', () => true);
            paypalHelper.__set__('isPaypalButtonEnabled', () => true);

            expect(paypalHelper.isPayPalBtnEnabledOnPdpPage()).to.be.true;
        });

        it('response should be false if paypal is among active payment methods but paypal button isn\'t enabled on PDP page', () => {
            paypalHelper.__set__('isPaypalButtonEnabled', () => false);

            expect(paypalHelper.isPayPalBtnEnabledOnPdpPage()).to.be.false;
        });

        it('response should be false if paypal isn\'t among active payment methods', () => {
            paypalHelper.__set__('isPayPalPaymentMethodActive', () => false);

            expect(paypalHelper.isPayPalBtnEnabledOnPdpPage()).to.be.false;
        });
    });

    describe('isPayPalBtnEnabledOnCartPage', () => {
        const isPayPalBtnEnabledOnCartPage = paypalHelper.__get__('isPayPalBtnEnabledOnCartPage');

        after(() => {
            paypalHelper.__ResetDependency__('isPayPalPaymentMethodActive');
            paypalHelper.__ResetDependency__('isPaypalButtonEnabled');
        });

        it('response should be true if paypal is among active payment methods & paypal button is enabled on CART page', () => {
            paypalHelper.__set__('isPayPalPaymentMethodActive', () => true);
            paypalHelper.__set__('isPaypalButtonEnabled', () => true);

            expect(isPayPalBtnEnabledOnCartPage()).to.be.true;
        });

        it('response should be false if paypal is among active payment methods but paypal button isn\'t enabled on CART page', () => {
            paypalHelper.__set__('isPaypalButtonEnabled', () => false);

            expect(isPayPalBtnEnabledOnCartPage()).to.be.false;
        });

        it('response should be false if paypal isn\'t among active payment methods', () => {
            paypalHelper.__set__('isPayPalPaymentMethodActive', () => false);

            expect(isPayPalBtnEnabledOnCartPage()).to.be.false;
        });
    });

    describe('isPayPalBtnEnabledOnMiniCartPage', () => {
        const isPayPalBtnEnabledOnMiniCartPage = paypalHelper.__get__('isPayPalBtnEnabledOnMiniCartPage');

        after(() => {
            paypalHelper.__ResetDependency__('isPayPalPaymentMethodActive');
            paypalHelper.__ResetDependency__('isPaypalButtonEnabled');
        });

        it('response should be true if paypal is among active payment methods & paypal button is enabled on MINICART page', () => {
            paypalHelper.__set__('isPayPalPaymentMethodActive', () => true);
            paypalHelper.__set__('isPaypalButtonEnabled', () => true);

            expect(isPayPalBtnEnabledOnMiniCartPage()).to.be.true;
        });

        it('response should be false if paypal is among active payment methods but paypal button isn\'t enabled on MINICART page', () => {
            paypalHelper.__set__('isPaypalButtonEnabled', () => false);

            expect(isPayPalBtnEnabledOnMiniCartPage()).to.be.false;
        });

        it('response should be false if paypal isn\'t among active payment methods', () => {
            paypalHelper.__set__('isPayPalPaymentMethodActive', () => false);

            expect(isPayPalBtnEnabledOnMiniCartPage()).to.be.false;
        });
    });

    describe('isPayPalBtnEnabledOnCurrentPage', () => {
        let pageId;

        after(() => {
            paypalHelper.__ResetDependency__('isPayPalBtnEnabledOnPdpPage');
            paypalHelper.__ResetDependency__('isPayPalBtnEnabledOnCartPage');
            paypalHelper.__ResetDependency__('isPayPalBtnEnabledOnMiniCartPage');
            paypalHelper.__ResetDependency__('isPayPalPaymentMethodActive');
        });

        it('response should be true if page flow is PDP and paypal button is enabled', () => {
            paypalHelper.__set__('isPayPalBtnEnabledOnPdpPage', () => true);
            pageId = 'page_flow_pdp';

            expect(paypalHelper.isPayPalBtnEnabledOnCurrentPage(pageId)).to.be.true;
        });

        it('response should be false if page flow is PDP and paypal button isn\'t enabled', () => {
            paypalHelper.__set__('isPayPalBtnEnabledOnPdpPage', () => false);

            expect(paypalHelper.isPayPalBtnEnabledOnCurrentPage(pageId)).to.be.false;
        });

        it('response should be true if page flow is CART and paypal button is enabled', () => {
            paypalHelper.__set__('isPayPalBtnEnabledOnCartPage', () => true);
            pageId = 'page_flow_cart';

            expect(paypalHelper.isPayPalBtnEnabledOnCurrentPage(pageId)).to.be.true;
        });

        it('response should be false if page flow is CART and paypal button isn\'t enabled', () => {
            paypalHelper.__set__('isPayPalBtnEnabledOnCartPage', () => false);

            expect(paypalHelper.isPayPalBtnEnabledOnCurrentPage(pageId)).to.be.false;
        });

        it('response should be true if page flow is MINICART and paypal button is enabled', () => {
            paypalHelper.__set__('isPayPalBtnEnabledOnMiniCartPage', () => true);
            pageId = 'page_flow_minicart';

            expect(paypalHelper.isPayPalBtnEnabledOnCurrentPage(pageId)).to.be.true;
        });

        it('response should be false if page flow is MINICART and paypal button isn\'t enabled', () => {
            paypalHelper.__set__('isPayPalBtnEnabledOnMiniCartPage', () => false);

            expect(paypalHelper.isPayPalBtnEnabledOnCurrentPage(pageId)).to.be.false;
        });

        it('response should be true if page flow is BILLING and paypal button is enabled', () => {
            paypalHelper.__set__('isPayPalPaymentMethodActive', () => true);
            pageId = 'page_flow_billing';

            expect(paypalHelper.isPayPalBtnEnabledOnCurrentPage(pageId)).to.be.true;
        });

        it('response should be false if page flow is BILLING and paypal button isn\'t enabled', () => {
            paypalHelper.__set__('isPayPalPaymentMethodActive', () => false);

            expect(paypalHelper.isPayPalBtnEnabledOnCurrentPage(pageId)).to.be.false;
        });

        it('response should be false if page flow isn\'t PDP/CART/MINICART/BILLING', () => {
            pageId = 'page_flow_account';

            expect(paypalHelper.isPayPalBtnEnabledOnCurrentPage(pageId)).to.be.false;
        });
    });

    describe('isLpmUsed', () => {
        const paymentMethodId = 'lpm_id';

        after(() => {
            enabledLPMsArray.length = 0;
        });

        it('response should be false if enabledLPMsArray is empty', () => {
            expect(paypalHelper.isLpmUsed(paymentMethodId)).to.be.false;
        });

        it('response should be false if enabledLPMsArray doesn\'t contain paymentMethodId', () => {
            enabledLPMsArray.push('lpm_id_1');

            expect(paypalHelper.isLpmUsed(paymentMethodId)).to.be.false;
        });

        it('response should be false if enabledLPMsArray contains paymentMethodId', () => {
            enabledLPMsArray.push('lpm_id');

            expect(paypalHelper.isLpmUsed(paymentMethodId)).to.be.true;
        });
    });

    describe('getPossiblePayPalPaymentMethodArray', () => {
        Object.defineProperty(enabledLPMsArray, 'concat', {
            value: function(arr) {
                return [].concat(this, arr);
            }
        });

        it('response should be an array with possible PayPal payment methods', () => {
            expect(paypalHelper.getPossiblePayPalPaymentMethodArray()).to.deep.equal(['PAYMENT_METHOD_ID_PAYPAL', 'PAYMENT_METHOD_ID_VENMO', 'PAYMENT_METHOD_ID_DEBIT_CREDIT_CARD']);
        });
    });

    describe('getOrderByOrderNo', () => {
        const orderNo = 'order_no';

        before(() => {
            stub(dw.order.OrderMgr, 'queryOrder');
            stub(dw.object.CustomObjectMgr, 'getCustomObject');
        });

        after(() => {
            dw.order.OrderMgr.queryOrder.restore();
            dw.object.CustomObjectMgr.getCustomObject.restore();
        });

        it('response should be PayPalNewTransactions custom object taken from CustomObjectMgr if there\'s one', () => {
            dw.object.CustomObjectMgr.getCustomObject.returns('PayPalNewTransactions_custom_object');

            expect(paypalHelper.getOrderByOrderNo(orderNo)).to.equal('PayPalNewTransactions_custom_object');
        });

        it('response should be an order taken from OrderMgr if there\'s none PayPalNewTransactions custom object with the given order number', () => {
            dw.object.CustomObjectMgr.getCustomObject.returns(null);
            dw.order.OrderMgr.queryOrder.returns({});

            expect(paypalHelper.getOrderByOrderNo(orderNo)).to.deep.equal({});
        });
    });
});
