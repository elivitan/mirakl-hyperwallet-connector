/* eslint-disable no-underscore-dangle */
const { bm_paypal: { paypalApiPath } } = require('../path.json');

const {
    describe, it, beforeEach, afterEach
} = require('mocha');

const { expect } = require('chai');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');

const bmPaypalRestService = stub();
const log = {};

const paypalApi = require('proxyquire').noCallThru()(paypalApiPath, {
    'dw/web/Resource': { msgf: () => 'errors' },
    '*/cartridge/scripts/paypal/bmPaypalUtils': {
        createErrorLog: (err) => {
            log.err = err.toString();
        }
    },
    '*/cartridge/config/paypalConstants': {
        SERVICE_NAME: 'int_paypal.http.rest',
        PARTNER_ATTRIBUTION_ID: 'SFCC_EC_B2C_23_3_0',
        TOKEN_TYPE_BILLING_AGREEMENT: 'BILLING_AGREEMENT',
        INVALID_CLIENT: 'invalid client',
        INVALID_RESOURCE_ID: 'invalid resource id',
        ERRORS_WHITE_LIST: [
            'INVALID_RESOURCE_ID',
            'INVALID CLIENT'
        ]
    },
    '*/cartridge/scripts/service/bmPaypalRestService': bmPaypalRestService
});

describe('paypalApi file', () => {
    const requestData = {
        body: {},
        method: 'GET',
        path: 'v2/checkout/orders/',
        partnerAttributionId: 'SFCC_EC_B2C_23_3_0',
        referenceid: 'id'
    };

    beforeEach(() => {
        bmPaypalRestService.returns({
            call: function(data) {
                this.getResponse = () => data;

                return { isOk: () => true };
            }
        });
    });

    afterEach(() => {
        bmPaypalRestService.reset();
    });

    describe('getOrderDetails', () => {
        it('result should be an error if bmPaypalRestService throws an error', () => {
            bmPaypalRestService.throws(Error);
            expect(() => paypalApi.getOrderDetails('73R2506398473783H')).to.throw();
        });

        it('result should be a path string to follow getOrderDetails path pattern', () => {
            expect(paypalApi.getOrderDetails('73R2506398473783H')).to.have.property('path').that.equals('v2/checkout/orders/73R2506398473783H');
        });
    });

    describe('createOrder', () => {
        const purchaseUnit = {};
        const paymentAction = 'capture';

        it('result should be a body obj to have values for intent and purchase_units', () => {
            expect(paypalApi.createOrder(purchaseUnit, paymentAction)).to.have.property('body').that.deep.equals({
                intent: 'CAPTURE',
                purchase_units: [{}]
            });
        });

        it('result should be an error if bmPaypalRestService doesn\'t return a call method', () => {
            bmPaypalRestService.returns({});

            expect(() => paypalApi.createOrder(purchaseUnit, paymentAction)).to.throw();
        });

        it('result should be an error if bmPaypalRestService.call returns isOk() as false but no errorMessage', () => {
            bmPaypalRestService.returns({
                call: () => {
                    return { isOk: () => false };
                }
            });

            expect(() => paypalApi.createOrder(purchaseUnit, paymentAction)).to.throw();
            expect(log.err).to.equal('errors');
        });

        it('result should be an error if bmPaypalRestService.call returns isOk() as false with errorMessage.error & errorMessage.error_description', () => {
            bmPaypalRestService.returns({
                call: () => {
                    return {
                        isOk: () => false,
                        errorMessage: JSON.stringify({
                            error: 'error',
                            error_description: 'error description'
                        })
                    };
                }
            });

            expect(() => paypalApi.createOrder(purchaseUnit, paymentAction)).to.throw();
            expect(log.err).to.equal('error description');
        });

        it('result should be an error if bmPaypalRestService.call returns isOk() as false with errorMessage.details', () => {
            bmPaypalRestService.returns({
                call: () => {
                    return {
                        isOk: () => false,
                        errorMessage: JSON.stringify({
                            details: [{
                                issue: 'INVALID CLIENT',
                                description: 'description'
                            }]
                        })
                    };
                }
            });

            expect(() => paypalApi.createOrder(purchaseUnit, paymentAction)).to.throw();
            expect(log.err).to.equal('errors');
        });

        it('result should be an error if bmPaypalRestService.call returns isOk() as false with errorMessage.name & errorMessage.message', () => {
            bmPaypalRestService.returns({
                call: () => {
                    return {
                        isOk: () => false,
                        errorMessage: JSON.stringify({
                            name: 'INVALID_RESOURCE_ID',
                            message: 'message'
                        })
                    };
                }
            });

            expect(() => paypalApi.createOrder(purchaseUnit, paymentAction)).to.throw();
            expect(log.err).to.equal('errors');
        });
    });

    describe('createTransaction', () => {
        const id = 'id';
        const paymentAction = 'capture';

        it('result should be a body obj to have values for payment_source', () => {
            expect(paypalApi.createTransaction(requestData, id, paymentAction)).to.have.property('body').that.deep.equals({
                payment_source: {
                    token: {
                        id: 'id',
                        type: 'BILLING_AGREEMENT'
                    }
                }
            });
        });

        it('result should be a path string to follow createTransaction path pattern', () => {
            expect(paypalApi.createTransaction(requestData, id, paymentAction)).to.have.property('path').that.equals('v2/checkout/orders/id/capture');
        });
    });

    describe('voidAuthorizedPayment', () => {
        it('result should be a path string to follow voidAuthorizedPayment path pattern', () => {
            expect(paypalApi.voidAuthorizedPayment('authorizationId')).to.have.property('path').that.equals('v2/payments/authorizations/authorizationId/void');
        });
    });

    describe('reauthorizeTransaction', () => {
        it('result should be a path string to follow reauthorizeTransaction path pattern', () => {
            expect(paypalApi.reauthorizeTransaction('authorizationId')).to.have.property('path').that.equals('v2/payments/authorizations/authorizationId/reauthorize');
        });
    });

    describe('refundTransaction', () => {
        const transactionid = 'transactionid';

        it('result should be a body obj to equal {}', () => {
            expect(paypalApi.refundTransaction(transactionid, requestData.body)).to.have.property('body').that.deep.equals({});
        });

        it('result should be a path string to follow refundTransaction path pattern', () => {
            expect(paypalApi.refundTransaction(transactionid, requestData.body)).to.have.property('path').that.equals('v2/payments/captures/transactionid/refund');
        });
    });

    describe('captureTransaction', () => {
        const authorizationId = 'authorizationId';

        it('result should be a body obj to equal {}', () => {
            expect(paypalApi.captureTransaction(authorizationId, requestData.body)).to.have.property('body').that.deep.equals({});
        });

        it('result should be a path string to follow captureTransaction path pattern', () => {
            expect(paypalApi.captureTransaction(authorizationId, requestData.body)).to.have.property('path').that.equals('v2/payments/authorizations/authorizationId/capture');
        });
    });

    describe('extendedAuthorization', () => {
        const purchaseUnit = {};
        const orderId = '5O190127TN364715T';

        it('result should be a body obj to have values for purchase_units', () => {
            expect(paypalApi.extendedAuthorization(orderId, purchaseUnit)).to.have.property('body').that.deep.equals({
                amount: {}
            });
        });

        it('result should be an error if bmPaypalRestService doesn\'t return a call method', () => {
            bmPaypalRestService.returns({});

            expect(() => paypalApi.extendedAuthorization(orderId, purchaseUnit)).to.throw();
        });

        it('result should be an error if bmPaypalRestService.call returns isOk() as false but no errorMessage', () => {
            bmPaypalRestService.returns({
                call: () => {
                    return { isOk: () => false };
                }
            });

            expect(() => paypalApi.extendedAuthorization(orderId, purchaseUnit)).to.throw();
            expect(log.err).to.equal('errors');
        });
    });
});
