/* eslint-disable no-underscore-dangle */
const { bm_paypal: { ppRestApiWrapperPath } } = require('../path.json');

const { expect } = require('chai');
const {
    it, describe, before, after, afterEach
} = require('mocha');

const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const createErrorLog = stub();
const reauthorizeTransaction = stub();
const refundTransaction = stub();
const captureTransaction = stub();
const extendedAuthorization = stub();
const getOrder = stub();
const cancelOrder = stub();
const getPaypalPaymentInstrument = stub();

getPaypalPaymentInstrument.returns({
    custom: {}
});

const ppRestApiWrapper = proxyquire(ppRestApiWrapperPath, {
    'dw/web/Resource': dw.web.Resource,
    'dw/order/OrderMgr': {
        getOrder,
        cancelOrder
    },
    '*/cartridge/scripts/paypal/paypalApi/bmPaypalApi': {
        createOrder: () => ({}),
        createTransaction: () => {
            return {
                status: 'authorized',
                purchase_units: {},
                payer: 'payer',
                id: 'id'
            };
        },
        voidAuthorizedPayment: () => {},
        getOrderDetails: () => ({}),
        reauthorizeTransaction,
        refundTransaction,
        captureTransaction,
        extendedAuthorization
    },
    '*/cartridge/config/paypalConstants': {
        ACTION_STATUS_SUCCESS: 'SUCCESS',
        STATUS_COMPLETED: 'COMPLETED',
        STATUS_CREATED: 'CREATED',
        STATUS_SAVED: 'SAVED'
    },
    '*/cartridge/scripts/paypal/bmPaypalHelper': {
        getPaymentActionType: () => 'authorize'
    },
    '*/cartridge/scripts/paypal/bmPaymentInstrumentHelper': {
        getPaypalPaymentInstrument
    },
    '*/cartridge/scripts/paypal/bmPaypalUtils': { createErrorLog }
});

describe('ppRestApiWrapper file', () => {
    describe('getPurchaseUnit', () => {
        const getPurchaseUnit = ppRestApiWrapper.__get__('getPurchaseUnit');
        const mandatoryKeys = ['description', 'amount', 'invoice_id'];

        let data = {
            desc: 'description',
            currencycode: 'USD',
            amt: 100,
            itemamt: 100,
            invmun: 0
        };

        afterEach(() => {
            data = {
                desc: 'description',
                currencycode: 'USD',
                amt: 100,
                itemamt: 100,
                invmun: 0
            };
        });

        it('If data.shiptoName && data.shiptoStreet were not provided', () => {
            const result = getPurchaseUnit(data);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys(mandatoryKeys);
            expect(result.amount.breakdown.shipping.value).to.equal('0');
            expect(result.amount.breakdown.tax_total.value).to.equal('0');
        });

        it('If data.shiptoName && data.shiptoStreet were provided', () => {
            data.shiptoName = 'name';
            data.shiptoStreet = 'street';

            const result = getPurchaseUnit(data);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys(...mandatoryKeys, 'shipping');
            expect(result.amount.breakdown.shipping.value).to.equal('0');
            expect(result.amount.breakdown.tax_total.value).to.equal('0');
            expect(result.shipping.name.full_name).to.equal('name');
        });
    });

    describe('ppRestSdk', () => {
        it('ppRestSdk should be a function', () => {
            expect(ppRestApiWrapper()).to.equal(undefined);
            expect(ppRestApiWrapper).to.be.a('function');
        });
    });

    describe('createOrder', () => {
        const reqData = {};
        const paymentAction = 'authorize';

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.returns('Api error');

            ppRestApiWrapper.__set__('getPurchaseUnit', () => ({}));
        });

        after(() => {
            dw.web.Resource.msg.restore();
            createErrorLog.reset();
            ppRestApiWrapper.__ResetDependency__('getPurchaseUnit');
        });

        it('If reqData was not provided', () => {
            const result = ppRestApiWrapper.prototype.createOrder(null, paymentAction);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Api error')).to.be.true;
        });

        it('If order successfully returned', () => {
            const result = ppRestApiWrapper.prototype.createOrder(reqData, paymentAction);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({});
        });
    });

    describe('createTransaction', () => {
        let reqData = {};

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.returns('Error');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        afterEach(() => {
            reqData = {};

            createErrorLog.reset();
        });

        it('If reqData.referenceid was not provided', () => {
            const result = ppRestApiWrapper.prototype.createTransaction(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error')).to.be.true;
        });

        it('If order was successfully created', () => {
            reqData.referenceid = 'id';

            const result = ppRestApiWrapper.prototype.createTransaction(reqData);

            expect(result).to.be.an('object');
            expect(result.responseData).to.have.all.keys('ack', 'paymentstatus', 'purchaseUnits', 'payer', 'transactionid');
            expect(result.responseData.purchaseUnits).to.deep.equal({});
        });
    });

    describe('doVoid', () => {
        let reqData = {};

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.returns('Error during voiding');
            getOrder.returns({
                status: 'CANCELLED'
            });
        });

        after(() => {
            dw.web.Resource.msg.restore();
            createErrorLog.reset();
            getOrder.reset();
        });

        afterEach(() => {
            reqData = {
                savedOrder: true
            };
        });

        it('If reqData.authorizationId was not provided', () => {
            const result = ppRestApiWrapper.prototype.doVoid(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error during voiding')).to.be.true;
        });

        it('If voiding was successfully performed', () => {
            reqData.authorizationId = 'id';

            const result = ppRestApiWrapper.prototype.doVoid(reqData);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                responseData: {
                    ack: 'SUCCESS'
                },
                status: 'COMPLETED'
            });
        });
    });

    describe('doReauthorize', () => {
        let reqData = {};

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('api.error.noid.during.reauthorization', 'paypalbm', null).returns('Error during reauthorization');
            dw.web.Resource.msg.withArgs('api.error.not.successful.reauthorize', 'paypalbm', null).returns('Error, not successful reauthorize');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        afterEach(() => {
            createErrorLog.reset();
            reauthorizeTransaction.reset();

            reqData = {};
        });

        it('If reqData.authorizationId was not provided', () => {
            const result = ppRestApiWrapper.prototype.doReauthorize(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error during reauthorization')).to.be.true;
        });

        it('If resp.status !== ppConstants.STATUS_CREATED and error was thrown', () => {
            reqData.authorizationId = 'id';
            reauthorizeTransaction.returns({
                status: 'ERROR'
            });

            const result = ppRestApiWrapper.prototype.doReauthorize(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error, not successful reauthorize')).to.be.true;
        });

        it('If reauthorization successfully performed', () => {
            reqData.authorizationId = 'id';
            reauthorizeTransaction.returns({
                status: 'CREATED'
            });

            const result = ppRestApiWrapper.prototype.doReauthorize(reqData);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                status: 'CREATED',
                responseData: {
                    ack: 'SUCCESS'
                }
            });
        });
    });

    describe('doRefundTransaction', () => {
        let reqData = {};

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('api.error.no.captureid', 'paypalbm', null).returns('Error no capture id');
            dw.web.Resource.msg.withArgs('api.error.not.successful.refund', 'paypalbm', null).returns('Error, not successful refund');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        afterEach(() => {
            createErrorLog.reset();
            refundTransaction.reset();

            reqData = {};
        });

        it('If reqData.transactionid was not provided', () => {
            const result = ppRestApiWrapper.prototype.doRefundTransaction(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error no capture id')).to.be.true;
        });

        it('If resp.status !== ppConstants.STATUS_COMPLETED and error was thrown', () => {
            reqData.transactionid = 'id';
            reqData.invNum = '00001';
            reqData.note = 'note';
            reqData.amt = 100;
            reqData.currencyCode = 'USD';

            refundTransaction.returns({
                status: 'ERROR'
            });

            const result = ppRestApiWrapper.prototype.doRefundTransaction(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error, not successful refund')).to.be.true;
        });

        it('If refund successfully performed', () => {
            reqData.transactionid = 'id';

            refundTransaction.returns({
                status: 'COMPLETED'
            });

            const result = ppRestApiWrapper.prototype.doRefundTransaction(reqData);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                status: 'COMPLETED',
                responseData: {
                    ack: 'SUCCESS'
                }
            });
        });
    });

    describe('doCapture', () => {
        let reqData = {};

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.returns('Error during capturing');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        afterEach(() => {
            createErrorLog.reset();
            captureTransaction.reset();

            reqData = {};
        });

        it('If reqData.authorizationId was not provided', () => {
            const result = ppRestApiWrapper.prototype.doCapture(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error during capturing')).to.be.true;
        });

        it('If invoice id and note to payer were not provided', () => {
            reqData.authorizationId = 'id';

            captureTransaction.returns({});

            const result = ppRestApiWrapper.prototype.doCapture(reqData);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                responseData: {
                    ack: 'SUCCESS'
                }
            });
        });

        it('If invoice id and note to payer were provided', () => {
            reqData.authorizationId = 'id';
            reqData.invNum = '00001';
            reqData.note = 'note';

            captureTransaction.returns({
                note: 'note',
                invNum: '00001'
            });

            const result = ppRestApiWrapper.prototype.doCapture(reqData);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                note: 'note',
                invNum: '00001',
                responseData: {
                    ack: 'SUCCESS'
                }
            });
        });
    });

    describe('getOrderDetails', () => {
        let id;

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.returns('Error, no token or id');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('If no id provided', () => {
            const result = ppRestApiWrapper.prototype.getOrderDetails(id);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error, no token or id')).to.be.true;
        });

        it('If order details successfully returned', () => {
            id = 'id';

            const result = ppRestApiWrapper.prototype.getOrderDetails(id);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({});
        });
    });

    describe('doAuthorize', () => {
        const setExternalOrderNo = stub();
        const fixedAmount = '78.74';

        const reqData0 = {};

        const reqData1 = {
            ppOrderId: '5O190127TN364715T',
            currencyCode: 'USD',
            orderNo: '0000001'
        };

        const result1 = {
            id: '5O190127TN364715T',
            links: [{
                href: 'href',
                method: 'GET',
                rel: 'self'
            }],
            purchase_units: [{
                id: 'O-9RR85649FD345344Y'
            }],
            status: 'SAVED'
        };

        const result2 = {
            id: '5O190127TN364715T',
            links: [{
                href: 'href',
                method: 'GET',
                rel: 'self'
            }],
            purchase_units: [{
                id: 'O-9RR85649FD345344Y'
            }],
            status: 'NOT_SAVED'
        };

        before(() => {
            stub(dw.web.Resource, 'msg');

            getOrder.returns({
                setExternalOrderNo
            });

            dw.web.Resource.msg.withArgs('api.error.noid.during.authorizeorder', 'paypalbm', null).returns('No PayPal order id was found');
            dw.web.Resource.msg.withArgs('api.error.not.successful.extendedauthorize', 'paypalbm', null).returns('Attempt to Save Order was not successful');
        });

        after(() => {
            dw.web.Resource.msg.restore();
            getOrder.reset();
        });

        afterEach(() => {
            createErrorLog.reset();
            extendedAuthorization.reset();
        });

        it('If order Id was not provided', () => {
            const result = ppRestApiWrapper.prototype.doAuthorize(reqData0, fixedAmount);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('No PayPal order id was found');
            expect(createErrorLog.calledWith('No PayPal order id was found')).to.be.true;
        });

        it('If status is not SAVED', () => {
            extendedAuthorization.returns(result2);

            const result = ppRestApiWrapper.prototype.doAuthorize(reqData1);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('Attempt to Save Order was not successful');
            expect(createErrorLog.calledWith('Attempt to Save Order was not successful')).to.be.true;
        });

        it('If order id was provided', () => {
            extendedAuthorization.returns(result1);

            const result = ppRestApiWrapper.prototype.doAuthorize(reqData1);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal(result1);
        });
    });
});
