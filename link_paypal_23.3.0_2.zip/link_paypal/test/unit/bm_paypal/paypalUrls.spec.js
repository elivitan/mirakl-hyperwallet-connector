const { bm_paypal: { paypalUrlsPath } } = require('../path.json');

const { stub } = require('sinon');
const { expect } = require('chai');
// eslint-disable-next-line object-curly-newline
const { it, describe, after } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

stub(dw.web.URLUtils, 'url').returns({
    appendCSRFTokenBM: () => ({
        toString: () => '/action'
    })
});

const paypalUrls = proxyquire(paypalUrlsPath, {
    'dw/web/URLUtils': dw.web.URLUtils
});

describe('paypalUrls', () => {
    after(() => {
        dw.web.URLUtils.url.restore();
    });

    it('should return an object', () => {
        expect(paypalUrls)
            .to.be.a('object')
            .that.has.all.keys([
                'testServiceConnection'
            ]);
    });
});
