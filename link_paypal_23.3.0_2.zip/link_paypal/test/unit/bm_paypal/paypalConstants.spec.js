const { bm_paypal: { paypalConstantsPath } } = require('../path.json');

const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const paypalConstants = proxyquire(paypalConstantsPath, {
});

describe('paypalConstants from bm_paypal cartridge', () => {
    it('response type should be object', () => {
        expect(paypalConstants).to.be.a('object');
    });

    it('response object should consist property SEARCH_BY_TRANSACTION_ID', () => {
        expect(paypalConstants).has.property('SEARCH_BY_TRANSACTION_ID');
    });

    it('response object should consist property SEARCH_BY_ORDER_NUMBER', () => {
        expect(paypalConstants).has.property('SEARCH_BY_ORDER_NUMBER');
    });

    it('response object should consist property INTENT_CAPTURE', () => {
        expect(paypalConstants).has.property('INTENT_CAPTURE');
    });

    it('response object should consist property STATUS_COMPLETED', () => {
        expect(paypalConstants).has.property('STATUS_COMPLETED');
    });

    it('response object should consist property STATUS_CAPTURED', () => {
        expect(paypalConstants).has.property('STATUS_CAPTURED');
    });

    it('response object should consist property STATUS_REFUNDED', () => {
        expect(paypalConstants).has.property('STATUS_REFUNDED');
    });

    it('response object should consist property STATUS_CREATED', () => {
        expect(paypalConstants).has.property('STATUS_CREATED');
    });

    it('response object should consist property PAYMENT_ACTION_AUTHORIZATION', () => {
        expect(paypalConstants).has.property('PAYMENT_ACTION_AUTHORIZATION');
    });

    it('response object should consist property PAYMENT_ACTION_AUTHORIZE', () => {
        expect(paypalConstants).has.property('PAYMENT_ACTION_AUTHORIZE');
    });

    it('response object should consist property PAYMENT_ACTION_CAPTURE', () => {
        expect(paypalConstants).has.property('PAYMENT_ACTION_CAPTURE');
    });

    it('response object should consist property ACTION_CREATE_TRANSACTION', () => {
        expect(paypalConstants).has.property('ACTION_CREATE_TRANSACTION');
    });

    it('response object should consist property ACTION_VOID', () => {
        expect(paypalConstants).has.property('ACTION_VOID');
    });

    it('response object should consist property ACTION_REAUTHORIZE', () => {
        expect(paypalConstants).has.property('ACTION_REAUTHORIZE');
    });

    it('response object should consist property ACTION_REFUND', () => {
        expect(paypalConstants).has.property('ACTION_REFUND');
    });

    it('response object should consist property ACTION_CAPTURE', () => {
        expect(paypalConstants).has.property('ACTION_CAPTURE');
    });

    it('response object should consist property SERVICE_NAME', () => {
        expect(paypalConstants).has.property('SERVICE_NAME');
    });

    it('response object should consist property UNKNOWN', () => {
        expect(paypalConstants).has.property('UNKNOWN');
    });

    it('response object should consist property PARTNER_ATTRIBUTION_ID', () => {
        expect(paypalConstants).has.property('PARTNER_ATTRIBUTION_ID');
    });

    it('response object should consist property ACTION_STATUS_SUCCESS', () => {
        expect(paypalConstants).has.property('ACTION_STATUS_SUCCESS');
    });

    it('response object should consist property TOKEN_TYPE_BILLING_AGREEMENT', () => {
        expect(paypalConstants).has.property('TOKEN_TYPE_BILLING_AGREEMENT');
    });

    it('response object should consist property INVALID_CLIENT', () => {
        expect(paypalConstants).has.property('INVALID_CLIENT');
    });

    it('response object should consist property TRANSACTION_STATUSES', () => {
        expect(paypalConstants).has.property('TRANSACTION_STATUSES');
    });

    it('response object should consist property TRANSACTION_FAILED_STATUSES', () => {
        expect(paypalConstants).has.property('TRANSACTION_FAILED_STATUSES');
    });

    it('response object should consist property INSTANCE_PRODUCTION', () => {
        expect(paypalConstants).has.property('INSTANCE_PRODUCTION');
    });

    it('response object should consist property INSTANCE_PRODUCTION', () => {
        expect(paypalConstants).has.property('INSTANCE_PRODUCTION');
    });

    it('response object should consist property INSTANCE_SANDBOX', () => {
        expect(paypalConstants).has.property('INSTANCE_SANDBOX');
    });

    it('response object should consist property VALUE_TYPE', () => {
        expect(paypalConstants).has.property('VALUE_TYPE');
    });

    it('response object should consist property ERRORS_WHITE_LIST', () => {
        expect(paypalConstants).has.property('ERRORS_WHITE_LIST');
    });

    it('response object should consist property PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD', () => {
        expect(paypalConstants).has.property('PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD');
    });
});
