const { bm_paypal: { paypalPreferencesPath } } = require('../path.json');

const { stub } = require('sinon');
const { expect } = require('chai');
// eslint-disable-next-line object-curly-newline
const { it, describe, after } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const fakeGetCurrent = stub(dw.system.Site, 'getCurrent');
const fakeGetCustomPreferenceValue = stub().returns(JSON.stringify({}));

fakeGetCurrent.returns({
    getCustomPreferenceValue: fakeGetCustomPreferenceValue
});

const paypalPreferences = proxyquire(paypalPreferencesPath, {
    'dw/system/Site': dw.system.Site,
    '~/cartridge/scripts/helpers/coreHelpers': {
        tryParseJSON: text => JSON.parse(text)
    }
});

describe('paypalPreferences', () => {
    after(() => {
        fakeGetCurrent.restore();
        fakeGetCustomPreferenceValue.reset();
    });

    it('should return an object', () => {
        expect(paypalPreferences)
            .to.be.a('object')
            .that.has.all.keys([
                'ocapiConfig', 'webdavConfig'
            ]);
    });
});
