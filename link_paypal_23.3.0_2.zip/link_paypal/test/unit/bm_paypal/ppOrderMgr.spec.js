/* eslint-disable no-underscore-dangle */
const { bm_paypal: { ppOrderMgrPath } } = require('../path.json');

const { expect } = require('chai');
const {
    it, describe, before, after
} = require('mocha');

const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const getOrderDetails = stub();
const createErrorLog = stub();
const getPaymentStatus = stub();
const getOrderPaymentInstrument = stub();
const isPaypalPaymentInstrument = stub();
const getOrder = stub();

let arrayList = {
    arr: [],
    push: (el) => arrayList.arr.push(el),
    sort: () => {},
    toArray: () => [{
        custom: { orderNo: '0000' },
        orderNo: '0000'
    }]
};

const ppOrderMgr = proxyquire(ppOrderMgrPath, {
    'dw/object/SystemObjectMgr': dw.object.SystemObjectMgr,
    'dw/object/CustomObjectMgr': dw.object.CustomObjectMgr,
    'dw/util/ArrayList': function() {
        return arrayList;
    },
    'dw/util/StringUtils': {
        formatCalendar: () => '09-11-2022'
    },
    'dw/util/PropertyComparator': function() {},
    'dw/value/Money': function() {
        return 5;
    },
    'dw/util/Calendar': function() {},
    'dw/order/Order': {
        PAYMENT_STATUS_PAID: 'PAID'
    },
    'dw/order/OrderMgr': {
        getOrder
    },
    'dw/system/Transaction': dw.system.Transaction,
    'dw/web/Resource': dw.web.Resource,
    'dw/order/PaymentInstrument': dw.order.PaymentInstrument,
    '*/cartridge/scripts/paypal/bmPaymentInstrumentHelper': {
        getOrderPaymentInstrument,
        isPaypalPaymentInstrument
    },
    '*/cartridge/scripts/paypal/bmPaypalHelper': {
        getPaymentStatus
    },
    '*/cartridge/scripts/paypal/bmPaypalUtils': {
        createErrorLog
    },
    '*/cartridge/config/paypalConstants': {
        STATUS_COMPLETED: 'COMPLETED',
        STATUS_REFUNDED: 'REFUNDED'
    },
    '*/cartridge/models/ppOrder': function() {
        return {
            getTransactionIdFromOrder: () => 'transaction-id'
        };
    },
    '*/cartridge/scripts/paypal/paypalApi/ppRestApiWrapper': function() {
        return { getOrderDetails };
    }
});

describe('ppOrderMgr file', function() {
    describe('getOrders', () => {
        const getOrders = ppOrderMgr.__get__('getOrders');

        const hasNextSystem = stub();
        const hasNextPP = stub();

        hasNextSystem.onFirstCall().returns(true);
        hasNextPP.onFirstCall().returns(true);
        hasNextSystem.onSecondCall().returns(false);
        hasNextPP.onSecondCall().returns(false);

        before(() => {
            stub(dw.object.SystemObjectMgr, 'querySystemObjects');
            dw.object.SystemObjectMgr.querySystemObjects.returns({
                hasNext: hasNextSystem,
                next: () => ({
                    creationDate: '2022-11-09',
                    orderToken: 'token',
                    orderNo: '0000',
                    createdBy: 'test',
                    customer: { registered: true },
                    customerName: 'name',
                    customerEmail: 'email',
                    totalGrossPrice: 100,
                    status: { displayValue: 'CANCELLED' },
                    custom: {},
                    externalOrderNo: 'O-9RR85649FD345344Y',
                    getCurrencyCode: () => 'USD',
                    getPaymentInstruments: () => {}
                })
            });
            stub(dw.object.CustomObjectMgr, 'queryCustomObjects');
            dw.object.CustomObjectMgr.queryCustomObjects.returns({
                hasNext: hasNextPP,
                next: () => ({
                    custom: {
                        orderDate: '2022-11-09',
                        orderTotal: 500,
                        orderNo: '0000',
                        firstName: 'firstname',
                        lastName: 'lastname',
                        email: 'email',
                        paymentStatus: 'AUTHORIZED',
                        currencyCode: 'USD'
                    }
                }),
                getCount: () => 7000
            });

            getOrderPaymentInstrument.returns({
                custom: { paypalPaymentStatus: 'VOIDED' },
                getPaymentTransaction: () => ({ getAmount: () => 100 })
            });
        });

        after(() => {
            dw.object.SystemObjectMgr.querySystemObjects.restore();
            dw.object.CustomObjectMgr.queryCustomObjects.restore();

            getOrderPaymentInstrument.reset();
        });

        afterEach(() => {
            isPaypalPaymentInstrument.reset();
            hasNextSystem.reset();

            arrayList = {
                arr: [],
                push: (el) => arrayList.arr.push(el),
                sort: () => { },
                toArray: () => [{
                    custom: { orderNo: '0000' },
                    orderNo: '0000'
                }]
            };
        });

        it('if paypalOrdersCount < maxPaypalOrdersCount and orders returned', () => {
            isPaypalPaymentInstrument.returns(true);
            const result = getOrders();

            expect(result.arr).to.be.an('array');
            expect(result.arr).to.have.length(2);
            expect(result.arr[0]).to.have.all.keys('orderToken', 'orderNo', 'orderDate', 'createdBy', 'isRegestered', 'customer', 'email', 'orderTotal', 'currencyCode', 'paypalAmount', 'savedOrder', 'status', 'dateCompare', 'isCustom', 'UUID');
        });

        it('if no orders returned', () => {
            isPaypalPaymentInstrument.onFirstCall().returns(false);
            isPaypalPaymentInstrument.onSecondCall().returns(true);
            hasNextSystem.onSecondCall().returns(true);
            hasNextSystem.onThirdCall().returns(false);

            dw.object.CustomObjectMgr.queryCustomObjects.returns({
                hasNext: hasNextPP,
                next: () => ({
                    custom: {
                        orderDate: '2022-11-09',
                        orderTotal: 500,
                        orderNo: '0000',
                        firstName: 'firstname',
                        lastName: 'lastname',
                        email: 'email',
                        paymentStatus: 'AUTHORIZED',
                        currencyCode: 'USD'
                    },
                    getPaymentInstruments: () => {}
                }),
                getCount: () => 10000
            });

            const result = getOrders('000', 'null');

            expect(result.arr).to.be.an('array');
            expect(result.arr).to.have.length(0);
        });
    });

    describe('updateCustomOrderStatus', () => {
        const updateCustomOrderStatus = ppOrderMgr.__get__('updateCustomOrderStatus');
        const orderNo = '0000';

        before(() => {
            stub(dw.object.CustomObjectMgr, 'getCustomObject');
            dw.object.CustomObjectMgr.getCustomObject.returns({
                custom: {
                    transactionId: 'id'
                }
            });
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('transaction.details.error', 'paypalbm', null).returns('Details error');
        });

        after(() => {
            dw.object.CustomObjectMgr.getCustomObject.restore();
            dw.web.Resource.msg.restore();

            getPaymentStatus.reset();
        });

        afterEach(() => {
            createErrorLog.reset();
            getOrderDetails.reset();
        });

        it('if error was thrown', () => {
            getOrderDetails.returns({
                err: true
            });

            expect(() => updateCustomOrderStatus(orderNo)).to.throw(Error, 'Details error');
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('if custom order status was successfully updated', () => {
            getOrderDetails.returns({
                err: false
            });

            updateCustomOrderStatus(orderNo);
            expect(createErrorLog.calledOnce).to.be.false;
            expect(getPaymentStatus.calledOnce).to.be.true;
        });
    });

    describe('updateOrderStatus', () => {
        const updateOrderStatus = ppOrderMgr.__get__('updateOrderStatus');
        const setPaymentStatus = stub();

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('transaction.details.error', 'paypalbm', null).returns('Details error');

            getOrderPaymentInstrument.returns({
                custom: {},
                getCustom: () => ({
                    paypalOrderID: 'id'
                })
            });
            getOrder.returns({
                setPaymentStatus
            });
        });

        after(() => {
            getOrder.reset();
            getOrderPaymentInstrument.reset();
            getPaymentStatus.reset();

            dw.web.Resource.msg.restore();
        });

        afterEach(() => {
            createErrorLog.reset();
            getOrderDetails.reset();
            setPaymentStatus.reset();
        });

        it('if error was thrown', () => {
            getOrderDetails.returns({
                err: true
            });

            expect(() => updateOrderStatus()).to.throw(Error, 'Details error');
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('if order status was successfully updated and payment status was set', () => {
            getOrderDetails.returns({
                err: false
            });
            getPaymentStatus.returns('REFUNDED');

            updateOrderStatus();

            expect(createErrorLog.calledOnce).to.be.false;
            expect(setPaymentStatus.calledWith('PAID')).to.be.true;
        });

        it('if order status was successfully updated', () => {
            getOrderDetails.returns({
                err: false
            });
            getPaymentStatus.returns('VOIDED');

            updateOrderStatus();

            expect(createErrorLog.calledOnce).to.be.false;
            expect(setPaymentStatus.calledOnce).to.be.false;
        });
    });

    describe('OrderMgrModel', () => {
        it('OrderMgrModel should be a function', () => {
            expect(ppOrderMgr).to.be.a('function');
            expect(ppOrderMgr()).to.equal(undefined);
        });
    });

    describe('getOrderByOrderNo', () => {
        before(() => {
            ppOrderMgr.__set__('getOrders', () => ({}));
        });

        after(() => {
            ppOrderMgr.__ResetDependency__('getOrders');
        });

        it('if orders was successfully returned', () => {
            expect(ppOrderMgr.prototype.getOrderByOrderNo()).to.deep.equal({});
        });
    });

    describe('getOrderByTransactionId', () => {
        before(() => {
            stub(dw.object.SystemObjectMgr, 'querySystemObjects');
            stub(dw.object.CustomObjectMgr, 'queryCustomObjects');

            ppOrderMgr.__set__('getOrders', () => ({}));
        });

        after(() => {
            dw.object.SystemObjectMgr.querySystemObjects.restore();
            dw.object.CustomObjectMgr.queryCustomObjects.restore();

            ppOrderMgr.__ResetDependency__('getOrders');
        });

        it('if orderNo got from paypalOrder', () => {
            dw.object.SystemObjectMgr.querySystemObjects.returns({
                count: 0
            });
            dw.object.CustomObjectMgr.queryCustomObjects.returns({
                count: 1
            });

            expect(ppOrderMgr.prototype.getOrderByTransactionId()).to.deep.equal({});
        });

        it('if orderNo got from systemOrder', () => {
            dw.object.SystemObjectMgr.querySystemObjects.returns({
                count: 1
            });
            dw.object.CustomObjectMgr.queryCustomObjects.returns({
                count: 0
            });

            expect(ppOrderMgr.prototype.getOrderByTransactionId()).to.deep.equal({});
        });
    });

    describe('getAllOrders', () => {
        before(() => {
            ppOrderMgr.__set__('getOrders', () => ({}));
        });

        after(() => {
            ppOrderMgr.__ResetDependency__('getOrders');
        });

        it('if all orders successfully returned', () => {
            expect(ppOrderMgr.prototype.getAllOrders()).to.deep.equal({});
        });
    });

    describe('getOrderByPaymentStatus', () => {
        before(() => {
            ppOrderMgr.__set__('getOrders', () => ({}));
        });

        after(() => {
            ppOrderMgr.__ResetDependency__('getOrders');
        });

        it('if all orders successfully returned', () => {
            expect(ppOrderMgr.prototype.getOrderByPaymentStatus()).to.deep.equal({});
        });
    });

    describe('getCustomOrderInfo', () => {
        before(() => {
            stub(dw.object.CustomObjectMgr, 'getCustomObject');
        });

        after(() => {
            dw.object.CustomObjectMgr.getCustomObject.restore();
        });

        afterEach(() => {
            createErrorLog.reset();
        });

        it('if error appeared and error log created', () => {
            dw.object.CustomObjectMgr.getCustomObject.throws(Error);

            ppOrderMgr.prototype.getCustomOrderInfo();

            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('if custom order info successfully returned', () => {
            dw.object.CustomObjectMgr.getCustomObject.returns({
                custom: { transactionId: 'id' }
            });

            const result = ppOrderMgr.prototype.getCustomOrderInfo();

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('transactionIdFromOrder', 'order');
            expect(result.order).to.deep.equal({
                custom: { transactionId: 'id' }
            });
        });
    });

    describe('getOrderData', () => {
        const orderNo = '000001';
        const orderToken = 'token';
        let isCustomOrder = true;

        const originalGetCustomOrderInfo = ppOrderMgr.prototype.getCustomOrderInfo;

        before(() => {
            ppOrderMgr.prototype.getCustomOrderInfo = () => ({
                order: {}
            });
            getOrder.returns({});
        });

        after(() => {
            ppOrderMgr.prototype.getCustomOrderInfo = originalGetCustomOrderInfo;
            getOrder.reset();
        });

        afterEach(() => {
            createErrorLog.reset();
        });

        it('if no transaction id from order returned and error was thrown', () => {
            expect(() => ppOrderMgr.prototype.getOrderData(isCustomOrder, orderNo, orderToken)).to.throw(Error);
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('if order data returned successfully', () => {
            isCustomOrder = false;

            const result = ppOrderMgr.prototype.getOrderData(isCustomOrder, orderNo, orderToken);

            expect(result).to.be.an('object');
            expect(result.transactionIdFromOrder).to.equal('transaction-id');
            expect(result.order).to.deep.equal({});
        });
    });

    describe('updateOrderData', () => {
        const orderNo = '000001';
        const orderToken = 'token';
        let isCustomOrder = true;

        before(() => {
            ppOrderMgr.__set__('updateCustomOrderStatus', () => {
                throw new Error();
            });
            ppOrderMgr.__set__('updateOrderStatus', () => { });
        });

        after(() => {
            ppOrderMgr.__ResetDependency__('updateCustomOrderStatus');
            ppOrderMgr.__ResetDependency__('updateOrderStatus');
        });

        afterEach(() => {
            createErrorLog.reset();
        });

        it('if error appeared while updating custom order status', () => {
            expect(ppOrderMgr.prototype.updateOrderData(orderNo, isCustomOrder, orderToken)).to.be.false;
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('if irder data successfully updated', () => {
            isCustomOrder = false;

            expect(ppOrderMgr.prototype.updateOrderData(orderNo, isCustomOrder, orderToken)).to.be.true;
            expect(createErrorLog.calledOnce).to.be.false;
        });
    });

    describe('createNewTransactionCustomObject', () => {
        before(() => {
            stub(dw.object.CustomObjectMgr, 'createCustomObject');
            dw.object.CustomObjectMgr.createCustomObject.returns({ custom: {} });
            getPaymentStatus.returns('AUTHORIZED');
        });

        after(() => {
            dw.object.CustomObjectMgr.createCustomObject.restore();
            getPaymentStatus.reset();
        });

        afterEach(() => {
            createErrorLog.reset();
        });

        it('if transaction was returned with error and error log created', () => {
            getOrderDetails.returns({
                err: true,
                responseData: {}
            });

            expect(() => ppOrderMgr.prototype.createNewTransactionCustomObject()).to.throw(Error);
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('if new transaction custom object successfully created', () => {
            getOrderDetails.returns({
                err: false,
                purchase_units: [{
                    invoice_id: 'id',
                    amount: {
                        value: 1,
                        currency_code: 'USD'
                    },
                    shipping: {}
                }],
                create_time: '00:00',
                id: 'id',
                payer: {
                    name: {
                        given_name: 'given_name',
                        surname: 'surname'
                    }
                }
            });

            ppOrderMgr.prototype.createNewTransactionCustomObject();

            expect(dw.object.CustomObjectMgr.createCustomObject.calledOnce).to.be.true;
            expect(getPaymentStatus.calledOnce).to.be.true;
        });
    });

    describe('getMaxSystemOrdersCount', () => {
        const maxPaypalOrdersCount = 9000;
        const maxCount = 18000;

        let paypalOrdersCount = 1;

        const getMaxSystemOrdersCount = ppOrderMgr.__get__('getMaxSystemOrdersCount');

        it('should return maxCount - paypalOrdersCount if paypalOrdersCount < maxPaypalOrdersCount', () => {
            expect(getMaxSystemOrdersCount(paypalOrdersCount)).that.deep.equal(maxCount - paypalOrdersCount);
        });

        it('should return maxPaypalOrdersCount if paypalOrdersCount < maxPaypalOrdersCount', () => {
            paypalOrdersCount = 9001;
            expect(getMaxSystemOrdersCount(paypalOrdersCount)).that.deep.equal(maxPaypalOrdersCount);
        });
    });

    describe('getPayPalOrdersByQuery', () => {
        const getPayPalOrdersByQuery = ppOrderMgr.__get__('getPayPalOrdersByQuery');

        before(() => {
            stub(dw.object.SystemObjectMgr, 'querySystemObjects');
            stub(dw.object.CustomObjectMgr, 'queryCustomObjects');
            dw.object.SystemObjectMgr.querySystemObjects.returns({});
            dw.object.CustomObjectMgr.queryCustomObjects.returns({});
        });

        after(() => {
            dw.object.SystemObjectMgr.querySystemObjects.reset();
            dw.object.CustomObjectMgr.queryCustomObjects.reset();
        });

        it('should return an object with paypalOrders and systemOrders keys', () => {
            expect(getPayPalOrdersByQuery()).that.deep.equal({
                paypalOrders: {},
                systemOrders: {}
            });
        });
    });

    describe('getPayPalOrdersFinalObject', () => {
        const getPayPalOrdersFinalObject = ppOrderMgr.__get__('getPayPalOrdersFinalObject');
        const order = {
            orderDate: 'Z',
            orderTotal: '100',
            currencyCode: 'USD',
            orderNo: '001',
            firstName: 'Test',
            lastName: 'Test',
            email: 'emeil',
            paymentStatus: 'status'
        };

        it('should return an object with Paypal orders', () => {
            expect(getPayPalOrdersFinalObject(order)).that.deep.equal({
                orderNo: '001',
                orderDate: '09-11-2022',
                createdBy: 'Merchant',
                isRegestered: 'Unknown',
                customer: [order.firstName, order.lastName].join(' '),
                email: order.email,
                orderTotal: {},
                currencyCode: order.currencyCode,
                paypalAmount: {},
                status: order.paymentStatus,
                isCustom: true,
                dateCompare: 946684800000
            });
        });
    });

    describe('getSystemOrderFinalObject', () => {
        const getSystemOrderFinalObject = ppOrderMgr.__get__('getSystemOrderFinalObject');
        const order = {
            customer: {
                registered: true
            },
            customerName: 'name',
            customerEmail: 'email',
            totalGrossPrice: {},
            getCurrencyCode: () => '',
            custom: {
                isSavedOrder: true
            },
            createdBy: '',
            orderToken: 'token',
            orderDate: 'Z',
            orderNo: '001',
            UUID: 'UUID'
        };

        const paymentInstrument = {
            getPaymentTransaction: () => {
                return {
                    getAmount: () => {
                        return {};
                    }
                };
            },
            custom: {
                paypalPaymentStatus: 'status'
            }
        };

        it('should return an object with Paypal system orders', () => {
            expect(getSystemOrderFinalObject(order, paymentInstrument)).that.deep.equal({
                orderToken: order.orderToken,
                orderNo: order.orderNo,
                orderDate: '09-11-2022',
                createdBy: order.createdBy,
                isRegestered: order.customer.registered,
                customer: order.customerName,
                email: order.customerEmail,
                orderTotal: order.totalGrossPrice,
                currencyCode: order.getCurrencyCode(),
                paypalAmount: paymentInstrument.getPaymentTransaction().getAmount(),
                status: paymentInstrument.custom.paypalPaymentStatus,
                dateCompare: NaN,
                isCustom: false,
                savedOrder: order.custom.isSavedOrder,
                UUID: order.UUID
            });
        });
    });
});
