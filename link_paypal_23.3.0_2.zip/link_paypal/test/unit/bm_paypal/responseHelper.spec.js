const { bm_paypal: { responseHelperPath } } = require('../path.json');

const { expect } = require('chai');
const { stub } = require('sinon');
const {
    describe, it, before, after
} = require('mocha');

require('dw-api-mock/demandware-globals');

const responseHelper = require('proxyquire').noCallThru()(responseHelperPath, {
    'dw/template/ISML': dw.template.ISML
});

describe('responseHelper file', () => {
    const templateName = 'template';
    let data;

    before(() => {
        stub(dw.template.ISML, 'renderTemplate');
    });

    after(() => {
        dw.template.ISML.renderTemplate.restore();
    });

    describe('render', () => {
        it('response type should be undefined', () => {
            expect(responseHelper.render(templateName, data)).to.be.a('undefined');
        });

        it('response type should be an error', () => {
            data = {};
            dw.template.ISML.renderTemplate.throws(Error);

            expect(() => responseHelper.render(templateName, data)).to.throw();
        });
    });

    describe('renderJson', () => {
        let responseData = {};
        let responseResult = {};

        it('If responseResult && responseData aren\'t empty, response type should be undefined', () => {
            expect(responseHelper.renderJson(responseResult, responseData)).to.be.a('undefined');
        });

        it('If responseData && responseData are empty, response type should be undefined', () => {
            responseResult = null;
            responseData = null;

            expect(responseHelper.renderJson(responseResult, responseData)).to.be.a('undefined');
        });

        it('If responseData && responseData.details aren\'t empty', () => {
            responseData = {
                details: {}
            };

            expect(responseHelper.renderJson(responseResult, responseData)).to.be.a('undefined');
        });
    });
});
