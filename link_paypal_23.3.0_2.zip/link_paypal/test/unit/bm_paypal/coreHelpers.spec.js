/* eslint-disable object-curly-newline */

const { bm_paypal: { coreHelpersPath } } = require('../path.json');

const { expect } = require('chai');
const { stub } = require('sinon');
const { it, describe, before, after } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const coreHelpers = proxyquire(coreHelpersPath, {
    'dw/web/Resource': dw.web.Resource,
    'dw/system/System': dw.system.System,
    'dw/system/Logger': dw.system.Logger,
    '~/cartridge/config/paypalConstants': {
        INSTANCE_STAGING: 'staging',
        INSTANCE_DEVELOPMENT: 'development',
        INSTANCE_PRODUCTION: 'production'
    }
});

describe('coreHelpers file', () => {
    describe('pluralize', () => {
        const word = 'word';
        let value = 1;

        it('result should be equal to "word" if value is set to 1', () => {
            expect(coreHelpers.pluralize(value, word)).to.equal('word');
        });

        it('result should be equal to "words" if value is set to 2', () => {
            value = 2;
            expect(coreHelpers.pluralize(value, word)).to.equal('words');
        });

        it('result should be equal to "words" if value is set to 2 & plural isn\'t null', () => {
            const plural = 'words';

            expect(coreHelpers.pluralize(value, word, plural)).to.equal('words');
        });
    });

    describe('sortByProperty', () => {
        const arr = [
            { status: 'new' },
            { status: 'open' },
            { status: 'new' }
        ];

        it('result should be a sorted array by object property', () => {
            expect(coreHelpers.sortByProperty(arr, 'status')).to.deep.equal([
                { status: 'new' },
                { status: 'new' },
                { status: 'open' }
            ]);
        });
    });

    describe('filterByProperty', () => {
        const arr = [
            { status: 'new' },
            { status: 'open' },
            { status: 'new' }
        ];

        it('result should be a filtered array by object property value', () => {
            expect(coreHelpers.filterByProperty(arr, 'status', 'open')).to.deep.equal([
                { status: 'open' }
            ]);
        });
    });

    describe('isJson', () => {
        it('result returns false if input value not a string', () => {
            expect(coreHelpers.isJson(50)).to.be.false;
            expect(coreHelpers.isJson(3.14)).to.be.false;
            expect(coreHelpers.isJson([])).to.be.false;
            expect(coreHelpers.isJson({})).to.be.false;
            expect(coreHelpers.isJson(null)).to.be.false;
            expect(coreHelpers.isJson(undefined)).to.be.false;
        });

        it('result returns false if input value is not json', () => {
            expect(coreHelpers.isJson('test')).to.be.false;
        });

        it('result returns false if input value is json', () => {
            const jsonObj = JSON.stringify({});
            const jsonArr = JSON.stringify([{}, {}]);

            expect(coreHelpers.isJson(jsonObj)).to.be.true;
            expect(coreHelpers.isJson(jsonArr)).to.be.true;
        });
    });

    describe('tryParseJSON', () => {
        after(() => {
            dw.system.Logger.getLogger.restore();
        });

        it('Result should be a parsed JSON', () => {
            expect(coreHelpers.tryParseJSON(JSON.stringify({}))).to.deep.equal({});
        });

        it('Result should be underfined & an error logged if JSON cannot be parsed', () => {
            const log = {};

            stub(dw.system.Logger, 'getLogger').returns({
                error: () => Object.assign(log, { error: 'error' })
            });

            expect(coreHelpers.tryParseJSON('')).be.undefined;
            expect(log).to.deep.equal({ error: 'error' });
        });
    });

    describe('getInstanceType', () => {
        before(() => {
            Object.assign(dw.system.System, {
                instanceType: 0,
                DEVELOPMENT_SYSTEM: 0,
                PRODUCTION_SYSTEM: 2,
                STAGING_SYSTEM: 1
            });
        });

        after(() => {
            dw.system.System.instanceType = null;
            dw.system.System.STAGING_SYSTEM = null;
            dw.system.System.PRODUCTION_SYSTEM = 0;
            dw.system.System.DEVELOPMENT_SYSTEM = 1;
        });

        it('should return the string `development`', () => {
            dw.system.System.instanceType = 0;
            expect(coreHelpers.getInstanceType()).to.be.equal('development');
        });

        it('should return the string `staging`', () => {
            dw.system.System.instanceType = 1;
            expect(coreHelpers.getInstanceType()).to.be.equal('staging');
        });

        it('should return the string `production`', () => {
            dw.system.System.instanceType = 2;
            expect(coreHelpers.getInstanceType()).to.be.equal('production');
        });

        it('should return an empty string', () => {
            dw.system.System.instanceType = 4;
            expect(coreHelpers.getInstanceType()).to.be.empty;
        });
    });

    describe('checkSetValue', () => {
        before(() => {
            stub(dw.web.Resource, 'msg');

            dw.web.Resource.msg.withArgs('value.set', 'paypalbm', null).returns('set');
            dw.web.Resource.msg.withArgs('value.notset', 'paypalbm', null).returns('not set');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('should return the string `set`', () => {
            expect(coreHelpers.checkSetValue('user-id')).to.be.equal('set');
        });

        it('should return the string `not set`', () => {
            expect(coreHelpers.checkSetValue('')).to.be.equal('not set');
            expect(coreHelpers.checkSetValue(null)).to.be.equal('not set');
            expect(coreHelpers.checkSetValue(undefined)).to.be.equal('not set');
        });
    });

    describe('isObject', () => {
        it('should return true', () => {
            expect(coreHelpers.isObject({})).to.be.true;
            expect(coreHelpers.isObject({ firstName: 'John', lastName: 'Doe' })).to.be.true;
        });

        it('should return false', () => {
            expect(coreHelpers.isObject(5)).to.be.false;
            expect(coreHelpers.isObject([])).to.be.false;
            expect(coreHelpers.isObject(5.5)).to.be.false;
            expect(coreHelpers.isObject(null)).to.be.false;
            expect(coreHelpers.isObject(true)).to.be.false;
            expect(coreHelpers.isObject(false)).to.be.false;
            expect(coreHelpers.isObject('string')).to.be.false;
            expect(coreHelpers.isObject(() => {})).to.be.false;
            expect(coreHelpers.isObject(undefined)).to.be.false;
            expect(coreHelpers.isObject(NaN)).to.be.false;
        });
    });
});
