/* eslint-disable no-underscore-dangle */
const { bm_paypal: { paymentInstrumentHelperPath } } = require('../path.json');

const { stub } = require('sinon');
const { expect } = require('chai');
const { describe, it } = require('mocha');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const bmPaymentInstrumentHelper = proxyquire(paymentInstrumentHelperPath, {
    'dw/order/PaymentMgr': dw.order.PaymentMgr,
    'dw/system/Transaction': dw.system.Transaction,
    '*/cartridge/models/ppOrderMgr': function() {
        return {
            getOrderData: () => ({
                order: {},
                transactionIdFromOrder: 'transid-000001'
            })
        };
    },
    '*/cartridge/models/ppTransactionMgr': function() {
        return {
            getTransactionData: () => ({})
        };
    },
    '*/cartridge/models/ppTransaction': function() {
        return {
            paymentstatus: 'COMPLETED'
        };
    },
    '*/cartridge/config/paypalConstants': {
        PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD: 'PAYPAL_CREDIT_CARD'
    }
});

describe('bmPaymentInstrumentHelper file', function() {
    const activePaymentMethods = [
        {
            active: true,
            ID: 'ApplePay',
            paymentProcessor: {
                ID: 'PAYPAL_ApplePay'
            }
        },
        {
            active: true,
            ID: 'PAYPAL',
            paymentProcessor: {
                ID: 'PAYPAL'
            }
        }
    ];

    before(() => {
        Array.some = function(a, b) {
            return Array.prototype.some.call(a, b);
        };

        stub(dw.order.PaymentMgr, 'getActivePaymentMethods');
    });

    after(() => {
        dw.order.PaymentMgr.getActivePaymentMethods.restore();
    });

    describe('getPaypalPaymentMethodId function', function() {
        const getPaypalPaymentMethodId = bmPaymentInstrumentHelper.__get__('getPaypalPaymentMethodId');

        it('getPaypalPaymentMethodId should return \'PAYPAL\' if activePaymentMethods has PAYPAL active method', function() {
            dw.order.PaymentMgr.getActivePaymentMethods.returns(activePaymentMethods);
            expect(getPaypalPaymentMethodId()).to.be.equal('PAYPAL');
        });

        it('getPaypalPaymentMethodId should return \'undefined\' if activePaymentMethods hasn\'t PAYPAL active method', function() {
            dw.order.PaymentMgr.getActivePaymentMethods.returns([activePaymentMethods[0]]);
            expect(getPaypalPaymentMethodId()).to.be.equal(undefined);
        });
    });

    describe('getPaypalPaymentInstrument function', function() {
        const basket = {
            getPaymentInstruments: stub()
        };

        before(() => {
            bmPaymentInstrumentHelper.__set__('getPaypalPaymentMethodId', () => false);
        });

        after(() => {
            bmPaymentInstrumentHelper.__ResetDependency__('getPaypalPaymentMethodId');
        });

        const paymentInstrumentObject = [{
            paymentMethod: 'PayPal',
            UUID: '49c7ed508ac1dd8182bf3018c9',
            ID: 'PAYPAL'
        }];

        it('getPaypalPaymentInstrument should return payment instrument object with id PAYPAL', function() {
            basket.getPaymentInstruments.returns(paymentInstrumentObject);

            expect(bmPaymentInstrumentHelper.getPaypalPaymentInstrument(basket)).to.deep.equal(paymentInstrumentObject[0]);
        });

        it('getPaypalPaymentInstrument should return false', function() {
            basket.getPaymentInstruments.returns('');

            expect(bmPaymentInstrumentHelper.getPaypalPaymentInstrument(basket)).to.equal(false);
        });
    });

    describe('updatePaypalPaymentInstrument', () => {
        const isCustomOrder = true;
        const httpParameterMap = {
            orderNo: { stringValue: '0000001' },
            orderToken: { stringValue: '1q2w3e4r5t6y7u8i9o0p' }
        };

        before(() => {
            stub(dw.system.Transaction, 'wrap', callback => callback());

            bmPaymentInstrumentHelper.__set__('getPaypalPaymentInstrument', () => ({
                custom: { paypalPaymentStatus: undefined }
            }));
        });

        after(() => {
            dw.system.Transaction.wrap.restore();
            bmPaymentInstrumentHelper.__ResetDependency__('getPaypalPaymentInstrument');
        });

        it('updates the payment instrument of the order with the payment status of the transaction', () => {
            expect(bmPaymentInstrumentHelper.updatePaypalPaymentInstrument(httpParameterMap, isCustomOrder)).to.be.undefined;
            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;
        });
    });

    describe('isPaypalPaymentInstrument', () => {
        const order = {
            getPaymentInstruments: (paymentMethodID) => ([{ paymentMethod: paymentMethodID }])
        };

        it('order contains a payment instrument with a PayPal payment method ID', () => {
            expect(bmPaymentInstrumentHelper.isPaypalPaymentInstrument(order)).to.be.a('boolean').that.is.true;
        });

        it('order does not contain a payment instrument with a PayPal payment methmod ID', () => {
            order.getPaymentInstruments = () => ([]);

            expect(bmPaymentInstrumentHelper.isPaypalPaymentInstrument(order)).to.be.a('boolean').that.is.false;
        });
    });

    describe('getPayPalCreditCardPi', () => {
        const getPayPalCreditCardPi = bmPaymentInstrumentHelper.__get__('getPayPalCreditCardPi');
        const order = {
            getPaymentInstruments: stub()
        };

        it('should return a PAYPAL_CREDIT_CARD payment instrument object if it exist', () => {
            order.getPaymentInstruments.returns([{}]);

            expect(getPayPalCreditCardPi(order))
                .that.deep.equal({});
        });

        it('should return false if PAYPAL_CREDIT_CARD payment instrument is not exist', () => {
            order.getPaymentInstruments.returns([]);

            expect(getPayPalCreditCardPi(order)).to.be.false;
        });
    });

    describe('getOrderPaymentInstrument', () => {
        const order = {
            getPaymentInstruments: stub()
        };

        it('should return a PayPal payment instrument', () => {
            order.getPaymentInstruments.returns([{
                paymentMethod: 'PayPal'
            }]);

            expect(bmPaymentInstrumentHelper.getOrderPaymentInstrument(order)).that.deep.equal({
                paymentMethod: 'PayPal'
            });
        });

        it('should return a PAYPAL_CREDIT_CARD payment instrument', () => {
            order.getPaymentInstruments.returns([{
                paymentMethod: 'PAYPAL_CREDIT_CARD'
            }]);

            expect(bmPaymentInstrumentHelper.getOrderPaymentInstrument(order)).that.deep.equal({
                paymentMethod: 'PAYPAL_CREDIT_CARD'
            });
        });

        it('should be false if no payment instrument was found', () => {
            order.getPaymentInstruments.returns([]);

            expect(bmPaymentInstrumentHelper.getOrderPaymentInstrument(order)).to.be.false;
        });
    });
});
