/* eslint-disable no-underscore-dangle */
const { bm_paypal: { mergeAccountsPayPalAndSingleAuthPath } } = require('../path.json');

const { expect } = require('chai');
const {
    it, describe, before, after
} = require('mocha');

const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const proxyquire = require('proxyquire').noCallThru();

const debug = stub();
const error = stub();
const getCustomPreferenceValue = stub();
const searchProfiles = stub();
const searchProfile = stub();
const writeNext = stub();

let isFileExist = true;
let isServiceStatusOk = true;

const URLUtils = {
    abs: (msg) => ({
        toString: () => msg
    })
};

const service = {
    setURL: () => {},
    setRequestMethod: () => {},
    addHeader: () => {},
    call: () => ({
        isOk: () => isServiceStatusOk
    })
};

const parametersForStep = {
    get: (value) => value
};

const profile = {
    externalProfile: null,
    currentProfile: {
        email: 'test@gmail.com',
        customerNo: 'customerNo',
        custom: {
            isMergedAccount: null
        },
        customer: {
            isExternallyAuthenticated: null
        }
    },
    customer: {
        externallyAuthenticated: null
    }
};

const mergeAccountsPayPalAndSingleAuth = proxyquire(mergeAccountsPayPalAndSingleAuthPath, {
    'dw/io/File': function() {
        this.exists = () => isFileExist;
        this.mkdir = () => {};

        return this;
    },
    'dw/system/Site': {
        current: {
            getCustomPreferenceValue
        }
    },
    'dw/util/Bytes': dw.util.Bytes,
    'dw/system/Logger': {
        getLogger: () => ({
            debug,
            error
        })
    },
    'dw/web/URLUtils': URLUtils,
    'dw/util/Calendar': dw.util.Calendar,
    'dw/crypto/Encoding': dw.crypto.Encoding,
    'dw/io/FileWriter': function() {
        this.close = () => {};

        return this;
    },
    'dw/util/StringUtils': dw.util.StringUtils,
    'dw/system/Transaction': dw.system.Transaction,
    'dw/customer/CustomerMgr': {
        searchProfiles,
        searchProfile
    },
    'dw/io/CSVStreamWriter': function() {
        this.writeNext = writeNext;
        this.close = () => {};

        return this;
    },
    'dw/svc/LocalServiceRegistry': {
        createService: (name, config) => {
            config.createRequest(service, []);
            config.parseResponse('', { getText: () => '{}' });

            return 'created service';
        }
    }
});

function resetAllDependency() {
    mergeAccountsPayPalAndSingleAuth.__ResetDependency__('encodeString');
    mergeAccountsPayPalAndSingleAuth.__ResetDependency__('getFileReportPath');
    mergeAccountsPayPalAndSingleAuth.__ResetDependency__('getProfileForMergeProcess');
    mergeAccountsPayPalAndSingleAuth.__ResetDependency__('createErrorLog');
    mergeAccountsPayPalAndSingleAuth.__ResetDependency__('getHttpService');
    mergeAccountsPayPalAndSingleAuth.__ResetDependency__('mergeBillingAgreementsWithProfile');
    mergeAccountsPayPalAndSingleAuth.__ResetDependency__('mergeCustomerAddresses');
    mergeAccountsPayPalAndSingleAuth.__ResetDependency__('removeCustomer');
    mergeAccountsPayPalAndSingleAuth.__ResetDependency__('getExternalId');
    mergeAccountsPayPalAndSingleAuth.__ResetDependency__('checkAuthenticationProvider');
}

describe('mergeAccountsPayPalAndSingleAuth file', () => {
    describe('setTimeout', () => {
        const setTimeout = mergeAccountsPayPalAndSingleAuth.__get__('setTimeout');

        it('if it has milliseconds', () => {
            expect(setTimeout(0.00001)).to.be.undefined;
        });
    });

    describe('encodeString', () => {
        const encodeString = mergeAccountsPayPalAndSingleAuth.__get__('encodeString');

        before(() => {
            stub(dw.crypto.Encoding, 'toBase64', () => 'encoded');
        });

        after(() => {
            dw.crypto.Encoding.toBase64.restore();
        });

        it('if it has milliseconds', () => {
            expect(encodeString()).to.be.equal('encoded');
        });
    });

    describe('createErrorLog', () => {
        const createErrorLog = mergeAccountsPayPalAndSingleAuth.__get__('createErrorLog');

        after(() => {
            debug.reset();
            error.reset();
        });

        it('if error was not passed', () => {
            createErrorLog();

            expect(debug.calledOnce).to.be.true;
        });

        it('if error has stack propery', () => {
            createErrorLog({ stack: 'stack' });

            expect(error.calledOnce).to.be.true;
        });

        it('if error has not stack propery', () => {
            createErrorLog({});

            expect(error.calledTwice).to.be.true;
        });
    });

    describe('differenceBetweenArraysWithObjectsByKeys', () => {
        const differenceBetweenArraysWithObjectsByKeys = mergeAccountsPayPalAndSingleAuth.__get__('differenceBetweenArraysWithObjectsByKeys');

        const primaryArray = [{ value: 'value', obj: { value: 'value' } }, {}];
        const secondaryArray = [{ value: 'value' }];
        const keys = ['value'];

        it('should be array with empty obj', () => {
            expect(differenceBetweenArraysWithObjectsByKeys(primaryArray, secondaryArray, keys)).to.be.deep.equal([{}]);
        });
    });

    describe('getExternalId', () => {
        const getExternalId = mergeAccountsPayPalAndSingleAuth.__get__('getExternalId');

        before(() => {
            profile.externalProfile = {
                externalID: 'externalID',
                authenticationProviderID: 'providerID'
            };
        });

        after(() => {
            profile.externalProfile = null;
        });

        it('should return externalID', () => {
            const externalProfiles = {
                toArray: () => [profile.externalProfile]
            };

            expect(getExternalId(externalProfiles, 'providerID')).to.be.deep.equal('externalID');
        });

        it('should return false', () => {
            const externalProfiles = {
                toArray: () => []
            };

            expect(getExternalId(externalProfiles, 'providerID')).to.be.false;
        });
    });

    describe('checkAuthenticationProvider', () => {
        const checkAuthenticationProvider = mergeAccountsPayPalAndSingleAuth.__get__('checkAuthenticationProvider');

        before(() => {
            profile.externalProfile = {
                externalID: 'externalID',
                authenticationProviderID: 'providerID'
            };
        });

        after(() => {
            profile.externalProfile = null;
        });

        it('should return externalID', () => {
            const externalProfiles = {
                toArray: () => [profile.externalProfile, profile.externalProfile]
            };

            expect(checkAuthenticationProvider(externalProfiles, 'providerID')).to.be.true;
        });
    });

    describe('isAddressNameExists', () => {
        const isAddressNameExists = mergeAccountsPayPalAndSingleAuth.__get__('isAddressNameExists');

        const currentAddresses = [{ ID: 'id' }, { ID: 'currect address' }];

        it('should return true if address name exists', () => {
            expect(isAddressNameExists(currentAddresses, 'currect address')).to.be.true;
        });
    });

    describe('mergeOrdersWithCustomer', () => {
        const mergeOrdersWithCustomer = mergeAccountsPayPalAndSingleAuth.__get__('mergeOrdersWithCustomer');

        const order = {
            setCustomerNo: () => {}
        };

        const arr = [order, order];
        const orders = {
            count: arr.length,
            asList: () => ({
                toArray: () => arr
            })
        };

        it('should return order amount', () => {
            expect(mergeOrdersWithCustomer(orders, 'currect address')).to.be.equal(2);
        });
    });

    describe('mergeBillingAgreementsWithProfile', () => {
        const mergeBillingAgreementsWithProfile = mergeAccountsPayPalAndSingleAuth.__get__('mergeBillingAgreementsWithProfile');

        const custom = {
            PP_API_billingAgreement: '["billingAgreementValue0", "billingAgreementValue1"]'
        };

        const currentProfile = Object.assign(profile.currentProfile, { custom: custom });
        const externalProfile = {
            custom: custom
        };

        before(() => {
            mergeAccountsPayPalAndSingleAuth.__set__('differenceBetweenArraysWithObjectsByKeys', () => ['billingAgreementUniqueValue0', 'billingAgreementUniqueValue']);
        });

        after(() => {
            mergeAccountsPayPalAndSingleAuth.__ResetDependency__('differenceBetweenArraysWithObjectsByKeys');
        });

        it('should return amount of unique values', () => {
            expect(mergeBillingAgreementsWithProfile(currentProfile, externalProfile)).to.be.equal(2);
        });

        it('should return 0 if there are no unique values', () => {
            currentProfile.custom.PP_API_billingAgreement = null;
            externalProfile.custom.PP_API_billingAgreement = null;

            expect(mergeBillingAgreementsWithProfile(currentProfile, externalProfile)).to.be.equal(0);
        });
    });

    describe('mergeCustomerAddresses', () => {
        const mergeCustomerAddresses = mergeAccountsPayPalAndSingleAuth.__get__('mergeCustomerAddresses');

        const customerAddress = {
            setAddress1: () => {},
            setAddress2: () => {},
            setCity: () => {},
            setCountryCode: () => {},
            setFirstName: () => {},
            setLastName: () => {},
            setPhone: () => {},
            setPostalCode: () => {},
            setStateCode: () => {}
        };

        const addressBook = {
            createAddress: () => customerAddress,
            addresses: {
                toArray: () => [{}]
            }
        };

        const currentCustomer = {
            addressBook: addressBook
        };

        const externalCustomer = {
            addressBook: addressBook
        };

        before(() => {
            mergeAccountsPayPalAndSingleAuth.__set__('differenceBetweenArraysWithObjectsByKeys', () => [{
                countryCode: {
                    value: 'UA'
                }
            }]);
        });

        after(() => {
            mergeAccountsPayPalAndSingleAuth.__ResetDependency__('differenceBetweenArraysWithObjectsByKeys');
            mergeAccountsPayPalAndSingleAuth.__ResetDependency__('isAddressNameExists');
        });

        it('should return external unique addresses', () => {
            mergeAccountsPayPalAndSingleAuth.__set__('isAddressNameExists', () => true);

            expect(mergeCustomerAddresses(currentCustomer, externalCustomer)).to.be.equal(1);
        });

        it('if there are no customerAddress', () => {
            mergeAccountsPayPalAndSingleAuth.__set__('isAddressNameExists', () => false);
            currentCustomer.addressBook.createAddress = () => null;

            expect(mergeCustomerAddresses(currentCustomer, externalCustomer)).to.be.equal(1);
        });

        it('if there are no externalAddresses', () => {
            externalCustomer.addressBook.addresses.toArray = () => [];

            expect(mergeCustomerAddresses(currentCustomer, externalCustomer)).to.be.equal(0);
        });
    });

    describe('getHttpService', () => {
        const getHttpService = mergeAccountsPayPalAndSingleAuth.__get__('getHttpService');

        it('should return created service', () => {
            expect(getHttpService()).to.equal('created service');
        });

        it('should return created service if it already exist', () => {
            expect(getHttpService()).to.equal('created service');
        });
    });

    describe('removeCustomer', () => {
        const removeCustomer = mergeAccountsPayPalAndSingleAuth.__get__('removeCustomer');

        before(() => {
            mergeAccountsPayPalAndSingleAuth.__set__('getHttpService', () => service);
            mergeAccountsPayPalAndSingleAuth.__set__('setTimeout', () => {});
        });

        after(() => {
            mergeAccountsPayPalAndSingleAuth.__ResetDependency__('getHttpService');
            mergeAccountsPayPalAndSingleAuth.__ResetDependency__('setTimeout');
        });

        it('if servise returned with status ok', () => {
            expect(() => removeCustomer('', profile.currentProfile)).to.not.throw();
        });

        it('if servise returned with unsuccessful status', () => {
            isServiceStatusOk = false;

            expect(removeCustomer('', profile.currentProfile)).to.be.undefined;
        });
    });

    describe('mergingProcess', () => {
        const mergingProcess = mergeAccountsPayPalAndSingleAuth.__get__('mergingProcess');

        before(() => {
            mergeAccountsPayPalAndSingleAuth.__set__('mergeOrdersWithCustomer', () => ({ orders: 'orders' }));
            mergeAccountsPayPalAndSingleAuth.__set__('mergeBillingAgreementsWithProfile', () => ({ billingAgreement: 'billingAgreement' }));
            mergeAccountsPayPalAndSingleAuth.__set__('mergeCustomerAddresses', () => ({ addresses: 'addresses' }));
            mergeAccountsPayPalAndSingleAuth.__set__('removeCustomer', () => {});
            mergeAccountsPayPalAndSingleAuth.__set__('getExternalId', () => {});
        });

        after(() => {
            resetAllDependency();
        });

        const externalProfile = Object.assign(profile.currentProfile, { customer: { externalProfiles: {} } });

        it('must return merged object', () => {
            expect(mergingProcess(profile.currentProfile, externalProfile, {})).to.be.deep.equal({
                addresses: {
                    addresses: 'addresses'
                },
                billingAgreement: {
                    billingAgreement: 'billingAgreement'
                },
                currentCustomerNo: 'customerNo',
                email: 'test@gmail.com',
                externalCustomerNo: 'customerNo',
                orders: {
                    orders: 'orders'
                }
            });
        });
    });

    describe('getProfileForMergeProcess', () => {
        const getProfileForMergeProcess = mergeAccountsPayPalAndSingleAuth.__get__('getProfileForMergeProcess');

        const externalProfile = {
            customer: {
                isExternallyAuthenticated: () => true,
                orderHistory: {
                    orders: 'orders'
                }
            }
        };

        after(() => {
            profile.currentProfile.customer.isExternallyAuthenticated = null;
            searchProfile.reset();
            resetAllDependency();
        });

        it('must return merged object with 3 main properties', () => {
            mergeAccountsPayPalAndSingleAuth.__set__('checkAuthenticationProvider', () => true);
            profile.currentProfile.customer.isExternallyAuthenticated = () => false;

            searchProfile.returns(externalProfile);

            const call = getProfileForMergeProcess(profile.currentProfile);

            expect(call.currentProfile).to.be.not.undefined;
            expect(call.externalOrders).to.be.not.undefined;
            expect(call.externalProfile).to.be.not.undefined;
        });

        it('if profiles is authenticated', () => {
            profile.currentProfile.customer.isExternallyAuthenticated = () => true;

            const call = getProfileForMergeProcess(profile.currentProfile);

            expect(call.currentProfile).to.be.not.undefined;
            expect(call.externalOrders).to.be.undefined;
            expect(call.externalProfile).to.be.undefined;
        });

        it('must return merged object with 3 main properties', () => {
            mergeAccountsPayPalAndSingleAuth.__set__('checkAuthenticationProvider', () => false);
            profile.currentProfile.customer.isExternallyAuthenticated = () => false;

            searchProfile.returns(externalProfile);

            const call = getProfileForMergeProcess(profile.currentProfile);

            expect(call.currentProfile).to.be.not.undefined;
            expect(call.externalOrders).to.be.undefined;
            expect(call.externalProfile).to.be.not.undefined;
        });
    });

    describe('getFileReportPath', () => {
        const getFileReportPath = mergeAccountsPayPalAndSingleAuth.__get__('getFileReportPath');

        before(() => {
            stub(dw.util.StringUtils, 'formatCalendar', () => 'FormatedTime');
        });

        after(() => {
            dw.util.StringUtils.formatCalendar.restore();
        });

        const parameters = {
            get: () => 'FileReportPath/{DateTime}'
        };

        it('must return merged object', () => {
            expect(getFileReportPath(parameters)).to.be.equal('FileReportPath/FormatedTime');
        });
    });

    describe('beforeStep', () => {
        before(() => {
            mergeAccountsPayPalAndSingleAuth.__set__('encodeString', () => {});
            mergeAccountsPayPalAndSingleAuth.__set__('getFileReportPath', () => 'FileReportPath');
            mergeAccountsPayPalAndSingleAuth.__set__('encodeString', () => {});

            searchProfiles.returns({
                asList: () => ({
                    toArray: () => [profile, profile]
                })
            });
        });

        after(() => {
            resetAllDependency();
            searchProfiles.reset();
            isFileExist = true;
        });

        it('if file exist', () => {
            mergeAccountsPayPalAndSingleAuth.beforeStep(parametersForStep);

            expect(searchProfiles.calledOnce).to.be.true;
        });

        it('if file not exist', () => {
            isFileExist = false;
            mergeAccountsPayPalAndSingleAuth.beforeStep(parametersForStep);

            expect(searchProfiles.calledOnce).to.be.false;
        });
    });

    describe('getTotalCount', () => {
        before(() => {
            mergeAccountsPayPalAndSingleAuth.__set__('getFileReportPath', () => 'FileReportPath');
            mergeAccountsPayPalAndSingleAuth.__set__('encodeString', () => {});

            searchProfiles.onFirstCall().returns({
                asList: () => ({
                    toArray: () => [profile, profile]
                })
            }).onSecondCall().returns({
                asList: () => ({
                    toArray: () => []
                })
            });
        });

        after(() => {
            resetAllDependency();
            searchProfiles.reset();
        });

        it('if there are 2 profiles', () => {
            mergeAccountsPayPalAndSingleAuth.beforeStep(parametersForStep);

            expect(mergeAccountsPayPalAndSingleAuth.getTotalCount()).to.be.equal(2);
        });

        it('if there are no profiles', () => {
            mergeAccountsPayPalAndSingleAuth.beforeStep(parametersForStep);

            expect(mergeAccountsPayPalAndSingleAuth.getTotalCount()).to.be.equal(0);
        });
    });

    describe('read', () => {
        before(() => {
            mergeAccountsPayPalAndSingleAuth.__set__('getProfileForMergeProcess', () => true);
            mergeAccountsPayPalAndSingleAuth.__set__('getFileReportPath', () => 'FileReportPath');
            mergeAccountsPayPalAndSingleAuth.__set__('encodeString', () => {});
        });

        after(() => {
            resetAllDependency();
            searchProfiles.reset();
        });

        it('if there is profiles', () => {
            searchProfiles.returns({
                asList: () => ({
                    toArray: () => [profile, profile]
                })
            });
            mergeAccountsPayPalAndSingleAuth.beforeStep(parametersForStep);

            expect(mergeAccountsPayPalAndSingleAuth.read()).to.be.true;
        });

        it('if there is no profiles', () => {
            searchProfiles.returns({
                asList: () => ({
                    toArray: () => []
                })
            });
            mergeAccountsPayPalAndSingleAuth.beforeStep(parametersForStep);

            expect(mergeAccountsPayPalAndSingleAuth.read()).to.be.undefined;
        });
    });

    describe('process', () => {
        const processResult = {
            email: '',
            currentCustomerNo: '',
            externalCustomerNo: '',
            orders: 0,
            addresses: 0,
            billingAgreement: 0
        };

        before(() => {
            mergeAccountsPayPalAndSingleAuth.__set__('createErrorLog', () => {});
        });

        after(() => {
            resetAllDependency();
            profile.externalProfile = null;
        });

        it('if profiles is not external', () => {
            expect(mergeAccountsPayPalAndSingleAuth.process(profile)).to.be.deep.equal(Object.assign({}, processResult, {
                email: 'test@gmail.com',
                currentCustomerNo: 'customerNo'
            }));
        });

        it('if profiles is external and there is an error', () => {
            profile.externalProfile = {};

            expect(mergeAccountsPayPalAndSingleAuth.process(profile)).to.be.deep.equal(processResult);
        });
    });

    describe('write', () => {
        const line = {
            email: 'email',
            currentCustomerNo: 'currentCustomerNo',
            externalCustomerNo: 'externalCustomerNo',
            orders: 'orders',
            addresses: 'addresses',
            billingAgreement: 'billingAgreement'
        };

        const lines = {
            toArray: () => [line, line]
        };

        it('should run without errors', () => {
            expect(() => mergeAccountsPayPalAndSingleAuth.write(lines)).to.not.throw();
        });
    });

    describe('afterStep', () => {
        it('must be called', () => {
            expect(mergeAccountsPayPalAndSingleAuth.afterStep()).to.be.undefined;
        });
    });
});
