const { paypal_credit_financing_options_ocapi: { paypalConstantsPath } } = require('../path.json');

const { expect } = require('chai');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const paypalConstants = proxyquire(paypalConstantsPath, {});

describe('paypalConstants', () => {
    it('Should have correct values for page flows', () => {
        expect(paypalConstants.PAGE_FLOW_PLP).to.equal('plp');
    });

    it('Should have correct values for query parameters', () => {
        expect(paypalConstants.QUERY_PARAMETER_CURRENCY_CODE).to.equal('currencyCode');
        expect(paypalConstants.QUERY_PARAMETER_CURRENCY_CODE_VALUE).to.equal('GBP');
        expect(paypalConstants.QUERY_PARAMETER_COUNTRY_CODE).to.equal('countryCode');
        expect(paypalConstants.QUERY_PARAMETER_COUNTRY_CODE_VALUE).to.equal('GB');
        expect(paypalConstants.QUERY_PARAMETER_PAGE_ID).to.equal('pageId');
        expect(paypalConstants.ALLOWED_QUERY_PARAMETER_PAGE_IDS).to.deep.equal(['plp', 'pdp', 'cart', 'minicart', 'billing']);
    });

    it('Should have correct values for intent types', () => {
        expect(paypalConstants.INTENT_AUTHORIZE).to.equal('AUTHORIZE');
        expect(paypalConstants.INTENT_CAPTURE).to.equal('CAPTURE');
    });

    it('Should have correct values for action type', () => {
        expect(paypalConstants.ACTION_TYPE_AUTHORIZE).to.equal('authorize');
        expect(paypalConstants.ACTION_TYPE_CAPTURE).to.equal('capture');
    });
});
