const { paypal_credit_financing_options_ocapi: { paypalPreferencesPath } } = require('../path.json');

const { expect } = require('chai');
const {
    it, describe, before, after
} = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const paypalPreferences = proxyquire(paypalPreferencesPath, {
    'dw/order/PaymentMgr': {
        getActivePaymentMethods: () => {
            return [
                {
                    active: true,
                    ID: 'ApplePay',
                    paymentProcessor: {
                        ID: 'BRAINTREE_APPLEPAY'
                    }
                },
                {
                    active: true,
                    ID: 'PAYPAL',
                    paymentProcessor: {
                        ID: 'PAYPAL'
                    }
                },
                {
                    active: true,
                    ID: 'local',
                    paymentProcessor: {
                        ID: 'BRAINTREE_LOCAL'
                    }
                },
                {
                    active: true,
                    ID: 'CREDIT_CARD',
                    paymentProcessor: {
                        ID: 'BRAINTREE_CREDIT'
                    }
                }
            ];
        }
    },
    '*/cartridge/scripts/util/paypalConstants': {
        ALLOWED_PROCESSOR_ID: 'PAYPAL'
    }

});

describe('getPaypalPaymentMethodId', () => {
    const getPaypalPaymentMethodId = paypalPreferences.__get__('getPaypalPaymentMethodId');
    const originalArray = Array;

    before(() => {
        Object.assign(Array, { some: (arr, cb) => arr.some(cb) });
    });

    after(() => {
        // eslint-disable-next-line no-global-assign
        Array = originalArray;
    });

    it('If payment method name was returned', () => {
        const result = getPaypalPaymentMethodId();

        expect(result).to.equal('PAYPAL');
    });
});
