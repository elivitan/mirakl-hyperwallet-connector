const { paypal_credit_financing_options_ocapi: { financialPreferencesPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');

const { it, describe } = require('mocha');
const { expect } = require('chai');
const { stub } = require('sinon');

require('babel-register')({ plugins: ['babel-plugin-rewire'] });

const campaignResponse = stub();
const responseObj = {
    bannerSize: undefined,
    publisherID: 'PP_Merchant_Publisher_ID',
    isActive: 'PP_Show_Credit_Financial_Banners'
};

const financialPreferences = require('proxyquire').noCallThru()(financialPreferencesPath, {
    'dw/system/Site': {
        getCurrent: () => {
            return {
                getCustomPreferenceValue: ccID => ccID
            };
        }
    },
    'dw/campaign/PromotionMgr': {
        getCampaign: campaignResponse
    }
});

describe('financialPreferences', () => {
    describe('getCreditBannerData', () => {
        const getCreditBannerData = financialPreferences.__get__('getCreditBannerData');

        it('Response type should be equal -> object and responseObj', () => {
            expect(getCreditBannerData()).to.be.a('object');
            expect(getCreditBannerData()).to.deep.equal(responseObj);
        });

        it('It should return false if the credit campaign is not active', () => {
            campaignResponse.returns({
                isActive: () => false
            });

            expect(getCreditBannerData()).to.deep.equal({ isActive: false });
        });

        it('It should return an object without bannerSize if ppCreditBannerHeight and ppCreditBannerWidth are empty', () => {
            campaignResponse.returns({
                isActive: () => true
            });

            financialPreferences.__set__('ppCreditBannerHeight', 100);
            financialPreferences.__set__('ppCreditBannerWidth', 100);

            expect(getCreditBannerData().bannerSize).to.be.equal('100x100');
        });
    });
});
