const { paypal_credit_financing_options_ocapi: { paypalCreditFinancingOptionsHelperPath } } = require('../path.json');

const { expect } = require('chai');
const { stub } = require('sinon');

require('babel-register')({ plugins: ['babel-plugin-rewire'] });
require('dw-api-mock/demandware-globals');

const getCalculatedFinancingOptions = stub();
const sessionCacheKeyMock = stub();
const locale = {
    getLocale: () => ({
        country: 'US'
    })
};

const creditFinancialOptionsHelper = require('proxyquire').noCallThru()(paypalCreditFinancingOptionsHelperPath, {
    'dw/util/StringUtils': dw.util.StringUtils,
    '*/cartridge/scripts/paypal/financialApi': {
        getCalculatedFinancingOptions
    },
    'dw/system/CacheMgr': {
        getCache: () => ({
            get: sessionCacheKeyMock,
            put: () => { }
        })
    },
    'dw/util/Locale': locale
});

describe('paypalCreditFinancingOptionsHelper file', () => {
    describe('parseCreditFinancialOptions', () => {
        const parseCreditFinancialOptions = creditFinancialOptionsHelper.__get__('parseCreditFinancialOptions');

        it('Should parse credit financial options correctly', () => {
            const data = {
                financing_options: [
                    {
                        option1: [
                            { credit_financing: { credit_type: 'type1' } },
                            { credit_financing: { credit_type: 'type2' } }
                        ]
                    },
                    {
                        option2: [
                            { credit_financing: { credit_type: 'type2' } },
                            { credit_financing: { credit_type: 'type3' } }
                        ]
                    }
                ]
            };

            const result = [];
            const creditType = 'type2';
            const array = [
                { credit_financing: { credit_type: 'type2' } },
                { credit_financing: { credit_type: 'type2' } }
            ];

            parseCreditFinancialOptions(data, result, creditType);

            expect(result).to.deep.equal(array);
        });

        it('Should skip non-array options', () => {
            const result = [1, 2, 3];
            const data = {
                financing_options: [
                    {
                        optionFieldName: {}
                    },
                    {
                        optionFieldName: [1, 2, 3]
                    },
                    {
                        optionFieldName: 'test'
                    }
                ]
            };

            parseCreditFinancialOptions(data, result, 'creditType');

            expect(result).to.deep.equal([1, 2, 3]);
        });

        it('Should parse credit financial options with no credit type specified', () => {
            const data = {
                financing_options: [
                    {
                        option1: [
                            { credit_financing: { credit_type: 'US' } },
                            { credit_financing: { credit_type: 'GBP' } }
                        ]
                    },
                    {
                        option2: [
                            { credit_financing: { credit_type: 'JPY' } },
                            { credit_financing: { credit_type: 'USDT' } }
                        ]
                    }
                ]
            };

            const result = [];
            const array = [
                { credit_financing: { credit_type: 'US' } },
                { credit_financing: { credit_type: 'GBP' } },
                { credit_financing: { credit_type: 'JPY' } },
                { credit_financing: { credit_type: 'USDT' } }
            ];

            parseCreditFinancialOptions(data, result);

            expect(result).to.deep.equal(array);
        });
    });

    describe('getAllOptions', function() {
        let result;

        before(function() {
            getCalculatedFinancingOptions.returns({
                financing_options: [{
                    3: [{
                        credit_financing: {
                            credit_type: 'US'
                        },
                        monthly_payment: {
                            value: 12
                        }
                    }],
                    6: [{
                        credit_financing: {
                            credit_type: 'US'
                        },
                        monthly_payment: {
                            value: 24
                        }
                    }],
                    12: [{
                        credit_financing: {
                            credit_type: 'UK'
                        },
                        monthly_payment: {
                            value: 6
                        }
                    }]
                }]
            });
        });

        beforeEach(function() {
            session.privacy = {
                paypalFinancialOptions: {}
            };
        });

        it('Should remove results that does not match creditType', function() {
            const expectedResult = [{
                credit_financing: { credit_type: 'US' },
                monthly_payment: { value: 12 }
            },
            {
                credit_financing: { credit_type: 'US' },
                monthly_payment: { value: 24 }
            }];

            result = creditFinancialOptionsHelper.getAllOptions(100, 'USD', 'US', 'US');

            expect(result).to.deep.equals(expectedResult);
        });

        it('Should remove results that does not match creditType from cost', function() {
            const expectedResult = [{
                credit_financing: { credit_type: 'US' },
                monthly_payment: { value: 12 }
            },
            {
                credit_financing: { credit_type: 'US' },
                monthly_payment: { value: 24 }
            }];

            result = creditFinancialOptionsHelper.getAllOptions(new dw.value.Money(100, 'USD'), 'USD', 'US');

            expect(result).to.deep.equals(expectedResult);
        });

        it('Should return all options', function() {
            const expectedResult = [{
                credit_financing: { credit_type: 'US' },
                monthly_payment: { value: 12 }
            },
            {
                credit_financing: { credit_type: 'US' },
                monthly_payment: { value: 24 }
            },
            {
                credit_financing: { credit_type: 'UK' },
                monthly_payment: { value: 6 }
            }
            ];

            result = creditFinancialOptionsHelper.getAllOptions(100, 'USD', 'US');

            expect(result).to.deep.equals(expectedResult);
        });

        it('Should return cachePaypalCreditFinancing ', function() {
            sessionCacheKeyMock.returns('_100_USD_US');
            result = creditFinancialOptionsHelper.getAllOptions(100, 'USD', 'US');
            expect(result).to.be.equal('_100_USD_US');
        });
    });

    describe('getLowestPossibleMonthlyCost', function() {
        let result;

        before(function() {
            stub(creditFinancialOptionsHelper, 'getAllOptions')
                .returns([{
                    credit_financing: { credit_type: 'US' },
                    monthly_payment: { value: 12 }
                },
                {
                    credit_financing: { credit_type: 'US' },
                    monthly_payment: { value: 24 }
                }]);
            stub(dw.util.StringUtils, 'formatMoney').returns('USD 12');
        });

        after(function() {
            dw.util.StringUtils.formatMoney.restore();
            creditFinancialOptionsHelper.getAllOptions.restore();
        });

        it('Should remove results that does not match creditType from cost', function() {
            const expectedResult = {
                value: 12,
                currencyCode: 'USD',
                formatted: 'USD 12'
            };

            result = creditFinancialOptionsHelper.getLowestPossibleMonthlyCost(new dw.value.Money(100, 'USD'), 'USD', 'US');

            expect(result).to.deep.equals(expectedResult);
        });

        it('If options is not empty array', function() {
            result = creditFinancialOptionsHelper.getLowestPossibleMonthlyCost(100, 'USD', 'US');
            expect(result.value).to.be.equal(12);
            expect(result.currencyCode).to.be.equal('USD');
            expect(result.formatted).to.be.equal('USD 12');
        });

        it('Return value of lower cost option', function() {
            result = creditFinancialOptionsHelper.getLowestPossibleMonthlyCost(100, 'USD');

            expect(result.value).to.be.equal(12);
            expect(result.currencyCode).to.be.equal('USD');
            expect(result.formatted).to.be.equal('USD 12');
        });
    });

    describe('getDataForAllOptionsBanner', function() {
        let result;
        const expectedResult = {
            'options': {
                '3': {
                    'term': 3,
                    'apr': 2.22,
                    'monthlyPayment': {
                        'value': 12,
                        'currencyCode': 'USD',
                        'formatted': 'USD 12'
                    },
                    'totalCost': {
                        'value': 1,
                        'currencyCode': 'USD',
                        'formatted': 'USD 12'
                    },
                    'purchaseCost': {
                        'value': 100,
                        'currencyCode': 'USD',
                        'formatted': 'USD 12'
                    },
                    'rawOptionData': {
                        'credit_financing': {
                            'credit_type': 'US',
                            'term': 3,
                            'apr': 2.22
                        },
                        'monthly_payment': {
                            'value': 12,
                            'currency_code': 'USD'
                        },
                        'total_cost': {
                            'value': 1,
                            'currency_code': 'USD'
                        }
                    }
                },
                '6': {
                    'term': 6,
                    'apr': 3.33,
                    'monthlyPayment': {
                        'value': 24,
                        'currencyCode': 'USD',
                        'formatted': 'USD 12'
                    },
                    'totalCost': {
                        'value': 2,
                        'currencyCode': 'USD',
                        'formatted': 'USD 12'
                    },
                    'purchaseCost': {
                        'value': 100,
                        'currencyCode': 'USD',
                        'formatted': 'USD 12'
                    },
                    'rawOptionData': {
                        'credit_financing': {
                            'credit_type': 'US',
                            'term': 6,
                            'apr': 3.33
                        },
                        'monthly_payment': {
                            'value': 24,
                            'currency_code': 'USD'
                        },
                        'total_cost': {
                            'value': 2,
                            'currency_code': 'USD'
                        }
                    }
                }
            },
            'monthSet': [3, 6],
            'monthlyPaymentValueSet': [12, 24]
        };

        before(function() {
            stub(creditFinancialOptionsHelper, 'getAllOptions')
                .returns([{
                    credit_financing: { credit_type: 'US', term: 3, apr: 2.22 },
                    monthly_payment: { value: 12, currency_code: 'USD' },
                    total_cost: { value: 1, currency_code: 'USD' }
                },
                {
                    credit_financing: { credit_type: 'US', term: 6, apr: 3.33 },
                    monthly_payment: { value: 24, currency_code: 'USD' },
                    total_cost: { value: 2, currency_code: 'USD' }
                }]);
            stub(dw.util.StringUtils, 'formatMoney').returns('USD 12');
        });

        after(function() {
            dw.util.StringUtils.formatMoney.restore();
            creditFinancialOptionsHelper.getAllOptions.restore();
        });

        it('Should remove results that does not match creditType from cost', function() {
            result = creditFinancialOptionsHelper.getDataForAllOptionsBanner(new dw.value.Money(100, 'USD'), 'USD', 'US');

            expect(result).to.deep.equals(expectedResult);
        });

        it('If no contryCode return Local countryCode ', function() {
            locale.getLocale = stub().returns({
                country: 'Ukraine'
            });
            result = creditFinancialOptionsHelper.getDataForAllOptionsBanner(100, 'USD');
            expect(result).to.deep.equal(expectedResult);
        });

        it('Should return data for banner', function() {
            expect(creditFinancialOptionsHelper.getDataForAllOptionsBanner(100, 'USD', 'US')).to.deep.equal(expectedResult);
        });
    });
});
