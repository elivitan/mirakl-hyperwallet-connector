const { paypal_credit_financing_options_ocapi: { productPath } } = require('../path.json');

const { expect } = require('chai');
const { stub } = require('sinon');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
const { before, after, it } = require('mocha');

require('babel-register')({ plugins: ['babel-plugin-rewire'] });

const paypalConstantsMock = {
    QUERY_PARAMETER_CURRENCY_CODE: 'currencyCode',
    QUERY_PARAMETER_CURRENCY_CODE_VALUE: 'GBP',
    QUERY_PARAMETER_COUNTRY_CODE: 'countryCode',
    QUERY_PARAMETER_COUNTRY_CODE_VALUE: 'GB',
    QUERY_PARAMETER_PAGE_ID: 'pageId',
    ALLOWED_QUERY_PARAMETER_PAGE_IDS: ['plp', 'pdp', 'cart', 'minicart', 'billing'],
    CUSTOM_ERROR_TYPE: 'customError',
    PAGE_FLOW_PDP: 'pdp',
    PAGE_FLOW_PLP: 'plp'
};

const financialPreferencesMock = {
    isActive: true
};

const hookHelperMock = {
    createObjectFromQueryString: stub(),
    isEmptyObject: stub()
};

const validationHelperMock = {
    isEmptyObject: stub()
};

const creditFinancialOptionsHelperMock = {};

const product = proxyquire(productPath, {
    'dw/web/Resource': dw.web.Resource,
    'dw/system/Logger': dw.system.Logger,
    'dw/system/Status': dw.system.Status,
    '~/cartridge/scripts/paypal/helpers/validationHelper': validationHelperMock,
    '~/cartridge/scripts/util/paypalConstants': paypalConstantsMock,
    '~/cartridge/config/financialPreferences': financialPreferencesMock,
    '*/cartridge/scripts/paypal/helpers/hooksHelper': hookHelperMock,
    '*/cartridge/scripts/paypal/paypalCreditFinancingOptionsHelper': creditFinancialOptionsHelperMock
});

const checkAllowedNameError = (data, message) => {
    expect(data).to.be.instanceof(dw.system.Status);
    expect(data.message.message).to.equal(message);
    expect(data.status).to.equal(1);
    expect(data.code).to.equal('customError');
};

describe('product file', () => {
    describe('beforeGET', () => {
        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('paypal.query.parameter.not.allowed.name.error', 'paypalerrors', null).returns('Not allowed name');
            dw.web.Resource.msg.withArgs('paypal.query.parameter.not.allowed.countryCode.error', 'paypalerrors', null).returns('Not allowed countryCode');
            dw.web.Resource.msg.withArgs('paypal.query.parameter.not.allowed.currencyCode.error', 'paypalerrors', null).returns('Not allowed currencyCode');
            dw.web.Resource.msg.withArgs('paypal.query.parameter.not.allowed.pageId.error', 'paypalerrors', null).returns('Not allowed pageId');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('If queryParamsObject is empty should not throw an error', () => {
            hookHelperMock.createObjectFromQueryString.returns({});
            validationHelperMock.isEmptyObject.returns(true);

            expect(product.beforeGET()).to.be.undefined;
        });

        it('Should give an error if no currencyCode', () => {
            validationHelperMock.isEmptyObject.returns(false);

            checkAllowedNameError(product.beforeGET(), 'Not allowed name');
        });

        it('Should give an error if no country Code', () => {
            hookHelperMock.createObjectFromQueryString.returns({
                currencyCode: 'USD'
            });
            validationHelperMock.isEmptyObject.returns(false);

            checkAllowedNameError(product.beforeGET(), 'Not allowed name');
        });

        it('Should give an error if no pageId', () => {
            hookHelperMock.createObjectFromQueryString.returns({
                currencyCode: 'USD',
                countryCode: 'US'
            });
            validationHelperMock.isEmptyObject.returns(false);

            checkAllowedNameError(product.beforeGET(), 'Not allowed name');
        });

        it('Should give an error if no country Code is not equal paypalConstant country code', () => {
            hookHelperMock.createObjectFromQueryString.returns({
                currencyCode: 'USD',
                countryCode: 'US',
                pageId: 'pageId'
            });

            validationHelperMock.isEmptyObject.returns(false);

            checkAllowedNameError(product.beforeGET(), 'Not allowed countryCode');
        });

        it('Should give an error if no country Code is not equal paypalConstant currency code', () => {
            hookHelperMock.createObjectFromQueryString.returns({
                currencyCode: 'GB',
                countryCode: 'GB',
                pageId: 'pageId'
            });

            validationHelperMock.isEmptyObject.returns(false);

            checkAllowedNameError(product.beforeGET(), 'Not allowed currencyCode');
        });

        it('Should give an error if not allowed pageId', () => {
            hookHelperMock.createObjectFromQueryString.returns({
                countryCode: 'GB',
                currencyCode: 'GBP',
                pageId: 'invalidPageId'
            });

            validationHelperMock.isEmptyObject.returns(false);
            checkAllowedNameError(product.beforeGET(), 'Not allowed pageId');
        });

        it('If an error occurs it returns a Status object with error', () => {
            const error = new Error('Test error');

            hookHelperMock.createObjectFromQueryString.throws(error);

            const expectedStatus = new dw.system.Status(dw.system.Status.ERROR, paypalConstantsMock.CUSTOM_ERROR_TYPE, error);

            expect(product.beforeGET()).to.deep.equal(expectedStatus);
        });
    });

    describe('modifyGETResponse', () => {
        it('Should set c_lowestPossibleMonthlyCost property for PLP page flow', () => {
            const productMock = {
                priceModel: {
                    minPrice: {
                        value: 10
                    },
                    minPricePerUnit: {
                        value: 5
                    }
                }
            };

            const productResponseMock = {};

            creditFinancialOptionsHelperMock.getLowestPossibleMonthlyCost = stub().returns({
                value: 10,
                currencyCode: 'USD',
                countryCode: 'US'
            });

            hookHelperMock.createObjectFromQueryString.returns({
                currencyCode: 'USD',
                countryCode: 'US',
                pageId: 'plp'
            });

            validationHelperMock.isEmptyObject.returns(false);

            product.modifyGETResponse(productMock, productResponseMock);

            expect(productResponseMock.c_lowestPossibleMonthlyCost).to.deep.equal({
                value: 10,
                currencyCode: 'USD',
                countryCode: 'US'
            });

            expect(productResponseMock.c_financialPreferences).to.deep.equal(financialPreferencesMock);
        });
        it('Should modify product response with credit financial options data', () => {
            const productMock = {
                priceModel: {
                    price: {
                        value: 10
                    }
                }
            };

            const productResponseMock = {};

            creditFinancialOptionsHelperMock.getDataForAllOptionsBanner = stub().returns({
                lowestPossibleMonthlyCost: {
                    value: 10,
                    currencyCode: 'USD',
                    countryCode: 'US'
                }
            });
            creditFinancialOptionsHelperMock.getLowestPossibleMonthlyCost = stub().returns({
                value: 10,
                currencyCode: 'USD',
                countryCode: 'US',
                formatted: '$10.00'
            });

            hookHelperMock.createObjectFromQueryString.returns({
                currencyCode: 'USD',
                countryCode: 'US',
                pageId: 'pdp'
            });

            validationHelperMock.isEmptyObject.returns(false);

            product.modifyGETResponse(productMock, productResponseMock);

            const expected = {
                lowestPossibleMonthlyCost: {
                    value: 10,
                    currencyCode: 'USD',
                    formatted: '$10.00'
                }
            };

            expect(productResponseMock.c_allOptionsData).to.deep.equal(expected);

            expect(productResponseMock.c_financialPreferences).to.deep.equal(financialPreferencesMock);
        });

        it('If an error occurs it returns a Status object with error', () => {
            const error = new Error('Test error');

            hookHelperMock.createObjectFromQueryString.throws(error);

            const expectedStatus = new dw.system.Status(dw.system.Status.ERROR, paypalConstantsMock.CUSTOM_ERROR_TYPE, error);

            expect(product.modifyGETResponse()).to.deep.equal(expectedStatus);
        });
    });
});
