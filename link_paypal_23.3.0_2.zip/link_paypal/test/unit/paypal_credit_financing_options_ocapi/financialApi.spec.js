const { paypal_credit_financing_options_ocapi: { financialApiPath } } = require('../path.json');

const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

const { it, describe } = require('mocha');
const { stub } = require('sinon');

const paypalRestServiceStub = {
    call: (type, url, data) => {
        return {
            requestUrl: 'https://developer.paypal.com/docs/limited-release/financing-options/api/' + url,
            requestType: type,
            requestData: data
        };
    }
};

const createErrorMsgStub = stub().returns('Mocked error message');

const financialApi = proxyquire(financialApiPath, {
    '*/cartridge/scripts/paypal/paypalUtils': {
        createErrorMsg: createErrorMsgStub
    },
    '*/cartridge/scripts/service/paypalRestService': paypalRestServiceStub
});

describe('financialApi file', () => {
    describe('getCalculatedFinancingOptions', () => {
        const data = {};

        it('Response type should be equal -> object', () => {
            expect(financialApi.getCalculatedFinancingOptions(data)).to.be.a('object');
        });

        it('Should handle error and return error message', () => {
            paypalRestServiceStub.call = stub().throws(new Error('Mocked error message'));

            const result = financialApi.getCalculatedFinancingOptions(data);

            expect(result).to.deep.equal({ err: 'Mocked error message' });
        });
    });
});
