const { paypal_credit_financing_options_ocapi: { validationHelperPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');

const { it, describe } = require('mocha');
const { expect } = require('chai');

require('babel-register')({ plugins: ['babel-plugin-rewire'] });

Object.setPrototypeOf(module,
    Object.assign(Object.getPrototypeOf(module), {
        superModule: {}
    }));

const baseValidationHelper = require('proxyquire').noCallThru()(validationHelperPath, {});

describe('validationHelper', () => {
    describe('isEmptyObject', () => {
        it('Should return true for an empty object', () => {
            const obj = {};
            const result = baseValidationHelper.isEmptyObject(obj);

            expect(result).to.be.true;
        });

        it('Should return false for an object with properties', () => {
            const obj = { foo: 'bar' };
            const result = baseValidationHelper.isEmptyObject(obj);

            expect(result).to.be.false;
        });

        it('Should return false for an object with nested properties', () => {
            const obj = { foo: { bar: 'baz' } };
            const result = baseValidationHelper.isEmptyObject(obj);

            expect(result).to.be.false;
        });
    });
});
