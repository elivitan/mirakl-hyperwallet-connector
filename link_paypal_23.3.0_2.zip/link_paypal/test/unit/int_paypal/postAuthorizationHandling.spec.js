const { int_paypal: { postAuthorizationHandlingPath } } = require('../path.json');

const { expect } = require('chai');
const { stub } = require('sinon');
const proxyquire = require('proxyquire').noCallThru();

let order = {
    email: 'sfra@gmail.com',
    getOrderNo: () => '111111',
    setExternalOrderNo: () => 'O-111111',
    custom: {}
};

const getPaypalPaymentInstrument = stub();

require('dw-api-mock/demandware-globals');

const postAuthorizationHandling = proxyquire(postAuthorizationHandlingPath, {
    '*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper': {
        getPaypalPaymentInstrument: getPaypalPaymentInstrument
    },
    '*/cartridge/models/billingAgreement': function() {
        return {
            isAccountAlreadyExist: emailBA => !empty(emailBA),
            updateBillingAgreement: activeBAUpdate => activeBAUpdate,
            saveBillingAgreement: activeBASave => activeBASave
        };
    }
});

describe('postAuthorizationHandling file', () => {
    describe('postAuthorizationHandling file', () => {
        it('postAuthorizationHandling should have property postAuthorization', () => {
            expect(postAuthorizationHandling).has.ownProperty('postAuthorization');
        });

        it('property postAuthorization is function', () => {
            expect(postAuthorizationHandling.postAuthorization).to.be.a('function');
        });
    });
    describe('postAuthorizationHandling file isActiveBillingAgreement==true', () => {
        before(() => {
            getPaypalPaymentInstrument.returns({
                custom: {
                    PP_API_ActiveBillingAgreement: JSON.stringify(order)
                }
            });

            customer.authenticated = true;
        });
        after(() => {
            getPaypalPaymentInstrument.returns(null);
        });

        it('if isAccountAlreadyExist is true and return is still object', () => {
            expect(postAuthorizationHandling.postAuthorization(null, order)).to.be.a('object');
        });

        it('if isAccountAlreadyExist is false and return is still object', () => {
            expect(postAuthorizationHandling.postAuthorization(null, order)).to.be.a('object');
        });

        it('if isAccountAlreadyExist is false and return is still object', () => {
            const failOrder = '';

            getPaypalPaymentInstrument.returns({
                custom: {
                    PP_API_ActiveBillingAgreement: JSON.stringify(failOrder)
                }
            });
            expect(postAuthorizationHandling.postAuthorization(null, order)).to.be.a('object');
        });
    });
});
