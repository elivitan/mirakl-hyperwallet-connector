/* eslint-disable no-underscore-dangle */
const { int_paypal: { paypalHelperPath } } = require('../path.json');

const proxyquire = require('proxyquire').noCallThru();
const { expect } = require('chai');
const {
    describe, it, before, after, beforeEach, afterEach
} = require('mocha');

const { stub, assert } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const encodeString = stub();
const getShippingAddress = stub();
const createShippingAddress = stub();
const getBAShippingAddress = stub();
const toBase64 = stub();
const Bytes = stub();
const isJson = stub();
const getCustomObject = stub();
const queryOrder = stub();
const updateBABillingAddress = stub();

const payPalPrefs = {
    billingAgreementDescription: 'billingAgreementDescription',
    paypalButtonLocation: 'MiniCart,Cart',
    billingAgreementEnabled: true
};

const currentBasket = {
    getDefaultShipment: () => ({
        getShippingAddress
    }),
    giftCertificateLineItems: [],
    productLineItems: {}
};

const getOrderDetails = () => {
    return {
        purchase_units: [{
            amount: {
                value: '244.23'
            }
        }]
    };
};

const paypalHelper = proxyquire(paypalHelperPath, {
    '*/cartridge/config/paypalPreferences': payPalPrefs,
    '*/cartridge/scripts/paypal/paypalUtils': {
        encodeString
    },
    '*/cartridge/scripts/util/basicHelpers': {
        isJson,
        generateRandomString: () => ('7Df6GhUjK8l9M5nB4vC3xZ2cV1bNmQa')
    },
    '*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper': {
        calculateNonGiftCertificateAmount: () => ({
            value: { toString: () => 111 }
        })
    },
    'dw/order/TaxMgr': dw.order.TaxMgr,
    '*/cartridge/scripts/paypal/helpers/addressHelper': {
        getBAShippingAddress,
        updateBABillingAddress,
        createShippingAddress
    },
    'dw/order/BasketMgr': {
        currentBasket
    },
    'dw/order/OrderMgr': {
        createOrderNo: () => '002001',
        queryOrder
    },
    'server': {
        forms: {
            getForm: () => ({
                clear: () => {},
                paypal: {
                    usedPaymentMethod: { htmlName: 'PayPal' },
                    makeDefaultPaypalAccount: {
                        htmlName: 'name'
                    }
                },
                paymentMethod: { htmlName: 'PayPal' }
            })
        }
    },
    '*/cartridge/config/paypalConstants': {
        PAYMENT_METHOD_ID_VENMO: 'Venmo',
        PAYMENT_METHOD_ID_PAYPAL: 'PayPal'
    },
    'dw/crypto/Encoding': { toBase64 },
    'dw/util/Bytes': Bytes,
    'dw/object/CustomObjectMgr': { getCustomObject },
    '*/cartridge/scripts/paypal/paypalApi': {
        getOrderDetails
    },
    '*/cartridge/config/sdkConfig': {
        paypalFraudNetScriptLink: 'https://c.paypal.com/da/r/fb.js'
    },
    '*/cartridge/config/paypalSDK': {
        fraudNetNoScriptURL: (fraudNetUID) => {
            return ['https://c.paypal.com/v1/r/d/b/ns?f=', fraudNetUID, '&js=0&r=1'].join('');
        }
    }
});

describe('paypalHelper file', () => {
    describe('getTransactionId function', () => {
        const getTransactionId = paypalHelper.__get__('getTransactionId');
        const transactionResponseAuthorization = {
            purchase_units: [{
                payments: {
                    authorizations: [{ id: '3E179939TX5111812E' }]
                }
            }]
        };

        const transactionResponseCapture = {
            purchase_units: [{
                payments: {
                    captures: [{ id: '3E179939TX5111812E' }]
                }
            }]
        };

        it('should return payments.authorizations[0].id ', () => {
            expect(getTransactionId(transactionResponseAuthorization)).equal('3E179939TX5111812E');
        });
        it('should return payments.captures[0].id ', () => {
            expect(getTransactionId(transactionResponseCapture)).equal('3E179939TX5111812E');
        });
    });
    describe('getTransactionStatus function', () => {
        const getTransactionStatus = paypalHelper.__get__('getTransactionStatus');
        const transactionResponse = {
            purchase_units: [{
                payments: {
                    authorizations: [{
                        id: '3E179939TX5111812E',
                        status: 'CREATED'
                    }]
                }
            }]
        };

        const transactionResponseCaptures = {
            purchase_units: [{
                payments: {
                    captures: [{
                        id: '3E179939TX5111812E',
                        status: 'CAPTURED'
                    }]
                }
            }]
        };

        it('getTransactionStatus should return CREATED', () => {
            expect(getTransactionStatus(transactionResponse)).equal('CREATED');
        });
        it('getTransactionStatus should return CAPTURED', () => {
            expect(getTransactionStatus(transactionResponseCaptures)).equal('CAPTURED');
        });
        it('getTransactionStatus should return CAPTURED if payments.refunds is empty ', () => {
            let transactionResponse_ = {
                purchase_units: [{
                    payments: {
                        authorizations: [{
                            id: '3E179939TX5111812E',
                            status: 'CAPTURED'
                        }]
                    }
                }]
            };

            expect(getTransactionStatus(transactionResponse_)).equal('CAPTURED');
        });
    });
    describe('isExpiredTransaction', () => {
        const isExpiredTransaction = paypalHelper.__get__('isExpiredTransaction');
        let creationDate;
        let dateNow = Date.parse(new Date());
        let getTime = 1584088139000;

        before(() => {
            stub(Date, 'now');
            stub(Date, 'parse');
            stub(Date.prototype, 'getTime');
        });

        beforeEach(() => {
            Date.now.returns(dateNow);
            Date.parse.returns(creationDate);
            Date.prototype.getTime.returns(getTime);
        });

        after(() => {
            Date.now.reset();
            Date.parse.reset();
            Date.prototype.getTime.reset();
        });

        describe('Transaction Expired', () => {
            before(() => {
                creationDate = 1584087421000;
            });

            it('returns true', () => {
                expect(isExpiredTransaction(creationDate)).to.be.equals(true);
            });
        });

        describe('Transaction Valid', () => {
            before(() => {
                creationDate = dateNow;
                getTime = dateNow + 1584347339000;
            });

            it('returns false', () => {
                expect(isExpiredTransaction(creationDate)).to.be.equals(false);
            });
        });

        it('If payment instrument was not provided', () => {
            expect(isExpiredTransaction()).to.be.false;
        });
    });

    describe('isPurchaseUnitChanged', () => {
        const isPurchaseUnitChanged = paypalHelper.__get__('isPurchaseUnitChanged');
        const paymentInstrument = {};

        let purchaseUnit = {
            amount: {
                currecy_code: 'USD',
                value: '244.23'
            },
            address: {}
        };

        describe('if orderDataHash is undefined', () => {
            before(() => {
                encodeString.withArgs(purchaseUnit).returns('123');
                session.privacy.orderDataHash = undefined;
            });
            after(() => {
                encodeString.reset();
                session.privacy.orderDataHash = undefined;
            });
            it('should return true', () => {
                expect(isPurchaseUnitChanged(purchaseUnit, paymentInstrument)).to.be.equals(true);
            });
        });

        describe('if encoded purchaseUnit equals to orderDataHash', () => {
            before(() => {
                encodeString.withArgs(purchaseUnit).returns('123');
                session.privacy.orderDataHash = '123';
            });
            after(() => {
                encodeString.reset();
                session.privacy.orderDataHash = undefined;
            });
            it('should return false', () => {
                expect(isPurchaseUnitChanged(purchaseUnit, paymentInstrument)).to.be.equals(false);
            });
        });

        describe('if encoded purchaseUnit is not equal to orderDataHash', () => {
            before(() => {
                encodeString.withArgs(purchaseUnit).returns('123');
                session.privacy.orderDataHash = '321';
            });
            after(() => {
                encodeString.reset();
                session.privacy.orderDataHash = undefined;
            });
            it('should return true', () => {
                expect(isPurchaseUnitChanged(purchaseUnit, paymentInstrument)).to.be.equals(true);
            });
        });
    });

    describe('cartPaymentForm', () => {
        const cartPaymentForm = paypalHelper.__get__('cartPaymentForm');
        let data = {};

        describe('if billing agreement is disabled and paypalOrderID exists', () => {
            before(() => {
                data = {
                    paypalData: {
                        paypalOrderID: '9D681170216583748',
                        payerEmail: undefined,
                        billingAgreementId: undefined
                    }
                };
            });
            after(() => {
                data = {};
            });
            it('should return payment form object with order id', () => {
                expect(cartPaymentForm(data)).to.deep.equal({
                    billingForm: {
                        paymentMethod: {
                            value: 'PayPal'
                        },
                        paypal: {
                            paypalActiveAccount: {
                                htmlValue: undefined
                            },
                            billingAgreementID: {
                                htmlValue: undefined
                            },
                            makeDefaultPaypalAccount: {
                                checked: true
                            },
                            savePaypalAccount: {
                                checked: true
                            }
                        }
                    }
                });
            });
        });

        describe('if billing agreement is enabled and BA id exists', () => {
            before(() => {
                data = {
                    paypalData: {
                        paypalOrderID: undefined,
                        payerEmail: 'epamtester@pptest.com',
                        billingAgreementId: 'B-36731823N9661964X'
                    }
                };
            });
            after(() => {
                data = {};
            });
            it('should return payment form object with BA id', () => {
                expect(cartPaymentForm(data)).to.deep.equal({
                    billingForm: {
                        paymentMethod: {
                            value: 'PayPal'
                        },
                        paypal: {
                            paypalActiveAccount: {
                                htmlValue: 'epamtester@pptest.com'
                            },
                            billingAgreementID: {
                                htmlValue: 'B-36731823N9661964X'
                            },
                            makeDefaultPaypalAccount: {
                                checked: true
                            },
                            savePaypalAccount: {
                                checked: true
                            }
                        }
                    }
                });
            });
        });

        describe('if billing agreement is enabled and BA email exists', () => {
            before(() => {
                data = {
                    paypalData: {
                        paypalOrderID: undefined,
                        payerEmail: 'epamtester@pptest.com',
                        billingAgreementId: undefined
                    }
                };
            });
            after(() => {
                data = {};
            });
            it('should return payment form object with BA email', () => {
                expect(cartPaymentForm(data)).to.deep.equal({
                    billingForm: {
                        paymentMethod: {
                            value: 'PayPal'
                        },
                        paypal: {
                            paypalActiveAccount: {
                                htmlValue: 'epamtester@pptest.com'
                            },
                            billingAgreementID: {
                                htmlValue: undefined
                            },
                            makeDefaultPaypalAccount: {
                                checked: true
                            },
                            savePaypalAccount: {
                                checked: true
                            }
                        }
                    }
                });
            });
        });
    });

    describe('getBARestData', () => {
        const getBARestData = paypalHelper.__get__('getBARestData');
        let isCartFlow;
        let isSkipShippingAddress = false;
        let tokenData;
        let shipping_address = {
            line1: 'test address',
            city: 'test city',
            state: 'test state',
            postal_code: 'test postal code',
            country_code: 'US',
            recipient_name: 'Mike Test'
        };

        let basketShippingAddress = {
            getAddress1: () => 'test address',
            getCity: () => 'test city',
            getStateCode: () => 'test state',
            getPostalCode: () => 'test postal code',
            getCountryCode: () => ({
                getValue: () => 'US'
            }),
            getFullName: () => 'Mike Test'
        };

        describe('if isCartFlow is true', () => {
            before(() => {
                isCartFlow = true;
            });
            after(() => {
                isCartFlow = undefined;
            });
            it('should return object with rest data', () => {
                tokenData = {
                    path: 'v1/billing-agreements/agreement-tokens',
                    method: 'POST',
                    body: {
                        description: 'billingAgreementDescription',
                        payer:
                        {
                            payment_method: 'PAYPAL'
                        },
                        plan:
                        {
                            type: 'MERCHANT_INITIATED_BILLING_SINGLE_AGREEMENT',
                            merchant_preferences:
                            {
                                return_url: '1',
                                cancel_url: '2',
                                accepted_pymt_type: 'INSTANT',
                                skip_shipping_address: false,
                                immutable_shipping_address: false
                            }
                        }
                    }
                };
                expect(getBARestData(isCartFlow, isSkipShippingAddress)).to.deep.equal(tokenData);
            });
        });

        describe('if isCartFlow is false', () => {
            before(() => {
                isCartFlow = false;
                getShippingAddress.returns(basketShippingAddress);
                getBAShippingAddress.withArgs(basketShippingAddress).returns(shipping_address);
            });
            after(() => {
                isCartFlow = undefined;
            });
            it('should return object with rest data', () => {
                tokenData = {
                    path: 'v1/billing-agreements/agreement-tokens',
                    method: 'POST',
                    body: {
                        description: 'billingAgreementDescription',
                        payer:
                        {
                            payment_method: 'PAYPAL'
                        },
                        plan:
                        {
                            type: 'MERCHANT_INITIATED_BILLING_SINGLE_AGREEMENT',
                            merchant_preferences:
                            {
                                return_url: '1',
                                cancel_url: '2',
                                accepted_pymt_type: 'INSTANT',
                                skip_shipping_address: false,
                                immutable_shipping_address: true
                            }
                        },
                        shipping_address: {
                            line1: 'test address',
                            city: 'test city',
                            state: 'test state',
                            postal_code: 'test postal code',
                            country_code: 'US',
                            recipient_name: 'Mike Test'
                        }
                    }
                };
                expect(getBARestData(isCartFlow, isSkipShippingAddress)).to.deep.equal(tokenData);
            });
        });

        describe('If hasOnlyGiftCertificates returns true', () => {
            before(() => {
                paypalHelper.__set__('hasOnlyGiftCertificates', () => true);
            });

            after(() => {
                paypalHelper.__ResetDependency__('hasOnlyGiftCertificates');
            });

            it('should return baTokenData with skip_shipping_address set to true', () => {
                const result = paypalHelper.getBARestData();

                expect(result).to.be.an('object');
                expect(result.body.plan.merchant_preferences.skip_shipping_address).to.be.true;
            });
        });
    });

    describe('updateCustomerPhone', () => {
        const updateCustomerPhone = paypalHelper.__get__('updateCustomerPhone');
        let billingData;
        const basket = {
            getBillingAddress: stub(),
            billingAddress: {
                phone: '4084842211'
            }
        };

        const billingAddress = {
            setPhone: stub()
        };

        basket.getBillingAddress.returns(billingAddress);
        describe('if phone is entered by user, email was not already set to basket and data form is without errors', () => {
            before(() => {
                billingData = {
                    phone: {
                        value: '6505895223'
                    }
                };
                updateCustomerPhone(basket, billingData);
            });
            after(() => {
                billingData = {};
            });
            it('should set customer`s phone to basket', () => {
                assert.calledWith(billingAddress.setPhone, '6505895223');
            });
        });

        describe('if phone is entered by user and data form is with errors', () => {
            before(() => {
                billingData = {
                    form: {
                        contactInfoFields: {
                            phone: {
                                htmlValue: '6505895223'
                            }
                        }
                    }
                };
                updateCustomerPhone(basket, billingData);
            });
            after(() => {
                billingData = {};
            });
            it('should set customer`s phone to basket', () => {
                assert.calledWith(billingAddress.setPhone, '6505895223');
            });
        });

        it('If customer phone was not updated', () => {
            updateCustomerPhone(basket, {});

            assert.notCalled(billingAddress.setPhone);
        });
    });

    describe('updatePayPalEmail', () => {
        const updatePayPalEmail = paypalHelper.__get__('updatePayPalEmail');

        describe('if paypalPayerEmail exists in session and is equal to currentPaypalEmail', () => {
            before(() => {
                session.privacy.paypalPayerEmail = 'epamtester@pptest.com';
            });
            after(() => {
                session.privacy.paypalPayerEmail = null;
            });
            it('should be written to basketModel from session', () => {
                let params = {
                    paypalPI: {
                        custom: {
                            currentPaypalEmail: 'epamtester@pptest.com'
                        }
                    },
                    basketModel: {}
                };

                updatePayPalEmail(params);
                expect(params.basketModel.paypalPayerEmail).to.equals('epamtester@pptest.com');
            });
        });

        describe('if paypalPayerEmail exists in session and is not equal to currentPaypalEmail', () => {
            before(() => {
                session.privacy.paypalPayerEmail = 'epamtester@pptest.com';
            });
            after(() => {
                session.privacy.paypalPayerEmail = null;
            });
            it('should be written to basketModel and paypal email should be changed in payment instrument', () => {
                let params = {
                    paypalPI: {
                        custom: {
                            currentPaypalEmail: 'test@test.com'
                        }
                    },
                    basketModel: {}
                };

                updatePayPalEmail(params);
                expect(params.paypalPI.custom.currentPaypalEmail).to.equals('epamtester@pptest.com');
            });
        });

        describe('if paypalPayerEmail does not exist in session', () => {
            it('should be written to basketModel from params', () => {
                let params = {
                    paypalPI: {
                        custom: {
                            currentPaypalEmail: 'test@test.com'
                        }
                    },
                    basketModel: {}
                };

                updatePayPalEmail(params);
                expect(params.basketModel.paypalPayerEmail).to.equals('test@test.com');
            });
        });
        describe('if paypalPayerEmail does not exist in session and in params', () => {
            it('should be written to basketModel as empty string', () => {
                let params = {
                    paypalPI: {
                        custom: {}
                    },
                    basketModel: {}
                };

                updatePayPalEmail(params);
                expect(params.basketModel.paypalPayerEmail).to.equals('');
            });
        });
    });

    describe('getItemsDescription', () => {
        const getItemsDescription = paypalHelper.__get__('getItemsDescription');
        const nameLength = 127;
        let productLineItems = [];

        describe('if was provided empty array', () => {
            it('should return empty string', () => {
                expect(getItemsDescription(productLineItems)).to.equals('');
            });
        });

        describe('if provided array with products', () => {
            before(() => {
                Array.map = function(a, b) {
                    return Array.prototype.map.call(a, b);
                };

                productLineItems = [
                    {
                        productName: 'name'
                    },
                    {
                        productName: 'longName'.repeat(nameLength)
                    }
                ];
            });
            it(`should return string of length not more than ${nameLength}`, () => {
                expect(getItemsDescription(productLineItems).length <= nameLength).to.be.true;
            });
        });
    });

    describe('hasGiftCertificates', () => {
        currentBasket.giftCertificateLineItems = [
            {
                giftCertificateID: 'id'
            }
        ];

        it('should return true if basket includes one or more certificate', () => {
            expect(paypalHelper.hasGiftCertificates(currentBasket)).to.be.true;
        });

        describe('if gift certificate was not found in basket', () => {
            before(() => {
                currentBasket.giftCertificateLineItems.length = 0;
            });

            it('should return false', () => {
                expect(paypalHelper.hasGiftCertificates(currentBasket)).to.be.false;
            });
        });
    });

    describe('isPaypalButtonEnabled', () => {
        let targetPage = 'cart';

        it('should return true if \'paypalButtonLocation\' include target page', () => {
            expect(paypalHelper.isPaypalButtonEnabled(targetPage)).to.be.true;
        });

        describe('if \'paypalButtonLocation\' doesn\'t include target page', () => {
            it('should return false', () => {
                targetPage = 'pdp';
                expect(paypalHelper.isPaypalButtonEnabled(targetPage)).to.be.false;
            });
        });

        it('should return false', () => {
            expect(paypalHelper.isPaypalButtonEnabled()).to.be.false;
        });
    });

    describe('getPreparedBillingFormFields', () => {
        const paypalPaymentInstrument = {
            custom: { currentPaypalEmail: 'paypal@email.com' }
        };

        const defaultBA = {
            baID: 'id',
            email: 'ba@email.com'
        };

        it('If billing agreement enabled', () => {
            const result = paypalHelper.getPreparedBillingFormFields(paypalPaymentInstrument, defaultBA);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                paymentMethod: {
                    name: 'PayPal',
                    value: 'PayPal'
                },
                makeDefaultPaypalAccount: {
                    name: 'name',
                    value: false
                }
            });
        });

        it('If billing agreement disabled', () => {
            payPalPrefs.billingAgreementEnabled = false;

            const result = paypalHelper.getPreparedBillingFormFields(paypalPaymentInstrument, defaultBA);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                paymentMethod: {
                    name: 'PayPal',
                    value: 'PayPal'
                },
                usedPaymentMethod: {
                    name: 'PayPal',
                    value: ''
                }
            });
        });
    });

    describe('getGiftCertificateDescription', () => {
        const getGiftCertificateDescription = paypalHelper.__get__('getGiftCertificateDescription');
        const giftCertificateLineItems = [
            {
                lineItemText: 'text',
                recipientEmail: 'customer@mail.com'
            },
            {
                lineItemText: 'text'.repeat(200),
                recipientEmail: 'customer@mail.com'
            }
        ];

        const desctriptionLength = 127;

        it('should return string', () => {
            expect(getGiftCertificateDescription(giftCertificateLineItems)).to.be.a('string');
        });

        it(`should return description string not longer than ${desctriptionLength}`, () => {
            expect(getGiftCertificateDescription(giftCertificateLineItems).length <= desctriptionLength).to.be.true;
        });

        describe('if provided empty certificate description', () => {
            it('should return empty string', () => {
                giftCertificateLineItems.length = 0;
                expect(getGiftCertificateDescription(giftCertificateLineItems)).to.deep.equal('');
            });
        });
    });

    describe('getAppliedGiftCertificateTotal', () => {
        const getAppliedGiftCertificateTotal = paypalHelper.__get__('getAppliedGiftCertificateTotal');

        const acc = {
            arr: [],
            add: (el) => acc.arr.push(el)
        };

        const giftCertificate = {
            paymentTransaction: { amount: 100 }
        };

        it('should add amount to acc', () => {
            const result = getAppliedGiftCertificateTotal(acc, giftCertificate);

            expect(result).to.be.an('number');
            expect(result).to.equal(1);

            expect(acc.arr[0]).to.equal(100);
        });
    });

    describe('getPurchaseUnit', () => {
        const basket = {
            currencyCode: 'USD',
            defaultShipment: {
                getShippingAddress: stub()
            },
            productLineItems: [],
            shippingTotalPrice: {
                subtract: () => ({
                    value: { toString: () => 40 }
                }),
                value: { toString: () => 45 }
            },
            adjustedShippingTotalPrice: 100,
            merchandizeTotalPrice: {
                subtract: () => ({
                    value: { toString: () => 100 }
                }),
                add: () => ({
                    value: { toString: () => 123 }
                })
            },
            adjustedMerchandizeTotalPrice: 100,
            giftCertificateLineItems: [],
            giftCertificateTotalPrice: 100,
            totalTax: {
                value: { toString: () => 0 }
            },
            giftCertificatePaymentInstruments: [{ value: 0 }]
        };

        const purchaseUnitProps = ['description', 'amount', 'invoice_id', 'shipping_preference'];

        before(() => {
            Array.reduce = (a, b) => Array.prototype.reduce.call(a, b);
            Object.assign(dw.order.TaxMgr,
                { TAX_POLICY_GROSS: 5 });

            stub(dw.order.TaxMgr, 'getTaxationPolicy');

            createShippingAddress.returns('shipping address');
            dw.order.TaxMgr.getTaxationPolicy.returns(5);
        });

        after(() => {
            Array.reduce = () => ({});
            dw.order.TaxMgr.getTaxationPolicy.restore();

            delete dw.order.TaxMgr.TAX_POLICY_GROSS;
        });

        afterEach(() => {
            createShippingAddress.reset();
        });

        it('If purchase unit returned and shipping_preference = \'GET_FROM_FILE\'', () => {
            const result = paypalHelper.getPurchaseUnit(basket);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys(purchaseUnitProps);
            expect(result.shipping_preference).to.equal('GET_FROM_FILE');

            expect(createShippingAddress.calledOnce).to.be.false;
        });

        it('If shipping address created and purchase unit returned', () => {
            basket.defaultShipment.getShippingAddress.returns('defaultShipment');

            const result = paypalHelper.getPurchaseUnit(basket);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('shipping', ...purchaseUnitProps);
            expect(result.shipping_preference).to.equal('SET_PROVIDED_ADDRESS');

            expect(createShippingAddress.calledOnce).to.be.true;
        });

        it('If no shipping address created and purchase unit returned', () => {
            basket.defaultShipment.getShippingAddress.returns(null);
            basket.giftCertificateLineItems.push({});

            const result = paypalHelper.getPurchaseUnit(basket);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys(purchaseUnitProps);
            expect(result.shipping_preference).to.equal('NO_SHIPPING');

            expect(createShippingAddress.calledOnce).to.be.false;
        });
    });

    describe('basketModelHack', () => {
        let selectedPaymentInstruments = [
            {
                paymentMethod: 'PayPal'
            },
            {
                paymentMethod: 'Venmo'
            }
        ];

        const basketModel = {
            resources: {},
            billing: {
                payment: {
                    selectedPaymentInstruments
                }
            }
        };

        const currencyCode = 'USD';
        const ppPaymentInstrumentCustomProps = { paymentId: 'PayPal' };

        afterEach(() => {
            selectedPaymentInstruments = [
                {
                    paymentMethod: 'PayPal'
                },
                {
                    paymentMethod: 'Venmo'
                }
            ];
        });

        it('If ppPaymentInstrumentCustomProps.paymentId === \'PayPal\'', () => {
            paypalHelper.basketModelHack(basketModel, currencyCode, ppPaymentInstrumentCustomProps);

            expect(basketModel.billing.payment.selectedPaymentInstruments[0].expirationMonth).to.equal('PayPal ');
        });

        it('If ppPaymentInstrumentCustomProps.paymentId === \'Venmo\'', () => {
            ppPaymentInstrumentCustomProps.paymentId = 'Venmo';

            paypalHelper.basketModelHack(basketModel, currencyCode, ppPaymentInstrumentCustomProps);
            expect(basketModel.billing.payment.selectedPaymentInstruments[0].expirationMonth).to.equal('Venmo ');
        });
    });

    describe('getUrlPath', () => {
        const credential = {
            URL: 'url/'
        };

        const path = 'path';

        it('should not add / to url', () => {
            expect(paypalHelper.getUrlPath(credential, path)).to.equal('url/path');
        });

        it('should add / to url', () => {
            credential.URL = 'url';
            expect(paypalHelper.getUrlPath(credential, path)).to.equal('url/path');
        });
    });

    describe('getAccessToken', () => {
        const credentials = {
            user: 'user',
            password: 'password'
        };

        it('should call toBase64 and Bytes', () => {
            paypalHelper.getAccessToken(credentials);

            assert.calledOnce(toBase64);
            assert.calledWith(Bytes, 'user:password');
        });
    });

    describe('getOrderByOrderNo', () => {
        const orderNo = 1;

        after(() => {
            getCustomObject.reset();
            queryOrder.reset();
        });

        it('should return custom object', () => {
            getCustomObject.returns({});

            expect(paypalHelper.getOrderByOrderNo(orderNo)).to.deep.equal({});
        });

        it('should return system object', () => {
            getCustomObject.returns(undefined);
            queryOrder.returns({});

            expect(paypalHelper.getOrderByOrderNo(orderNo)).to.deep.equal({});
        });
    });

    describe('updatePaymentId', () => {
        let paypalPaymentInstrument;
        let billingForm;

        beforeEach(() => {
            paypalPaymentInstrument = {
                custom: {
                    paymentId: 'Venmo'
                }
            };

            billingForm = {
                paypal: {
                    usedPaymentMethod: {
                        htmlValue: 'PayPal'
                    }
                }
            };
        });

        it('If paymentId is Venmo, but used payment method is not', () => {
            paypalHelper.updatePaymentId(paypalPaymentInstrument, billingForm);

            expect(paypalPaymentInstrument.custom.paymentId).to.equal(null);
        });

        it('If paymentId is not Venmo, but used payment method is Venmo', () => {
            billingForm.paypal.usedPaymentMethod.htmlValue = 'Venmo';
            paypalPaymentInstrument.custom.paymentId = 'PayPal';

            paypalHelper.updatePaymentId(paypalPaymentInstrument, billingForm);

            expect(paypalPaymentInstrument.custom.paymentId).to.equal('Venmo');
        });

        it('If paymentInstrument was not updated', () => {
            paypalPaymentInstrument.custom.paymentId = 'PayPal';

            paypalHelper.updatePaymentId(paypalPaymentInstrument, billingForm);

            expect(paypalPaymentInstrument.custom.paymentId).to.equal('PayPal');
        });
    });

    describe('updateBillingInfoIfAccountChanged', () => {
        const params = {
            baFromPI: {
                email: 'email@email.com'
            },
            activeBA: {
                email: 'email'
            },
            paypalPI: {
                custom: {
                    currentPaypalEmail: 'curr@email.com'
                }
            },
            billing_info: { email: 'email' },
            BADetailsError: true,
            handleError: stub()
        };

        afterEach(() => {
            params.handleError.reset();
        });

        it('If params.baFromPI.email !== params.activeBA.email and error was handled', () => {
            paypalHelper.updateBillingInfoIfAccountChanged(params);

            expect(params.handleError.calledOnce).to.be.true;
        });

        it('If params.baFromPI.email !== params.activeBA.email and billing address was updated', () => {
            params.BADetailsError = false;

            expect(paypalHelper.updateBillingInfoIfAccountChanged(params)).to.be.false;

            expect(params.handleError.notCalled).to.be.true;
            expect(updateBABillingAddress.calledOnce).to.be.true;
            expect(session.privacy.paypalPayerEmail).to.equal('email');
        });

        it('If paypalPayerEmail was set to currentPaypalEmail', () => {
            params.baFromPI.email = 'email';

            expect(paypalHelper.updateBillingInfoIfAccountChanged(params)).to.be.false;
            expect(session.privacy.paypalPayerEmail).to.equal('curr@email.com');
        });
    });

    describe('getTransactionHistory', () => {
        const dateTime = '2023-02-28T12:00:00.000Z';

        before(() => {
            stub(Date.prototype, 'toISOString').returns(dateTime);
        });

        after(() => {
            Date.prototype.toISOString.restore();
        });

        const getTransactionHistory = paypalHelper.__get__('getTransactionHistory');

        const transactionResponse = {
            resource: {
                status: 'REFUND',
                create_time: dateTime,
                amount: { value: '50.00' }
            },
            purchase_units: [{
                payments: {
                    captures: [{ create_time: dateTime, amount: { value: '50.00' }, status: 'CAPTURE' }],
                    authorizations: [{ create_time: dateTime, amount: { value: '50.00' }, status: 'CREATED' }]
                }
            }],
            paymentStatus: 'REFUND'
        };

        it('should returns an object (purchase_units captures)', () => {
            const val = getTransactionHistory(transactionResponse);

            expect(val).to.be.an('object').that.has.all.keys([
                'amount', 'timestamp', 'status'
            ]);

            expect(val).to.include({
                amount: '50.00',
                status: 'CAPTURE',
                timestamp: dateTime
            });
        });

        it('should returns an object (purchase_units authorizations)', () => {
            delete transactionResponse.purchase_units[0].payments.captures;

            const val = getTransactionHistory(transactionResponse);

            expect(val).to.be.an('object').that.has.all.keys([
                'amount', 'timestamp', 'status'
            ]);

            expect(val).to.include({
                amount: '50.00',
                status: 'CREATED',
                timestamp: dateTime
            });
        });

        it('should returns an object (resource for WebHook) paymentStatus', () => {
            delete transactionResponse.purchase_units;

            const val = getTransactionHistory(transactionResponse);

            expect(val).to.be.an('object').that.has.all.keys([
                'amount', 'timestamp', 'status'
            ]);

            expect(val).to.include({
                amount: '50.00',
                status: 'REFUND',
                timestamp: dateTime
            });
        });

        it('should returns an object (resource for WebHook) resourse status', () => {
            delete transactionResponse.paymentStatus;

            const val = getTransactionHistory(transactionResponse);

            expect(val).to.be.an('object').that.has.all.keys([
                'amount', 'timestamp', 'status'
            ]);

            expect(val).to.include({
                amount: '50.00',
                status: 'REFUND',
                timestamp: dateTime
            });
        });

        it('should returns an object (saved order flow)', () => {
            transactionResponse.status = 'SAVED';
            transactionResponse.isSavedOrder = true;
            transactionResponse.amount = { value: '50.00' };

            const val = getTransactionHistory(transactionResponse);

            expect(val).to.be.an('object').that.has.all.keys([
                'amount', 'timestamp', 'status'
            ]);

            expect(val).to.include({
                amount: '50.00',
                status: 'SAVED',
                timestamp: dateTime
            });
        });
    });

    describe('prepareTransactionHistory', () => {
        const responseData = {};
        const objectType = { custom: { paypalTransactionHistory: null } };

        before(() => {
            isJson.returns(false);

            paypalHelper.__set__('getTransactionHistory', () => ({
                amount: '40.00',
                status: 'Capture',
                timestamp: '2023-02-28T12:00:00.000Z'
            }));
        });

        after(() => {
            isJson.reset();
            paypalHelper.__ResetDependency__('getTransactionHistory');
        });

        it('should returns one item of transaction history in json format', () => {
            const val = paypalHelper.prepareTransactionHistory(objectType, responseData);

            expect(val).to.be.a('string').that.is.not.empty;
            expect(JSON.parse(val)).to.have.lengthOf(1);
        });

        it('should returns a list of transaction history in json format', () => {
            isJson.returns(true);

            objectType.custom.paypalTransactionHistory = JSON.stringify([{
                amount: '40.00',
                status: 'Created',
                timestamp: '2023-02-28T10:00:00.000Z'
            }]);

            const val = paypalHelper.prepareTransactionHistory(objectType, responseData);

            expect(val).to.be.a('string').that.is.not.empty;
            expect(JSON.parse(val)).to.have.lengthOf(2);
        });
    });

    describe('updateViewDataForFraudNet', () => {
        const expectedUID = '7Df6GhUjK8l9M5nB4vC3xZ2cV1bNmQa';

        let response;

        beforeEach(() => {
            response = {
                viewData: {
                    paypal: {
                        fraudNet: {}
                    }
                }
            };
        });

        it('should update viewData for FraudNet integration', () => {
            payPalPrefs.isFraudNetEnabled = true;

            paypalHelper.updateViewDataForFraudNet(response);

            expect(response.viewData.paypal.fraudNet.fraudNetUID).to.equal(expectedUID);
            expect(response.viewData.paypal.fraudNet.paypalFraudNetScriptLink).to.equal('https://c.paypal.com/da/r/fb.js');
            expect(response.viewData.paypal.fraudNet.fraudNetNoScriptURL).to.equal('https://c.paypal.com/v1/r/d/b/ns?f=' + expectedUID + '&js=0&r=1');
        });

        it('should not update viewData for FraudNet integration if isFraudNetEnabled is set to false', () => {
            payPalPrefs.isFraudNetEnabled = false;

            paypalHelper.updateViewDataForFraudNet(response);

            expect(response.viewData.paypal.fraudNet).to.deep.equal({});
        });
    });

    describe('getBillingAgreementProperties', () => {
        const pi = { custom: {} };
        const hasDefaultPaymentMethod = false;

        it('if payment instument has no active BA', () => {
            const result = paypalHelper.getBillingAgreementProperties(pi, hasDefaultPaymentMethod);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                activeBAEmail: undefined,
                activeBAID: undefined,
                hasDefaultPaymentMethod: false
            });
        });

        it('if payment instument has active BA, but it is not default', () => {
            pi.custom = {
                PP_API_ActiveBillingAgreement: JSON.stringify({
                    email: 'test@email.com',
                    baID: 'test-id',
                    default: false
                })
            };

            const result = paypalHelper.getBillingAgreementProperties(pi, hasDefaultPaymentMethod);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                activeBAEmail: 'test@email.com',
                activeBAID: 'test-id',
                hasDefaultPaymentMethod: false
            });
        });

        it('if payment instument has active BA and is default', () => {
            pi.custom = {
                PP_API_ActiveBillingAgreement: JSON.stringify({
                    email: 'test@email.com',
                    baID: 'test-id-2',
                    default: true,
                    saveToProfile: true
                })
            };

            const result = paypalHelper.getBillingAgreementProperties(pi, hasDefaultPaymentMethod);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                activeBAEmail: 'test@email.com',
                activeBAID: 'test-id-2',
                hasDefaultPaymentMethod: true
            });
        });
    });

    describe('stringifyBillingAddress', () => {
        it('billing address string representation should be returned', () => {
            const billingAddress = {
                firstName: 'firstName',
                lastName: 'lastName',
                address1: 'address1',
                city: 'city',
                stateCode: 'TXS',
                postalCode: '82100',
                countryCode: { value: 'US' },
                phone: '00000000000'
            };

            const expectedResult = '{"firstName":"firstName","lastName":"lastName","address1":"address1","address2":"","city":"city","stateCode":"TXS","postalCode":"82100","countryCode":{"value":"US"},"phone":"00000000000"}';

            const result = paypalHelper.stringifyBillingAddress(billingAddress);

            expect(result).to.be.an('string');
            expect(result).to.equal(expectedResult);
        });
    });
});
