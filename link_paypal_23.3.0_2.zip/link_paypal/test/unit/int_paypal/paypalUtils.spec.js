/* eslint-disable no-underscore-dangle */
const { int_paypal: { paypalUtilsPath } } = require('../path.json');

const proxyquire = require('proxyquire').noCallThru();
const { expect } = require('chai');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const get = stub();
const toBase64 = stub();
const error = stub();
const debug = stub();
const restService = { configuration: { credential: { user: 'g12346F' } } };
const disableFunds = ['sepa', 'bancontact', 'eps', 'giropay', 'ideal', 'mybank', 'p24', 'sofort'];

const paypalPreferences = {
    billingAgreementEnabled: undefined,
    isCapture: undefined,
    enabledLPMs: undefined,
    isPayNowFlowEnabled: undefined,
    CWPPButtonUrl: 'CWPPButtonUrl',
    partnerAttributionId: 'partnerAttributionId'
};

const paypalConstants = {
    PAYPAL_FILE_NAME_PREFIX: 'PayPal',
    PAYPAL_CATEGORY: 'PayPal_General'
};

const paypalUtils = proxyquire(paypalUtilsPath, {
    'dw/svc/LocalServiceRegistry': {
        createService: () => {
            return restService;
        }
    },
    '*/cartridge/config/sdkConfig': {
        disableFunds,
        allowedCurrencies: []
    },
    '*/cartridge/config/paypalPreferences': paypalPreferences,
    'server': {
        forms: {
            getForm: () => {}
        }
    },
    'dw/util/Bytes': () => { },
    'dw/crypto/Encoding': { toBase64 },
    'dw/system/Site': { getCurrent: () => ({ getDefaultLocale: () => 'US' }) },
    'dw/web/URLUtils': dw.web.URLUtils,
    'dw/system/Logger': {
        getLogger: () => ({
            debug,
            error
        })
    },
    'dw/web/Resource': dw.web.Resource,
    '*/cartridge/config/paypalConstants': paypalConstants
});

describe('paypalUtils file', () => {
    describe('getClientId', () => {
        const getClientId = paypalUtils.__get__('getClientId');

        describe('if client id exists in cash', () => {
            before(() => {
                get.returns('g12345D');
            });
            after(() => {
                get.reset();
            });
            it('should return client id from cash', () => {
                expect(getClientId()).to.be.equals('g12346F');
            });
        });

        describe('if client doesn`t exist in cash', () => {
            before(() => {
                get.returns(null);
            });
            after(() => {
                get.reset();
            });
            it('should create client id, save it in cash and return from cash', () => {
                expect(getClientId()).to.be.equals('g12346F');
            });
        });
    });

    describe('encodeString', () => {
        const encodeString = paypalUtils.__get__('encodeString');
        const purchaseUnit = {};

        after(() => {
            toBase64.reset();
        });

        it('should return encoded string', () => {
            encodeString(purchaseUnit);

            expect(toBase64.calledOnce).to.be.true;
        });
    });

    describe('createCWPPButtonUrl', () => {
        const rurl = 'rurl';

        before(() => {
            stub(dw.web.URLUtils, 'abs');
            dw.web.URLUtils.abs.returns({ toString: () => '' });

            paypalUtils.__set__('getClientId', () => 'id');
        });

        after(() => {
            dw.web.URLUtils.abs.restore();
            paypalUtils.__ResetDependency__('getClientId');
        });

        it('should return paypal url', () => {
            const result = paypalUtils.createCWPPButtonUrl(rurl);

            expect(result).to.be.a('string');
            expect(result).to.equal('CWPPButtonUrlflowEntry=static&client_id=id&locale=US&scope=openid profile email address&redirect_uri=&state=rurl');
        });
    });

    describe('createErrorLog', () => {
        const err = {
            stack: 'stack',
            message: 'error-message'
        };

        afterEach(() => {
            error.reset();
            debug.reset();
        });

        it('If error log with error message and error stack was created', () => {
            paypalUtils.createErrorLog(err);

            expect(error.calledWith('error-messagestack')).to.be.true;
        });

        it('If error log was created', () => {
            paypalUtils.createErrorLog('error');

            expect(error.calledWith('error')).to.be.true;
        });

        it('If debug log was created', () => {
            paypalUtils.createErrorLog();

            expect(debug.calledOnce).to.be.true;
        });
    });

    describe('createDebugLog', () => {
        const err = 'Error';

        before(() => {
            paypalUtils.__set__('paypalLogger', undefined);
        });

        it('should create debug log', () => {
            paypalUtils.createDebugLog(err);

            expect(debug.calledWith('Error')).to.be.true;
        });
    });

    describe('createErrorMsg', () => {
        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('paypal.error.general', 'paypalerrors', null).returns('pp.error');
            dw.web.Resource.msg.withArgs('paypal.error.customerror', 'paypalerrors', 'pp.error').returns('custom error message');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('should create custom error message', () => {
            expect(paypalUtils.createErrorMsg('customerror')).to.equal('custom error message');
        });
    });

    describe('errorHandle', () => {
        const emit = stub();
        const req = {};
        const res = { json: stub() };
        const msg = 'message';
        let err = true;

        before(() => {
            paypalUtils.__set__('createErrorLog', () => {});
            paypalUtils.__set__('createErrorMsg', () => 'msg');
        });

        after(() => {
            paypalUtils.__ResetDependency__('createErrorLog');
            paypalUtils.__ResetDependency__('createErrorMsg');
        });

        afterEach(() => {
            emit.reset();
            res.json.reset();
        });

        it('If error log was created and json passed to template', () => {
            paypalUtils.errorHandle.call({ emit }, req, res, err, msg);

            expect(res.json.calledOnce).to.be.true;
            expect(emit.calledOnce).to.be.true;
        });

        it('If error log was not created and json passed to template', () => {
            err = false;

            paypalUtils.errorHandle.call({ emit }, req, res, err, msg);

            expect(res.json.calledOnce).to.be.true;
            expect(emit.calledOnce).to.be.true;
        });
    });

    describe('handleError', () => {
        let errorTrigger = true;
        const callback = stub();
        const args = [];

        afterEach(() => {
            callback.reset();
        });

        it('If error was triggered and callback was called', () => {
            paypalUtils.handleError(errorTrigger, callback, args);

            expect(callback.calledOnce).to.be.true;
        });

        it('If error was not triggered and false returned', () => {
            errorTrigger = false;

            expect(paypalUtils.handleError(errorTrigger, callback, args)).to.be.false;

            expect(callback.calledOnce).to.be.false;
        });
    });

    describe('tryParseJSON', () => {
        const createErrorLogStub = stub();

        before(() => {
            paypalUtils.__set__('createErrorLog', createErrorLogStub);
        });

        after(() => {
            paypalUtils.__ResetDependency__('createErrorLog');
        });

        it('if the element was successfully parsed, and result returned', () => {
            const element = {
                testKey: 'testValue',
                testArr: []
            };

            const result = paypalUtils.tryParseJSON(JSON.stringify(element));

            expect(result).to.be.an('object');
            expect(result).to.deep.equal(element);

            expect(createErrorLogStub.notCalled).to.be.true;
        });

        it('if the element was invalid, and error appeared', () => {
            const element = '[1, 2, 3, 4, ]';

            const result = paypalUtils.tryParseJSON(element);

            expect(result).to.equal(undefined);

            expect(createErrorLogStub.calledWithMatch('Unable to parse:   [1, 2, 3, 4, ] SyntaxError: Unexpected token ] in JSON at position 13')).to.be.true;
        });
    });

    describe('addFlashMessagesCustomAttribute', () => {
        const systemObj = { custom: {} };
        const firstMsg = { text: 'text', type: 'danger' };
        const secondMsg = { text: 'text', type: 'info' };

        it('should add flash message', () => {
            paypalUtils.addFlashMessagesCustomAttribute(systemObj, 'text', 'danger');
            expect(systemObj.custom).to.have.property('flashMessages').that.deep.equals(JSON.stringify([firstMsg]));
        });

        it('should add another flash message to the existing one', () => {
            paypalUtils.__set__('tryParseJSON', () => [firstMsg]);
            paypalUtils.addFlashMessagesCustomAttribute(systemObj, 'text', 'info');
            expect(systemObj.custom).to.have.property('flashMessages').that.deep.equals(JSON.stringify([firstMsg, secondMsg]));
        });
    });
});
