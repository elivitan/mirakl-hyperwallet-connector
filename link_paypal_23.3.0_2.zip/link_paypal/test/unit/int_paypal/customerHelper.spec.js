/* eslint-disable object-curly-newline */

const { int_paypal: { customerHelperPath } } = require('../path.json');

const { expect } = require('chai');
const { describe, it, before, after } = require('mocha');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const customerHelper = proxyquire(customerHelperPath, {
    'dw/customer/Customer': dw.customer.Customer
});

describe('customerHelper file', () => {
    describe('getCustomerPaymentInstruments', () => {
        let creditCardPaymentInstruments = [{
            creditCardType: 'Visa',
            creditCardHolder: 'John Doe',
            creditCardExpired: false,
            maskedCreditCardNumber: '***********1111',
            creditCardExpirationMonth: '08',
            creditCardExpirationYear: '2023',
            creditCardNumberLastDigits: '1111',
            paymentMethod: 'CREDIT_CARD'
        }, {
            creditCardType: 'Visa',
            creditCardHolder: 'John Doe',
            creditCardExpired: false,
            maskedCreditCardNumber: '***********7777',
            creditCardExpirationMonth: '09',
            creditCardExpirationYear: '2023',
            paymentMethod: 'CREDIT_CARD'
        }];

        before(() => {
            Object.assign(global.customer, {
                authenticated: true,
                profile: {
                    wallet: {
                        getPaymentInstruments: () => ({
                            toArray: () => creditCardPaymentInstruments
                        })
                    }
                }
            });
        });

        after(() => {
            global.customer = new dw.customer.Customer();
        });

        it('should return an array with payment instruments for the payment method name that was passed', () => {
            expect(customerHelper.getCustomerPaymentInstruments('CREDIT_CARD'))
                .to.be.an('array')
                .that.deep.equal(creditCardPaymentInstruments);
        });

        it('should return an empty array if wallet is empty', () => {
            creditCardPaymentInstruments = [];

            expect(customerHelper.getCustomerPaymentInstruments('CREDIT_CARD'))
                .to.be.an('array').that.is.empty;
        });

        it('should return empty array if customer not authenticated', () => {
            global.customer.authenticated = false;

            expect(customerHelper.getCustomerPaymentInstruments('CREDIT_CARD'))
                .to.be.an('array').that.is.empty;
        });
    });

    describe('getPaypalCustomerId', () => {
        const payload = {
            customer: { id: 'pp-customer-id-2' }
        };

        before(() => {
            Object.assign(global.customer, {
                profile: {
                    custom: { payPalCustomerId: 'pp-customer-id' }
                }
            });
        });

        after(() => {
            global.customer = new dw.customer.Customer();
        });

        it('should return paypal customer id from customer profile', () => {
            const result = customerHelper.getPaypalCustomerId(payload);

            expect(result).to.be.a('string');
            expect(result).to.equal('pp-customer-id');
        });

        it('should return paypal customer id from API response', () => {
            global.customer.profile.custom = {};

            const result = customerHelper.getPaypalCustomerId(payload);

            expect(result).to.be.a('string');
            expect(result).to.equal('pp-customer-id-2');
        });
    });
});
