const { expect } = require('chai');
const { int_paypal: { buttonConfigHelperPath } } = require('../path.json');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const payPalPrefs = {
    cwppButtonStyles: {
        'login': {
            theme: 'blue', buttonType: 'CWP', buttonSize: 'md', buttonShape: 'rect'
        },
        'billing': {
            theme: 'blue', buttonType: 'CWP', buttonSize: 'lg', buttonShape: 'pill'
        }
    },
    disableFundingList: [],
    enabledLPMs: []
};

const paypalConstants = {
    PAGE_FLOW_LOGIN: 'login',
    PAGE_FLOW_BILLING: 'billing'
};

const getLocaleWithHyphen = stub();

const buttonConfigHelper = require('proxyquire').noCallThru()(buttonConfigHelperPath, {
    '*/cartridge/config/paypalPreferences': payPalPrefs,
    '*/cartridge/scripts/paypal/paypalUtils': {
        getClientId: () => 'client-id'
    },
    '*/cartridge/config/paypalUrls': {
        cwppUrl: 'cwpp-url'
    },
    '*/cartridge/config/sdkConfig': {
        cwppScores: 'address'
    },
    '*/cartridge/config/paypalConstants': paypalConstants,
    '*/cartridge/scripts/util/basicHelpers': {
        getLocaleWithHyphen: getLocaleWithHyphen
    }
});

describe('buttonConfigHelper file', () => {
    describe('getAvailableLPMSArray', () => {
        before(() => {
            payPalPrefs.enabledLPMs = ['mybank', 'giropay'];
            payPalPrefs.disableFundingList = ['bancontact', 'venmo'];
        });

        after(() => {
            payPalPrefs.enabledLPMs = [];
            payPalPrefs.disableFundingList = [];
        });

        it('if disableFundingList contains lpm', () => {
            payPalPrefs.disableFundingList.push('giropay');

            expect(buttonConfigHelper.getAvailableLPMSArray()).to.be.an('array').that.includes('mybank');
        });

        it('if disableFundingList contains all available LPMs', () => {
            payPalPrefs.disableFundingList.push('mybank');

            expect(buttonConfigHelper.getAvailableLPMSArray()).to.be.an('array').that.is.empty;
        });
    });
    describe('createCwppButtonConfig', () => {
        const configKeysResult = [
            'fullPage', 'responseType', 'containerid', 'scopes',
            'theme', 'buttonSize', 'buttonShape', 'buttonType',
            'appid', 'locale', 'returnurl', 'authend'
        ];

        before(() => {
            request.getLocale = () => 'default';
            getLocaleWithHyphen.returns('en-us');
        });

        after(() => {
            getLocaleWithHyphen.reset();
        });

        it('should return an object with config for login flow', () => {
            const val = buttonConfigHelper.createCwppButtonConfig('login');

            expect(val).to.be.an('object').that.is.not.empty;
            expect(val).to.have.all.keys(configKeysResult);
        });

        it('should return an object with config for billing flow', () => {
            const val = buttonConfigHelper.createCwppButtonConfig('billing');

            expect(val).to.be.an('object').that.is.not.empty;
            expect(val).to.have.all.keys(configKeysResult);
        });

        it('should return empty object for minicart flow', () => {
            const val = buttonConfigHelper.createCwppButtonConfig('minicart');

            expect(val).to.be.an('object').that.is.empty;
        });

        it('should return empty object for cart flow', () => {
            const val = buttonConfigHelper.createCwppButtonConfig('cart');

            expect(val).to.be.an('object').that.is.empty;
        });

        it('should return empty object for pdp flow', () => {
            const val = buttonConfigHelper.createCwppButtonConfig('pdp');

            expect(val).to.be.an('object').that.is.empty;
        });
    });
});
