/* eslint-disable object-curly-newline */

const { int_paypal: { paypalProcessorHelperPath } } = require('../path.json');

const { stub, test: sinonTest } = require('sinon');
const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({ plugins: ['babel-plugin-rewire'] });

const createPaymentInstrument = stub();
const getPaypalPaymentInstrument = stub();
const getTransactionId = stub();
const getTransactionStatus = stub();
const prepareTransactionHistory = stub();

const paypalProcessorHelper = proxyquire(paypalProcessorHelperPath, {
    '*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper': {
        createPaymentInstrument,
        getPaypalPaymentInstrument
    },
    '*/cartridge/config/paypalConstants': {
        PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD: 'PAYPAL_CREDIT_CARD'
    },
    '*/cartridge/scripts/paypal/helpers/paypalHelper': {
        getTransactionId,
        getTransactionStatus,
        prepareTransactionHistory
    }
});

describe('paypalProcessorHelper file', () => {
    describe('handlePaymentInstrument', () => {
        const basket = {};
        const billingForm = {
            paymentMethod: {
                value: 'PayPal'
            },
            paypal: {
                usedPaymentMethod: {
                    value: ''
                }
            }
        };

        it('should return paypal payment instrument from basket', sinonTest(() => {
            getPaypalPaymentInstrument.returns({
                paymentMethod: 'PayPal',
                paymentTransaction: {}
            });

            expect(paypalProcessorHelper.handlePaymentInstrument).to.be.a('function');
            expect(paypalProcessorHelper.handlePaymentInstrument(basket, billingForm)).to.be.an('object').that.deep.equal({
                paymentMethod: 'PayPal',
                paymentTransaction: {}
            });
        }));

        it('should create paypal payment instrument if it is not found in basket', sinonTest(() => {
            getPaypalPaymentInstrument.returns(null);
            createPaymentInstrument.returns({
                paymentMethod: 'PayPal',
                paymentTransaction: {}
            });

            expect(paypalProcessorHelper.handlePaymentInstrument(basket, billingForm));
        }));
    });

    describe('handleBaShippingAddress', () => {
        const shippingAddress = {};
        const billingAgreementDetails = {
            billing_info: {
                billing_address: {
                    line1: '473 Wiseman Street',
                    line2: '',
                    city: 'Servierville',
                    postalCode: '37862',
                    countryCode: 'US',
                    state: 'TN'
                },
                first_name: 'John',
                last_name: 'Doe',
                phone: '+1234567890'
            }
        };

        it('should fill shipping address from billing_address if shipping_address was not set', () => {
            expect(paypalProcessorHelper.handleBaShippingAddress).to.be.a('function');
            expect(paypalProcessorHelper.handleBaShippingAddress(shippingAddress, billingAgreementDetails)).to.be.deep.equal({
                line1: '473 Wiseman Street',
                line2: '',
                city: 'Servierville',
                postalCode: '37862',
                countryCode: 'US',
                state: 'TN',
                recipient_name: 'John Doe',
                phone: '+1234567890'
            });
        });

        it('should return shipping address from billingAgreementDetails if shipping_address was set', () => {
            billingAgreementDetails.shipping_address = {
                line1: '472 Wiseman Street',
                line2: '',
                city: 'Servierville',
                postalCode: '37863',
                countryCode: 'US',
                state: 'TN'
            };

            expect(paypalProcessorHelper.handleBaShippingAddress(shippingAddress, billingAgreementDetails)).to.be.deep.equal({
                line1: '472 Wiseman Street',
                line2: '',
                city: 'Servierville',
                postalCode: '37863',
                countryCode: 'US',
                state: 'TN',
                phone: '+1234567890'
            });
        });
    });

    describe('clearCurrentPaypalEmail', () => {
        it('should remove currentPaypalEmail value from paymentInstrument', sinonTest(() => {
            const paymentInstrument = { custom: { currentPaypalEmail: 'test@paypal.com' } };

            expect(paypalProcessorHelper.clearCurrentPaypalEmail).to.be.a('function');

            stub(dw.system.Transaction, 'wrap').callsArg(0);

            expect(paypalProcessorHelper.clearCurrentPaypalEmail(paymentInstrument)).to.be.an('undefined');
            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;
            expect(paymentInstrument.custom.currentPaypalEmail).to.be.null;

            dw.system.Transaction.wrap.restore();
        }));
    });

    describe('saveGeneralTransactionData', () => {
        const paymentInstrument = {
            paymentTransaction: {
                custom: {}
            },
            getPaymentTransaction: () => {
                return {
                    setTransactionID: () => {}
                };
            },
            custom: {}
        };

        it('should be a function', () => {
            expect(paypalProcessorHelper.saveGeneralTransactionData).to.be.a('function');
        });

        it('should save a general transaction data', () => {
            expect(paypalProcessorHelper.saveGeneralTransactionData(paymentInstrument, {}, {})).to.be.an('undefined');
        });
    });

    describe('getPaymentMethodId', () => {
        const billingForm = {
            paypal: {
                usedPaymentMethod: {
                    value: 'PAYPAL_CREDIT_CARD'
                }
            }
        };

        it('should be a function', () => {
            expect(paypalProcessorHelper.getPaymentMethodId).to.be.a('function');
        });

        it('should return PAYPAL_CREDIT_CARD string', () => {
            expect(paypalProcessorHelper.getPaymentMethodId(billingForm)).to.be.deep.equal('PAYPAL_CREDIT_CARD');
        });

        it('should return PayPal string', () => {
            const PAYMENT_METHOD_PAYPAL = 'PayPal';

            billingForm.paypal.usedPaymentMethod.value = PAYMENT_METHOD_PAYPAL;
            billingForm.paymentMethod = {
                value: PAYMENT_METHOD_PAYPAL
            };

            expect(paypalProcessorHelper.getPaymentMethodId(billingForm)).to.be.deep.equal(PAYMENT_METHOD_PAYPAL);
        });
    });
});
