const { int_paypal: { authorizationAndCaptureWhHelperPath } } = require('../path.json');

const { expect } = require('chai');
const {
    describe, it, before, after
} = require('mocha');

const { stub } = require('sinon');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const paymentInstrument = {
    custom: {},
    paymentTransaction: {
        custom: {}
    }
};

const authorizationAndCaptureWhHelper
    = proxyquire(authorizationAndCaptureWhHelperPath, {
        'dw/system/Transaction': dw.system.Transaction,
        '*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper': {
            getPaypalPaymentInstrument: () => paymentInstrument
        },
        '*/cartridge/scripts/paypal/helpers/paypalHelper': {
            prepareTransactionHistory: () => ([])
        },
        'dw/object/CustomObject': dw.object.CustomObject,
        'dw/web/Resource': dw.web.Resource
    });

describe('autorizationAndCaptureWhHelper', () => {
    it('authorizationAndCaptureWhHelper is object', () => {
        expect(authorizationAndCaptureWhHelper).to.be.a('object');
    });

    it('authorizationAndCaptureWhHelper has own property updateOrderPaymentStatus', () => {
        expect(authorizationAndCaptureWhHelper).to.haveOwnProperty('updateOrderPaymentStatus');
    });

    it('authorizationAndCaptureWhHelper.updateOrderPaymentStatus is a function', () => {
        expect(authorizationAndCaptureWhHelper.updateOrderPaymentStatus).to.be.a('function');
    });

    describe('updateOrderPaymentStatus', () => {
        let order = {};
        const paymentStatus = 'AUTHORIZED';
        const responseData = {};

        before(() => {
            stub(dw.web.Resource, 'msg');

            dw.web.Resource.msg.withArgs('paypal.request.webhook.summary', 'locale', null).returns('The webhook for event notifications from the PayPal REST API has fired.');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('If order is not instance of CustomObject', () => {
            authorizationAndCaptureWhHelper.updateOrderPaymentStatus(order, paymentStatus, responseData);

            expect(paymentInstrument.custom).to.have.all.keys('paypalPaymentStatus', 'paypalRequest', 'paypalResponse');
            expect(paymentInstrument.custom.paypalPaymentStatus).to.equal('AUTHORIZED');
        });

        it('If order is instance of CustomObject', () => {
            order = Object.assign(new dw.object.CustomObject(), { custom: {} });

            authorizationAndCaptureWhHelper.updateOrderPaymentStatus(order, paymentStatus, responseData);

            expect(order.custom).to.have.all.keys('paymentStatus', 'paypalRequest', 'paypalResponse', 'paypalTransactionHistory');
            expect(order.custom.paymentStatus).to.equal('AUTHORIZED');
        });
    });
});
