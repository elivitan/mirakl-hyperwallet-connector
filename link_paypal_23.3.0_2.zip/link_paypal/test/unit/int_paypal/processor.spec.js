/* eslint-disable object-curly-newline */

const { int_paypal: { processorPath } } = require('../path.json');

const { stub } = require('sinon');
const { expect } = require('chai');
const { describe, it, before, after } = require('mocha');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({ plugins: ['babel-plugin-rewire'] });

const createPaymentInstrument = stub();
const getPaypalPaymentInstrument = stub();
const calculateNonGiftCertificateAmount = stub();
const isBillingAgreementID = stub();
const isSameBillingAgreement = stub();
const getBaFromPaymentInstument = stub();
const handleBaShippingAddress = stub();
const clearCurrentPaypalEmail = stub();
const createBAReqBody = stub();
const createBaFromForm = stub();
const getPurchaseUnit = stub();
const isPurchaseUnitChanged = stub();
const createErrorLog = stub();
const handleError = stub();
const encodeString = stub();
const updateBillingInfoIfAccountChanged = stub();
const updateOrderBillingAddress = stub();
const updateBABillingAddress = stub();
const validateCheckoutOrdersPaypalAddresses = stub();
const validateBaPaypalAddresses = stub();
const getOrderDetails = stub();
const getBADetails = stub();
const updateOrderDetails = stub();
const createTransaction = stub();
const createOrder = stub();
const saveOrder = stub();
const getTransactionId = stub();
const getTransactionStatus = stub();
const prepareTransactionHistory = stub();
const isSavedCardFlow = stub();
const stringifyBillingAddress = stub();
const saveCreditCardToCustomerWallet = stub();

const DEBIT_CREDIT_CARD_ID = 'PayPal Debit/Credit Card';

const paypalPreferences = {
    saveOrderFlow: false
};

const resources = {
    paypal: {
        error: {
            general: 'An error occurs, please try again'
        }
    }
};

request.httpReferer = 'https://dx.commercecloud.salesforce.com/on/demandware.store/Sites-RefArch-Site/en_US/Cart-Show';

const processor = proxyquire(processorPath, {
    'dw/order/Order': dw.order.Order,
    'dw/system/Transaction': dw.system.Transaction,
    'dw/web/Resource': dw.web.Resource,
    '*/cartridge/config/paypalPreferences': paypalPreferences,
    '*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper': { createPaymentInstrument, getPaypalPaymentInstrument, calculateNonGiftCertificateAmount },
    '*/cartridge/scripts/paypal/helpers/billingAgreementHelper': {
        createBAReqBody,
        createBaFromForm,
        isBillingAgreementID,
        isSameBillingAgreement,
        getBaFromPaymentInstument
    },
    '*/cartridge/scripts/paypal/helpers/paypalHelper': {
        getPurchaseUnit,
        isPurchaseUnitChanged,
        getTransactionId,
        getTransactionStatus,
        prepareTransactionHistory,
        updateBillingInfoIfAccountChanged,
        stringifyBillingAddress
    },
    '*/cartridge/scripts/paypal/paypalUtils': {
        createErrorLog,
        encodeString,
        handleError
    },
    '*/cartridge/scripts/paypal/helpers/addressHelper': {
        updateOrderBillingAddress,
        updateBABillingAddress,
        validateCheckoutOrdersPaypalAddresses,
        validateBaPaypalAddresses
    },
    '*/cartridge/scripts/paypal/paypalApi': {
        getOrderDetails,
        getBADetails,
        updateOrderDetails,
        createTransaction,
        createOrder,
        saveOrder
    },
    '*/cartridge/config/paypalConstants': {
        PAYMENT_METHOD_ID_VENMO: 'venmo',
        PAYMENT_METHOD_ID_Debit_Credit_Card: DEBIT_CREDIT_CARD_ID,
        PAYMENT_METHOD_ID_PAYPAL: 'PayPal',
        STATUS_SAVED: 'SAVED',
        PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD: 'PAYPAL_CREDIT_CARD'
    },
    '*/cartridge/scripts/util/collections': {
        forEach: () => {}
    },
    '*/cartridge/scripts/paypal/helpers/paypalProcessorHelper': {
        clearCurrentPaypalEmail,
        handleBaShippingAddress,
        handlePaymentInstrument: () => ({
            paymentMethod: 'PayPal',
            UUID: 'ee6d20764050743b97cab7e8f6',
            custom: {
                paypalOrderID: '8UU486582S253361B'
            }
        }),
        saveGeneralTransactionData: () => {}
    },
    '*/cartridge/scripts/paypal/helpers/creditCardHelper': {
        isSavedCardFlow: isSavedCardFlow,
        formatComplexCCBrandCode: () => {},
        saveCreditCardToCustomerWallet: saveCreditCardToCustomerWallet
    }
});

describe('processor file', () => {
    before(() => {
        session.privacy = {};
    });

    describe('handleOrderDetailsError', () => {
        before(() => {
            stub(dw.web.Resource, 'msg');
        });

        after(() => {
            createErrorLog.reset();
            dw.web.Resource.msg.restore();
        });

        it('should return an error object', () => {
            dw.web.Resource.msg.returns(resources.paypal.error.general);

            expect(processor.__get__('handleOrderDetailsError')(resources.paypal.error.general))
                .that.deep.equal({
                    error: true,
                    fieldErrors: [],
                    serverErrors: [resources.paypal.error.general]
                });

            expect(createErrorLog.calledOnce).to.be.true;
        });
    });

    describe('handleBillingAgreementFlow', () => {
        const basket = {};
        const billingForm = {};
        const paymentInstrument = { custom: {} };
        const billingInfo = {
            billing_address: {
                city: 'Pond',
                country_code: 'US',
                line1: '4866 Rodney Street',
                postal_code: '63040',
                state: 'MO'
            },
            email: 'I.VinogradovVN@gmail.com',
            first_name: 'Ivan',
            last_name: 'C Vinogradov',
            payer_id: 'QMG34HJTGX6NU',
            phone: '408-922-3384'
        };

        let shippingAddress = {
            city: 'Pond',
            country_code: 'US',
            line1: '4866 Rodney Street',
            postal_code: '63040',
            state: 'MO',
            recipient_name: 'Ivan C Vinogradov',
            phone: '408-922-3384'
        };

        const handleBillingAgreementFlow = processor.__get__('handleBillingAgreementFlow');

        before(() => {
            stub(dw.web.Resource, 'msg');

            createBaFromForm.returns({
                default: true,
                saveToProfile: true,
                baID: 'B-73122468JR707841D',
                email: 'I.VinogradovVN@gmail.com'
            });

            getBADetails.returns({ billing_info: billingInfo });
            getBaFromPaymentInstument.returns({});
        });

        after(() => {
            getBADetails.reset();
            createBaFromForm.reset();
            dw.web.Resource.msg.restore();
        });

        it('should return an object with property shipping address that is equal to shippin address argument of function', () => {
            expect(handleBillingAgreementFlow).to.be.a('function');

            expect(handleBillingAgreementFlow(basket, billingForm, shippingAddress, paymentInstrument))
                .to.be.an('object')
                .that.deep.equal({
                    shippingAddress: shippingAddress
                });

            expect(createBaFromForm.calledOnce).to.be.true;
            expect(getBaFromPaymentInstument.calledOnce).to.be.true;
            expect(getBADetails.calledOnce).to.be.true;
            expect(isSameBillingAgreement.calledOnce).to.be.true;
            expect(updateBillingInfoIfAccountChanged.calledOnce).to.be.true;
            expect(updateBABillingAddress.called).to.be.false;
        });

        it('should called updateBABillingAddress function if billing agreement is the same', () => {
            updateBillingInfoIfAccountChanged.reset();

            getBaFromPaymentInstument.returns(null);

            expect(handleBillingAgreementFlow(basket, billingForm, shippingAddress, paymentInstrument))
                .that.deep.equal({
                    shippingAddress: shippingAddress
                });

            expect(updateBillingInfoIfAccountChanged.calledOnce).to.be.false;
            expect(updateBABillingAddress.calledOnce).to.be.true;
        });

        it('should return an object with error true if getBADetails return err', () => {
            getBADetails.returns({ err: 'error message' });
            dw.web.Resource.msg.returns(resources.paypal.error.general);

            expect(handleBillingAgreementFlow(basket, billingForm, shippingAddress, paymentInstrument))
                .that.deep.equal({
                    error: true,
                    fieldErrors: [],
                    serverErrors: [resources.paypal.error.general]
                });

            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('should return an object with error true if shippingAddress is not set or undefined', () => {
            shippingAddress = null;

            getBADetails.returns({});
            validateBaPaypalAddresses.returns({});
            handleBaShippingAddress.returns({
                city: 'NY',
                country: 'US',
                recipient_name: 'John Doe'
            });

            expect(handleBillingAgreementFlow(basket, billingForm, shippingAddress, paymentInstrument))
                .that.deep.equal({
                    shippingAddress: {
                        city: 'NY',
                        country: 'US',
                        recipient_name: 'John Doe'
                    }
                });

            expect(validateBaPaypalAddresses.calledOnce).to.be.true;
            expect(handleBaShippingAddress.calledOnce).to.be.true;
        });

        it('should return an object with error true if shippingAddress is not set or undefined', () => {
            validateBaPaypalAddresses.reset().returns({
                error: true,
                fields: {},
                message: 'Please enter a valid shipping address.',
                errorName: 'shipping.address.invalid'
            });

            expect(handleBillingAgreementFlow(basket, billingForm, shippingAddress, paymentInstrument))
                .that.deep.equal({
                    error: true,
                    errorName: 'shipping.address.invalid',
                    statusCode: 422,
                    fieldErrors: [{}],
                    serverErrors: ['Please enter a valid shipping address.']
                });

            expect(validateBaPaypalAddresses.calledOnce).to.be.true;
            expect(clearCurrentPaypalEmail.calledOnce).to.be.true;
        });
    });

    describe('handleOrderIdFlow', () => {
        const basket = {};
        const paymentInstrument = { custom: {} };
        const billingForm = { paypal: { usedPaymentMethod: { value: 'PayPal' } } };

        const payer = {
            address: {},
            email_address: 'I.VinogradovVN@gmail.com',
            name: {},
            payer_id: 'QMG34HJTGX6NU',
            phone_number: {
                national_number: '4084607119',
                phone_type: 'HOME'
            },
            phone: '4084607119'
        };

        const purchaseUnits = [{
            amount: {},
            description: 'Casual Spring Easy Jacket',
            invoice_id: '00003402',
            payee: {
                email_address: 'user@business.example.com',
                merchant_id: 'BZKDAFFRXNJ7G'
            }
        }];

        const handleOrderIdFlow = processor.__get__('handleOrderIdFlow');

        before(() => {
            stub(dw.web.Resource, 'msg');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('should return an object with shipping address property', () => {
            getOrderDetails.returns({ payer, purchase_units: purchaseUnits });
            validateCheckoutOrdersPaypalAddresses.returns({ error: false });

            expect(handleOrderIdFlow).to.be.a('function');

            expect(handleOrderIdFlow(basket, billingForm, paymentInstrument))
                .to.be.an('object')
                .that.deep.equal({
                    shippingAddress: {
                        amount: {},
                        description: 'Casual Spring Easy Jacket',
                        invoice_id: '00003402',
                        payee: {
                            email_address: 'user@business.example.com',
                            merchant_id: 'BZKDAFFRXNJ7G'
                        },
                        phone: '4084607119'
                    }
                });
        });

        it('should return an object with error if validation for checkout orders paypal addresses is failed', () => {
            validateCheckoutOrdersPaypalAddresses.returns({
                error: true,
                errorName: 'shipping.address.invalid',
                fields: { country: 'Invalid field' },
                message: 'Shipping address validation is failure'
            });

            expect(handleOrderIdFlow(basket, billingForm, paymentInstrument))
                .to.deep.equal({
                    error: true,
                    errorName: 'shipping.address.invalid',
                    statusCode: 422,
                    fieldErrors: [{ country: 'Invalid field' }],
                    serverErrors: ['Shipping address validation is failure']
                });
        });

        it('should return an object with error if getOrderDetails is failed', () => {
            getOrderDetails.returns({ payer, purchase_units: purchaseUnits, err: {} });
            dw.web.Resource.msg.returns(resources.paypal.error.general);

            expect(handleOrderIdFlow(basket, billingForm, paymentInstrument))
                .to.deep.equal({
                    error: true,
                    fieldErrors: [],
                    serverErrors: [resources.paypal.error.general]
                });
        });
    });

    describe('checkOrderValidity', () => {
        const order = { status: 'new' };
        const paymentInstrument = {
            paymentTransaction: {
                amount: { value: 10 }
            }
        };

        const checkOrderValidity = processor.__get__('checkOrderValidity');

        before(() => {
            stub(dw.web.Resource, 'msg');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('should return an object with property error equal to false', () => {
            expect(checkOrderValidity).to.be.a('function');

            expect(checkOrderValidity(order, paymentInstrument))
                .to.be.an('object')
                .that.deep.equal({
                    error: false,
                    fieldErrors: [],
                    serverErrors: []
                });
        });

        it('should return an object with property error equal to true if payment transaction abount is zero', () => {
            dw.web.Resource.msg.returns('Order total 0 is not allowed for PayPal');
            paymentInstrument.paymentTransaction.amount.value = 0;

            expect(checkOrderValidity(order, paymentInstrument))
                .that.deep.equal({
                    error: true,
                    fieldErrors: [],
                    serverErrors: ['Order total 0 is not allowed for PayPal']
                });
        });

        it('should return an object with property error equal to true if paymentInstrument is empty', () => {
            dw.web.Resource.msg.returns(resources.paypal.error.general);
            order.status = 8;

            expect(checkOrderValidity(order, paymentInstrument))
                .that.deep.equal({
                    error: true,
                    fieldErrors: [],
                    serverErrors: [resources.paypal.error.general]
                });
        });

        it('should return an object with property error equal to true if order is empty', () => {
            delete order.status;

            expect(checkOrderValidity(order, paymentInstrument))
                .that.deep.equal({
                    error: true,
                    fieldErrors: [],
                    serverErrors: [resources.paypal.error.general]
                });
        });

        it('should return an object with property error equal to true if order status is failed', () => {
            delete paymentInstrument.paymentTransaction;

            expect(checkOrderValidity(order, paymentInstrument))
                .that.deep.equal({
                    error: true,
                    fieldErrors: [],
                    serverErrors: [resources.paypal.error.general]
                });
        });
    });

    describe('handle', () => {
        const basket = {};
        const shippingAddress = {
            city: 'Pond',
            country_code: 'US',
            line1: '4866 Rodney Street',
            postal_code: '63040',
            state: 'MO',
            recipient_name: 'Ivan C Vinogradov',
            phone: '408-922-3384'
        };

        const paymentInformation = {
            billingForm: {
                paypal: {
                    usedPaymentMethod: {
                        value: 'paypal'
                    }
                }
            }
        };

        before(() => {
            processor.__set__('handleBillingAgreementFlow', () => ({ shippingAddress: shippingAddress }));
            processor.__set__('handleOrderIdFlow', () => ({ shippingAddress: shippingAddress }));
        });

        after(() => {
            processor.__ResetDependency__('handleBillingAgreementFlow');
            processor.__ResetDependency__('handleOrderIdFlow');
        });

        it('should return an object for billing agreement flow', () => {
            isBillingAgreementID.returns(true);

            expect(processor.handle(basket, paymentInformation, shippingAddress))
                .to.deep.equal({
                    success: true,
                    shippingAddress: shippingAddress,
                    paymentInstrument: {
                        paymentMethod: 'PayPal',
                        UUID: 'ee6d20764050743b97cab7e8f6',
                        custom: {
                            paypalOrderID: '8UU486582S253361B'
                        }
                    }
                });
        });

        it('should return an object for order id flow', () => {
            isBillingAgreementID.returns(false);

            expect(processor.handle(basket, paymentInformation, shippingAddress))
                .to.deep.equal({
                    success: true,
                    shippingAddress: shippingAddress,
                    paymentInstrument: {
                        paymentMethod: 'PayPal',
                        UUID: 'ee6d20764050743b97cab7e8f6',
                        custom: {
                            paypalOrderID: '8UU486582S253361B'
                        }
                    }
                });
        });

        it('should return an object with error', () => {
            processor.__set__('handleOrderIdFlow', () => ({
                error: true,
                fieldErrors: [],
                serverErrors: []
            }));

            expect(processor.handle(basket, paymentInformation, shippingAddress))
                .to.deep.equal({
                    error: true,
                    fieldErrors: [],
                    serverErrors: []
                });
        });
    });

    describe('handleAuthorizeBillingAgreement', () => {
        const order = {};
        const purchaseUnit = {};
        const paymentInstrument = {
            paymentMethod: 'PAYPAL_CREDIT_CARD',
            custom: {
                paypalOrderID: null,
                PP_API_ActiveBillingAgreement: 'billing-agreement-data'
            }
        };

        const handleAuthorizeBillingAgreement = processor.__get__('handleAuthorizeBillingAgreement');

        before(() => {});

        after(() => {});

        afterEach(() => {
            createOrder.reset();
            createErrorLog.reset();
            createBAReqBody.reset();
        });

        it('should return an empty object if condition is false', () => {
            expect(handleAuthorizeBillingAgreement(order, paymentInstrument, purchaseUnit)).to.be.an('object').that.empty;
        });

        it('should return an object if condition is true', () => {
            const resp = {
                payment_source: {
                    token: {
                        id: 'billing-agreement-id',
                        type: 'BILLING_AGREEMENT'
                    }
                }
            };

            paymentInstrument.paymentMethod = 'PayPal';
            createOrder.returns({ resp: { id: 'paypal-order-id' } });
            createBAReqBody.returns(resp);

            expect(handleAuthorizeBillingAgreement(order, paymentInstrument, purchaseUnit)).to.deep.equal(resp);
            expect(paymentInstrument.custom.paypalOrderID).to.be.equal('paypal-order-id');
            expect(createOrder.calledOnce).to.be.true;
            expect(createBAReqBody.calledOnce).to.be.true;
        });

        it('should return an object with error data', () => {
            const errorMessage = 'error message';

            paymentInstrument.paymentMethod = 'PayPal';
            createOrder.returns({ err: errorMessage });

            expect(handleAuthorizeBillingAgreement(order, paymentInstrument, purchaseUnit)).to.deep.equal({
                error: true,
                authorized: false,
                fieldErrors: [],
                serverErrors: [errorMessage],
                message: errorMessage
            });

            expect(createOrder.calledOnce).to.be.true;
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('should catch an error from createBAReqBody method', () => {
            const error = new SyntaxError('JSON.parse: unexpected character');

            paymentInstrument.paymentMethod = 'PayPal';
            createOrder.returns({ resp: { id: 'paypal-order-id' } });
            createBAReqBody.throws(error);

            expect(handleAuthorizeBillingAgreement(order, paymentInstrument, purchaseUnit)).to.deep.equals({
                error: true,
                authorized: false,
                fieldErrors: [],
                serverErrors: [error]
            });

            expect(createOrder.calledOnce).to.be.true;
            expect(createBAReqBody.calledOnce).to.be.true;
            expect(createErrorLog.calledOnce).to.be.true;
        });
    });

    describe('authorize', () => {
        let purchaseUnit = {
            amount: {},
            description: 'Long Sleeve Crew Neck',
            invoice_id: '00003603',
            shipping: {}
        };

        let order = {};
        let paymentInstrument = {
            custom: {}
        };

        isPurchaseUnitChanged.returns(true);
        getPurchaseUnit.returns(purchaseUnit);

        before(() => {
            stub(dw.web.Resource, 'msg');

            createBAReqBody.returns({
                payment_source: {
                    token: {
                        id: 'B-7J122468JR707841D',
                        type: 'BILLING_AGREEMENT'
                    }
                }
            });

            getTransactionId.returns('7ML06956NU4656408');
            getTransactionStatus.returns('COMPLETED');
            prepareTransactionHistory.returns([]);
        });

        after(() => {
            dw.web.Resource.msg.restore();

            getTransactionId.reset();
            getTransactionStatus.reset();
            prepareTransactionHistory.reset();
        });

        afterEach(() => {
            createErrorLog.reset();
            updateOrderDetails.reset();
            createOrder.reset();
            createTransaction.reset();
            saveOrder.reset();
            saveCreditCardToCustomerWallet.reset();
            paypalPreferences.saveOrderFlow = false;
        });

        it('should return object {error: true} if paymentInstrument or order is empty ', () => {
            dw.web.Resource.msg.returns('Some server error');
            expect(processor.authorize(order, paymentInstrument)).to.deep.equal({
                error: true,
                fieldErrors: [],
                serverErrors: ['Some server error']
            });
        });

        it('should return object {error: true} if paymentInstrument.paymentTransaction.amount.value is 0', () => {
            dw.web.Resource.msg.returns('Some server error');
            const paymentInstrument2 = {
                paymentTransaction: {
                    amount: {
                        value: 0
                    }
                },
                custom: {
                    payPalOrderStatus: ''
                }
            };

            const order2 = {
                status: {
                    displayValue: 'CREATED',
                    value: 0
                }
            };

            expect(processor.authorize(order2, paymentInstrument2)).to.deep.equal({
                error: true,
                fieldErrors: [],
                serverErrors: ['Some server error']
            });
        });

        it('shoud return {authorized: true} if BA is active', () => {
            let paymentInstrument3 = {
                paymentTransaction: { amount: { value: 47.23 }, custom: {} },
                paymentMethod: 'PAYPAL_CREDIT_CARD',
                creditCardHolder: 'Card Holder',
                creditCardToken: null,
                custom: {
                    currentPayPalEmail: 'I.VinogradovVN@gmail.com',
                    PP_API_ActiveBillingAgreement: '{"baID":"B-73122468JR707841D","default":true,"email":"I.VinogradovVN@gmail.com","saveToProfile":true}',
                    payPalOrderStatus: '',
                    payPalSaveCreditCard: true,
                    paypalCreditCardBillingAddress: 'billingAddress'
                },
                getPaymentTransaction: () => {
                    return { setTransactionID: () => { } };
                }
            };

            let order3 = {
                createdBy: 'Customer',
                currencyCode: 'USD',
                currentOrderNo: '00003605',
                customerEmail: 'I.VinogradovVN@gmail.com',
                customerLocaleID: 'en_US',
                customerName: 'Ivan C Vinofradov',
                status: {
                    displayValue: 'CREATED',
                    value: 0
                },
                custom: {}
            };

            let resp = {
                id: '7ML06956NU4656408',
                links: [
                    {
                        href: 'https://api.sandbox.paypal.com/v2/checkout/orders/7ML06956NU4656408',
                        method: 'GET',
                        rel: 'self'
                    },
                    {
                        href: 'https://www.sandbox.paypal.com/checkoutnow?token=7ML06956NU4656408',
                        method: 'GET',
                        rel: 'approve'
                    },
                    {
                        href: 'https://api.sandbox.paypal.com/v2/checkout/orders/7ML06956NU4656408',
                        method: 'PATCH',
                        rel: 'update'
                    },
                    {
                        href: 'https://api.sandbox.paypal.com/v2/checkout/orders/7ML06956NU4656408',
                        method: 'POST',
                        rel: 'authorize'
                    }
                ],
                status: 'CREATED'
            };

            updateOrderDetails.returns({});
            createOrder.returns({ resp });
            createTransaction.returns({
                response: {
                    status: 'COMPLETED'
                }
            });

            expect(processor.authorize(order3, paymentInstrument3)).to.deep.equal({ authorized: true });
        });

        it('If on order details update error was thrown', () => {
            const paymentInstrument4 = {
                custom: { paypalOrderID: 'id' },
                paymentTransaction: {
                    amount: { value: 100 }
                }
            };

            const order4 = { status: 'AUTHORIZED' };

            updateOrderDetails.returns({ err: 'updateOrderDetailsError' });

            const result = processor.authorize(order4, paymentInstrument4);

            expect(result).to.be.an('object');
            expect(result.message).to.equal('updateOrderDetailsError');
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If order details were successfully updated', () => {
            const paymentInstrument4 = {
                custom: {
                    paypalOrderID: 'id',
                    payPalOrderStatus: ''
                },
                paymentTransaction: {
                    custom: {},
                    amount: { value: 100 }
                },
                getPaymentTransaction: () => {
                    return { setTransactionID: () => { } };
                }
            };

            const order4 = {
                status: 'AUTHORIZED',
                custom: {}
            };

            updateOrderDetails.returns({});

            const result = processor.authorize(order4, paymentInstrument4);

            expect(result).to.be.an('object');
            expect(result.authorized).to.be.true;
            expect(createErrorLog.calledOnce).to.be.false;
        });

        it('If on order creation error was thrown', () => {
            const paymentInstrument5 = {
                custom: {
                    paypalOrderID: 'id',
                    PP_API_ActiveBillingAgreement: true
                },
                paymentTransaction: {
                    amount: { value: 100 }
                }
            };

            const order5 = { status: 'AUTHORIZED' };

            createOrder.returns({ err: 'createOrder' });

            const result = processor.authorize(order5, paymentInstrument5);

            expect(result).to.be.an('object');
            expect(result.error).to.be.true;
            expect(result.message).to.equal('createOrder');
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If on BA req body creation error was thrown', () => {
            const paymentInstrument5 = {
                custom: {
                    paypalOrderID: 'id',
                    PP_API_ActiveBillingAgreement: true
                },
                paymentTransaction: {
                    amount: { value: 100 }
                }
            };

            const order5 = { status: 'AUTHORIZED' };

            createOrder.returns({ resp: { id: 'id' }, err: false });
            createBAReqBody.throwsException();

            const result = processor.authorize(order5, paymentInstrument5);

            expect(result).to.be.an('object');
            expect(result.error).to.be.true;
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If on transaction creation error was thrown', () => {
            const paymentInstrument5 = {
                custom: {
                    paypalOrderID: 'id',
                    PP_API_ActiveBillingAgreement: false
                },
                paymentTransaction: {
                    amount: { value: 100 }
                }
            };

            const order5 = { status: 'AUTHORIZED', custom: {} };

            createTransaction.returns({ err: 'Error' });

            const result = processor.authorize(order5, paymentInstrument5);

            expect(result).to.be.an('object');
            expect(result.error).to.be.true;
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If Save Order Flow is on', () => {
            const paymentInstrument5 = {
                custom: {
                    paypalOrderID: 'id',
                    PP_API_ActiveBillingAgreement: false
                },
                paymentTransaction: {
                    amount: { value: 100 },
                    custom: {}
                }
            };

            calculateNonGiftCertificateAmount.returns({
                value: 40.50
            });

            saveOrder.returns({ status: 'SAVED' });

            const order5 = { status: 'AUTHORIZED', custom: {} };

            paypalPreferences.saveOrderFlow = true;

            const result = processor.authorize(order5, paymentInstrument5);

            expect(result).to.be.an('object');
            expect(result.authorized).to.be.false;
            expect(createErrorLog.calledOnce).to.be.false;
        });
    });
});
