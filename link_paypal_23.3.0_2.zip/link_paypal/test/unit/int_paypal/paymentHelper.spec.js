/* eslint-disable object-curly-newline */

const { int_paypal: { paymentHelperPath } } = require('../path.json');

const { expect } = require('chai');
const { stub, createStubInstance } = require('sinon');
const { describe, it, before, after } = require('mocha');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const originalSession = global.session;

const pluralize = stub();
const customerModel = stub();
const getExpirationMonthDiff = stub();

const prefs = {
    creditCardExpireNotification: -1
};

const paypalConstants = {
    FLASH_MESSAGE_DANGER: 'danger',
    FLASH_MESSAGE_WARNING: 'warning'
};

customerModel.FLASH_MESSAGE_DANGER = 'danger';
customerModel.FLASH_MESSAGE_WARNING = 'warning';

const paymentHelper = proxyquire(paymentHelperPath, {
    'dw/web/Resource': dw.web.Resource,
    'dw/order/PaymentMgr': dw.order.PaymentMgr,
    'dw/system/Transaction': dw.system.Transaction,
    '*/cartridge/models/customer': customerModel,
    '*/cartridge/config/paypalPreferences': prefs,
    '*/cartridge/config/paypalConstants': paypalConstants,
    '*/cartridge/scripts/util/basicHelpers': {
        pluralize,
        getExpirationMonthDiff
    }
});

describe('paymentHelper file', () => {
    describe('getActivePaymentMethods', () => {
        before(() => {
            stub(dw.order.PaymentMgr, 'getActivePaymentMethods');

            dw.order.PaymentMgr.getActivePaymentMethods.returns({
                toArray: () => [
                    { active: true, ID: 'CREDIT_CARD' },
                    { active: true, ID: 'PayPal' },
                    { active: false, ID: 'Venmo' }
                ]
            });
        });

        after(() => {
            dw.order.PaymentMgr.getActivePaymentMethods.restore();
        });

        it('should return object with active payment methods', () => {
            expect(paymentHelper.getActivePaymentMethods())
                .to.be.an('object')
                .that.deep.equal({
                    CREDIT_CARD: { isActive: true, paymentMethodId: 'CREDIT_CARD' },
                    PayPal: { isActive: true, paymentMethodId: 'PayPal' },
                    Venmo: { isActive: false, paymentMethodId: 'Venmo' }
                });
        });

        it('should return an empty array if getActivePaymentMethods returns an empty collection', () => {
            dw.order.PaymentMgr.getActivePaymentMethods.returns({ toArray: () => [] });

            expect(paymentHelper.getActivePaymentMethods()).to.be.an('object').that.is.empty;
        });
    });

    describe('getExpirationDataForCC', () => {
        const creditCard = {
            creditCardExpirationMonth: 3,
            creditCardExpirationYear: 2023
        };

        const listOfkeys = ['expireNotification', 'expireStyle', 'expireMessage'];

        before(() => {
            stub(dw.web.Resource, 'msg');
            stub(dw.web.Resource, 'msgf');

            pluralize.returns('month');
            getExpirationMonthDiff.returns(8);

            dw.web.Resource.msg.withArgs('paypal.creditcard.expired', 'locale', null).returns('Expired');
            dw.web.Resource.msgf.withArgs('paypal.creditcard.expires', 'locale', null, 1, 'month').returns('Expires in 1 month');
        });

        after(() => {
            pluralize.reset();
            getExpirationMonthDiff.reset();

            dw.web.Resource.msg.restore();
            dw.web.Resource.msgf.restore();
        });

        it('shoud return null if expire notification is disabled', () => {
            expect(paymentHelper.getExpirationDataForCC(creditCard)).to.be.null;
        });

        it('shoud return null if expire notification is enabled and month difference is more than max expire value', () => {
            prefs.creditCardExpireNotification = 0;

            expect(paymentHelper.getExpirationDataForCC(creditCard)).to.be.null;
        });

        it('shoud return an object if expire notification is enabled (pref equal to 0 - expired)', () => {
            getExpirationMonthDiff.returns(-1);

            const val = paymentHelper.getExpirationDataForCC(creditCard);

            expect(val).to.be.an('object').that.has.all.keys(listOfkeys);

            expect(val).to.be.deep.equal({
                expireNotification: true,
                expireStyle: 'danger',
                expireMessage: 'Expired'
            });
        });

        it('shoud return an object if expire notification is enabled (pref equal to 1 - expires in 1 month)', () => {
            prefs.creditCardExpireNotification = 1;
            getExpirationMonthDiff.returns(0);

            const val = paymentHelper.getExpirationDataForCC(creditCard);

            expect(val).to.be.an('object').that.has.all.keys(listOfkeys);

            expect(val).to.be.deep.equal({
                expireNotification: true,
                expireStyle: 'warning',
                expireMessage: 'Expires in 1 month'
            });
        });

        it('shoud return an object if expire notification is enabled (pref equal to 2 - expires in 2 month)', () => {
            prefs.creditCardExpireNotification = 2;
            pluralize.returns('months');
            getExpirationMonthDiff.returns(1);

            dw.web.Resource.msgf.withArgs('paypal.creditcard.expires', 'locale', null, 2, 'months').returns('Expires in 2 months');

            const val = paymentHelper.getExpirationDataForCC(creditCard);

            expect(val).to.be.an('object').that.has.all.keys(listOfkeys);

            expect(val).to.be.deep.equal({
                expireNotification: true,
                expireStyle: 'warning',
                expireMessage: 'Expires in 2 months'
            });
        });

        it('shoud return an object if expire notification is enabled (pref equal to 3 - expires in 3 month)', () => {
            prefs.creditCardExpireNotification = 3;
            pluralize.returns('months');
            getExpirationMonthDiff.returns(2);

            dw.web.Resource.msgf.withArgs('paypal.creditcard.expires', 'locale', null, 3, 'months').returns('Expires in 3 months');

            const val = paymentHelper.getExpirationDataForCC(creditCard);

            expect(val).to.be.an('object').that.has.all.keys(listOfkeys);
            expect(val).to.be.deep.equal({
                expireNotification: true,
                expireStyle: 'warning',
                expireMessage: 'Expires in 3 months'
            });
        });
    });

    describe('addExpirationDataForCC', () => {
        const creditCard = {
            creditCardExpirationMonth: 12,
            creditCardExpirationYear: 2023
        };

        before(() => {
            stub(paymentHelper, 'getExpirationDataForCC').returns(null);
        });

        after(() => {
            paymentHelper.getExpirationDataForCC.restore();
        });

        it('credit card data should be the same', () => {
            expect(paymentHelper.addExpirationDataForCC(creditCard)).to.be.undefined;
            expect(creditCard).to.deep.equal({
                creditCardExpirationMonth: 12,
                creditCardExpirationYear: 2023
            });
        });

        it('if credit card is expired than credit card will have additional props', () => {
            creditCard.creditCardExpirationMonth = 3;
            paymentHelper.getExpirationDataForCC.returns({
                expireNotification: true,
                expireStyle: 'danger',
                expireMessage: 'Expired'
            });

            expect(paymentHelper.addExpirationDataForCC(creditCard)).to.be.undefined;
            expect(creditCard).to.deep.equal({
                creditCardExpirationMonth: 3,
                creditCardExpirationYear: 2023,
                expireNotification: true,
                expireStyle: 'danger',
                expireMessage: 'Expired'
            });
        });
    });

    describe('getExpirationNotificationForCC', () => {
        let notificationObj = {};
        const creditCard = {
            expireNotification: false,
            expireStyle: 'danger'
        };

        let paymentInstrument = {
            custom: { braintreeCreditCardExpirationNotice: null }
        };

        beforeEach(() => {
            notificationObj = {};
        });

        before(() => {
            stub(dw.web.Resource, 'msg');

            global.session = originalSession;
            global.session.custom.ccExpiredNotice = null;

            dw.web.Resource.msg.withArgs('creditcard.notification.expired', 'account', null).returns('credit card notification expired');
            dw.web.Resource.msg.withArgs('creditcard.notification.expiresoon', 'account', null).returns('credit card notification expire soon');
        });

        after(() => {
            global.session = originalSession;

            dw.web.Resource.msg.restore();
        });

        it('if expireNotification equal to false or not exist in object', () => {
            expect(paymentHelper.getExpirationNotificationForCC(notificationObj, creditCard, paymentInstrument)).to.be.undefined;
            expect(notificationObj).to.be.empty;
        });

        it('if expireStyle equal to `danger` and session custom ccExpiredNotice is not true', () => {
            creditCard.expireNotification = true;

            expect(paymentHelper.getExpirationNotificationForCC(notificationObj, creditCard, paymentInstrument)).to.be.undefined;
            expect(notificationObj).to.be.empty;
        });

        it('if expireStyle equal to `danger` and session custom ccExpiredNotice equal to true', () => {
            global.session.custom.ccExpiredNotice = true;

            expect(paymentHelper.getExpirationNotificationForCC(notificationObj, creditCard, paymentInstrument)).to.be.undefined;
            expect(notificationObj).to.be.not.empty;
            expect(notificationObj).to.be.deep.equal({ type: 'danger', message: 'credit card notification expired' });
            expect(global.session.custom).to.not.have.property('ccExpiredNotice');
        });

        it('if expireStyle equal `warning`, braintreeCreditCardExpirationNotice equal false and existing type in notificationObj not equal `danger`', () => {
            creditCard.expireStyle = 'warning';

            paymentInstrument = createStubInstance(dw.customer.CustomerPaymentInstrument);
            paymentInstrument.custom.braintreeCreditCardExpirationNotice = false;

            expect(paymentHelper.getExpirationNotificationForCC(notificationObj, creditCard, paymentInstrument)).to.be.undefined;
            expect(notificationObj).to.be.not.empty;
            expect(notificationObj).to.be.deep.equal({ type: 'warning', message: 'credit card notification expire soon' });
        });

        it('if expireStyle equal `warning`, braintreeCreditCardExpirationNotice equal false and existing type in notificationObj equal `danger`', () => {
            notificationObj = { type: 'danger', message: 'credit card notification expired' };

            expect(paymentHelper.getExpirationNotificationForCC(notificationObj, creditCard, paymentInstrument)).to.be.undefined;
            expect(notificationObj).to.be.not.empty;
            expect(notificationObj).to.be.deep.equal({ type: 'danger', message: 'credit card notification expired' });
        });

        it('if expireStyle equal `warning`, braintreeCreditCardExpirationNotice equal true and existing type in notificationObj not equal `danger`', () => {
            paymentInstrument = createStubInstance(dw.customer.CustomerPaymentInstrument);
            paymentInstrument.custom.braintreeCreditCardExpirationNotice = true;

            expect(paymentHelper.getExpirationNotificationForCC(notificationObj, creditCard, paymentInstrument)).to.be.undefined;
            expect(notificationObj).to.be.empty;
        });
    });

    describe('addExpirationNotificationForCC', () => {
        const creditCardList = [];

        before(() => {
            global.session = originalSession;
            global.session.custom.ccExpiredNotice = null;

            customerModel.returns({
                addFlashMessage: () => undefined
            });

            stub(dw.web.Resource, 'msg');
            stub(paymentHelper, 'getExpirationDataForCC');

            dw.web.Resource.msg.withArgs('creditcard.notification.expired', 'account', null).returns('credit card notification expired');
            dw.web.Resource.msg.withArgs('creditcard.notification.expiresoon', 'account', null).returns('credit card notification expire soon');
        });

        after(() => {
            global.session = originalSession;
            customerModel.reset();
            paymentHelper.getExpirationDataForCC.restore();
            dw.web.Resource.msg.restore();
        });

        it('should exit from function if list of credit cards is empty', () => {
            expect(paymentHelper.addExpirationNotificationForCC(creditCardList)).to.be.undefined;
        });

        it('if credit card is not expired/expires soon', () => {
            creditCardList.push({
                creditCardExpirationYear: '2023',
                creditCardExpirationMonth: '4',
                creditCardType: 'Visa',
                maskedCreditCardNumber: '***********1119',
                custom: {}
            });

            paymentHelper.getExpirationDataForCC.returns(null);

            expect(paymentHelper.addExpirationNotificationForCC(creditCardList)).to.be.undefined;
        });

        it('if credit card is expires soon', () => {
            paymentHelper.getExpirationDataForCC.returns({
                expireNotification: true,
                expireStyle: 'warning',
                expireMessage: 'Expires in 1 month'
            });

            expect(paymentHelper.addExpirationNotificationForCC(creditCardList)).to.be.undefined;
        });

        it('if credit card is expired', () => {
            paymentHelper.getExpirationDataForCC.returns({
                expireNotification: true,
                expireStyle: 'danger',
                expireMessage: 'Expired'
            });

            expect(paymentHelper.addExpirationNotificationForCC(creditCardList)).to.be.undefined;
        });
    });
});
