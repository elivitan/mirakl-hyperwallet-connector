const { int_paypal: { paypalConstantsPath } } = require('../path.json');

const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const paypalConstants = proxyquire(paypalConstantsPath, {});

describe('paypalConstants', () => {
    it('response type should be object', () => {
        expect(paypalConstants).to.be.a('object');
    });
    it('response object should consist property ACCESS_TOKEN', () => {
        expect(paypalConstants).has.property('ACCESS_TOKEN');
    });
    it('response object should consist property USER_INFO', () => {
        expect(paypalConstants).has.property('USER_INFO');
    });
    it('response object should consist property VERIFY_WH_SIG', () => {
        expect(paypalConstants).has.property('VERIFY_WH_SIG');
    });

    it('response object should consist property PAYMENT_AUTHORIZATION_VOIDED', () => {
        expect(paypalConstants).has.property('PAYMENT_AUTHORIZATION_VOIDED');
    });
    it('response object should consist property PAYMENT_CAPTURE_REFUNDED', () => {
        expect(paypalConstants).has.property('PAYMENT_CAPTURE_REFUNDED');
    });
    it('response object should consist property PAYMENT_CAPTURE_COMPLETED', () => {
        expect(paypalConstants).has.property('PAYMENT_CAPTURE_COMPLETED');
    });
    it('response object should consist property STATUS_SUCCESS', () => {
        expect(paypalConstants).has.property('STATUS_SUCCESS');
    });
    it('response object should consist property METHOD_POST', () => {
        expect(paypalConstants).has.property('METHOD_POST');
    });
    it('response object should consist property METHOD_GET', () => {
        expect(paypalConstants).has.property('METHOD_GET');
    });
    it('response object should consist property PAYMENT_STATUS_REFUNDED', () => {
        expect(paypalConstants).has.property('PAYMENT_STATUS_REFUNDED');
    });
    it('response object should consist property CONNECT_WITH_PAYPAL_CONSENT_DENIED', () => {
        expect(paypalConstants).has.property('CONNECT_WITH_PAYPAL_CONSENT_DENIED');
    });
    it('response object should consist property ENDPOINT_ACCOUNT_SHOW', () => {
        expect(paypalConstants).has.property('ENDPOINT_ACCOUNT_SHOW');
    });
    it('response object should consist property ENDPOINT_CHECKOUT_LOGIN', () => {
        expect(paypalConstants).has.property('ENDPOINT_CHECKOUT_LOGIN');
    });
    it('response object should consist property PAYMENT_METHOD_ID_PAYPAL', () => {
        expect(paypalConstants).has.property('PAYMENT_METHOD_ID_PAYPAL');
    });
    it('response object should consist property PAYMENT_METHOD_ID_VENMO', () => {
        expect(paypalConstants).has.property('PAYMENT_METHOD_ID_VENMO');
    });
    it('response object should consist property PAYMENT_METHOD_ID_Debit_Credit_Card', () => {
        expect(paypalConstants).has.property('PAYMENT_METHOD_ID_Debit_Credit_Card');
    });
    it('response object should consist property PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD', () => {
        expect(paypalConstants).has.property('PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD');
    });
    it('response object should consist property PP_FUNDING_SOURCE_CARD', () => {
        expect(paypalConstants).has.property('PP_FUNDING_SOURCE_CARD');
    });
    it('response object should consist property PP_DEBIT_CREDIT_PAYMENT_TYPE', () => {
        expect(paypalConstants).has.property('PP_DEBIT_CREDIT_PAYMENT_TYPE');
    });
    it('response object should consist property LOGIN_PAYPAL', () => {
        expect(paypalConstants).has.property('LOGIN_PAYPAL');
    });
    it('response object should consist property APMA_STAGE_COMPLETE', () => {
        expect(paypalConstants).has.property('APMA_STAGE_COMPLETE');
    });
    it('response object should consist property APMA_STAGE_ADDRESS', () => {
        expect(paypalConstants).has.property('APMA_STAGE_ADDRESS');
    });
    it('response object should consist property APMA_STAGE_ACCOUNT', () => {
        expect(paypalConstants).has.property('APMA_STAGE_ACCOUNT');
    });
    it('response object should consist property FLASH_MESSAGE_SUCCESS', () => {
        expect(paypalConstants).has.property('FLASH_MESSAGE_SUCCESS');
    });
    it('response object should consist property FLASH_MESSAGE_INFO', () => {
        expect(paypalConstants).has.property('FLASH_MESSAGE_INFO');
    });
    it('response object should consist property FLASH_MESSAGE_DANGER', () => {
        expect(paypalConstants).has.property('FLASH_MESSAGE_DANGER');
    });
    it('response object should consist property FLASH_MESSAGE_WARNING', () => {
        expect(paypalConstants).has.property('FLASH_MESSAGE_WARNING');
    });
    it('response object should consist property FLASH_MESSAGE_ERROR_INTERNAL_SERVER', () => {
        expect(paypalConstants).has.property('FLASH_MESSAGE_ERROR_INTERNAL_SERVER');
    });
    it('response object should consist property AUTHENTICATION_PAYPAL_PROVIDER_ID', () => {
        expect(paypalConstants).has.property('AUTHENTICATION_PAYPAL_PROVIDER_ID');
    });
    it('response object should consist property ORDER_SAVED_EXPLICITLY', () => {
        expect(paypalConstants).has.property('ORDER_SAVED_EXPLICITLY');
    });
    it('response object should consist property NO_INSTRUCTION', () => {
        expect(paypalConstants).has.property('NO_INSTRUCTION');
    });
    it('response object should consist property BILLING_ADDRESS_ID', () => {
        expect(paypalConstants).has.property('BILLING_ADDRESS_ID');
    });
    it('response object should consist property SHIPPING_ADDRESS_ID', () => {
        expect(paypalConstants).has.property('SHIPPING_ADDRESS_ID');
    });
    it('response object should consist property REGEXP_PHONE', () => {
        expect(paypalConstants).has.property('REGEXP_PHONE');
    });
    it('response object should consist property REGEXP_EMAIL', () => {
        expect(paypalConstants).has.property('REGEXP_EMAIL');
    });
    it('response object should consist property CREDIT_CARD_TAB', () => {
        expect(paypalConstants).has.property('CREDIT_CARD_TAB');
    });
    it('response object should consist property PAYPAL_TAB', () => {
        expect(paypalConstants).has.property('PAYPAL_TAB');
    });
    it('response object should consist property ACTIVE_TAB', () => {
        expect(paypalConstants).has.property('ACTIVE_TAB');
    });
    it('response object should consist property FRAUDNET_UID_LENGTH', () => {
        expect(paypalConstants).has.property('FRAUDNET_UID_LENGTH');
    });
    it('response object should consist property UNKNOWN', () => {
        expect(paypalConstants).has.property('UNKNOWN');
    });
    it('response object should consist property PAYPAL_FILE_NAME_PREFIX', () => {
        expect(paypalConstants).has.property('PAYPAL_FILE_NAME_PREFIX');
    });
    it('response object should consist property PAYPAL_CATEGORY', () => {
        expect(paypalConstants).has.property('PAYPAL_CATEGORY');
    });
    it('response object should consist property SESSION_PAYMENTS_AVAILABILITY_LOGGEDIN', () => {
        expect(paypalConstants).has.property('SESSION_PAYMENTS_AVAILABILITY_LOGGEDIN');
    });
    it('response object should consist property SESSION_PAYMENTS_AVAILABILITY_ALL', () => {
        expect(paypalConstants).has.property('SESSION_PAYMENTS_AVAILABILITY_ALL');
    });
    it('response object should consist property CREDIT_CARD_COMPLEX_BRAND_CODE', () => {
        expect(paypalConstants).has.property('CREDIT_CARD_COMPLEX_BRAND_CODE');
    });
    it('response object should consist property CREDIT_CARD_SAVE_STATUS_VAULTED', () => {
        expect(paypalConstants).has.property('CREDIT_CARD_SAVE_STATUS_VAULTED');
    });
    it('response object should consist property PAYPAL_ORDER_STATUS_COMPLETED', () => {
        expect(paypalConstants).has.property('PAYPAL_ORDER_STATUS_COMPLETED');
    });
    it('response object should consist property CC_NUMBER_LIMIT_NUMBER_START', () => {
        expect(paypalConstants).has.property('CC_NUMBER_LIMIT_NUMBER_START');
    });
    it('response object should consist property CC_NUMBER_LIMIT_NUMBER_END', () => {
        expect(paypalConstants).has.property('CC_NUMBER_LIMIT_NUMBER_END');
    });
    it('response object should consist property CC_3DS_AUTHENTICATION_REASON_SKIPPED_BY_BUYER', () => {
        expect(paypalConstants).has.property('CC_3DS_AUTHENTICATION_REASON_SKIPPED_BY_BUYER');
    });
    it('response object should consist property CC_3DS_AUTHENTICATION_STATUS_APPROVED', () => {
        expect(paypalConstants).has.property('CC_3DS_AUTHENTICATION_STATUS_APPROVED');
    });
    it('response object should consist property CC_3DS_AUTHENTICATION_SUCCESS_STATUSES', () => {
        expect(paypalConstants).has.property('CC_3DS_AUTHENTICATION_SUCCESS_STATUSES');
    });
    it('response object should consist property CC_3DS_AUTHENTICATION_STATUS_NO', () => {
        expect(paypalConstants).has.property('CC_3DS_AUTHENTICATION_STATUS_NO');
    });
    it('response object should consist property CC_3DS_AUTHENTICATION_REASON_FAILED_STATUSES', () => {
        expect(paypalConstants).has.property('CC_3DS_AUTHENTICATION_REASON_FAILED_STATUSES');
    });
    it('response object should consist property CC_3DS_AUTHENTICATION_REASON_WHITE_LIST', () => {
        expect(paypalConstants).has.property('CC_3DS_AUTHENTICATION_REASON_WHITE_LIST');
    });
    it('response object should consist property CC_3DS_AUTHENTICATION_FAILED_STATUSES', () => {
        expect(paypalConstants).has.property('CC_3DS_AUTHENTICATION_FAILED_STATUSES');
    });
    it('response object should consist property CC_3DS_LIABILITY_SHIFT_STATUS_POSSIBLE', () => {
        expect(paypalConstants).has.property('CC_3DS_LIABILITY_SHIFT_STATUS_POSSIBLE');
    });
    it('response object should consist property SCA_WHEN_REQUIRED', () => {
        expect(paypalConstants).has.property('SCA_WHEN_REQUIRED');
    });
    it('response object should consist property SCA_ALWAYS', () => {
        expect(paypalConstants).has.property('SCA_ALWAYS');
    });
});
