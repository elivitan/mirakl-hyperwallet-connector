const { int_paypal: { authorizationAndCaptureWhMgrPath } } = require('../path.json');

const proxyquire = require('proxyquire').noCallThru();
const { expect } = require('chai');
const { describe, it } = require('mocha');

const paypalConstants = {
    PAYMENT_CAPTURE_REFUNDED: 'PAYMENT.CAPTURE.REFUNDED',
    PAYMENT_CAPTURE_COMPLETED: 'PAYMENT.CAPTURE.COMPLETED',
    PAYMENT_AUTHORIZATION_VOIDE: 'PAYMENT.AUTHORIZATION.VOIDED'
};

const authorizationAndCaptureWhMgr = proxyquire(authorizationAndCaptureWhMgrPath,
    {
        '*/cartridge/models/whBase': () => {},
        '*/cartridge/scripts/paypal/helpers/authorizationAndCaptureWhHelper': {
            updateOrderPaymentStatus: () => {}
        },
        '*/cartridge/config/paypalConstants': paypalConstants
    });

const obj = new authorizationAndCaptureWhMgr();

describe('authorizationAndCaptureWhMgr file', () => {
    describe('authorizationAndCaptureWhMgr constructor', () => {
        it('should be a function', () => {
            expect(authorizationAndCaptureWhMgr).to.be.a('function');
        });

        it('should return an object', () => {
            expect(obj).to.be.a('object');
        });
    });

    describe('completePaymentOnDwSide function', () => {
        it('should be called', () => {
            expect(obj.completePaymentOnDwSide()).to.have.been.called;
        });
    });

    describe('voidPaymentOnDwSide function', () => {
        it('should be called', () => {
            expect(obj.voidPaymentOnDwSide()).to.have.been.called;
        });
    });

    describe('refundPaymentOnDwSide function', () => {
        it('should be called', () => {
            expect(obj.refundPaymentOnDwSide()).to.have.been.called;
        });
    });

    describe('isApproppriateEventType function', () => {
        it('should be called', () => {
            expect(obj.isApproppriateEventType()).to.have.been.called;
        });

        it('should return true', () => {
            const eventType = paypalConstants.PAYMENT_CAPTURE_REFUNDED;

            expect(obj.isApproppriateEventType(eventType)).to.equal(true);
        });

        it('should retrun false', () => {
            const eventType = 'wrong';

            expect(obj.isApproppriateEventType(eventType)).to.equal(false);
        });
    });
});
