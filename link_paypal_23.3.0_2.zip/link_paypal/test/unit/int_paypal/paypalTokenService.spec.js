const { int_paypal: { paypalTokenServicePath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe, beforeEach } = require('mocha');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const proxyquire = require('proxyquire').noCallThru();

const getAccessToken = stub();
const getUrlPath = stub();

const ServiceCredential = () => {};

const paypalConstants = {
    ACCESS_TOKEN: 'access_token',
    USER_INFO: 'userinfo',
    VERIFY_WH_SIG: 'verify-webhook-signature'
};

const paypalTokenService = proxyquire(paypalTokenServicePath, {
    'int_paypal.http.token.service': {},
    'dw/svc/ServiceCredential': ServiceCredential,
    'dw/svc/LocalServiceRegistry': {
        createService: (name, obj) => ({
            createRequest: obj.createRequest,
            parseResponse: obj.parseResponse,
            filterLogMessage: obj.filterLogMessage,
            getRequestLogMessage: obj.getRequestLogMessage,
            getResponseLogMessage: obj.getResponseLogMessage
        })
    },
    '*/cartridge/scripts/paypal/helpers/paypalHelper': {
        getAccessToken,
        getUrlPath
    },
    '*/cartridge/config/paypalConstants': paypalConstants
});

describe('paypalTokenService file', () => {
    const service = paypalTokenService();

    describe('parseResponse', () => {
        it('should parse', () => {
            expect(service.parseResponse({}, { text: '{"prop": "value"}' })).to.be.deep.equal({ prop: 'value' });
        });
    });

    describe('filterLogMessage', () => {
        it('should retrun message', () => {
            expect(service.filterLogMessage('msg')).to.be.equal('msg');
        });
    });

    describe('getRequestLogMessage', () => {
        it('should retrun request', () => {
            expect(service.getRequestLogMessage('request')).to.be.equal('request');
        });
    });

    describe('getResponseLogMessage', () => {
        it('should retrun request', () => {
            expect(service.getResponseLogMessage({ text: 'response' })).to.be.equal('response');
        });
    });

    describe('createRequest ', () => {
        const reqService = {
            configuration: {
                credential: new ServiceCredential()
            },
            setURL: () => {},
            setRequestMethod: () => {},
            addHeader: () => {}
        };

        const requestData = {
            requestType: '',
            code: '',
            accessToken: '',
            whObject: ''
        };

        beforeEach(() => {
            reqService.configuration.credential = new ServiceCredential();
        });

        it('should throw an error while credentials is not instanceof ServiceCredential', () => {
            reqService.configuration.credential = {};

            expect(() => service.createRequest(reqService, requestData)).to.throw();
        });

        it('if requestType is paypalConstants.ACCESS_TOKEN', () => {
            requestData.requestType = paypalConstants.ACCESS_TOKEN;
            requestData.code = 'requestData_code';

            expect(service.createRequest(reqService, requestData)).to.be.equal('grant_type=authorization_code&code=requestData_code');
        });

        it('if requestType is paypalConstants.USER_INFO', () => {
            requestData.requestType = paypalConstants.USER_INFO;

            expect(service.createRequest(reqService, requestData)).to.be.equal('');
        });

        it('if requestType is paypalConstants.VERIFY_WH_SIG', () => {
            requestData.requestType = paypalConstants.VERIFY_WH_SIG;
            requestData.whObject = { prop: 'value' };

            expect(service.createRequest(reqService, requestData)).to.be.equal('{"prop":"value"}');
        });

        it('if requestType is unknown', () => {
            requestData.requestType = 'unknown';

            expect(service.createRequest(reqService, requestData)).to.be.equal('');
        });
    });
});
