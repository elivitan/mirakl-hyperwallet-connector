/* eslint-disable no-underscore-dangle */
const { int_paypal: { paymentInstrumentHelperPath } } = require('../path.json');

const proxyquire = require('proxyquire').noCallThru();
const { expect } = require('chai');
const { stub } = require('sinon');
const {
    describe, it, before, after, beforeEach, afterEach
} = require('mocha');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const paymentInstrumentHelper = proxyquire(paymentInstrumentHelperPath, {
    '*/cartridge/config/paypalConstants': {
        PAYMENT_METHOD_ID_PAYPAL: 'PayPal'
    },
    '*/cartridge/scripts/paypal/helpers/creditCardHelper': {
        isSavedCardFlow: () => {}
    }
});

describe('paymentInstrmentHelper file', () => {
    describe('getPaypalPaymentInstrument', () => {
        const getPaypalPaymentInstrument = paymentInstrumentHelper.__get__('getPaypalPaymentInstrument');
        let basket;
        let paymentInstruments;

        describe('if paymentInstrument with paypal as payment method id is not empty', () => {
            before(() => {
                paymentInstruments = [{ Array: {} }];
                basket = {
                    getPaymentInstruments: () => {
                        return paymentInstruments;
                    }
                };
            });
            after(() => {
                basket = {};
                paymentInstruments = null;
            });
            it('return paypal payment instrument', () => {
                expect(getPaypalPaymentInstrument(basket)).to.be.equal(paymentInstruments[0]);
            });
        });

        describe('if payment instrument is empty', () => {
            before(() => {
                paymentInstruments = [];
                basket = {
                    getPaymentInstruments: () => paymentInstruments
                };
            });
            after(() => {
                basket = {};
                paymentInstruments = null;
            });
            it('return false', () => {
                expect(getPaypalPaymentInstrument(basket)).to.be.equal(false);
            });
        });
    });

    describe('calculateNonGiftCertificateAmount', () => {
        const calculateNonGiftCertificateAmount = paymentInstrumentHelper.__get__('calculateNonGiftCertificateAmount');
        let Decimal = function(value) {
            this.value = value;
        };

        Decimal.prototype.subtract = function(money) {
            return new Decimal(this.value - money.value);
        };

        Decimal.prototype.value = null;

        let getAmount = new dw.value.Money(20);
        const gcPaymentInstrs = {
            iterator: () => {
                return new dw.util.Iterator([{
                    getPaymentTransaction: () => ({
                        getAmount: () => {
                            return getAmount;
                        }
                    })
                }]);
            }
        };

        let lineItemCtnr = {
            currencyCode: 'USD',
            getGiftCertificatePaymentInstruments: () => gcPaymentInstrs,
            totalGrossPrice: new dw.value.Money(100)
        };

        it('should return amount after discount', () => {
            expect(calculateNonGiftCertificateAmount(lineItemCtnr).value).to.be.equal(80);
        });
    });

    describe('removePaypalPaymentInstrument', () => {
        describe('if payment instrument of basket was not provided', () => {
            const basket = {
                getPaymentInstruments: stub(),
                removePaymentInstrument: stub()
            };

            before(() => {
                basket.getPaymentInstruments.returns(null);
            });

            it('should return undefined', () => {
                expect(paymentInstrumentHelper.removePaypalPaymentInstrument(basket)).to.be.undefined;
            });
        });

        it('should remove payment instrument from basket', () => {
            const basket = {
                getPaymentInstruments: stub(),
                removePaymentInstrument: stub()
            };

            basket.getPaymentInstruments.returns({});

            expect(paymentInstrumentHelper.removePaypalPaymentInstrument(basket)).to.be.undefined;
            expect(basket.removePaymentInstrument.calledOnce).to.be.true;
        });
    });

    describe('removePayPalPaymentInstrumentByEmail', () => {
        const paymentInstruments = [{
            custom: {
                currentPaypalEmail: 'paypal@email.com'
            }
        }];

        const basket = {
            getPaymentInstruments: () => ({
                toArray: () => paymentInstruments
            }),
            removePaymentInstrument: stub()
        };

        let email = 'paypal@email.com';

        afterEach(() => {
            basket.removePaymentInstrument.reset();
        });

        it('should find payment instrument and remove it', () => {
            paymentInstrumentHelper.removePayPalPaymentInstrumentByEmail(basket, email);

            expect(basket.removePaymentInstrument.calledOnce).to.be.true;
            expect(basket.removePaymentInstrument.calledWith(paymentInstruments[0])).to.be.true;
        });

        it('should not find payment instrument and not remove it', () => {
            email = 'fake@email.com';

            paymentInstrumentHelper.removePayPalPaymentInstrumentByEmail(basket, email);

            expect(basket.removePaymentInstrument.calledOnce).to.be.false;
        });
    });

    describe('getPaymentInstrumentAction', () => {
        const responseKeys = ['noOrderIdChange', 'isOrderIdChanged', 'checkBillingAgreement'];
        const paymentInstrument = {
            custom: {
                paypalOrderID: 'paypal-order-id',
                PP_API_ActiveBillingAgreement: 'agreement'
            }
        };

        before(() => {
            session.privacy = {};
            session.privacy.paypalOrderID = 'paypal-order-id';
        });

        after(() => {
            delete session.privacy.paypalOrderID;
        });

        it('should return an object', () => {
            expect(paymentInstrumentHelper.getPaymentInstrumentAction(paymentInstrument)).to.be.a('object');
        });

        it('should return not empty object', () => {
            expect(paymentInstrumentHelper.getPaymentInstrumentAction(paymentInstrument)).to.not.be.empty;
        });

        it('should return object with isOrderIdChanged key and false value', () => {
            expect(paymentInstrumentHelper.getPaymentInstrumentAction(paymentInstrument).isOrderIdChanged).to.be.false;
        });

        responseKeys.forEach((key) => {
            it(`should return ${key} key`, () => {
                expect(paymentInstrumentHelper.getPaymentInstrumentAction(paymentInstrument)).to.contain.key(key);
            });
        });

        describe('if id of payment instrument and form is different', () => {
            before(() => {
                paymentInstrument.custom.paypalOrderID = 'newId';
            });

            it('should return object with isOrderIdChanged key and true value', () => {
                expect(paymentInstrumentHelper.getPaymentInstrumentAction(paymentInstrument).isOrderIdChanged).to.be.true;
            });
        });

        describe('createPaymentInstrument', () => {
            let getPaymentMethod;
            let amount = new dw.value.Money(10);
            const instrument = {
                paymentTransaction: {
                    setPaymentProcessor: stub()
                }
            };

            const basket = {
                totalGrossPrice: new dw.value.Money(20),
                getGiftCertificatePaymentInstruments: () => ({
                    iterator: () => {
                        return new dw.util.Iterator([{
                            getPaymentTransaction: () => ({
                                getAmount: () => {
                                    return amount;
                                }
                            })
                        }]);
                    }
                }),
                createPaymentInstrument: () => (instrument)
            };

            const paymentType = 'PayPal';

            before(() => {
                getPaymentMethod = stub(dw.order.PaymentMgr, 'getPaymentMethod');
                getPaymentMethod.returns({
                    getPaymentProcessor: () => ({})
                });
            });

            after(() => {
                getPaymentMethod.reset();
            });

            it('should be an object', () => {
                expect(paymentInstrumentHelper.createPaymentInstrument(basket, paymentType)).to.be.a('object');
            });

            it('should return not empty object', () => {
                expect(paymentInstrumentHelper.getPaymentInstrumentAction(paymentInstrument)).to.not.be.empty;
            });

            it('should create and return payment instruments', () => {
                expect(paymentInstrumentHelper.createPaymentInstrument(basket, paymentType)).to.deep.equal(instrument);
            });
        });

        describe('removeNonPayPalPaymentInstrument', () => {
            let paymentInstruments = [
                {
                    paymentMethod: 'PayPal'
                },
                {
                    paymentMethod: 'CREDIT_CARD'
                },
                {
                    paymentMethod: 'GIFT_CERTIFICATE'
                }
            ];

            const basket = {
                getPaymentInstruments: () => ({
                    iterator: (() => {
                        let index = 0;
                        let prevLength = paymentInstruments.length;

                        return () => ({
                            hasNext: () => index < paymentInstruments.length,
                            next: () => {
                                if (prevLength !== paymentInstruments.length) {
                                    prevLength = paymentInstruments.length;

                                    return paymentInstruments[index - 1];
                                }

                                return paymentInstruments[index++];
                            }
                        });
                    })()
                }),
                removePaymentInstrument: (instrument) => {
                    paymentInstruments = paymentInstruments.filter((inst) => {
                        return inst.paymentMethod !== instrument.paymentMethod;
                    });
                }
            };

            beforeEach(() => {
                paymentInstrumentHelper.removeNonPayPalPaymentInstrument(basket);
            });

            afterEach(() => {
                paymentInstruments = [
                    {
                        paymentMethod: 'PayPal'
                    },
                    {
                        paymentMethod: 'CREDIT_CARD'
                    },
                    {
                        paymentMethod: 'GIFT_CERTIFICATE'
                    }
                ];
            });

            describe('should delete instruments except \'GIFT_CERTIFICATE\'', () => {
                it('should return true', () => {
                    paymentInstrumentHelper.removeNonPayPalPaymentInstrument(basket);

                    expect(paymentInstruments.length === 1).to.be.true;
                });
            });

            describe('should delete all instruments if \'GIFT_CERTIFICATE\' was not provided', () => {
                before(() => {
                    paymentInstruments = [
                        {
                            paymentMethod: 'PayPal'
                        },
                        {
                            paymentMethod: 'CREDIT_CARD'
                        }
                    ];
                    paymentInstrumentHelper.removeNonPayPalPaymentInstrument(basket);
                });

                it('should return true', () => {
                    expect(paymentInstruments.length === 0).to.be.true;
                });
            });
        });
    });

    describe('getCustomerPiByCreditCardToken', () => {
        const originalCustomer = customer;

        before(() => {
            customer = {
                profile: {
                    wallet: {
                        paymentInstruments: {
                            toArray: () => [{ creditCardToken: '1111' }, { creditCardToken: '2222' }]
                        }
                    }
                }
            };
        });

        after(() => {
            customer = originalCustomer;
        });

        it('customer payment instrument should be returned', () => {
            const result = paymentInstrumentHelper.getCustomerPiByCreditCardToken('1111');

            expect(result).to.be.an('object');
            expect(result.creditCardToken).to.equal('1111');
        });

        it('if there is no pi with such credit card token, undefined should be returned', () => {
            const result = paymentInstrumentHelper.getCustomerPiByCreditCardToken('3333');

            expect(result).to.be.undefined;
        });
    });

    describe('getCustomerPiByUUID', () => {
        const paymentInstrument = {
            getUUID: () => '001'
        };

        before(() => {
            customer.profile.wallet.paymentInstruments = {
                toArray: () => {
                    return [paymentInstrument];
                }
            };
        });

        after(() => {
            customer.profile.wallet.paymentInstruments = null;
        });

        it('should be a function', () => {
            expect(paymentInstrumentHelper.getCustomerPiByUUID).to.be.a('function');
        });

        it('should return a customer payment instrument', () => {
            expect(paymentInstrumentHelper.getCustomerPiByUUID('001')).that.deep.equal(paymentInstrument);
        });

        it('should not return a customer payment instrument', () => {
            expect(paymentInstrumentHelper.getCustomerPiByUUID('002')).to.be.an('undefined');
        });
    });
});
