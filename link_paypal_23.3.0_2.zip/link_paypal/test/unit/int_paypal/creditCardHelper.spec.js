'use strict';

const { int_paypal: { creditCardHelperPath } } = require('../path.json');

const { stub } = require('sinon');
const { expect } = require('chai');
const {
    describe, it, before, after, afterEach
} = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({ plugins: ['babel-plugin-rewire'] });

const generateClientToken = stub();
const createOrder = stub();
const wrap = stub().callsArg(0);
const getCustomerPiByCreditCardToken = stub();
const saveGeneralTransactionData = stub();
const createErrorLog = stub();
const getBillingAddressFromForm = stub();
const getCustomerPaymentInstruments = stub();
const getExpirationDataForCC = stub();

const prefs = {
    isCreditCardActive: null,
    saveOrderFlow: null,
    debitCreditButtonEnabled: null,
    disableFundingList: [],
    isCreditCardVaultEnabled: null,
    hostedFieldsStyles: 'styles',
    threeDSecureFlow: '3dsFlow',
    verifyCardOnAccountPage: true
};

const payPalConstants = {
    PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD: 'PAYPAL_CREDIT_CARD',
    PP_FUNDING_SOURCE_CARD: 'card',
    CREDIT_CARD_COMPLEX_BRAND_CODE: ['American Express', 'UnionPay', 'JCB', 'Debit networks'],
    CREDIT_CARD_SAVE_STATUS_VAULTED: 'VAULTED',
    CC_NUMBER_LIMIT_NUMBER_START: 0,
    CC_NUMBER_LIMIT_NUMBER_END: 10,
    SCA_WHEN_REQUIRED: 'SCA_WHEN_REQUIRED',
    REGEXP_NAME: /^[A-Z][a-zA-Z '.-]*[A-Za-z][^-]$/
};

const creditCardHelper = proxyquire(creditCardHelperPath, {
    '*/cartridge/config/paypalConstants': payPalConstants,
    '*/cartridge/config/paypalPreferences': prefs,
    '*/cartridge/scripts/paypal/paypalApi': {
        generateClientToken,
        createOrder
    },
    'dw/web/Resource': {
        msg: resource => {
            switch (resource) {
                case 'paypal.creditcard.field.cardNumber.placeholder':
                    return 'Card Number';

                case 'paypal.creditcard.field.cvv.placeholder':
                    return 'Cvv';

                case 'paypal.creditcard.field.expirationdate.placeholder':
                    return 'Expiration date';

                case 'paypal.creditcard.3ds.verification.failed':
                    return '3DSecure popup was canceled by the buyer or credit card verification failed. Please try again';

                case 'paypal.error.creditcard.field.empty':
                    return 'Field is empty. Please enter a value.';

                case 'paypal.error.creditcard.field.invalid':
                    return 'Field is invalid. Please enter a valid value.';

                case 'paypal.error.creditcard.field.general.notification':
                    return 'Please enter valid credit card details.';

                case 'paypal.creditcard.expired':
                    return 'Expired';

                default:
                    return undefined;
            }
        }
    },
    'dw/system/Transaction': {
        wrap
    },
    '*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper': {
        getCustomerPiByCreditCardToken
    },
    '*/cartridge/scripts/paypal/helpers/paypalProcessorHelper': {
        saveGeneralTransactionData
    },
    '*/cartridge/scripts/paypal/paypalUtils': {
        createErrorLog
    },
    '*/cartridge/config/paypalUrls': {
        myAccountUrl: 'my-account.com'
    },
    '*/cartridge/scripts/paypal/helpers/addressHelper': {
        getBillingAddressFromForm: getBillingAddressFromForm
    },
    '*/cartridge/scripts/paypal/helpers/customerHelper': {
        getCustomerPaymentInstruments: getCustomerPaymentInstruments
    },
    '*/cartridge/scripts/paypal/helpers/paymentHelper': {
        getExpirationDataForCC: getExpirationDataForCC
    }
});

const setCreditCardHolder = stub();
const setCreditCardNumber = stub();
const setCreditCardExpirationMonth = stub();
const setCreditCardExpirationYear = stub();
const setCreditCardType = stub();
const getPaymentInstruments = stub();

const paymentInstrument = {
    creditCardToken: '',
    creditCardType: '',
    paymentMethod: 'PAYPAL_CREDIT_CARD'
};

const customerPaymentInstruments = {
    wallet: {
        paymentInstruments: [],
        getPaymentInstruments: getPaymentInstruments,
        createPaymentInstrument: () => Object.assign(paymentInstrument, {
            setCreditCardHolder: setCreditCardHolder,
            setCreditCardNumber: setCreditCardNumber,
            setCreditCardExpirationMonth: setCreditCardExpirationMonth,
            setCreditCardExpirationYear: setCreditCardExpirationYear,
            setCreditCardType: setCreditCardType
        })
    }
};

const baseCustomer = customer;

describe('creditCardHelper file', () => {
    describe('getApplicablePayPalCcPi', () => {
        const getApplicablePayPalCcPi = creditCardHelper.__get__('getApplicablePayPalCcPi');

        before(() => {
            customer.authenticated = true;

            Array.filter = function(a, b) {
                return Array.prototype.filter.call(a, b);
            };
        });

        after(() => {
            customer.authenticated = baseCustomer.authenticated;
            paymentInstrument.paymentMethod = 'PAYPAL_CREDIT_CARD';
        });

        it('should be a function', () => {
            expect(getApplicablePayPalCcPi).to.be.a('function');
        });

        it('should return an empty array if payment instruments object is empty', () => {
            customer.profile = customerPaymentInstruments;

            expect(getApplicablePayPalCcPi()).to.be.an('array').that.is.empty;
        });

        it('should return an array with payment instrument, if there is PAYPAL_CREDIT_CARD payment instrument', () => {
            customerPaymentInstruments.wallet.paymentInstruments.push(paymentInstrument);

            expect(getApplicablePayPalCcPi()).that.deep.equal([
                paymentInstrument
            ]);
        });

        it('should return an empty array if there is not PAYPAL_CREDIT_CARD payment instrument', () => {
            paymentInstrument.paymentMethod = 'PayPal';

            expect(getApplicablePayPalCcPi()).to.be.an('array').that.is.empty;
        });

        it('should return an empty array if !customer.authenticated', () => {
            customer.authenticated = false;

            expect(getApplicablePayPalCcPi()).to.be.an('array').that.is.empty;
        });
    });

    describe('getHostedFieldsConfigs', () => {
        const viewData = {
            forms: {
                billingForm: {
                    creditCardFields: {
                        cardNumber: {
                            htmlName: 'cardNumber'
                        }
                    }
                }
            }
        };

        before(() => {
            customer.authenticated = true;

            getExpirationDataForCC.withArgs({
                UUID: 'uuid1',
                paymentMethod: 'PAYPAL_CREDIT_CARD'
            }).returns({
                expireNotification: true,
                expireStyle: 'warning',
                expireMessage: 'expired in 1 month'
            });
        });

        after(() => {
            generateClientToken.reset();
            getExpirationDataForCC.reset();
            customer.authenticated = baseCustomer.authenticated;
            prefs.isCreditCardVaultEnabled = false;
        });

        it('should be a function', () => {
            expect(creditCardHelper.getHostedFieldsConfigs).to.be.a('function');
        });

        it('should return a hosted Fields config object', () => {
            generateClientToken.returns('token');
            paymentInstrument.custom = {
                payPalDefaultCard: true
            };
            prefs.isCreditCardVaultEnabled = true;

            customerPaymentInstruments.wallet.paymentInstruments.push({
                UUID: 'uuid1',
                paymentMethod: 'PAYPAL_CREDIT_CARD'
            });

            expect(creditCardHelper.getHostedFieldsConfigs(viewData)).that.deep.equal({
                fieldsConfig: {
                    numberHtmlName: viewData.forms.billingForm.creditCardFields.cardNumber.htmlName,
                    styles: prefs.hostedFieldsStyles
                },
                fieldsPlaceholders: {
                    number: 'Card Number',
                    cvv: 'Cvv',
                    expirationDate: 'Expiration date'
                },
                fieldsGeneralNotificationError: 'Please enter valid credit card details.',
                clientToken: 'token',
                creditCardPmId: payPalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD,
                threeDSecureValue: prefs.threeDSecureFlow,
                isShowCheckbox: true,
                expirationCreditCards: {
                    uuid1: {
                        expireNotification: true,
                        expireStyle: 'warning',
                        expireMessage: 'expired in 1 month'
                    }
                },
                customerSavedCreditCards: customerPaymentInstruments.wallet.paymentInstruments,
                isNewCardOptionSelected: false,
                errorMessages: {
                    threeDSVerificationFailed: '3DSecure popup was canceled by the buyer or credit card verification failed. Please try again'
                }
            });

            expect(getExpirationDataForCC.calledTwice, 'getExpirationDataForCC called twice').to.be.true;
        });
    });

    describe('isHostedFieldsEnabled', () => {
        it('should be a function', () => {
            expect(creditCardHelper.isHostedFieldsEnabled).to.be.a('function');
        });

        it('should return false (temporary case)', () => {
            expect(creditCardHelper.isHostedFieldsEnabled()).to.be.false;
        });
    });

    describe('formatComplexCCBrandCode', () => {
        it('should be a function', () => {
            expect(creditCardHelper.isHostedFieldsEnabled).to.be.a('function');
        });

        it('should return American Express if brandCode is American Express', () => {
            expect(creditCardHelper.formatComplexCCBrandCode('American Express')).that.deep.equal('American Express');
        });

        it('should return masterCard if brandCode is MasterCard', () => {
            expect(creditCardHelper.formatComplexCCBrandCode('masterCard')).that.deep.equal('MasterCard');
        });
    });

    describe('isSavedCardFlow', () => {
        const originalHttpParameterMap = request.httpParameterMap;

        before(() => {
            request.httpParameterMap = {
                paypalCreditCardList: {
                    empty: true
                }
            };
        });

        after(() => {
            request.httpParameterMap = originalHttpParameterMap;
        });

        it('should be a function', () => {
            expect(creditCardHelper.isSavedCardFlow).to.be.a('function');
        });

        it('should be false if customer.registered === false', () => {
            customer.registered = false;

            expect(creditCardHelper.isSavedCardFlow()).to.be.false;
        });

        it('should be false if customer.registered === true && paypalCreditCardList is empty', () => {
            customer.registered = true;

            expect(creditCardHelper.isSavedCardFlow()).to.be.false;
        });

        it('should be false if customer.registered === true && paypalCreditCardList === newcard', () => {
            request.httpParameterMap.paypalCreditCardList.empty = false;
            request.httpParameterMap.paypalCreditCardList.stringValue = 'newcard';

            expect(creditCardHelper.isSavedCardFlow()).to.be.false;
        });

        it('should be true if customer.registered === true && paypalCreditCardList !== newcard', () => {
            request.httpParameterMap.paypalCreditCardList.stringValue = 'uuid';

            expect(creditCardHelper.isSavedCardFlow()).to.be.true;
        });
    });

    describe('saveCreditCardToCustomerWallet', () => {
        before(() => {
            customer = {
                profile: {
                    custom: {},
                    wallet: customerPaymentInstruments.wallet
                }
            };
            creditCardHelper.__set__('formatComplexCCBrandCode', (brand) => brand);
        });

        after(() => {
            customer.profile.custom = {};
            getPaymentInstruments.reset();
            wrap.reset();
            creditCardHelper.__ResetDependency__('formatComplexCCBrandCode');
        });

        it('if the checkout flow was executed and credit card was successfully saved to customer wallet', () => {
            const responseData = {
                payment_source: {
                    card: {
                        attributes: {
                            vault: {
                                status: payPalConstants.CREDIT_CARD_SAVE_STATUS_VAULTED,
                                id: 'id',
                                customer: {
                                    id: 'customerId'
                                }
                            }
                        },
                        expiry: '25-01',
                        brand: 'Visa',
                        last_digits: '0001'
                    }
                }
            };

            const billingAddressAsString = 'billing-address-as-a-string';
            const cardHolderName = 'Card Name';

            creditCardHelper.saveCreditCardToCustomerWallet(responseData, billingAddressAsString, cardHolderName);

            expect(customer.profile.custom.payPalCustomerId).to.equal('customerId');

            expect(setCreditCardHolder.calledWithExactly('Card Name')).to.be.true;
            expect(setCreditCardExpirationMonth.calledWithExactly(1)).to.be.true;
            expect(setCreditCardExpirationYear.calledWithExactly(25)).to.be.true;
            expect(setCreditCardType.calledWithExactly('visa')).to.be.true;
        });

        it('if the myaccount flow was executed and credit card was successfully saved to customer wallet', () => {
            customer.profile.custom.payPalCustomerId = 'pp-customer-id';

            const responseData = {
                payment_source: {
                    card: {
                        id: 'id',
                        name: 'name',
                        expiry: '25-01',
                        brand: 'Visa',
                        last_digits: '0001'
                    }
                },
                customer: { id: 'customer-id' }
            };

            const billingAddressAsString = 'billing-address-as-a-string';

            getPaymentInstruments.returns(['pi1', 'pi2']);

            creditCardHelper.saveCreditCardToCustomerWallet(responseData, billingAddressAsString);

            expect(customer.profile.custom.payPalCustomerId).to.equal('pp-customer-id');

            expect(setCreditCardHolder.calledWithExactly('name')).to.be.true;
            expect(setCreditCardExpirationMonth.calledWithExactly(1)).to.be.true;
            expect(setCreditCardExpirationYear.calledWithExactly(25)).to.be.true;
            expect(setCreditCardType.calledWithExactly('visa')).to.be.true;
        });
    });

    describe('completeSavedCcOrder', () => {
        const purchaseUnit = {};
        const order = {
            custom: {}
        };

        before(() => {
            paymentInstrument.paymentTransaction = {
                transactionID: 'transactionId'
            };

            createOrder.returns({
                resp: {
                    id: 'orderId'
                }
            });
        });

        after(() => {
            createOrder.reset();
            createErrorLog.reset();
            wrap.reset();
        });

        it('should be a function', () => {
            expect(creditCardHelper.completeSavedCcOrder).to.be.a('function');
        });

        it('should return an object', () => {
            expect(creditCardHelper.completeSavedCcOrder(purchaseUnit, order, paymentInstrument)).to.be.an('object');
        });

        it('should return authorize === true if order is created', () => {
            expect(creditCardHelper.completeSavedCcOrder(purchaseUnit, order, paymentInstrument)).that.deep.equal({
                authorized: true
            });
        });

        it('should return an error object if createOrder thrown an error', () => {
            const errorMsg = 'An error occurred';

            createOrder.returns({
                err: errorMsg
            });

            expect(creditCardHelper.completeSavedCcOrder(purchaseUnit, order, paymentInstrument)).that.deep.equal({
                error: true,
                authorized: false,
                fieldErrors: [],
                serverErrors: [errorMsg],
                message: errorMsg
            });

            expect(createErrorLog.calledOnce).to.be.true;
        });
    });

    describe('getCustomerData', () => {
        const lineItemCtnr = {
            customerEmail: 'email',
            billingAddress: {
                phone: 'phone'
            }
        };

        after(() => {
            customer.profile.custom = {};
        });

        it('should be a function', () => {
            expect(creditCardHelper.getCustomerData).to.be.a('function');
        });

        it('should return an object with email_address and phone', () => {
            expect(creditCardHelper.getCustomerData(lineItemCtnr)).that.deep.equal({
                email_address: lineItemCtnr.customerEmail,
                phone: {
                    phone_number: {
                        national_number: lineItemCtnr.billingAddress.phone
                    }
                }
            });
        });

        it('should return an object with email_address, phone and id', () => {
            customer.profile.custom.payPalCustomerId = 'customerId';

            expect(creditCardHelper.getCustomerData(lineItemCtnr)).that.deep.equal({
                email_address: lineItemCtnr.customerEmail,
                phone: {
                    phone_number: {
                        national_number: lineItemCtnr.billingAddress.phone
                    }
                },
                id: customer.profile.custom.payPalCustomerId
            });
        });
    });

    describe('getVerificationMethod', () => {
        const getVerificationMethod = creditCardHelper.__get__('getVerificationMethod');

        it('should return a verification method SCA_WHEN_REQUIRED', () => {
            expect(getVerificationMethod()).to.equal('SCA_WHEN_REQUIRED');
        });

        it('should return null, because verification is turned off', () => {
            prefs.verifyCardOnAccountPage = false;

            expect(getVerificationMethod()).to.be.null;
        });
    });

    describe('getCreditCardFields', () => {
        const form = {
            dwfrm_paypalCreditCard_cardName: 'Visa',
            dwfrm_paypalCreditCard_cardNumber: '4111111111111111',
            dwfrm_paypalCreditCard_cardExpirationDate: '2028-05',
            dwfrm_paypalCreditCard_cardSecurityCode: '371'
        };

        before(() => {
            getBillingAddressFromForm.returns({
                address_line_1: 'Address line1',
                address_line_2: '',
                admin_area_1: 'Texas',
                admin_area_2: 'City',
                postal_code: 'IO-315',
                country_code: 'US'
            });
            creditCardHelper.__set__('getVerificationMethod', () => null);
        });

        after(() => {
            getBillingAddressFromForm.reset();
            creditCardHelper.__ResetDependency__('getVerificationMethod');
        });

        it('should return the object which contains all the properties required for API request without verification method', () => {
            const result = creditCardHelper.getCreditCardFields(form);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('name', 'number', 'expiry', 'security_code', 'billing_address', 'experience_context');
            expect(result.experience_context).to.have.all.keys('return_url', 'cancel_url');
            expect(result).to.not.have.property('verification_method');
        });

        it('should return the object which contains all the properties required for API request and verification method', () => {
            creditCardHelper.__set__('getVerificationMethod', () => 'SCA_WHEN_REQUIRED');

            const result = creditCardHelper.getCreditCardFields(form);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('name', 'number', 'expiry', 'security_code', 'billing_address', 'experience_context', 'verification_method');
            expect(result.experience_context).to.have.all.keys('return_url', 'cancel_url');
        });
    });

    describe('validateCcFields', () => {
        it('should return an error object if cardholderName is empty', () => {
            expect(creditCardHelper.validateCcFields('cardholderName', '')).to.be.deep.equal({
                errorMessage: 'Field is empty. Please enter a value.',
                fieldName: 'holder_name',
                isError: true
            });
        });

        it('should return an error object if cardholderName is invalid', () => {
            expect(creditCardHelper.validateCcFields('cardholderName', '1invalid1-name)')).to.be.deep.equal({
                errorMessage: 'Field is invalid. Please enter a valid value.',
                fieldName: 'holder_name',
                isError: true
            });
        });

        it('should return an object without error if cardholderName is valid', () => {
            expect(creditCardHelper.validateCcFields('cardholderName', 'CorrectName')).to.be.be.deep.equal({
                isError: false
            });
        });

        it('should return an error object if field is empty', () => {
            expect(creditCardHelper.validateCcFields('cvv', {
                isEmpty: true
            })).to.be.deep.equal({
                errorMessage: 'Field is empty. Please enter a value.',
                fieldName: 'security_code',
                isError: true
            });
        });

        it('should return an error object if field is invalid', () => {
            expect(creditCardHelper.validateCcFields('expiration_date', {
                isEmpty: false,
                isValid: false
            })).to.be.deep.equal({
                errorMessage: 'Field is invalid. Please enter a valid value.',
                fieldName: 'expiration_date',
                isError: true
            });
        });

        it('should return an object without error if field is valid', () => {
            expect(creditCardHelper.validateCcFields('expiration_date', {
                isEmpty: false,
                isValid: true
            })).to.be.deep.equal({
                isError: false
            });
        });
    });

    describe('deleteCreditCardFromWallet', () => {
        const removePaymentInstrument = stub();

        before(() => {
            customer.profile.wallet = {
                removePaymentInstrument: removePaymentInstrument
            };
        });

        after(() => {
            customer.profile.wallet = {};

            wrap.reset();
        });

        it('payment instrument should be deleted from wallet', () => {
            const pi = {
                name: 'name',
                expiry: '25-01',
                brand: 'Visa',
                last_digits: '0001'
            };

            creditCardHelper.deleteCreditCardFromWallet(pi);

            expect(removePaymentInstrument.calledOnce).to.be.true;
            expect(removePaymentInstrument.calledWithExactly(pi)).to.be.true;
        });
    });

    describe('setDefaultCard', () => {
        const mockCreditCard = { custom: { payPalDefaultCard: false } };

        before(() => {
            getCustomerPaymentInstruments.returns([mockCreditCard]);
        });

        after(() => {
            wrap.reset();
            getCustomerPaymentInstruments.reset();
        });

        afterEach(() => {
            mockCreditCard.custom.payPalDefaultCard = false;
        });

        it('should set new default credit card', () => {
            creditCardHelper.setDefaultCard();

            expect(mockCreditCard.custom.payPalDefaultCard).to.be.true;
        });

        it('should not set new default credit card, because there is no more saved payment instruments', () => {
            getCustomerPaymentInstruments.returns([]);

            creditCardHelper.setDefaultCard();

            expect(mockCreditCard.custom.payPalDefaultCard).to.be.false;
        });
    });

    describe('getDefaultCard', () => {
        before(() => {
            getCustomerPaymentInstruments.returns([
                { cardName: 'FirstCard', custom: { payPalDefaultCard: false } },
                { cardName: 'SecondCard', custom: { payPalDefaultCard: false } },
                { cardName: 'ThirdCard', custom: { payPalDefaultCard: true } },
                { cardName: 'FourthCard', custom: { payPalDefaultCard: false } }
            ]);
        });

        after(() => {
            getCustomerPaymentInstruments.reset();
        });

        it('should return default credit card from customer payment instruments', () => {
            const result = creditCardHelper.getDefaultCard();

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ cardName: 'ThirdCard', custom: { payPalDefaultCard: true } });
        });
    });

    describe('updateSavedCreditCardBA', () => {
        const savedPI = {
            custom: {
                paypalCreditCardBillingAddress: 'paypalCreditCardBillingAddress-1'
            }
        };

        before(() => {
            getCustomerPiByCreditCardToken.returns(savedPI);
        });

        after(() => {
            getCustomerPiByCreditCardToken.reset();
        });

        afterEach(() => {
            wrap.reset();
        });

        it('should not update paypalCreditCardBillingAddress, because the same address was already saved', () => {
            const pi = {
                custom: {
                    paypalCreditCardBillingAddress: 'paypalCreditCardBillingAddress-1'
                }
            };

            creditCardHelper.updateSavedCreditCardBA(pi);

            expect(wrap.called).to.be.false;
        });

        it('should update paypalCreditCardBillingAddress, because different address was already saved', () => {
            const pi = {
                custom: {
                    paypalCreditCardBillingAddress: 'paypalCreditCardBillingAddress-2'
                }
            };

            creditCardHelper.updateSavedCreditCardBA(pi);

            expect(wrap.calledOnce).to.be.true;
            expect(savedPI.custom.paypalCreditCardBillingAddress).to.equal('paypalCreditCardBillingAddress-2');
        });
    });

    describe('prepareCardFieldsAccountPage', () => {
        it('should return an object with formatted fields', () => {
            expect(creditCardHelper.prepareCardFieldsAccountPage({
                number: '4111 1111 1111 1111',
                expiry: '12 / 2033'
            })).to.be.deep.equal({
                number: '4111111111111111',
                expiry: '2033-12'
            });
        });

        it('should return an object with formatted fields', () => {
            expect(creditCardHelper.prepareCardFieldsAccountPage({
                number: '4111 1111 1111 1111',
                expiry: '12 / 33'
            })).to.be.deep.equal({
                number: '4111111111111111',
                expiry: '2033-12'
            });
        });
    });

    describe('validateCardAccountPage', () => {
        it('should return an object without error if card holder name is valid', () => {
            expect(creditCardHelper.validateCardAccountPage('name', 'ValidName')).to.be.deep.equal({
                isError: false
            });
        });

        it('should return an object with error if card holder name is invalid', () => {
            expect(creditCardHelper.validateCardAccountPage('name', '.Invalid..Name...')).to.be.deep.equal({
                isError: true,
                fieldName: 'card-holder-name',
                errorMessage: 'Field is invalid. Please enter a valid value.'
            });
        });

        it('should return an object without error if expiration date field is valid', () => {
            expect(creditCardHelper.validateCardAccountPage('expiry', '2033-12')).to.be.deep.equal({
                isError: false
            });
        });

        it('should return an object with error if expiration date field is invalid', () => {
            expect(creditCardHelper.validateCardAccountPage('expiry', '2033-15')).to.be.deep.equal({
                isError: true,
                fieldName: 'expiration-date',
                errorMessage: 'Field is invalid. Please enter a valid value.'
            });
        });

        it('should return an object with error if credit card is expired', () => {
            expect(creditCardHelper.validateCardAccountPage('expiry', '2002-12')).to.be.deep.equal({
                isError: true,
                fieldName: 'expiration-date',
                errorMessage: 'Expired'
            });
        });
    });
});
