/* eslint-disable no-underscore-dangle */

const { int_paypal: { billingAgreementHelperPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({ plugins: ['babel-plugin-rewire'] });

const billingAgreementHelper = proxyquire(billingAgreementHelperPath, {});

describe('billingAgreementHelper file', () => {
    describe('createBaFromForm', () => {
        it('should return BA object with data', () => {
            let billingForm = {
                paypal: {
                    billingAgreementID: {
                        htmlValue: 'B-31J59452XL217381K'
                    },
                    billingAgreementPayerEmail: {
                        htmlValue: 'epamtester@pptest.com'
                    },
                    makeDefaultPaypalAccount: {
                        checked: true
                    },
                    savePaypalAccount: {
                        checked: true
                    }
                }
            };

            let createdBa = {
                baID: 'B-31J59452XL217381K',
                email: 'epamtester@pptest.com',
                default: true,
                saveToProfile: true
            };

            expect(billingAgreementHelper.createBaFromForm(billingForm)).to.deep.equals(createdBa);
        });
    });

    describe('isSameBillingAgreement', () => {
        it('should return true if billing agreements are the same', () => {
            let activeBA = {
                email: 'epamtester@pptest.com',
                default: true,
                saveToProfile: true
            };

            let formBA = {
                email: 'epamtester@pptest.com',
                default: true,
                saveToProfile: true
            };

            expect(billingAgreementHelper.isSameBillingAgreement(activeBA, formBA)).to.be.equals(true);
        });

        it('should return false if billing agreements are different', () => {
            let activeBA = {
                email: 'test@test.com',
                default: false,
                saveToProfile: true
            };

            let formBA = {
                email: 'epamtester@pptest.com',
                default: true,
                saveToProfile: true
            };

            expect(billingAgreementHelper.isSameBillingAgreement(activeBA, formBA)).to.be.equals(false);
        });
    });

    describe('createBAReqBody', () => {
        const paymentInstrument = {
            custom: {
                PP_API_ActiveBillingAgreement: JSON.stringify({ baID: 'id' })
            }
        };

        it('should return body for request', () => {
            expect(billingAgreementHelper.createBAReqBody(paymentInstrument))
                .to.be.an('object')
                .that.deep.equal({
                    payment_source: {
                        token: {
                            id: 'id',
                            type: 'BILLING_AGREEMENT'
                        }
                    }
                });
        });
    });

    describe('isBillingAgreementID', () => {
        const billingForm = {
            paypal: {
                billingAgreementID: { htmlValue: '{}' }
            }
        };

        it('should return true if billingAgreementID is set', () => {
            expect(billingAgreementHelper.isBillingAgreementID(billingForm)).to.be.true;
        });

        it('should return false if billingAgreementID is empty or not set', () => {
            billingForm.paypal.billingAgreementID.htmlValue = '';

            expect(billingAgreementHelper.isBillingAgreementID(billingForm)).to.be.false;
        });
    });

    describe('getBaFromPaymentInstument', () => {
        const paymentInstrument = {
            custom: {
                PP_API_ActiveBillingAgreement: JSON.stringify({
                    baID: 'billing-aggreament-id'
                })
            }
        };

        it('should return an object with BillingAgreement details', () => {
            expect(billingAgreementHelper.getBaFromPaymentInstument(paymentInstrument)).to.be.an('object');
        });

        it('should return null if PP_API_ActiveBillingAgreement is not set', () => {
            paymentInstrument.custom.PP_API_ActiveBillingAgreement = null;

            expect(billingAgreementHelper.getBaFromPaymentInstument(paymentInstrument)).to.be.null;
        });
    });
});
