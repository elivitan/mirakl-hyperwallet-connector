const { int_paypal: { paypalPreferencesPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

const paypalCartButtonConfig = stub();
const paypalBillingButtonConfig = stub();
const paypalPdpButtonConfig = stub();
const paypalMinicartButtonConfig = stub();
const paypalStaticImageLink = stub();
const CWPPStaticImageLink = stub();
const getValue = stub();
const getActivePaymentMethods = stub();

getActivePaymentMethods.returns([
    {
        ID: 'ID',
        paymentProcessor: {
            ID: 'ID'
        }
    }
]);

Object.setPrototypeOf(Array, {
    some: () => {
    },
    forEach: (arr, callBack) => {
        if (arr !== undefined) {
            for (let i = 0; i < arr.length; i += 1) {
                callBack(arr[i], i, this);
            }
        }
    }
});

const paypalPreferences = proxyquire(paypalPreferencesPath, {
    'dw/order/PaymentMgr': {
        getActivePaymentMethods: getActivePaymentMethods
    },
    'dw/system/Site': {
        current: {
            getCustomPreferenceValue: (pref) => ({
                getValue: () => getValue(pref)
            })
        }
    },
    './sdkConfig': {
        paypalCartButtonConfig,
        paypalBillingButtonConfig,
        paypalPdpButtonConfig,
        paypalMinicartButtonConfig,
        paypalStaticImageLink,
        CWPPStaticImageLink
    },
    '*/cartridge/config/paypalConstants': {
        SESSION_PAYMENTS_AVAILABILITY_LOGGEDIN: 'LoggedIn',
        SESSION_PAYMENTS_AVAILABILITY_ALL: 'All'
    },
    '~/cartridge/scripts/paypal/helpers/paymentHelper': {
        getActivePaymentMethods: () => ({})
    }
});

describe('paypalPreferences file', () => {
    describe('getPreferences', () => {
        const getPreferences = paypalPreferences.__get__('getPreferences');

        after(() => {
            customer.authenticated = null;
        });

        it('should include isSessionPaymentsEnabled set to true if session payments are enabled for logged-in user', () => {
            getValue.withArgs('PP_Session_Payments_Enabled').returns('LoggedIn');
            customer.authenticated = true;

            expect(getPreferences()).to.have.property('isSessionPaymentsEnabled').which.is.true;
        });

        it('should include isSessionPaymentsEnabled set to true if session payments are enabled for all users', () => {
            getValue.withArgs('PP_Session_Payments_Enabled').returns('All');

            expect(getPreferences()).to.have.property('isSessionPaymentsEnabled').which.is.true;
        });

        it('should include isSessionPaymentsEnabled set to false if session payments are disabled', () => {
            getValue.withArgs('PP_Session_Payments_Enabled').returns('Disabled');

            expect(getPreferences()).to.have.property('isSessionPaymentsEnabled').which.is.false;
        });

        it('should include the boolean threeDSecureFlow property', () => {
            expect(getPreferences()).to.have.property('isSessionPaymentsEnabled').which.is.string;
        });

        it('should have the property verifyCardOnAccountPage', () => {
            expect(getPreferences()).to.have.property('verifyCardOnAccountPage');
        });
    });

    describe('getActiveLPMs', () => {
        const getActiveLPMs = paypalPreferences.__get__('getActiveLPMs');

        before(() => {
            getActivePaymentMethods.returns([
                {
                    ID: 'venmo',
                    paymentProcessor: {
                        ID: 'PAYPAL_LOCAL'
                    }
                },
                {
                    ID: 'mybank',
                    paymentProcessor: {
                        ID: 'PAYPAL_LOCAL'
                    }
                },
                {
                    ID: 'PayPal',
                    paymentProcessor: {
                        ID: 'PAYPAL'
                    }
                }
            ]);
        });

        after(() => {
            getActivePaymentMethods.reset();
        });

        it('should return an array with lpms', () => {
            expect(getActiveLPMs()).to.be.deep.equal(['venmo', 'mybank']);
        });
    });
});
