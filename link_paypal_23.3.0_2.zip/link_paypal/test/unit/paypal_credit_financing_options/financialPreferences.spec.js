const { paypal_credit_financing_options: { financialPreferencesPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');

require('dw-api-mock/demandware-globals');
require('babel-register')({ plugins: ['babel-plugin-rewire'] });

let campaignResponse;
let bannerSize;

const responseObj = {
    bannerSize,
    publisherID: 'PP_Merchant_Publisher_ID',
    isActive: 'PP_Show_Credit_Financial_Banners'
};

const financialPreferences = require('proxyquire').noCallThru()(financialPreferencesPath, {
    'dw/system/Site': {
        current: {
            getCustomPreferenceValue: value => value
        }
    },
    'dw/campaign/PromotionMgr': {
        getCampaign: () => campaignResponse
    }
});

describe('financialPreferences', () => {
    describe('getCreditBannerData', () => {
        const getCreditBannerData = financialPreferences.__get__('getCreditBannerData');

        it('response type should be equal -> object', () => {
            expect(financialPreferences).to.be.a('object');
            expect(financialPreferences).deep.equal(responseObj);
        });

        it('it should return false if the credit campaign is not active', () => {
            campaignResponse = {
                isActive: () => false
            };

            expect(getCreditBannerData()).to.deep.equal({ isActive: false });
        });

        it('it should return an object without bannerSize if ppCreditBannerHeight and ppCreditBannerWidth are empty', () => {
            campaignResponse = {
                isActive: () => true
            };

            financialPreferences.__set__('ppCreditBannerHeight', 100);
            financialPreferences.__set__('ppCreditBannerWidth', 100);

            expect(getCreditBannerData().bannerSize).to.be.equal('100x100');
        });
    });
});
