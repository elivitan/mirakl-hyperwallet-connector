const { paypal_credit_financing_options: { financialApiPath } } = require('../path.json');

const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const { it, describe } = require('mocha');
const { stub } = require('sinon');

const paypalRestServiceStub = {
    call: (type, url, data) => {
        return {
            requestUrl: 'https://developer.paypal.com/docs/limited-release/financing-options/api/' + url,
            requestType: type,
            requestData: data
        };
    }
};

const financialApi = proxyquire(financialApiPath, {
    '*/cartridge/scripts/paypal/paypalUtils': {
        createErrorMsg: stub().returns('Mocked error message')
    },
    '*/cartridge/scripts/service/paypalRestService': paypalRestServiceStub
});

describe('financialApi file', () => {
    describe('getCalculatedFinancingOptions', () => {
        const data = {};

        it('response type should be equal -> object', () => {
            expect(financialApi.getCalculatedFinancingOptions(data)).to.be.a('object');
        });

        it('should handle error and return error message', () => {
            paypalRestServiceStub.call = stub().throws(new Error('Mocked error message'));

            const result = financialApi.getCalculatedFinancingOptions(data);

            expect(result).to.deep.equal({ err: 'Mocked error message' });
        });
    });
});
