const { bm_paypal_configuration: { paymentHelperPath } } = require('../path.json');

const { stub } = require('sinon');
const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const paymentHelper = proxyquire(paymentHelperPath, {
    'dw/order/PaymentMgr': dw.order.PaymentMgr
});

describe('paymentHelper file', () => {
    describe('getPaymentMethod', () => {
        before(() => {
            stub(dw.order.PaymentMgr, 'getPaymentMethod').returns({});
        });

        after(() => {
            dw.order.PaymentMgr.getPaymentMethod.restore();
        });

        it('should returns a PaymentMethod object', () => {
            expect(paymentHelper.getPaymentMethod('PayPal')).to.be.an('object');
        });
    });
});
