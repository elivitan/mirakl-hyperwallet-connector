CHANGELOG
=========

## 23.3.0
* Hosted fields on the My Account page
* Hosted fields integration on Checkout page
* Redesign of the existing PayPal Plugin Configuration in BM
* LiPP account linking additional security layer
* Unlink Login with PayPal from my user account
* Verification and Vaulting on Checkout page
* Email notification regarding unlinking with the pre-existing user account
* Address retrieval for Hosted Fields on Checkout page
* Highlight CC which are going to expire or is expired
* Show notification for expired CC on the My Account page
* Hosted fields validation errors for My Account page
* Investigate the possibility of using 3DS on the My Account page
* Add Config Check pop-up
* Test connection with PayPal
* Code quality improvement: Ajax & CSRF Tokenization
* Implement idempotency requests: adding header
* EC with Paypal: unsupported shipping handling
* Improvement regarding Automatic PM adding flow
* LiPP notifications improvements
* Implement Cross-Border Pay Later Messaging
* Transactions order: Replace buttons Capture and Void with button Authorize Payment
* Hide PayPal Debit Credit button if Hosted Fields are enabled

## 23.1.0
* SFRA base cartridge updated to 6.3.0 version.
* Usage of "actions.order.create" method was removed from client JS side.
* Usage of "actions.order.capture" method was removed from client JS side.
* Pay Now flow added.
* Improvements for the PayPal Transactions in the BM added.
* General small code improvements and bug fixing added.

## 22.1.0
* SFRA support up to 6.1.0

## 21.3.0
* SFRA support up to 6.0
