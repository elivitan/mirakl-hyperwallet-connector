'use strict';

const page = module.superModule;
const server = require('server');

const csrfProtection = require('*/cartridge/scripts/middleware/csrf');

const {
    addEnableFundigParamPaylater
} = require('*/cartridge/scripts/helpers/enableFundingHelper');

server.extend(page);

server.append('Begin', csrfProtection.generateToken, function(_, res, next) {
    const paypal = res.getViewData().paypal;

    if (paypal) {
        const sdkUrl = paypal.sdkUrl;

        paypal.sdkUrl = addEnableFundigParamPaylater(sdkUrl);
    }

    res.setViewData({
        paypal: paypal
    });

    next();
});

module.exports = server.exports();
