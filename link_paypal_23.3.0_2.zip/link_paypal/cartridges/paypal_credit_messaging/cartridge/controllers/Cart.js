'use strict';

const page = module.superModule;
const server = require('server');

const Site = require('dw/system/Site');
const BasketMgr = require('dw/order/BasketMgr');

const csrfProtection = require('*/cartridge/scripts/middleware/csrf');

const {
    getClientId
} = require('*/cartridge/scripts/paypal/paypalUtils');

const {
    cartMessageConfig
} = require('*/cartridge/config/creditMessageConfig');

const {
    addEnableFundigParamPaylater
} = require('*/cartridge/scripts/helpers/enableFundingHelper');

const {
    isPayPalPmActive,
    billingAgreementEnabled
} = require('*/cartridge/config/paypalPreferences');

server.extend(page);

server.append('Show', csrfProtection.generateToken, function(req, res, next) {
    const currentSite = Site.getCurrent();
    const creditMessageAvailable = !billingAgreementEnabled
        && isPayPalPmActive
        && currentSite.getCustomPreferenceValue('PP_Show_On_Cart');

    if (!creditMessageAvailable) {
        return next();
    }

    const paypal = res.getViewData().paypal;

    if (paypal) {
        const sdkUrl = paypal.sdkUrl;

        paypal.sdkUrl = addEnableFundigParamPaylater(sdkUrl);
    }

    this.on('route:BeforeComplete', function(req, res) { // eslint-disable-line no-shadow
        const basket = BasketMgr.getCurrentBasket();

        if (!basket) {
            return;
        }

        const paypalPayLaterCrossBorderMassagingEnabled = currentSite.getCustomPreferenceValue('PP_Pay_Later_Cross_Border_Messaging_Enabled');
        const clientID = getClientId();
        const bannerSdkUrl = ['https://www.paypal.com/sdk/js?client-id=', clientID, '&components=messages'].join('');

        if (paypalPayLaterCrossBorderMassagingEnabled) {
            const Locale = require('dw/util/Locale');

            const currentLocale = Locale.getLocale(req.locale.id).country;
            const currency = req.session.currency;

            paypal.locale = currentLocale;
            paypal.currencyCode = currency.currencyCode;
        }

        res.setViewData({
            paypalAmount: basket.totalGrossPrice.value,
            bannerSdkUrl: bannerSdkUrl,
            bannerConfig: cartMessageConfig,
            creditMessageAvailable: creditMessageAvailable,
            paypal: paypal
        });
    });

    return next();
});

module.exports = server.exports();
