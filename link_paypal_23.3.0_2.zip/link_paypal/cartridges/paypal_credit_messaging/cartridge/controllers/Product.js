'use strict';

const page = module.superModule;
const server = require('server');

const Site = require('dw/system/Site');

const csrfProtection = require('*/cartridge/scripts/middleware/csrf');

const {
    getClientId
} = require('*/cartridge/scripts/paypal/paypalUtils');

const {
    cartSdkUrl
} = require('*/cartridge/config/paypalSDK');

const {
    isPaypalButtonEnabled
} = require('*/cartridge/scripts/paypal/helpers/paypalHelper');

const {
    productDetailMessageConfig
} = require('*/cartridge/config/creditMessageConfig');

const {
    addEnableFundigParamPaylater
} = require('*/cartridge/scripts/helpers/enableFundingHelper');

const {
    isPayPalPmActive,
    billingAgreementEnabled
} = require('*/cartridge/config/paypalPreferences');

server.extend(page);

server.append('Show', csrfProtection.generateToken, function(req, res, next) {
    const currentSite = Site.getCurrent();
    const paypal = res.getViewData().paypal;
    const paypalPayLaterCrossBorderMassagingEnabled = currentSite.getCustomPreferenceValue('PP_Pay_Later_Cross_Border_Messaging_Enabled');
    const creditMessageAvailable = !billingAgreementEnabled
        && isPayPalPmActive
        && currentSite.getCustomPreferenceValue('PP_Show_On_PDP');

    if (paypal) {
        const sdkUrl = paypal.sdkUrl;

        paypal.sdkUrl = addEnableFundigParamPaylater(sdkUrl);
    }

    if (creditMessageAvailable) {
        const clientID = getClientId();
        const creditMessageSdk = ['https://www.paypal.com/sdk/js?client-id=', clientID, '&components=messages'].join('');
        const bannerSdkUrl = (isPaypalButtonEnabled('pdp') || isPaypalButtonEnabled('minicart'))
            ? (cartSdkUrl)
            : creditMessageSdk;

        if (paypalPayLaterCrossBorderMassagingEnabled) {
            const Locale = require('dw/util/Locale');

            const currentLocale = Locale.getLocale(req.locale.id).country;
            const currency = req.session.currency;

            paypal.locale = currentLocale;
            paypal.currencyCode = currency.currencyCode;
        }

        res.setViewData({
            bannerSdkUrl: bannerSdkUrl,
            bannerConfig: productDetailMessageConfig,
            creditMessageAvailable: creditMessageAvailable,
            paypal: paypal
        });
    }

    next();
});

module.exports = server.exports();
