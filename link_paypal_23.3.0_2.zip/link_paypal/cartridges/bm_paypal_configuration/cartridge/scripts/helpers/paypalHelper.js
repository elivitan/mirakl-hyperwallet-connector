'use strict';

const payPalPreferences = require('*/cartridge/config/paypalPreferences');

/**
 * Check if Paypal button is enabled
 * @param {string} targetPage button location value
 * @return {boolean} disabled or enabled
 */
function isPaypalButtonEnabled(targetPage) {
    const paypalButtonLocation = payPalPreferences.payPalButtonLocation;
    const displayPages = paypalButtonLocation.toLowerCase();

    if (displayPages === 'none' || !targetPage) {
        return false;
    }

    return displayPages.split(',').filter(Boolean).indexOf(targetPage) !== -1;
}

module.exports = {
    isPaypalButtonEnabled: isPaypalButtonEnabled
};
