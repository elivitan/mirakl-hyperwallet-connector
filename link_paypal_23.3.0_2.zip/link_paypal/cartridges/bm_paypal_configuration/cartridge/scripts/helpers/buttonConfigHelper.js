'use strict';

const payPalPreferences = require('*/cartridge/config/paypalPreferences');

/**
 * Gets active paypal credit messaging Site Pref metadata
 *
 * @returns {Object} with cart, product, category enabled flag
 * */
function getBannerConfigPages() {
    const preferenceNaming = {
        payPalShowOnPdp: 'PP_Show_On_PDP',
        payPalShowOnCart: 'PP_Show_On_Cart',
        payPalShowOnCategory: 'PP_Show_On_Category'
    };

    return Object.keys(preferenceNaming).reduce(function(preferenceValues, name) {
        const value = payPalPreferences[name];
        const preferenceName = preferenceNaming[name];

        if (value) {
            preferenceValues[preferenceName.split('_').pop().toLocaleLowerCase()] = value;
        }

        return preferenceValues;
    }, {});
}

/**
 * @param {string} locale - a locale value
 * @returns {string} - return a locale with hyphen
 */
function getLocaleWithHyphen(locale) {
    const Site = require('dw/system/Site');

    let currentLocale = locale;

    if (currentLocale === 'default') {
        currentLocale = Site.current.defaultLocale;
    }

    if (currentLocale.split('_').length !== 2) {
        currentLocale = [currentLocale, currentLocale].join('-');
    }

    return currentLocale.toLowerCase().replace('_', '-');
}

module.exports = {
    getLocaleWithHyphen: getLocaleWithHyphen,
    getBannerConfigPages: getBannerConfigPages
};
