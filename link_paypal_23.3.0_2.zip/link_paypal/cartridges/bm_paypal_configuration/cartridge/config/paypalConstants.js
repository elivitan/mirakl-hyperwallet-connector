'use strict';

const dwSystem = require('dw/system/System');

const baseConstants = module.superModule;

const constants = Object.assign(baseConstants, {
    instanceType: dwSystem.instanceType === dwSystem.PRODUCTION_SYSTEM ? baseConstants.INSTANCE_PRODUCTION : baseConstants.INSTANCE_SANDBOX
});

module.exports = constants;
