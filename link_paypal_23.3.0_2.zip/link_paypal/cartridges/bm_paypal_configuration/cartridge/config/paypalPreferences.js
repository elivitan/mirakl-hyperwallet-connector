'use strict';

const currentSite = require('dw/system/Site').current;

/**
 * Get client id
 * @returns {string} client id
 */
function getClientId() {
    const serviceName = 'int_paypal.http.rest';
    const paypalService = require('dw/svc/LocalServiceRegistry').createService(serviceName, {});

    return paypalService.configuration.credential.user;
}

const paypalButtonLocation = currentSite.getCustomPreferenceValue('PP_Button_Location');

module.exports = {
    clientId: getClientId(),
    buttonStylesApi: {
        cwpp: currentSite.getCustomPreferenceValue('PP_CWPP_Button_Styles'),
        payPalSmart: currentSite.getCustomPreferenceValue('PP_Smart_Button_Styles'),
        payPalCredit: currentSite.getCustomPreferenceValue('PP_Credit_Banner_Styles')
    },
    payPalShowOnPdp: currentSite.getCustomPreferenceValue('PP_Show_On_PDP'),
    payPalShowOnCart: currentSite.getCustomPreferenceValue('PP_Show_On_Cart'),
    payPalShowOnCategory: currentSite.getCustomPreferenceValue('PP_Show_On_Category'),
    payPalButtonLocation: paypalButtonLocation.length ? paypalButtonLocation.join(',') : 'Billing',
    hostedFieldsStyles: currentSite.getCustomPreferenceValue('PP_Hosted_Fields_Styles')
};
