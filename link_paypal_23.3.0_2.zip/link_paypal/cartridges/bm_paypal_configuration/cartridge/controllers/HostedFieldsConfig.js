'use strict';

/**
 * @namespace HostedFieldsConfig
 */

const payPalPreferences = require('*/cartridge/config/paypalPreferences');

/**
 * Renders configuration template with required configurations and parameters
 */
function start() {
    require('dw/template/ISML').renderTemplate('button/hostedFields/configuration', {
        hostedFieldsStyles: payPalPreferences.hostedFieldsStyles
    });
}

/**
 * Save Button configuration to Custom Preference
 *
 * success response: (status code 200) with redirect url
 * error response: (status code 500) with error message
 * */
function saveButton() {
    const Transaction = require('dw/system/Transaction');

    response.setContentType('application/json');

    try {
        const params = request.httpParameterMap;

        const hostedFieldsStyles = {
            color: params.inputColor.value,
            invalidColor: params.invalidColor.value,
            validColor: params.validColor.value,
            fontSize: params.fontSize.value
        };

        Transaction.wrap(function() {
            require('dw/system/Site').current.setCustomPreferenceValue('PP_Hosted_Fields_Styles', JSON.stringify(hostedFieldsStyles));
        });

        response.writer.print(JSON.stringify({
            redirectUrl: require('dw/web/URLUtils').https('Configuration-Start',
                'isHostedFieldStyles',
                true,
                'tab',
                'hostedfields').toString()
        }));
    } catch (error) {
        response.setStatus(500);
        response.writer.print(error.message);
    }
}

start.public = true;
saveButton.public = true;

exports.Start = start;
exports.SaveButton = saveButton;
