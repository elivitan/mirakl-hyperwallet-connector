'use strict';

/**
 * @namespace Configuration
 */

/**
 * Gets the alert message text to show on successful saving of button configs
 * @returns {string} alert message text
 */
function getButtonSavedFlashMessage() {
    const Resource = require('dw/web/Resource');
    const savedPPButtonLocation = request.httpParameterMap.savedButtonStyle.stringValue;
    const savedPPCreditBannerLocation = request.httpParameterMap.savedBannerStyles.stringValue;
    const savedCWPPButtonLocation = request.httpParameterMap.location.stringValue;
    const isHostedFieldStyles = request.httpParameterMap.isHostedFieldStyles.stringValue;

    if (savedPPButtonLocation) {
        return Resource.msgf('smartbutton.saved.title', 'paypalbmconfiguration', null, savedPPButtonLocation);
    }

    if (savedPPCreditBannerLocation) {
        const pageName = Resource.msgf('banner.configuration.option.' + savedPPCreditBannerLocation, 'paypalbmconfiguration', null);

        return Resource.msgf('banner.saved.title', 'paypalbmconfiguration', null, pageName);
    }

    if (savedCWPPButtonLocation) {
        return Resource.msgf('cwpp.saved.title', 'paypalbmconfiguration', null, savedCWPPButtonLocation);
    }

    if (isHostedFieldStyles) {
        return Resource.msg('hostedfields.saved.title', 'paypalbmconfiguration', null);
    }

    return '';
}

/**
 * Renders configuration template with required configurations and parameters
 */
function start() {
    const payPalUrls = require('*/cartridge/config/paypalUrls');
    const payPalPreferences = require('*/cartridge/config/paypalPreferences');

    require('dw/template/ISML').renderTemplate('button/configurationBoard', {
        savedSBLocation: request.httpParameterMap.savedButtonStyle.stringValue,
        savedBSLocation: request.httpParameterMap.savedBannerStyles.stringValue,
        flashMessages: getButtonSavedFlashMessage(),
        payPalSDK: payPalUrls.payPalSDK.replace(/\{0\}/, payPalPreferences.clientId)
    });
}

start.public = true;

exports.Start = start;
