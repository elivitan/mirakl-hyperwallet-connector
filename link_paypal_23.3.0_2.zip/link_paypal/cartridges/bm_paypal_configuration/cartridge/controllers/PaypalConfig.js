'use strict';

/* global request response */

const currentSite = require('dw/system/Site').current;
const Transaction = require('dw/system/Transaction');

const payPalPreferences = require('*/cartridge/config/paypalPreferences');

/**
 * Renders configurationBoard template with required configurations and parameters
 * */
function start() {
    const paypalHelper = require('~/cartridge/scripts/helpers/paypalHelper');
    const paymentHelper = require('~/cartridge/scripts/helpers/paymentHelper');
    const buttonConfigHelper = require('~/cartridge/scripts/helpers/buttonConfigHelper');
    const payPalConstants = require('*/cartridge/config/paypalConstants');

    require('dw/template/ISML').renderTemplate('button/paypal/configuration', {
        cartButtonEnabled: paypalHelper.isPaypalButtonEnabled('cart'),
        minicartButtonEnabled: paypalHelper.isPaypalButtonEnabled('minicart'),
        pdpButtonEnabled: paypalHelper.isPaypalButtonEnabled('pdp'),
        pvpButtonEnabled: paypalHelper.isPaypalButtonEnabled('pvp'),
        savedSBLocation: request.httpParameterMap.savedButtonStyle.stringValue,
        savedBSLocation: request.httpParameterMap.savedBannerStyles.stringValue,
        savedSmartStyles: payPalPreferences.buttonStylesApi.payPalSmart,
        savedBannerConfigs: payPalPreferences.buttonStylesApi.payPalCredit,
        bannerConfigs: buttonConfigHelper.getBannerConfigPages(),
        isPaymentMethodEnabled: paymentHelper.getPaymentMethod(payPalConstants.PAYMENT_METHOD_ID_PAYPAL)
    });
}

/**
 * Save smart Button configuration to Custom Preference value
 *
 * sucess response: (status code 200) with redirect url
 * error response: (status code 500) with error message
 * */
function saveSmartButton() {
    response.setContentType('application/json');

    try {
        const params = request.httpParameterMap;
        const data = JSON.parse(payPalPreferences.buttonStylesApi.payPalSmart);

        const smartButtonStyle = {
            height: params.heightFormControlRange.intValue,
            color: params.color.value,
            shape: params.shape.value,
            label: params.label.value,
            layout: params.layout.value,
            tagline: params.tagline.booleanValue
        };

        data[params.location.value] = smartButtonStyle;

        Transaction.wrap(function() {
            currentSite.setCustomPreferenceValue('PP_Smart_Button_Styles', JSON.stringify(data));
        });

        response.writer.print(JSON.stringify({
            redirectUrl: require('dw/web/URLUtils').https('Configuration-Start',
                'savedButtonStyle',
                params.location.value,
                'tab',
                'paypal').toString()
        }));
    } catch (error) {
        response.setStatus(500);
        response.writer.print(error.message);
    }
}

/**
 * Save banner configuration to Custom Preference value
 *
 * sucess response: (status code 200) with redirect url
 * error response: (status code 500) with error message
 * */
function saveCreditBanner() {
    response.setContentType('application/json');

    try {
        const params = request.httpParameterMap;
        const data = JSON.parse(payPalPreferences.buttonStylesApi.payPalCredit);

        const bannerStyle = {
            styleColor: params.styleColor.value,
            styleRatio: params.styleRatio.value,
            styleLayout: params.styleLayout.value,
            styleTextColor: params.styleTextColor.value,
            styleLogoPosition: params.styleLogoPosition.value,
            styleLogoType: params.styleLogoType.value
        };

        data[params.placement.value] = bannerStyle;

        Transaction.wrap(function() {
            currentSite.setCustomPreferenceValue('PP_Credit_Banner_Styles', JSON.stringify(data));
        });

        response.writer.print(JSON.stringify({
            redirectUrl: require('dw/web/URLUtils').https('Configuration-Start',
                'savedBannerStyles',
                params.placement.value,
                'tab',
                'paypal').toString()
        }));
    } catch (error) {
        response.setStatus(500);
        response.writer.print(error.message);
    }
}

start.public = true;
saveSmartButton.public = true;
saveCreditBanner.public = true;

exports.Start = start;
exports.SaveSmartButton = saveSmartButton;
exports.SaveCreditBanner = saveCreditBanner;
