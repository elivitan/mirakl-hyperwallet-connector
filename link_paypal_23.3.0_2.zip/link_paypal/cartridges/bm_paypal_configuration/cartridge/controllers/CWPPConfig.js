'use strict';

/* global request response */

const payPalPreferences = require('*/cartridge/config/paypalPreferences');

/**
 * @namespace CWPPConfig
 */

/**
 * Renders configuration template with required configurations and parameters
 */
function start() {
    const paymentHelper = require('~/cartridge/scripts/helpers/paymentHelper');
    const buttonConfigHelper = require('~/cartridge/scripts/helpers/buttonConfigHelper');
    const payPalUrls = require('*/cartridge/config/paypalUrls');
    const payPalConstants = require('*/cartridge/config/paypalConstants');

    const payPalApiConfig = {
        appid: payPalPreferences.clientId,
        locale: buttonConfigHelper.getLocaleWithHyphen(request.getLocale()),
        returnurl: payPalUrls.cwppConfigUrl,
        authend: payPalConstants.instanceType
    };

    require('dw/template/ISML').renderTemplate('button/cwpp/configuration', {
        payPalApiConfig: JSON.stringify(payPalApiConfig),
        payPalExternalApi: payPalUrls.payPalExternalSDK,
        pdpButtonEnabled: false,
        cartButtonEnabled: false,
        minicartButtonEnabled: false,
        buttonStyles: payPalPreferences.buttonStylesApi.cwpp,
        isPaymentMethodEnabled: paymentHelper.getPaymentMethod(payPalConstants.PAYMENT_METHOD_ID_PAYPAL)
    });
}

/**
 * Save Button configuration to Custom Preference
 *
 * sucess response: (status code 200) with redirect url
 * error response: (status code 500) with error message
 * */
function saveButton() {
    const Transaction = require('dw/system/Transaction');

    response.setContentType('application/json');

    try {
        const params = request.httpParameterMap;
        const data = JSON.parse(payPalPreferences.buttonStylesApi.cwpp);

        const buttonStyle = {
            theme: params.theme.value,
            buttonType: params.buttonType.value,
            buttonSize: params.buttonSize.value,
            buttonShape: params.buttonShape.value
        };

        data[params.location.value] = buttonStyle;

        Transaction.wrap(function() {
            require('dw/system/Site').current.setCustomPreferenceValue('PP_CWPP_Button_Styles', JSON.stringify(data));
        });

        response.writer.print(JSON.stringify({
            redirectUrl: require('dw/web/URLUtils').https('Configuration-Start',
                'tab',
                'cwpp',
                'location',
                params.location.value).toString()
        }));
    } catch (error) {
        response.setStatus(500);
        response.writer.print(error.message);
    }
}

start.public = true;
saveButton.public = true;

exports.Start = start;
exports.SaveButton = saveButton;
