'use strict';

((win, doc) => {
    const $cardNumberField = doc.getElementById('card-number');
    const $expDataField = doc.getElementById('exp-date');
    const $cvvField = doc.getElementById('cvv');

    const $form = doc.getElementById('js-pphf-config-form');
    const $color = doc.getElementById('js-pphf-input-color');
    const $invalidColor = doc.getElementById('js-pphf-invalid-color');
    const $validColor = doc.getElementById('js-pphf-valid-color');

    const $fontSizeFormControlNumber = doc.getElementById('js-font-size-number');
    const $fontSizeFormControlRange = doc.getElementById('js-font-size-range');

    const $allExampleInputs = doc.getElementsByClassName('js-hosted-fields-form-input');

    /**
    * Validates inputs based on field values
    */
    function validate () {
        if ($cardNumberField.value === '1111 1111 1111 1111') {
            $cardNumberField.style.color = $invalidColor.value;
        } else if ($cardNumberField.value.length === 19){
            $cardNumberField.style.color = $validColor.value;
        } else {
            $cardNumberField.style.color = $color.value;
        }

        if ($expDataField.value === '11 / 11') {
            $expDataField.style.color = $invalidColor.value;
        } else if ($expDataField.value.length === 7) {
            $expDataField.style.color = $validColor.value;
        } else {
            $expDataField.style.color = $color.value;
        }

        if ($cvvField.value.length === 3) {
            $cvvField.style.color = $validColor.value;
        } else {
            $cvvField.style.color = $color.value;
        }
    };

    /**
     * Updates the credit card view based on selected styles
     */
    function updateView() {
        Array.prototype.forEach.call($allExampleInputs, (element) => {
            element.style.color = $color.value;
            element.style.fontSize = `${$fontSizeFormControlRange.value}pt`;
        });

        validate();
    };

    $fontSizeFormControlRange.addEventListener('change', () => {
        $fontSizeFormControlNumber.value = $fontSizeFormControlRange.value;

        Array.prototype.forEach.call($allExampleInputs, (element) => {
            element.style.fontSize = `${$fontSizeFormControlRange.value}pt`;
        });
    });

    $fontSizeFormControlNumber.addEventListener('change', () => {
        $fontSizeFormControlRange.value = $fontSizeFormControlNumber.value;
    });

    $form.addEventListener('change', () => updateView());

    $cvvField.addEventListener('input', () => updateView());

    $cardNumberField.addEventListener('input', (event) => {
        const cardField = event.target;
        const cardValue = cardField.value.replace(/\D/g, '').substring(0, 16);

        let formattedValue = '';

        for (let i = 0; i < cardValue.length; i++) {
            if (i > 0 && i % 4 === 0) {
                formattedValue += ' ';
            }

            formattedValue += cardValue.charAt(i);
        };

        cardField.value = formattedValue;

        validate();
    });

    $expDataField.addEventListener('input', (event) => {
        const expDateField = event.target;
        const expDateValue = expDateField.value.replace(/\D/g, '').substring(0, 4);

        let formattedValue = '';

        for (let i = 0; i < expDateValue.length; i++) {
            if (i === 2) {
                formattedValue += ' / ';
            }

            formattedValue += expDateValue.charAt(i);
        }

        expDateField.value = formattedValue;

        validate();
    });

    $form.addEventListener('submit', (event) => {
        event.preventDefault();

        const alertHandler = new AlertHandlerModel();

        fetch(event.currentTarget.action, {
            method: 'POST',
            body: new FormData(event.currentTarget)
        })
            .then((response) => response.json())
            .then((response) => {
                win.location.href = response.redirectUrl;
            })
            .catch((error) => {
                alertHandler.showAlertMessage({
                    message: error.message,
                    type: 'danger'
                });
            });
    });

    doc.addEventListener('DOMContentLoaded', () => {
        const hostedFieldsStyles = JSON.parse($form.getAttribute('data-hosted-fields-styles'));

        $color.value = hostedFieldsStyles.color;
        $invalidColor.value = hostedFieldsStyles.invalidColor;
        $validColor.value = hostedFieldsStyles.validColor;

        $fontSizeFormControlNumber.value = hostedFieldsStyles.fontSize;
        $fontSizeFormControlRange.value = hostedFieldsStyles.fontSize;

        updateView();
    });
})(window, document);
