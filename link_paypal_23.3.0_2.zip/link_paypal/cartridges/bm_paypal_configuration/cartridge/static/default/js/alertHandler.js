'use strict';

class AlertHandlerModel {
    constructor() {
        this.$alertsContainer = document.querySelector('.js-flash-messages-container');
    }

    /**
     * Appends Alerts message
     * Avaible alerts types:
     * primary,  secondary, success, danger, warning, info, alert, dark
     * @param {Object} alert Alerts and type messages
     */
    showAlertMessage(alert) {
        const $alertTemplate = document.querySelector('.js-alert-template');
        const $alertContainer = $alertTemplate.cloneNode(true);

        $alertContainer.append(alert.message);
        this.$alertsContainer.append($alertContainer);

        $alertContainer.classList.add(`alert-${alert.type}`, 'show');
        $alertContainer.classList.remove('d-none');
    }

    /**
     * Fades Alerts message
     */
    fadeAlerts() {
        const $alertContainers = document.querySelectorAll('.js-alert-template');

        $alertContainers.forEach((alert) => alert.classList.add('d-none'));
    }

    /**
     * Closes an alert message
     */
    closeAlert() {
        this.$alertsContainer.addEventListener('click', (e) => {
            if (e.target.parentElement.type === 'button') {
                const closeBtn = e.target.parentElement;

                closeBtn.parentElement.classList.remove('show');
                closeBtn.parentElement.classList.add('hide');

                setTimeout(() => closeBtn.parentElement.classList.add('d-none'), 1000);
            }
        });
    }
}
