'use strict';

((win, doc, $, paypal) => {
    /**
     * Variables
     */
    const $colorButton = doc.getElementById('js-color-button');
    const $shapeButton = doc.getElementById('js-shape-button');
    const $label = doc.getElementById('js-label');
    const $locationButton = doc.getElementById('js-location-button');
    const $layoutButton = doc.getElementById('js-layout-button');
    const $smartbuttonConfigForm = doc.getElementById('js-smartbutton-form');

    const $taglineButton = doc.getElementById('js-tagline-button');
    const $heightFormControlNumber = doc.getElementById('js-height-number');
    const $heightFormControlRange = doc.getElementById('js-height-range');

    const DATA_SMART_STYLE_SELECTOR = 'data-smart-styles';
    const PAYPAL_CART_BUTTON_CLASS_SELECTOR = '.js-paypal-cart-button';
    const PAYPAL_SMART_BUTTON_DEFAULT_CONFIG = {
        height: 35,
        color: 'gold',
        shape: 'rect',
        layout: 'vertical',
        label: 'checkout',
        tagline: false
    };

    const alertHandler = new AlertHandlerModel();

    /**
     * Return style configurations for Pay Pal smart button
     * Available values:
     *  height: (number) from 25 to 55,
     *  color: (string) gold, blue, silver, black, white,
     *  shape: (string) pill, rect,
     *  layout: (string) horizontal, vertical,
     *  tagline: (boolean) true, false
     *
     * PLEASE NOTE: 'vertical' layout is not allowed for active tagline
     *
     * @returns {Object}  object with height, color, shape, layout, label, tagline configuration values in it
     */
    function getSmartButtonStyleConfigs() {
        return {
            height: Math.floor($heightFormControlRange.value),
            color: $colorButton.value,
            shape: $shapeButton.value,
            layout: $layoutButton.value,
            label: $label.value,
            tagline: JSON.parse($taglineButton.value)
        };
    }

    /**
     * Update html option's with saved Pay Pal smart button  values from custom pref PP_Smart_Button_Styles
     *
     * @param {Object} savedSmartStyles object with height, color, shape, layout, label, tagline configs
     */
    function updateValuesWithStyleConfigs(savedSmartStyles) {
        $heightFormControlNumber.value = savedSmartStyles.height;
        $heightFormControlRange.value = savedSmartStyles.height;
        $colorButton.value = savedSmartStyles.color;
        $shapeButton.value = savedSmartStyles.shape;
        $layoutButton.value = savedSmartStyles.layout;
        $label.value = savedSmartStyles.label;
        $taglineButton.value = savedSmartStyles.tagline;
        $locationButton.value = savedSmartStyles.location;
    }
    /**
     *Renders the Pay Pal smart button based on the received configuration object (styleConfiguration).
    * @param {Object} styleConfiguration object with color, height, label, layout, location, shape, tagline configs
    */
    function renderPaypalButton(styleConfiguration) {
        if (!styleConfiguration) {
            styleConfiguration = getSmartButtonStyleConfigs();
            doc.querySelector(PAYPAL_CART_BUTTON_CLASS_SELECTOR).innerHTML = '';
            alertHandler.fadeAlerts();
        }

        paypal.Buttons({
            onInit: (_, actions) => {
                return actions.disable();
            },
            createOrder: () => { },
            onApprove: () => { },
            onCancel: () => { },
            onError: () => { },
            style: styleConfiguration
        }).render(PAYPAL_CART_BUTTON_CLASS_SELECTOR);
    }

    doc.addEventListener('DOMContentLoaded', function () {
        let pageType = 'billing';
        const params = (new URLSearchParams(win.location.search));

        if (params.has('savedButtonStyle')) {
            pageType = params.get('savedButtonStyle');
            win.history.replaceState(null, null, win.location.pathname);
        }

        let smartButtonConfig = JSON.parse($smartbuttonConfigForm.getAttribute(DATA_SMART_STYLE_SELECTOR))[pageType];

        if (!smartButtonConfig) {
            smartButtonConfig = PAYPAL_SMART_BUTTON_DEFAULT_CONFIG;
        }

        smartButtonConfig.location = pageType;

        updateValuesWithStyleConfigs(smartButtonConfig);
        renderPaypalButton(smartButtonConfig);
    });

    $colorButton.addEventListener('change', () => renderPaypalButton());

    $label.addEventListener('change', () => renderPaypalButton());

    $heightFormControlRange.addEventListener('change', () => {
        const smartButtonStyleConfigs = getSmartButtonStyleConfigs();

        doc.querySelector(PAYPAL_CART_BUTTON_CLASS_SELECTOR).innerHTML = '';
        alertHandler.fadeAlerts();

        $heightFormControlNumber.value = $heightFormControlRange.value;
        renderPaypalButton(smartButtonStyleConfigs);
    });

    $heightFormControlNumber.addEventListener('change', () => {
        alertHandler.fadeAlerts();
        $heightFormControlRange.value = $heightFormControlNumber.value;
        const event = doc.createEvent('Event');
        event.initEvent('change', true, true);

        // Dispatch the event
        $heightFormControlRange.dispatchEvent(event);
    });

    $shapeButton.addEventListener('change', () => renderPaypalButton());

    $layoutButton.addEventListener('change', () => {
        // vertical layout is not allowed for active tagline
        const isTaglineButton = JSON.parse($taglineButton.value);
        const isLayoutVertical = $layoutButton.value === 'vertical';

        doc.querySelector(PAYPAL_CART_BUTTON_CLASS_SELECTOR).innerHTML = '';
        alertHandler.fadeAlerts();

        if (isTaglineButton && isLayoutVertical) {
            $taglineButton.value = false;
            alertHandler.showAlertMessage(win.resourcesAlertMessages.layout);
        }

        const smartButtonStyleConfigs = getSmartButtonStyleConfigs();

        renderPaypalButton(smartButtonStyleConfigs);
    });

    $taglineButton.addEventListener('change', () => {
        // style.tagline is not allowed for vertical layout
        const isTaglineButton = JSON.parse($taglineButton.value);
        const isLayoutVertical = $layoutButton.value === 'vertical';

        doc.querySelector(PAYPAL_CART_BUTTON_CLASS_SELECTOR).innerHTML = '';
        alertHandler.fadeAlerts();

        if (isTaglineButton && isLayoutVertical) {
            $layoutButton.value = 'horizontal';
            alertHandler.showAlertMessage(win.resourcesAlertMessages.tagline);
        }

        const smartButtonStyleConfigs = getSmartButtonStyleConfigs();

        renderPaypalButton(smartButtonStyleConfigs);
    });

    $locationButton.addEventListener('change', () => {
        const savedSmartStyles = JSON.parse(
            $smartbuttonConfigForm.getAttribute(DATA_SMART_STYLE_SELECTOR)
        );
        const locationButton = $locationButton.value;

        doc.querySelector(PAYPAL_CART_BUTTON_CLASS_SELECTOR).innerHTML = '';

        alertHandler.fadeAlerts();

        if (!savedSmartStyles[locationButton]) {
            savedSmartStyles[locationButton] = PAYPAL_SMART_BUTTON_DEFAULT_CONFIG;
        }

        savedSmartStyles[locationButton].location = locationButton;
        updateValuesWithStyleConfigs(savedSmartStyles[locationButton]);

        paypal.Buttons({
            onInit: (_, actions) => {
                return actions.disable();
            },
            createOrder: () => { },
            onApprove: () => { },
            onCancel: () => { },
            onError: () => { },
            style: savedSmartStyles[locationButton]
        }).render(PAYPAL_CART_BUTTON_CLASS_SELECTOR).then(function () {
            win.scrollTo(0, 0);
        });
    });

    $smartbuttonConfigForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // eslint-disable-next-line no-undef
        $.post(e.currentTarget.action, e.currentTarget.serialize())
            .done(function (data) {
                location.href = data.redirectUrl;
            })
            .fail(function (err) {
                alertHandler.showAlertMessage({
                    message: err.responseText,
                    type: 'danger'
                });
            });

        return false;
    });

    alertHandler.closeAlert();
})(window, document, window.jQuery, window.paypal);
