'use strict';

const serviceName = 'int_paypal.http.rest';
const ServiceCredential = require('dw/svc/ServiceCredential');
const LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
const Resource = require('dw/web/Resource');
const tokenCache = require('dw/system/CacheMgr').getCache('paypalRestOauthTokenOcapi');

const {
    createErrorLog
} = require('*/cartridge/scripts/paypal/paypalUtils');

/**
 * Deprecated method, must to be modify.
 * Create and store oauth token
 * @param  {dw.svc.Service} service current service based on serviceName
 * @returns {string} oauth token
 */
function getToken(service) {
    const bearerToken = tokenCache.get('token');

    if (bearerToken) {
        return 'Bearer ' + bearerToken;
    }

    service.setThrowOnError().call({
        createToken: true
    });

    const {
        error_description,
        access_token
    } = service.response;

    if (!error_description && access_token) {
        tokenCache.put('token', access_token);

        return 'Bearer ' + access_token;
    }

    if (error_description) {
        throw new Error(error_description);
    } else {
        throw new Error('Unknown error occurred');
    }
}

// Deprecated method, must to be modify.
/** createRequest callback for a service.
 * @param  {dw.svc.Service} service service instance
 * @param  {Object} data call data with path, method, body for a call or createToken in case of recursive call
 * @returns {string} request body
 */
function createRequest(service, data) {
    const {
        getUrlPath
    } = require('*/cartridge/scripts/paypal/helpers/paypalHelper');

    const credential = service.configuration.credential;

    if (!(credential instanceof ServiceCredential)) {
        throw new Error(Resource.msgf('service.nocredentials', 'paypalerrors', null, serviceName));
    }

    const {
        path,
        method,
        body,
        createToken,
        partnerAttributionId
    } = data;

    // recursive part for create token call
    if (createToken) {
        service.setRequestMethod('POST');
        service.setURL(getUrlPath(credential, 'v1/oauth2/token?grant_type=client_credentials'));
        service.addHeader('Content-Type', 'application/x-www-form-urlencoded');

        return '';
    }

    const token = getToken(service);

    service.setURL(getUrlPath(credential, path));
    service.addHeader('Content-Type', 'application/json');
    service.setRequestMethod(method || 'POST');
    service.addHeader('Authorization', token);

    if (partnerAttributionId) {
        service.addHeader('PayPal-Partner-Attribution-Id', partnerAttributionId);
    }

    return body ? JSON.stringify(body) : '';
}

/** Handle error
 * @param {Object} errorResponse service result object with error status
 * @param {Object} requestData data for request
 */
function errorHandler(errorResponse, requestData) {
    if (!requestData.errorMessage) {
        createErrorLog(Resource.msgf('service.wrongendpoint', 'paypalerrors', null, requestData.path));

        throw new Error();
    }

    let errorName;
    let errorDescription;
    const errorData = JSON.parse(errorResponse.errorMessage);
    const errorDetails = errorData.details[0];

    // For type error ex -> {"error", "error_description"}
    if (errorData.error) {
        errorName = errorData.error;
        errorDescription = errorData.error_description;
    // For error details with issue -> {"name", "message", "details": [{"name", "description"}]}
    } else if (errorDetails) {
        errorName = errorDetails.name || errorDetails.issue;
        errorDescription = errorDetails.message || errorDetails.description;
    } else {
        errorName = errorData.name;
        errorDescription = errorData.message;
    }

    if (errorName.toLowerCase() === 'invalid_client') {
        createErrorLog(Resource.msgf('service.wrongcredentials', 'paypalerrors', null, errorResponse.configuration.credential.ID));
    } else {
        createErrorLog(errorDescription);
    }

    throw new Error(['Error Name: ', errorName.toLowerCase(), '; Error description: ', errorDescription].join(''));
}

// Deprecated method, must to be modify.
module.exports = (function() {
    let restService;

    try {
        restService = LocalServiceRegistry.createService(serviceName, {
            createRequest: createRequest,
            parseResponse: function(_, httpClient) {
                return JSON.parse(httpClient.getText());
            },
            filterLogMessage: function(msg) {
                return msg;
            },
            getRequestLogMessage: function(request) {
                return request;
            },
            getResponseLogMessage: function(response) {
                return response.text;
            }
        });
    } catch (error) {
        createErrorLog(Resource.msgf('service.error', 'paypalerrors', null, serviceName));

        throw new Error();
    }

    return {
        call: function(data) {
            let result;

            try {
                result = restService.setThrowOnError().call(data);
            } catch (error) {
                createErrorLog(Resource.msgf('service.generalerror', 'paypalerrors', null, serviceName));

                throw new Error();
            }

            if (!result.isOk()) {
                errorHandler(result, data);
            }

            return restService.response;
        }
    };
}());
