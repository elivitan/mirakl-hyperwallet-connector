'use strict';

/**
 *  Returns active LPM`s ids
 *
 * @returns {Array} with lpm`s ids
 */
const getActiveLPMs = function() {
    const PaymentMgr = require('dw/order/PaymentMgr');

    const activePaymentMethods = PaymentMgr.getActivePaymentMethods();

    const lpms = [];

    Array.forEach(activePaymentMethods, function(paymentMethod) {
        if (paymentMethod.paymentProcessor.ID === 'PAYPAL_LOCAL') {
            lpms.push(paymentMethod.ID.toLowerCase());
        }
    });

    return lpms;
};

/**
 *  Returns PayPal custom and hardcoded preferences
 *
 * @returns {Object} statis preferences
 */
function getPreferences() {
    const currentSite = require('dw/system/Site').current;
    const sdkConfig = require('./sdkConfig');

    const paypalButtonLocation = currentSite.getCustomPreferenceValue('PP_Button_Location');

    return {
        enabledLPMsArray: getActiveLPMs(),
        paypalPdpButtonConfig: sdkConfig.paypalPdpButtonConfig,
        paypalCartButtonConfig: sdkConfig.paypalCartButtonConfig,
        paypalBillingButtonConfig: sdkConfig.paypalBillingButtonConfig,
        paypalMinicartButtonConfig: sdkConfig.paypalMinicartButtonConfig,
        paypalStaticImageLink: sdkConfig.paypalStaticImageLink,
        paypalButtonLocation: paypalButtonLocation.length ? paypalButtonLocation.join(',') : 'Billing',
        partnerAttributionId: 'SFCC_EC_B2C_23_3_0',
        isCapture: currentSite.getCustomPreferenceValue('PP_Payment_Model').value === 'Sale',
        billingAgreementEnabled: currentSite.getCustomPreferenceValue('PP_BA_Enabled'),
        billingAgreementDescription: currentSite.getCustomPreferenceValue('PP_BA_Description'),
        authorizationAndCaptureWhId: currentSite.getCustomPreferenceValue('PP_WH_Authorization_And_Capture_Id')
    };
}

module.exports = getPreferences();
