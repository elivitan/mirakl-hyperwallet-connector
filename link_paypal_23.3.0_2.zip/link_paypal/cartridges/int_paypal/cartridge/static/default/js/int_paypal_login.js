/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./cartridges/int_paypal/cartridge/client/default/js/login.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./cartridges/int_paypal/cartridge/client/default/js/cwpp/connectWithPayPal.js":
/*!*************************************************************************************!*\
  !*** ./cartridges/int_paypal/cartridge/client/default/js/cwpp/connectWithPayPal.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var MIN_NUMBER_OF_PARAMETERS = 8;
var $container = document.getElementById('js-cwpp-button');
var $staticImage = document.getElementById('js-cwpp-static-image');

/**
 * @returns {void}
 */
function showPayPalStaticImageButton() {
  if ($staticImage) {
    $staticImage.classList.remove('d-none');
  }
}

/**
 * @returns {boolean} - returns true if container exists false if not
 */
function isContainerExist() {
  if (!$container) {
    showPayPalStaticImageButton();
    return false;
  }
  return true;
}

/**
 * @param {*} callback - a callback function for onload event
 * @returns {void}
 */
function addConnectWithPayPalScript(callback) {
  if (!isContainerExist()) {
    return;
  }
  var script = document.createElement('script');
  script.id = 'paypal-api';
  script.src = $container.getAttribute('data-cwpp-sdk');
  script.onload = function () {
    if (callback && typeof callback === 'function') {
      callback();
    }
  };
  script.onerror = showPayPalStaticImageButton;
  document.body.appendChild(script);
}

/**
 * Connect with PayPal
 * @link {https://developer.paypal.com/docs/log-in-with-paypal/integrate/generate-button}
 */
function initConnectWithPayPal() {
  if (!isContainerExist()) {
    return;
  }
  var parameters = JSON.parse($container.getAttribute('data-parameters'));
  if (!(window.paypal && 'use' in window.paypal && Object.keys(parameters).length > MIN_NUMBER_OF_PARAMETERS)) {
    showPayPalStaticImageButton();
    return;
  }
  window.paypal.use(['login'], function (login) {
    login.render(parameters);
  });
}

/**
 * Function which initiate PayPal functionality on the Login Page
 */
function init() {
  addConnectWithPayPalScript(initConnectWithPayPal);
}
module.exports = {
  init: init
};

/***/ }),

/***/ "./cartridges/int_paypal/cartridge/client/default/js/login.js":
/*!********************************************************************!*\
  !*** ./cartridges/int_paypal/cartridge/client/default/js/login.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


if (window.paypalPreferences.isCWPPEnabled) {
  var connectWithPayPal = __webpack_require__(/*! ./cwpp/connectWithPayPal */ "./cartridges/int_paypal/cartridge/client/default/js/cwpp/connectWithPayPal.js");
  connectWithPayPal.init();
}

/***/ })

/******/ });
//# sourceMappingURL=int_paypal_login.js.map