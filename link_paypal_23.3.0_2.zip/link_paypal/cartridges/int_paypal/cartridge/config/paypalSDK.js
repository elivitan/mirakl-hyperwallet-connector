'use strict';

const paypalUtils = require('*/cartridge/scripts/paypal/paypalUtils');
const prefs = require('*/cartridge/config/paypalPreferences');
const sdkConfig = require('*/cartridge/config/sdkConfig');
const creditCardHelper = require('*/cartridge/scripts/paypal/helpers/creditCardHelper');

const PAYPAL_SDK_LINK = 'https://www.paypal.com/sdk/js?client-id=';
const lpmsList = sdkConfig.disableFunds;

const FUNDING_PREFS = [
    { name: 'debitCreditButtonEnabled', value: prefs.debitCreditButtonEnabled },
    { name: 'paypalCreditOrPayLaterButtonEnabled', value: prefs.paypalCreditOrPayLaterButtonEnabled },
    { name: 'venmoEnabled', value: !prefs.billingAgreementEnabled && prefs.isVenmoEnabled }
];

const FUNDING_SOURCES = {
    debitCreditButtonEnabled: 'card',
    paypalCreditOrPayLaterButtonEnabled: 'credit',
    venmoEnabled: 'venmo'
};

/**
 * Determine if current currency supported by PP SDK
 * @param  {Array} allowedCurrenciesFromPP Allowed currencies for PP SDK
 * @param  {string} storeCurrency Current session currency
 * @returns {boolean} Currency match state
 */
function isAllowedCurrency(allowedCurrenciesFromPP, storeCurrency) {
    return allowedCurrenciesFromPP.some(function(allowedCurrency) {
        return allowedCurrency === storeCurrency;
    });
}

/**
 * Gets the disabled funding sources
 * @returns {array} of disbled funding sources
 */
function disabledPaymentOptions() {
    FUNDING_PREFS.forEach(function(fundingPref) {
        if (!fundingPref.value && !sdkConfig.disableFunds.includes(FUNDING_SOURCES[fundingPref.name])) {
            sdkConfig.disableFunds.push(FUNDING_SOURCES[fundingPref.name]);
        }
    });

    if (empty(prefs.enabledLPMs)) {
        return sdkConfig.disableFunds;
    }

    const lpmMethods = prefs.enabledLPMs.map(function(lpm) {
        return lpm.toLowerCase();
    });

    sdkConfig.disableFunds = sdkConfig.disableFunds.filter(function(fund) {
        return lpmMethods.indexOf(fund) === -1;
    });

    return sdkConfig.disableFunds;
}

/**
 * Returns enable funding part of the SDK URL
 * @param  {string} url Current SDK URL
 * @param  {Array} customEnableFundingList Additional currencies for enable-funding PP SDK
 * @returns {string} URL SDK with the necessary values in the part of enable-funding
 */
function addEnableFundingParam(url, customEnableFundingList) {
    const enableFundingKey = '&enable-funding=';

    let customEnableFundingArray;

    if (!empty(customEnableFundingList)) {
        customEnableFundingArray = customEnableFundingList.slice(0);
    } else {
        customEnableFundingArray = [];
    }

    FUNDING_PREFS.forEach(function(fundingPref) {
        if (fundingPref.value) {
            customEnableFundingArray.push(FUNDING_SOURCES[fundingPref.name]);
        }
    });

    if (!empty(customEnableFundingArray)) {
        return url + enableFundingKey + customEnableFundingArray.join(',');
    }

    return url;
}

/**
 * Returns disable funding part of the SDK URL
 * @param  {string} url Current SDK URL
 * @param  {Array} customDisableFundingList Additional currencies for disable-funding PP SDK
 * @returns {string} URL SDK with the necessary values in the part of disable-funding
 */
function addDisableFundingParam(url, customDisableFundingList) {
    const disableFundingKey = '&disable-funding=';
    const customDisableFundingArray = disabledPaymentOptions();

    if (!empty(customDisableFundingList)) {
        customDisableFundingList.forEach(element => {
            customDisableFundingArray.push(element);
        });
    }

    return url + disableFundingKey + customDisableFundingArray.join(',');
}

/**
 * Creates SDK url for paypal button on cart page based on payment action and client id
 * @returns {string} created url
 */
function createCartSDKUrl() {
    const clientID = paypalUtils.getClientId();
    const currentCurrencyCode = session.currency.currencyCode;
    // Excludes LPM's from enable funding list
    const disabledLpms = lpmsList.filter(function(lpmName) {
        return prefs.enableFundingList.includes(lpmName);
    });

    const enableFunding = prefs.enableFundingList.filter(function(ef) {
        return !disabledLpms.includes(ef);
    });

    let sdkUrl = [PAYPAL_SDK_LINK, clientID, '&commit=' + prefs.isPayNowFlowEnabled, '&components=buttons,messages,funding-eligibility'].join('');

    const isHostedFields = creditCardHelper.isHostedFieldsEnabled();

    if (isHostedFields) {
        FUNDING_PREFS[0].value = false;
    }

    if (!prefs.isCapture && !prefs.billingAgreementEnabled) {
        sdkUrl += '&intent=authorize';
    }

    if (prefs.billingAgreementEnabled) {
        sdkUrl += '&vault=true';
    }

    if (isAllowedCurrency(sdkConfig.allowedCurrencies, currentCurrencyCode)) {
        sdkUrl += '&currency=' + currentCurrencyCode;
    }

    sdkUrl = addEnableFundingParam(sdkUrl, enableFunding);
    sdkUrl = addDisableFundingParam(sdkUrl, prefs.disableFundingList);

    return sdkUrl;
}

/**
 * Creates SDK url for paypal button on billing page based on payment action and client id
 * @returns {string} created url
 */
function createBillingSDKUrl() {
    const dwSystem = require('dw/system/System');
    const clientID = paypalUtils.getClientId();
    const currentCurrencyCode = session.currency.currencyCode;
    const isActiveLPM = !prefs.billingAgreementEnabled && prefs.isCapture && !empty(prefs.enabledLPMs);

    let components = '&components=buttons,marks,payment-fields,funding-eligibility';

    let sdkUrl = [PAYPAL_SDK_LINK, clientID, components].join('');

    sdkUrl += isActiveLPM || prefs.isPayNowFlowEnabled ? '&commit=true' : '&commit=false';

    if (!prefs.isCapture && !prefs.billingAgreementEnabled) {
        sdkUrl += '&intent=authorize';
    }

    if (prefs.billingAgreementEnabled) {
        sdkUrl += '&vault=true';
    }

    if (isAllowedCurrency(sdkConfig.allowedCurrencies, currentCurrencyCode)) {
        sdkUrl += '&currency=' + currentCurrencyCode;
    }

    sdkUrl = addEnableFundingParam(sdkUrl, prefs.enableFundingList);
    sdkUrl = addDisableFundingParam(sdkUrl, prefs.disableFundingList);

    // Only for LPM testing purposes
    if (dwSystem.DEVELOPMENT_SYSTEM === dwSystem.instanceType && currentCurrencyCode !== 'USD') {
        sdkUrl += ['&buyer-country=', request.locale.split('_')[1]].join('');
    }

    return sdkUrl;
}

/**
 * Creates SDK url for paypal button on account page for vaulting based on client id
 * @returns {string} created url
 */
function createAccountSDKUrl() {
    const clientID = paypalUtils.getClientId();

    return [PAYPAL_SDK_LINK, clientID, '&commit=false&vault=true&disable-funding=card,credit'].join('');
}

/**
 * Creates url for paypal fraudNet noscript
 * @param  {string} fraudNetUID fraudNet UID
 * @returns {string} created url
 */
function createFraudNetNoScriptURL(fraudNetUID) {
    return ['https://c.paypal.com/v1/r/d/b/ns?f=', fraudNetUID, '&js=0&r=1'].join('');
}

module.exports = {
    accountSDKUrl: createAccountSDKUrl(),
    billingSdkUrl: createBillingSDKUrl(),
    cartSdkUrl: createCartSDKUrl(),
    fraudNetNoScriptURL: createFraudNetNoScriptURL
};
