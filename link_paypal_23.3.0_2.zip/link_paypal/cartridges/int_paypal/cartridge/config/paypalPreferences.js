/* eslint-disable no-underscore-dangle */

'use strict';

const sdkConfig = require('./sdkConfig');
const PaymentMgr = require('dw/order/PaymentMgr');

const ALLOWED_PROCESSOR_ID = 'PAYPAL';
const ALLOWED_LPM_PROCESSOR_ID = 'PAYPAL_LOCAL';

const preferences = {};

/**
 * Returns whether the payment method is active
 * @param {string} paymentMethodId The payment method id
 * @returns {boolean} True or false
 */
function isPaymentMethodActive(paymentMethodId) {
    const activePaymentMethods = PaymentMgr.getActivePaymentMethods();

    return Array.some(activePaymentMethods, function(paymentMethod) {
        const isAllowedProcessorId = paymentMethod.paymentProcessor.ID === ALLOWED_PROCESSOR_ID
            || paymentMethod.paymentProcessor.ID === ALLOWED_LPM_PROCESSOR_ID;

        return isAllowedProcessorId && paymentMethodId === paymentMethod.ID;
    });
}

/**
 * Adds _whiteList object property with preferences which would be shown on client side
 */
const addWhiteListPrefs = function() {
    preferences._whiteListedForStorefront = {};

    // List of custom preferences keys that should be visible on client side
    const whiteList = ['billingAgreementEnabled', 'partnerAttributionId', 'isPayNowFlowEnabled', 'isCWPPEnabled'];

    // Make prefs from whiteList visible on client side
    whiteList.forEach(function(key) {
        preferences._whiteListedForStorefront[key] = JSON.parse(JSON.stringify(preferences[key]));
    });
};

/**
 *  Returns active LPM`s ids
 *
 * @returns {Array} with lpm`s ids
 */
const getActiveLPMs = function() {
    const activePaymentMethods = PaymentMgr.getActivePaymentMethods();

    const lpms = [];

    Array.forEach(activePaymentMethods, function(paymentMethod) {
        if (paymentMethod.paymentProcessor.ID === ALLOWED_LPM_PROCESSOR_ID) {
            lpms.push(paymentMethod.ID.toLowerCase());
        }
    });

    return lpms;
};

/**
 * Returns PayPal custom and hardcoded preferences
 *
 * @returns {Object} statis preferences
 */
function getPreferences() {
    const paypalConstants = require('*/cartridge/config/paypalConstants');
    const dwSystem = require('dw/system/System');

    const site = require('dw/system/Site').current;
    const isBaEnabled = site.getCustomPreferenceValue('PP_BA_Enabled');
    const isCapture = site.getCustomPreferenceValue('PP_Payment_Model').value === 'Sale';
    const isExtendedAuth = site.getCustomPreferenceValue('PP_Payment_Model').value === 'ExtendedAuth';
    const paypalButtonLocation = site.getCustomPreferenceValue('PP_Button_Location');
    const isPayPalPmActive = isPaymentMethodActive(paypalConstants.PAYMENT_METHOD_ID_PAYPAL);
    const sessionPaymentsAvailability = site.getCustomPreferenceValue('PP_Session_Payments_Enabled').getValue();

    let isSessionPaymentsEnabled = false;

    if (sessionPaymentsAvailability === paypalConstants.SESSION_PAYMENTS_AVAILABILITY_ALL
        || (sessionPaymentsAvailability === paypalConstants.SESSION_PAYMENTS_AVAILABILITY_LOGGEDIN && customer.authenticated)) {
        isSessionPaymentsEnabled = true;
    }

    preferences.threeDSecureFlow = site.getCustomPreferenceValue('PP_CC_3DS_Verification').value;
    preferences.isCreditCardActive = isPaymentMethodActive(paypalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD);
    preferences.isVenmoEnabled = isPaymentMethodActive(paypalConstants.PAYMENT_METHOD_ID_VENMO);
    preferences.enabledLPMs = getActiveLPMs();

    preferences.isCreditCardVaultEnabled = site.getCustomPreferenceValue('PP_Store_CC_To_Vault');
    preferences.isCapture = isCapture;
    preferences.isPayPalPmActive = isPayPalPmActive;
    preferences.billingAgreementEnabled = isBaEnabled;
    preferences.billingAgreementDescription = site.getCustomPreferenceValue('PP_BA_Description');
    preferences.paypalButtonLocation = paypalButtonLocation.length ? paypalButtonLocation.join(',') : 'Billing';
    preferences.authorizationAndCaptureWhId = site.getCustomPreferenceValue('PP_WH_Authorization_And_Capture_Id');
    preferences.paypalCartButtonConfig = sdkConfig.paypalCartButtonConfig;
    preferences.paypalBillingButtonConfig = sdkConfig.paypalBillingButtonConfig;
    preferences.paypalPdpButtonConfig = sdkConfig.paypalPdpButtonConfig;
    preferences.paypalPvpButtonConfig = sdkConfig.paypalPvpButtonConfig;
    preferences.paypalMinicartButtonConfig = sdkConfig.paypalMinicartButtonConfig;
    preferences.paypalProcessorId = ALLOWED_PROCESSOR_ID;
    preferences.paypalStaticImageLink = sdkConfig.paypalStaticImageLink;
    preferences.partnerAttributionId = 'SFCC_EC_B2C_23_3_0';
    preferences.debitCreditButtonEnabled = site.getCustomPreferenceValue('PP_Debit_Credit_Button_Enabled');
    preferences.paypalCreditOrPayLaterButtonEnabled = site.getCustomPreferenceValue('PP_Credit_Pay_Later_Button_Enabled');
    preferences.enableFundingList = site.getCustomPreferenceValue('PP_Enable_Funding_List');
    preferences.disableFundingList = site.getCustomPreferenceValue('PP_Disable_Funding_List');
    preferences.automaticPmAddingEnabled = site.getCustomPreferenceValue('PP_Automatic_Payment_Method_Adding_Enabled');
    preferences.isPayNowFlowEnabled = site.getCustomPreferenceValue('PP_Pay_Now_Enabled') && !isBaEnabled && isCapture;
    preferences.isFraudNetEnabled = site.getCustomPreferenceValue('PP_FraudNet_Enabled');
    preferences.saveOrderFlow = !isBaEnabled && isExtendedAuth && (isPayPalPmActive || preferences.isVenmoEnabled);
    preferences.customerServiceEmail = site.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@testorganization.com';
    preferences.isSessionPaymentsEnabled = isSessionPaymentsEnabled;
    preferences.creditCardExpireNotification = site.getCustomPreferenceValue('PP_Credit_Card_Expire_Notification').getValue();
    preferences.verifyCardOnAccountPage = site.getCustomPreferenceValue('PP_Verify_CC_On_My_Account');

    // Used only for 'Connect with Paypal' feature
    preferences.isCWPPEnabled = site.getCustomPreferenceValue('PP_CWPP_Button_Enabled');
    preferences.CWPPButtonUrl = site.getCustomPreferenceValue('PP_CWPP_Button_Url');
    preferences.accountLinkingSecurityLayerEnabled = site.getCustomPreferenceValue('PP_CWPP_Account_Linking_Security_Layer_Enabled');
    preferences.CWPPStaticImageLink = sdkConfig.CWPPStaticImageLink;
    preferences.PP_CWPP_Agent_Login = site.getCustomPreferenceValue('PP_CWPP_Agent_Login');
    preferences.PP_CWPP_Agent_Password = site.getCustomPreferenceValue('PP_CWPP_Agent_Password');
    preferences.cwppButtonStyles = sdkConfig.cwppButtonStyles;
    preferences.payPalExternalApiSdk = sdkConfig.payPalExternalApiSdk;
    preferences.instanceType = dwSystem.instanceType === dwSystem.PRODUCTION_SYSTEM ? 'production' : 'sandbox';
    preferences.paymentMethods = require('~/cartridge/scripts/paypal/helpers/paymentHelper').getActivePaymentMethods();

    addWhiteListPrefs();

    return preferences;
}

module.exports = getPreferences();
