'use strict';

const URLUtils = require('dw/web/URLUtils');

const CHECKOUT_BEGIN = 'Checkout-Begin';

module.exports = {
    getPurchaseUnit: URLUtils.https('Paypal-GetPurchaseUnit').toString(),
    getCartPurchaseUnit: URLUtils.https('Paypal-GetPurchaseUnit', 'isCartFlow', 'true').toString(),
    returnFromCart: URLUtils.https('Paypal-ReturnFromCart').toString(),
    cartPage: URLUtils.https('Cart-Show').toString(),
    placeOrderStage: URLUtils.url(CHECKOUT_BEGIN, 'stage', 'placeOrder').toString(),
    updateOrderData: URLUtils.url('Paypal-UpdateOrderDetails').toString(),
    createBillingAgreementToken: URLUtils.url('Paypal-GetBillingAgreementToken').toString(),
    createBillingAgreement: URLUtils.url('Paypal-CreateBillingAgreement').toString(),
    removeBillingAgreement: URLUtils.url('Paypal-RemoveBillingAgreement').toString(),
    saveBillingAgreement: URLUtils.url('Paypal-SaveBillingAgreement').toString(),
    paymentStage: URLUtils.https(CHECKOUT_BEGIN, 'stage', 'payment').toString(),
    finishLpmOrder: URLUtils.url('Paypal-FinishLpmOrder').toString(),
    savePaypalDefaultAddress: URLUtils.url('Paypal-SavePaypalDefaultAddress').toString(),
    getPaypalOrderId: URLUtils.https('Paypal-GetPaypalOrderId').toString(),
    finishPayNowFlow: URLUtils.url('Paypal-FinishPayNowFlow').toString(),
    cwppUrl: URLUtils.https('Paypal-ConnectWithPaypal').toString(),
    removeAllProductsFromCart: URLUtils.https('Cart-RemoveAllProductsFromCart').toString(),
    validateStaticImage: URLUtils.https('Paypal-ValidateStaticImage').toString(),
    unlinkCwppUrl: URLUtils.https('Paypal-UnlinkCWPP').toString(),
    deleteCreditCardUrl: URLUtils.url('Paypal-DeleteCreditCard').toString(),
    renderAccountsUrl: URLUtils.https('Paypal-RenderAccountsList').toString(),
    myAccountUrl: URLUtils.https('Account-Show', 'registration', 'false').toString(),
    validateHostedFields: URLUtils.https('Paypal-ValidateHostedFields').toString(),
    chooseShippingUrl: URLUtils.url(CHECKOUT_BEGIN, 'stage', 'shipping').toString()
};
