import { returnFromCart, validateStaticImageAddress } from './helpers/api';
import { initPaypalButtonBehaviorOnPdp } from './pdp/pdpHelper';
import { addProductToCart, initPayPalBtnBehaviorOnSet } from './helpers/helper';

/**
 * Applies PayPal button behavior
 */
function applyPaypalButtonBehavior() {
    const paypalButton = document.querySelector('.paypal-pdp-button');
    const isProductSet = Boolean(document.querySelector('.set-items'));

    if (isProductSet) {
        initPayPalBtnBehaviorOnSet();
    } else if (paypalButton) {
        initPaypalButtonBehaviorOnPdp();
    }
}

/**
 * Inits PayPal static image functionality on PDP
 */
function initStaticImageFunctionality() {
    const loaderInstance = require('./components/loader');
    const paypalStaticImageContainers = document.querySelectorAll('.paypal-static-image-container');

    let isAddressNeedChange;

    validateStaticImageAddress().then(isNeed => {
        isAddressNeedChange = isNeed;
    });

    paypalStaticImageContainers && paypalStaticImageContainers.forEach((container, index) => {
        const staticImage = container.querySelector('#paypal-static-image');
        const selector = `${container.className}${index}`;

        staticImage.classList.add(selector);

        staticImage.addEventListener('click', function() {
            const loaderContainer = this.closest('.pdp-paypal-button-container').querySelector('.paypalLoader');
            const loader = loaderInstance(loaderContainer);

            loader.show();

            const result = addProductToCart(`.${this.className}`);

            if (result.cart) {
                returnFromCart(isAddressNeedChange);
            } else {
                loader.hide();

                throw new Error(result.message || 'Error occurs while trying to add product to the cart');
            }
        });
    });

    applyPaypalButtonBehavior();
}

/**
 * Inits PayPal functionality on PDP
 */
function initPaypalFunctionality() {
    const paypalButtonContainers = document.querySelectorAll('.paypal-pdp-button, .paypal-pdp-button-global');
    const PP_BTN_SELECTOR = '.js-paypal-button-on-product-page';
    const isBAEnabled = window.paypalPreferences.billingAgreementEnabled;
    const PayPalProductModel = require('./models/buttons/payPalProduct');
    const PayPalProductBAModel = require('./models/billingAgreement/payPalProduct');

    paypalButtonContainers && paypalButtonContainers.forEach((container, index) => {
        const ppButton = container.querySelector(PP_BTN_SELECTOR);

        if (ppButton) {
            ppButton.classList.add(`${ppButton.classList[1]}-${index}-pdp`);

            const selector = `.${Array.from(ppButton.classList).join('.')}`;

            let payPalProductInstance;

            if (isBAEnabled) {
                payPalProductInstance = new PayPalProductBAModel(selector);
            } else {
                payPalProductInstance = new PayPalProductModel(selector);
            }

            payPalProductInstance.initPayPalButton();
        }
    });

    applyPaypalButtonBehavior();
}

$('body').ready(() => {
    const isPaypalStaticImage = Boolean(document.getElementById('paypal-static-image'));

    if (isPaypalStaticImage) {
        initStaticImageFunctionality();
    } else if (window.paypal) {
        initPaypalFunctionality();
    }
});
