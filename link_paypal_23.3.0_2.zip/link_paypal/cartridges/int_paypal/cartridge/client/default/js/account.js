const loaderInstance = require('./components/loader');
const AlertHandlerModel = require('./models/alertHandler');
const helper = require('./helpers/helper');
const $loaderContainer = document.querySelector('.paypalLoader');
const loader = loaderInstance($loaderContainer);

const $paypalAccountBtn = document.querySelector('.paypal-account-button');
const $addNewAccountBtn = document.querySelector('.add-paypal-account');
const $submitCwppUnlinkBtn = document.querySelector('.js-unlink-submit');
const $unlinkSection = document.querySelector('.js-unlink-section');
const $paypalBlock = document.querySelector('.paypal-block');
const $limitMsg = document.querySelector('.limitMsg');

if ($addNewAccountBtn && $paypalAccountBtn) {
    const isBaLimitReached = JSON.parse($paypalAccountBtn.getAttribute('data-paypal-is-ba-limit-reached'));

    $addNewAccountBtn.onclick = function() {
        this.classList.add('d-none');

        if (window.paypal && $paypalAccountBtn.innerHTML === '' && !isBaLimitReached) {
            const PayPalAccountBAModel = require('./models/billingAgreement/payPalAccount');
            const payPalAccountInstance = new PayPalAccountBAModel('.paypal-account-button');

            payPalAccountInstance.initPayPalButton();
        } else if (isBaLimitReached) {
            $limitMsg.style.display = 'block';
        }
    };
}

if ($paypalBlock) {
    $paypalBlock.onclick = function(e) {
        const target = e.target;

        if (target.classList.contains('remove-paypal-button')) {
            const baEmail = target.dataset.billingAgreementEmail;

            loader.show();

            return $.ajax({
                url: helper.getUrlWithCsrfToken(window.paypalUrls.removeBillingAgreement + `?billingAgreementEmail=${baEmail}`),
                type: 'DELETE'
            })
                .then(() => {
                    loader.hide();
                    location.reload();
                })
                .fail(() => {
                    loader.hide();
                });
        }

        return false;
    };
}

if ($submitCwppUnlinkBtn && $unlinkSection) {
    $submitCwppUnlinkBtn.addEventListener('click', () => {
        const alertHandler = new AlertHandlerModel();

        fetch(helper.getUrlWithCsrfToken(window.paypalUrls.unlinkCwppUrl), {
            method: 'POST'
        })
            .then((res) => res.json())
            .then((res) => {
                if (res.errorMessage) {
                    alertHandler.showError(res.errorMessage);
                } else {
                    $unlinkSection.classList.add('d-none');

                    alertHandler.showInfo(res.alertMessage);
                }
            })
            .catch(() => {
                location.reload();
            });
    });
}
