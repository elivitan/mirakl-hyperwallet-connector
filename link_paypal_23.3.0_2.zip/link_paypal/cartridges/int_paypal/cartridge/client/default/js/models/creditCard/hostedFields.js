'use strict';

const api = require('../../helpers/api');
const helper = require('../../helpers/helper');
const loaderInstance = require('../../components/loader');

const $loaderContainer = document.querySelector('.js-paypalLoader');

const CreditCardBaseModel = require('./creditCardBase');

/**
 * The class represents the hosted fields functionality
 */
class HostedFields extends CreditCardBaseModel {
    constructor() {
        super();

        this.hostedFieldsSelectors = {
            number: '#paypalCardNumber',
            cvv: '#paypalCvv',
            expirationDate: '#paypalExpirationDate'
        };
        this.hostedFieldsConfigs = helper.tryParseJSON(document.querySelector('.js-paypal-cc-fields').getAttribute('data-configs'));
        this.loader = loaderInstance($loaderContainer);
        this.$hostedFieldContainer = document.querySelector('.js-paypal-cc-fields');
        this.$continueButton = document.querySelector('button.submit-payment');
        this.is3DSEnabled = this.hostedFieldsConfigs.threeDSecureValue !== 'DISABLED';
        this.$cardHolderInput = document.getElementById('paypalCardOwner');
    }

    /**
     * Initiates and process the hosted fields
     */
    init() {
        this.renderMark();

        paypal.HostedFields.render({
            styles: {
                input: {
                    'font-size': this.hostedFieldsConfigs.fieldsConfig.styles.fontSize + 'pt',
                    color: this.hostedFieldsConfigs.fieldsConfig.styles.color
                },
                '.number': {
                    'font-family': 'helvetica, tahoma, calibri, sans-serif'
                },
                '.valid': {
                    color: this.hostedFieldsConfigs.fieldsConfig.styles.validColor
                },
                '.invalid': {
                    color: this.hostedFieldsConfigs.fieldsConfig.styles.invalidColor
                }
            },
            fields: {
                number: {
                    selector: this.hostedFieldsSelectors.number,
                    placeholder: this.hostedFieldsConfigs.fieldsPlaceholders.number
                },
                cvv: {
                    selector: this.hostedFieldsSelectors.cvv,
                    placeholder: this.hostedFieldsConfigs.fieldsPlaceholders.cvv
                },
                expirationDate: {
                    selector: this.hostedFieldsSelectors.expirationDate,
                    placeholder: this.hostedFieldsConfigs.fieldsPlaceholders.expirationDate
                }
            },
            createOrder: () => {
                const $saveCreditCardAccount = document.getElementById('saveCreditCardAccount');

                const paymentSourceData = {
                    card: {
                        name: this.cardHolderName,
                        billing_address: {
                            address_line_1: this.billingAddress.address1,
                            address_line_2: this.billingAddress.address2,
                            admin_area_2: this.billingAddress.city,
                            admin_area_1: this.billingAddress.stateCode,
                            postal_code: this.billingAddress.postalCode,
                            country_code: this.billingAddress.countryCode
                        },
                        attributes: {}
                    }
                };

                if ($saveCreditCardAccount && $saveCreditCardAccount.checked) {
                    paymentSourceData.card.attributes.vault = {
                        store_in_vault: 'ON_SUCCESS'
                    };
                }

                return api.getPaypalOrderId(paymentSourceData);
            }
        })
            .then(cardFields => {
                this.cardFields = cardFields;

                this.$continueButton.addEventListener('click', event => {
                    if (!event.isTrusted || !this.isActiveCreditCardTab()) {
                        return;
                    }

                    this.hideErrors();
                    this.loader.show();

                    const isNewCcFlow = !this.$paypalCreditCardList
                        || (this.$paypalCreditCardList && this.$paypalCreditCardList.selectedOptions[0].id === 'new-card-account');

                    if (isNewCcFlow) {
                        event.preventDefault();
                        event.stopPropagation();

                        this.processNewCreditCard();
                    }
                });
            });

        this.$cardHolderInput.addEventListener('input', (event) => {
            const validateSymbol = !(/[0-9]/i.test(event.data));

            if (!validateSymbol) {
                event.target.value = event.target.value.slice(0, -1);
            }
        });
    }

    /**
     * Process a new Credit card on the checkout page
     */
    processNewCreditCard() {
        const $billingForm = document.getElementById('dwfrm_billing');
        const getAddressFieldsFromUI = require('base/checkout/address').methods.getAddressFieldsFromUI;

        this.billingAddress = getAddressFieldsFromUI($billingForm);
        this.cardHolderName = this.$cardHolderInput.value;

        const submitObject = {
            cardholderName: this.cardHolderName
        };

        // Add 3ds secure to card processing if it is not disabled
        if (this.is3DSEnabled) {
            submitObject.contingencies = [this.hostedFieldsConfigs.threeDSecureValue];
        }

        this.cardFields
            .submit(submitObject)
            .then(({
                authenticationReason,
                liabilityShift,
                liabilityShifted,
                authenticationStatus
            }) => {
                const fieldsState = this.cardFields.getState();

                Object.assign(fieldsState.fields, { cardholderName: this.cardHolderName });

                api.validateHostedFields(fieldsState)
                    .then(response => response.json())
                    .then(data => {
                        if (!data.error) {
                            this.loader.hide();
                        } else {
                            const errorObj = {
                                name: 'INVALID_REQUEST',
                                details: [],
                                errorNotification: data.errorNotification
                            };

                            Object.values(data.fieldsErrors).forEach(field => {
                                errorObj.details.push({
                                    field: field.fieldName, description: field.errorMessage
                                });
                            });

                            this.handleErrors(errorObj);
                            this.loader.hide();
                        }
                    });

                this.verifyCardResponse(authenticationReason, liabilityShift, liabilityShifted, authenticationStatus);
            })
            .catch((err) => {
                this.handleErrors(err);
                this.loader.hide();
            });
    }

    /**
     * Verifies whether the buyer can continue with the authorization by current Credit Card
     * @param {string} authenticationReason The reeson of the autentication result
     * @param {string} liabilityShift  Signals whether the issuing bank may accept liability for the transaction
     * @param {string} liabilityShifted Indicates whether the liability for fraud has been shifted away from the merchant.
     * @param {string} authenticationStatus  Indicates the result of the authentication challenge. This is a server-side parameter.
     */
    verifyCardResponse(authenticationReason, liabilityShift, liabilityShifted, authenticationStatus) {
        const AlertHandlerModel = require('.././alertHandler');
        const alertHandlerInstance = new AlertHandlerModel();

        // 3ds is disabled through site preferences and is not required for the buyer
        const is3DSNotRequired = authenticationStatus === window.paypalConstants.CC_3DS_AUTHENTICATION_STATUS_APPROVED
            && liabilityShifted === undefined;

        const is3DSFailed = window.paypalConstants.CC_3DS_AUTHENTICATION_REASON_FAILED_STATUSES.includes(authenticationReason)
            && !liabilityShifted && window.paypalConstants.CC_3DS_AUTHENTICATION_FAILED_STATUSES.includes(authenticationStatus);

        const is3DSApproved = window.paypalConstants.CC_3DS_AUTHENTICATION_SUCCESS_STATUSES.includes(authenticationStatus)
            && liabilityShifted && liabilityShift === window.paypalConstants.CC_3DS_LIABILITY_SHIFT_STATUS_POSSIBLE;

        if (is3DSFailed) {
            alertHandlerInstance.showError(this.hostedFieldsConfigs.errorMessages.threeDSVerificationFailed);
        // If CC_3DS_AUTHENTICATION_REASON_WHITE_LIST contains an authenticationReason
        // we can continue with the authorization and assume liability
        } else if (is3DSNotRequired || is3DSApproved
            || window.paypalConstants.CC_3DS_AUTHENTICATION_REASON_WHITE_LIST.includes(authenticationReason)) {
            this.clearHostedFields();

            this.$continueButton.click();
        }
    }

    /**
     * Clears hosted fields
     */
    clearHostedFields() {
        Object.keys(this.hostedFieldsSelectors).forEach(selectorName => {
            this.cardFields.clear(selectorName);
        });

        this.$cardHolderInput.value = '';
    }

    /**
     * Renders the credit card tab
     */
    renderMark() {
        paypal.Marks({
            fundingSource: 'card'
        }).render('.js-credit-card-mark');

        document.querySelector('.js-nav-item-credit-card').classList.remove('d-none');
    }

    /**
     * Indicates whether the credit card tab is active
     * @returns {boolean} True/False
     */
    isActiveCreditCardTab() {
        return document.getElementById('credit-card-content').classList.contains('active');
    }

    // Base hosted fields error handler
    handleErrors(error) {
        const AlertHandlerModel = require('../alertHandler');
        const alertHandler = new AlertHandlerModel();

        if (['INVALID_REQUEST', 'UNPROCESSABLE_ENTITY'].includes(error.name)) {
            error.details.forEach((elem) => {
                const fieldPathAsArray = elem.field.split('/');

                this.showError(fieldPathAsArray.pop(), elem.description);
            });

            alertHandler.showError(this.hostedFieldsConfigs.fieldsGeneralNotificationError);
        }
    }

    /**
     * Shows the hosted fields errors
     * @param {string} field A field name
     * @param {string} message An error message
     */
    showError(field, message) {
        const $errorContainer = document.querySelector(`.js-card-${field}-error`);
        const $elementContainer = document.querySelector(`.js-card-${field}-input`);

        $errorContainer.innerText = message;
        $errorContainer.classList.remove('d-none');
        $elementContainer.classList.add('border-danger');
    }

    /**
     * Hides the hosted fields errors
     */
    hideErrors() {
        const $errorContainers = document.querySelectorAll('.js-card-error');
        const $inputContainers = document.querySelectorAll('.js-card-input');

        $errorContainers.forEach(element => {
            element.classList.add('d-none');
            element.innerText = '';
        });

        $inputContainers.forEach(element => {
            element.classList.remove('border-danger');
        });
    }

    /**
     * Shows a hosted fields container
     */
    showHostedFileds() {
        this.$hostedFieldContainer.classList.remove('d-none');
    }

    /**
     * Hides a hosted fields container
     */
    hideHostedFields() {
        this.$hostedFieldContainer.classList.add('d-none');
    }
}

module.exports = HostedFields;
