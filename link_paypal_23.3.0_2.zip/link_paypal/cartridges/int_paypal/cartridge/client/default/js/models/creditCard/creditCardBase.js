'use strict';

const helper = require('../../helpers/helper');

/**
 * PayPal CreditCardBase model
 */
class CreditCardBase {
    constructor() {
        this.$saveCreditCardAccountContainer = document.getElementById('saveCreditCardAccountContainer');
        this.$saveCreditCardAccount = document.getElementById('saveCreditCardAccount');
        this.$paypalCreditCardList = document.getElementById('paypalCreditCardList');
    }

    /**
     * Process the save checkbox behavior on the billing page
     */
    processSaveCheckbox() {
        this.$saveCreditCardAccount.addEventListener('change', e => {
            document.getElementById('credit-card-saveAccount').value = e.target.checked;
        });
    }

    /**
     * Process the credit card account list on the billing page
     */
    processCcAccountList() {
        this.$paypalCreditCardList.addEventListener('change', e => {
            const $selectedOption = e.target.selectedOptions[0];

            if ($selectedOption.id === 'new-card-account') {
                this.showHostedFileds();
            } else {
                this.hideHostedFields();

                helper.selectBillingAddress($selectedOption);
            }
        });
    }

    /**
     * Process the billing address list on the billing page
     */
    processBilligAddressList() {
        const that = this;
        const $checkoutStage = document.querySelector('.data-checkout-stage');
        const handleStageChange = () => {
            const currentStage = $checkoutStage.getAttribute('data-checkout-stage');

            if (currentStage === 'payment') {
                helper.selectBillingAddress(that.$paypalCreditCardList.selectedOptions[0]);
            }
        };

        const observer = new MutationObserver(handleStageChange);

        observer.observe($checkoutStage, { attributes: true });

        // Handles the case when the billing page was loaded directly on the payment stage
        handleStageChange();
    }
}

module.exports = CreditCardBase;
