'use strict';

module.exports = () => {
    const HostedFieldsModel = require('../models/creditCard/hostedFields');
    const hostedFieldsInstance = new HostedFieldsModel();

    if (hostedFieldsInstance.$paypalCreditCardList) {
        hostedFieldsInstance.processCcAccountList();
        hostedFieldsInstance.processBilligAddressList();
    }

    if (hostedFieldsInstance.$saveCreditCardAccountContainer) {
        hostedFieldsInstance.processSaveCheckbox();
    }

    hostedFieldsInstance.init();
};
