'use strict';

/**
 * Returns an object represented shipments data for Pay now flow:
 * currentBasketShipmentUUID - UUID of current shipment of basket,
 * onlinePickupMethodID - an id if online pickup shipping method that use for Pay now flow
 * @returns {Object} An object represented shipments data for Pay now flow
 */
const getPayNowData = () => {
    const $payPalBtn = document.querySelector('.js-paypal-button-on-billing-form') || document.querySelector('.js-paypal-button-on-cart-page');

    return JSON.parse($payPalBtn.getAttribute('data-paynow'));
};

/**
 * ShipmentsDomModel constructor
 */
function ShipmentsDomModel() {
    const SessionStorageModel = require('../models/sessionStorage');
    const AlertHandlerModel = require('./alertHandler');

    // Checkout page
    this.$shippingSummary = document.querySelector('.shipping-summary');
    this.$shippingAddressInfo = document.querySelector('.js-checkout-shipping-address-info');
    this.$shippingMethodList = document.querySelector('.shipping-method-list');
    this.$shippingSection = document.querySelector('.shipping-section');

    // Cart page
    this.$shippingMethods = document.getElementById('shippingMethods');

    // General varibales
    this.payNowData = getPayNowData();
    this.sessionStorageInstance = new SessionStorageModel();
    this.alertHandler = new AlertHandlerModel();
}

/**
 * Shows the shipping sections on billing page
 */
ShipmentsDomModel.prototype.setLastUsedShippingMethodId = function() {
    const $checkedShippingMethod = document.querySelector('.shipping-method-list .form-check input[checked=checked]');

    // Sets a last used shipping method id only when one is selected,
    // otherwise the Online pickup shipping method id is used
    if ($checkedShippingMethod) {
        this.sessionStorageInstance.setItem('last_used_shippig_method_id', $checkedShippingMethod.value);
    }
};

ShipmentsDomModel.prototype.getLastUsedShippingMethodId = function() {
    return this.sessionStorageInstance.getItem('last_used_shippig_method_id');
};

/**
 * Shows the shipping sections on billing page
 */
ShipmentsDomModel.prototype.showShippingSectionsOnBillingPage = function() {
    if (this.$shippingSummary) {
        this.$shippingSummary.classList.remove('d-none');
    }

    if (this.$shippingSection) {
        this.$shippingSection.classList.remove('d-none');
    }
};

/**
 * Hides the shipping sections on billing page
 */
ShipmentsDomModel.prototype.hideShippingSectionsOnBillingPage = function() {
    if (this.$shippingSummary) {
        this.$shippingSummary.classList.add('d-none');
    }

    if (this.$shippingSection) {
        this.$shippingSection.classList.add('d-none');
    }
};

/**
 * Show the shipping address info message
 */
ShipmentsDomModel.prototype.showShippingAddressInfoMsg = function() {
    if (this.$shippingAddressInfo) {
        this.$shippingAddressInfo.classList.remove('d-none');
    }
};

/**
 * Hides the shipping address info message
 */
ShipmentsDomModel.prototype.hideShippingAddressInfoMsg = function() {
    if (this.$shippingAddressInfo) {
        this.$shippingAddressInfo.classList.add('d-none');
    }
};

/**
 * Selects shipping method on Billing page during Pay now flow
 * @param {string} shippingMethodId A shipping method id
 */
ShipmentsDomModel.prototype.selectShippingMethodOnBillingPage = function(shippingMethodId) {
    const baseShipping = require('base/checkout/shipping').methods;
    const baseAddress = require('base/checkout/address').methods;

    if (!this.$shippingMethodList) {
        return;
    }

    const $shippingForm = this.$shippingMethodList.closest('form');
    const urlParams = baseAddress.getAddressFieldsFromUI($shippingForm);

    // Saves shipping method id before shipments will update with Online Pickup shipping method
    // Is used for case when buyer clicked the PayPal tab, and then choose a Credit card tab back
    if (!shippingMethodId) {
        this.setLastUsedShippingMethodId();
    }

    // Does Ajax call to select shipping method
    baseShipping.selectShippingMethodAjax(this.$shippingMethodList.getAttribute('data-select-shipping-method-url'),
        Object.assign({
            shipmentUUID: this.payNowData.currentBasketShipmentUUID,
            methodID: shippingMethodId || this.payNowData.onlinePickupMethodID
        }, urlParams),
        this.$shippingMethodList);
};

/**
 * Selects shipping method on Cart page during Pay now flow
 */
ShipmentsDomModel.prototype.selectShippingMethodOnCartPage = function() {
    const cart = require('../cart');
    const shippingMethodId = this.getLastUsedShippingMethodId();
    const shipmentsUUID = this.payNowData.currentBasketShipmentUUID;

    fetch(this.$shippingMethods.getAttribute('data-actionUrl'), {
        method: 'POST',
        body: `methodID=${shippingMethodId}&shipmentUUID=${shipmentsUUID}`,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    })
        .then(response => {
            return response.json();
        })
        .then(data => {
            if (data.error) {
                window.location.href = data.redirectUrl;
            } else {
                const $shippingOption = document.querySelector(`[data-shipping-id='${shippingMethodId}']`);

                $shippingOption.setAttribute('selected', '');
                $shippingOption.selected = true;

                document.querySelector('.coupons-and-promos').replaceChildren(data.totals.discountsHtml);
                cart.updateCartTotals(data);
                cart.updateApproachingDiscounts(data.approachingDiscounts);
            }
        })
        .catch(error => {
            if (error.redirectUrl) {
                window.location.href = error.redirectUrl;
            } else {
                this.alertHandler.showError(error.responseJSON.errorMessage);
            }
        });
};

module.exports = ShipmentsDomModel;
