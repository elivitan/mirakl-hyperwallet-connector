'use strict';

const helper = require('../../helpers/helper');

const PayPalBaseBAModel = require('./payPalBase');

class PayPalCartBAModel extends PayPalBaseBAModel {
    constructor(selector) {
        super(selector);

        this.isCartFlow = true;
    }

    /**
     * Makes post call to create a BA and calls the returnFromCart endpoint, triggers checkout (stage = place order)
     * @returns {Object} JSON response that includes the billing agreement token
     */
    onApprove() {
        const that = this;

        return super.onApprove()
            .then((result) => {
                return helper.returnFromCart.call(that, result);
            })
            .fail((error) => {
                that.loader.hide();

                const errorResponse = error.responseJSON;

                if (helper.handleValidationAddressResult(error) || errorResponse.errorName === 'shipping.address.invalid') {
                    that.payPalInstance.close();

                    if (errorResponse.message) {
                        that.alertHandler.showError(errorResponse.message);
                    }
                } else {
                    if (window.location.href !== window.paypalUrls.cartPage) {
                        window.location.href = window.paypalUrls.cartPage;
                    }

                    that.alertHandler.showError(error.responseText);
                }
            });
    }

    /**
     * Shows errors if paypal widget was closed with errors
     */
    onError() {
        super.onError();

        if (window.location.href !== window.paypalUrls.cartPage) {
            window.location.href = window.paypalUrls.cartPage;
        }

        this.alertHandler.showError(window.paypalConstants.FLASH_MESSAGE_ERROR_INTERNAL_SERVER);
    }

    /**
     * Inits paypal Billing Agreement button on Cart page
     */
    initPayPalButton() {
        const that = this;

        super.initPayPalButton();

        const paypalCartButtonContainer = document.querySelectorAll('.paypal-cart-button');

        setTimeout(() => {
            paypalCartButtonContainer.forEach((container)=>{
                const paypalFrame = container.querySelector('.paypal-buttons-context-iframe');

                if (!paypalFrame) {
                    that.payPalInstance.render(container)
                        .then(() => {
                            that.loader.hide();
                        });
                }
            });
        });
    }
}

module.exports = PayPalCartBAModel;
