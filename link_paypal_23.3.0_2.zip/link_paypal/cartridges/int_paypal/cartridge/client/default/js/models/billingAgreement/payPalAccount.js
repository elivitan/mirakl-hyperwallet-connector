'use strict';

const PayPalBaseBAModel = require('./payPalBase');
const helper = require('../../helpers/helper');

class PayPalAccountBAModel extends PayPalBaseBAModel {
    constructor(selector) {
        super(selector);

        this.isCartFlow = true;
    }

    /**
     * Makes post call using facilitator Access Token
     * @returns {Object} JSON response that includes the billing agreement token
     */
    onApprove() {
        const that = this;

        return super.onApprove()
            .then(({ id, payer }) => {
                const email = payer.payer_info.email;

                return fetch(helper.getUrlWithCsrfToken(window.paypalUrls.saveBillingAgreement), {
                    method: 'POST',
                    body: JSON.stringify({ baID: id, email }),
                    headers: {
                        contentType: 'application/json'
                    }
                });
            })
            .then(() => {
                that.loader.hide();
                location.reload();
            })
            .fail((err) => {
                that.paypalInstance.close();
                that.loader.hide();

                const errorResponse = err.responseJSON;

                that.alertHandler.showError(errorResponse.message);
            });
    }

    /**
     * Inits paypal Billing Agreement button on Account page
     */
    initPayPalButton() {
        const that = this;

        super.initPayPalButton();

        this.payPalInstance.render(this.selector)
            .then(() => {
                that.loader.hide();
            });
    }
}

module.exports = PayPalAccountBAModel;
