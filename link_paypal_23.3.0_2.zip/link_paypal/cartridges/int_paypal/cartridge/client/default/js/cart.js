import { updateOrderData, returnFromCart, validateStaticImageAddress } from './helpers/api';

const PP_BTN_SELECTOR = '.js-paypal-button-on-cart-page';

const $paypalImage = document.getElementById('paypal-image') || document.getElementById('venmo-image');
const $cartButton = document.querySelector(PP_BTN_SELECTOR);
const isBAEnabled = $cartButton && window.paypalPreferences.billingAgreementEnabled;

let payPalCartInstance = null;

if ($paypalImage || isBAEnabled) {
    const PayPalCartBAModel = require('./models/billingAgreement/payPalCart');

    payPalCartInstance = new PayPalCartBAModel(PP_BTN_SELECTOR);
} else {
    const PayPalCartModel = require('./models/buttons/payPalCart');

    payPalCartInstance = new PayPalCartModel(PP_BTN_SELECTOR);
}

/**
 * Sets a previous choose shipping method on the card page in case if
 * Pay Now flow was activated on the Billing page
 */
const handleShippingMethodsOnPayNowFlow = () => {
    const SessionStorageModel = require('./models/sessionStorage');
    const sessionStorageInstance = new SessionStorageModel();

    if (sessionStorageInstance.getActiveBillingPmTab() === window.paypalConstants.PAYPAL_TAB && !$cartButton.classList.contains('js-mini-cart-btn')) {
        const ShipmentsDomModel = require('./models/shipmentsDom');
        const shipmentsDomInstance = new ShipmentsDomModel();

        shipmentsDomInstance.selectShippingMethodOnCartPage();
        sessionStorageInstance.setActiveBillingPmTab(window.paypalConstants.CREDIT_CARD_TAB);
    }
};

if ($cartButton && window.paypalPreferences.isPayNowFlowEnabled) {
    handleShippingMethodsOnPayNowFlow();
}

/**
 * Injects SDK into page for cart/minicart
*/
function injectPaypalSDK() {
    const head = document.head;
    const script = document.createElement('script');

    script.type = 'text/javascript';
    script.onload = function() {
        payPalCartInstance.initPayPalButton();
    };

    script.src = window.paypalSDK.cartSdkUrl;
    script.setAttribute('data-partner-attribution-id', window.paypalPreferences.partnerAttributionId);
    head.appendChild(script);
}

if ($paypalImage) {
    const isUpdateRequired = JSON.parse($paypalImage.getAttribute('data-is-update-required'));

    let isAddressNeedChange;

    validateStaticImageAddress().then(isNeed => {
        isAddressNeedChange = isNeed;
    });

    $paypalImage.addEventListener('click', function() {
        if (isUpdateRequired) {
            updateOrderData(isAddressNeedChange);
        } else {
            returnFromCart(isAddressNeedChange);
        }
    });
} else if (!window.paypal) {
    // We do not inject SDK if SDK is already injected and window.paypal exists to avoid PayPal components destroying
    injectPaypalSDK();
} else {
    payPalCartInstance.initPayPalButton();
}

/**
 * re-renders the approaching discount messages
 * @param {Object} approachingDiscounts - updated approaching discounts for the cart
 */
const updateApproachingDiscounts = approachingDiscounts => {
    const $approachingDiscounts = document.querySelector('.approaching-discounts');

    $approachingDiscounts.replaceChildren();

    if (approachingDiscounts.length > 0) {
        approachingDiscounts.forEach(item => {
            const $sigleApprocahingDiscount = document.createElement('div');

            $sigleApprocahingDiscount.classList.add('single-approaching-discount', 'text-center');
            $sigleApprocahingDiscount.innerHTML = item.discountMsg;

            $approachingDiscounts.append($sigleApprocahingDiscount);
        });
    }
};

/**
 * Updates items view on the cart page
 * @param {Object} data - AJAX response from the server
 * @param {Object} item An item of basket
 */
const updateCartItemView = (data, item) => {
    const UUID = item.UUID;
    const $item = document.querySelector(`.item-${UUID}`);
    const $unitPrice = document.querySelector(`.uuid-${UUID} .unit-price`);
    const $lineItemUnitPrice = document.querySelector(`.line-item-price-${UUID} .unit-price`);
    const $itemTotal = document.querySelector(`.item-total-${UUID}`);

    $unitPrice.replaceChildren();
    $unitPrice.insertAdjacentHTML('afterbegin', item.renderedPrice);
    $lineItemUnitPrice.replaceChildren();
    $lineItemUnitPrice.insertAdjacentHTML('afterbegin', item.renderedPrice);
    $itemTotal.replaceChildren();
    $itemTotal.insertAdjacentHTML('afterbegin', item.priceTotal.renderedPrice);

    if (data.totals.orderLevelDiscountTotal.value > 0) {
        document.querySelector('.coupons-and-promos').replaceChildren(data.totals.discountsHtml);
    }

    if (item.renderedPromotions) {
        $item.replaceChildren(item.renderedPromotions);
    } else {
        $item.replaceChildren();
    }
};

/**
 * re-renders the order totals and the number of items in the cart
 * @param {Object} data - AJAX response from the server
 */
const updateCartTotals = data => {
    const $miniCartLink = document.querySelector('.minicart-link');
    const $subTotal = document.querySelector('.sub-total');
    const orderLevelDiscountTotal = data.totals.orderLevelDiscountTotal;
    const $orderDiscount = document.querySelector('.order-discount');
    const $shippingDiscount = document.querySelector('.shipping-discount');

    $miniCartLink.setAttribute('aria-label', data.resources.minicartCountOfItems);
    $miniCartLink.setAttribute('title', data.resources.minicartCountOfItems);

    document.querySelector('.number-of-items').replaceChildren(data.resources.numberOfItems);
    document.querySelector('.shipping-cost').replaceChildren(data.totals.totalShippingCost);
    document.querySelector('.tax-total').replaceChildren(data.totals.totalTax);
    document.querySelector('.grand-total').replaceChildren(data.totals.grandTotal);
    document.querySelector('.minicart-quantity').replaceChildren(data.numItems);

    data.items.forEach(function(item) {
        updateCartItemView(data, item);
    });

    if ($subTotal) {
        document.querySelector('.sub-total').replaceChildren(data.totals.subTotal);
    }

    if (orderLevelDiscountTotal.value > 0) {
        $orderDiscount.classList.remove('hide-order-discount');
        document.querySelector('.order-discount-total').replaceChildren('- ' + orderLevelDiscountTotal.formatted);
    } else {
        $orderDiscount.classList.add('hide-order-discount');
    }

    if (data.totals.shippingLevelDiscountTotal.value > 0) {
        $shippingDiscount.classList.remove('hide-shipping-discount');
        document.querySelector('.shipping-discount-total').replaceChildren('- ' + data.totals.shippingLevelDiscountTotal.formatted);
    } else {
        $shippingDiscount.classList.add('hide-shipping-discount');
    }
};

export {
    updateCartTotals,
    updateApproachingDiscounts
};
