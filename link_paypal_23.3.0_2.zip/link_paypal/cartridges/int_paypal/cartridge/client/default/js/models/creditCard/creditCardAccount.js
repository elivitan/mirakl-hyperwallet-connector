'use strict';

const Loader = require('../../components/loader');
const AlertHandler = require('../../models/alertHandler');

const clientSideValidation = require('base/components/clientSideValidation');
const helper = require('../../helpers/helper');

/**
 * PayPal CreditCardAccount model
 */
class CreditCardAccount {
    constructor() {
        this.$addNewCardButton = document.querySelector('.js-paypal-add-new-card-btn');
        this.$addNewCardForm = document.querySelector('.js-paypal-add-credit-card-form');
        this.$addNewCardContainer = document.querySelector('.js-paypal-add-new-card-container');
        this.$addNewCardBlock = document.querySelector('.js-paypal-add-new-card-block');
        this.$cancelButton = document.querySelector('.js-paypal-add-new-card-cancel-btn');
        this.$saveButton = document.querySelector('.js-paypal-add-new-card-save-btn');
        this.$loaderContainer = document.querySelector('.js-paypal-loader');
        this.$expirationDateInput = document.querySelector('.js-paypal-expiration-date-input');
        this.$cardNumberInput = document.querySelector('.js-paypal-card-number-input');
        this.$cardSecurityCodeInput = document.querySelector('.js-paypal-cvv-input');
        this.$cardHolderNameInput = document.querySelector('.js-paypal-card-holder-name-input');
        this.formLoader = Loader(this.$loaderContainer);
        this.alertHandler = new AlertHandler();
        this.isError = false;

        this.CSS_CLASSES = {
            D_NONE: 'd-none',
            FONT_WEIGHT_BOLD: 'font-weight-bold'
        };
    }

    /**
     * Shows the new card block on the Account Page
     * @returns {void}
     */
    showAddNewCardOptions() {
        this.$addNewCardContainer.classList.add(this.CSS_CLASSES.D_NONE);
        this.$addNewCardBlock.classList.remove(this.CSS_CLASSES.D_NONE);
    }

    /**
     * Hides the new card block on the Account Page
     * @returns {void}
     */
    hideAddNewCardOptions() {
        this.$addNewCardContainer.classList.remove(this.CSS_CLASSES.D_NONE);
        this.$addNewCardBlock.classList.add(this.CSS_CLASSES.D_NONE);

        clientSideValidation.functions.clearForm(this.$addNewCardForm);
    }

    /**
     * Handles server side validation errors
     * @param {Object} error - Error object from server side
     * @returns {void}
     */
    handleError(error) {
        this.isError = true;

        Object.values(error.fieldsErrors).forEach(field => {
            const $errorContainer = document.querySelector(`.js-paypal-${field.fieldName}-error`);
            const $elementContainer = document.querySelector(`.js-paypal-${field.fieldName}-input`);

            $errorContainer.innerText = field.errorMessage;
            $errorContainer.classList.remove('d-none');
            $elementContainer.classList.add('border-danger');
            $elementContainer.style.color = 'red';
        });
    }

    /**
     * Hides all form errors
     * @returns {void}
     */
    hideErrors() {
        this.isError = false;

        const $errorContainers = document.querySelectorAll('.js-paypal-error');
        const $inputContainers = document.querySelectorAll('.paypal-hosted-fields-container');

        $errorContainers.forEach(element => {
            element.classList.add('d-none');
            element.innerText = '';
        });

        $inputContainers.forEach(element => {
            element.classList.remove('border-danger');
            element.style.color = 'black';
        });
    }

    /**
     * This function handles the saving of a credit card
     * @param {Event} event - The event parameter for triggered action
     * @returns {void}
     */
    handleSaveCreditCardButton(event) {
        const addCreditCardFormUrl = this.$addNewCardForm.getAttribute('action');
        const formData = new FormData(this.$addNewCardForm);
        const encodedFormData = btoa(JSON.stringify(Object.fromEntries(formData)));

        this.hideErrors();

        const isValidForm = helper.validateForm(this.$addNewCardForm);

        if (isValidForm.isValid) {
            this.formLoader.show();

            fetch(helper.getUrlWithCsrfToken(addCreditCardFormUrl), {
                method: 'POST',
                body: encodedFormData
            })
                .then((res) => res.json())
                .then((data) => {
                    if (data.error) {
                        if (data.fieldsErrors) {
                            this.handleError(data);
                        } else {
                            this.alertHandler.showError(data.message);
                        }
                    } else {
                        fetch(data.renderAccountsUrl)
                            .then((template) => template.text())
                            .then((templateHtml) => {
                                this.$addNewCardForm.reset();
                                this.alertHandler.hideAlerts();
                                this.hideAddNewCardOptions();

                                document.querySelector('.js-credit-card-accounts').innerHTML = templateHtml;

                                this.initRemoveCreditCardEvent();
                            });
                    }

                    this.formLoader.hide();
                })
                .catch((error) => {
                    this.formLoader.hide();
                    this.alertHandler.showError(error.message);
                });

            event.preventDefault();
            event.stopPropagation();
        } else {
            isValidForm.invalidFields.forEach((element) => {
                element.style.color = 'red';
            });
        }
    }

    /**
     * This function handles the removing of a credit card
     * @param {Event} event - The event parameter for triggered action
     * @returns {void}
     */
    handleRemoveCreditCardButton(event) {
        const target = event.target;
        const targetId = target.getAttribute('data-id');

        this.alertHandler.hideAlerts();
        this.creditCardsLoader.show();

        fetch(helper.getUrlWithCsrfToken(`${window.paypalUrls.deleteCreditCardUrl}?uuid=${targetId}`), {
            method: 'GET'
        })
            .then((response) => {
                return response.json();
            })
            .then((data) => {
                if (data.error) {
                    this.alertHandler.showError(data.message);
                } else {
                    document.getElementById(`uuid-${targetId}`).remove();

                    if (data.newDefaultCreditCardId) {
                        document.querySelector(`.uuid-${data.newDefaultCreditCardId}`).classList.add(this.CSS_CLASSES.FONT_WEIGHT_BOLD);
                    }
                }

                this.creditCardsLoader.hide();
            })
            .catch(() => {
                location.reload();
            });
    }

    /**
     * Inits Credit Card remove functionality on the Account Page
     * @returns {void}
     */
    initRemoveCreditCardEvent() {
        this.$removeButtons = document.querySelectorAll('.js-remove-pp-payment');
        this.$creditCardsLoaderContainer = document.querySelector('.js-paypal-cc-loader');

        this.creditCardsLoader = Loader(this.$creditCardsLoaderContainer);

        if (this.$removeButtons.length) {
            this.$removeButtons.forEach((button) => {
                button.addEventListener('click', this.handleRemoveCreditCardButton.bind(this));
            });
        }
    }

    /**
     * Handles input event for expiration date field
     * @param {Event} event - The event parameter for triggered action
     * @returns {void}
     */
    handleExpirationDateInput(event) {
        const expDateField = event.target;
        const expDateValue = expDateField.value.replace(/\D/g, '');

        expDateField.style.color = 'black';

        let formattedValue = '';

        for (let i = 0; i < expDateValue.length; i++) {
            if (i === 2) {
                formattedValue += ' / ';
            }

            formattedValue += expDateValue.charAt(i);
        }

        expDateField.value = formattedValue;
    }

    /**
     * Handles input event for card number field
     * @param {Event} event - The event parameter for triggered action
     * @returns {void}
     */
    handleCardNumberInput(event) {
        const cardField = event.target;
        const cardNumber = cardField.value.replace(/\D/g, '');

        cardField.style.color = 'black';

        let formattedNumber = cardNumber;

        if (cardNumber.length >= 4 && cardNumber.length <= 16) {
            if (/^3([47068])/.test(cardNumber)) {
                if (cardNumber.length <= 10) {
                    formattedNumber = cardNumber.replace(/^(\d{4})(\d{1,6})$/, '$1 $2');
                } else {
                    formattedNumber = cardNumber.replace(/^(\d{4})(\d{6})(\d+)$/, '$1 $2 $3');
                }
            } else {
                formattedNumber = cardNumber.replace(/(\d{4})(?=\d)/g, '$1 ');
            }
        } else if (cardNumber.length > 16) {
            formattedNumber = cardNumber.replace(/^(\d{4})(\d{4})(\d{4})(\d+)$/, '$1 $2 $3 $4');
        }

        cardField.value = formattedNumber;
    }

    /**
     * Handles input event for card security code field
     * @param {Event} event - The event parameter for triggered action
     * @returns {void}
     */
    handleCardSecurityCodeInput(event) {
        event.target.style.color = 'black';

        event.target.value = event.target.value.replace(/\D/g, '');
    }

    /**
     * Handles input event for cardholder field
     * @param {Event} event - The event parameter for triggered action
     * @returns {void}
     */
    handleCardHolderNameInput(event) {
        event.target.style.color = 'black';

        const validateSymbol = !(/[0-9]/i.test(event.data));

        if (!validateSymbol) {
            event.target.value = event.target.value.slice(0, -1);
        }
    }

    /**
     * Inits Credit Card specific events on the Account Page
     * @returns {void}
     */
    initEvents() {
        if (this.$addNewCardButton) {
            this.$addNewCardButton.addEventListener('click', this.showAddNewCardOptions.bind(this));
        }

        if (this.$cancelButton) {
            this.$cancelButton.addEventListener('click', this.hideAddNewCardOptions.bind(this));
        }

        if (this.$saveButton) {
            this.$saveButton.addEventListener('click', this.handleSaveCreditCardButton.bind(this));
        }

        this.$expirationDateInput.addEventListener('input', this.handleExpirationDateInput.bind(this));

        this.$cardNumberInput.addEventListener('input', this.handleCardNumberInput.bind(this));

        this.$cardSecurityCodeInput.addEventListener('input', this.handleCardSecurityCodeInput.bind(this));

        this.$cardHolderNameInput.addEventListener('input', this.handleCardHolderNameInput.bind(this));

        this.initRemoveCreditCardEvent();
    }
}

module.exports = CreditCardAccount;
