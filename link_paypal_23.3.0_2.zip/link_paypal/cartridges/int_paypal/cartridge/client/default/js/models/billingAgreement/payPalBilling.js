'use strict';

const billingAgreementHelper = require('../../billing/registered/billingAgreementHelper');

const PayPalBaseBAModel = require('./payPalBase');

class PayPalBillingBAModel extends PayPalBaseBAModel {
    constructor(selector) {
        super(selector);

        this.dataAttributes = {
            ID: 'data-ba-id',
            SAVED_ACCOUNT: 'data-has-saved-account',
            DEFAULT_ACCOUNT: 'data-has-default-account'
        };
    }

    /**
     * Makes post call using facilitator Access Token,
     * save's billingAgreementID & billingAgreementPayerEmail to input field
     * and triggers checkout place order stage
     * @returns {Object} JSON response that includes the billing agreement token
     */
    onApprove() {
        const that = this;

        return super.onApprove()
            .then(({ id, payer }) => {
                const payerInfo = payer.payer_info;
                const billingAddress = payerInfo.billing_address;
                const $restPaypalAccountsList = document.getElementById('restPaypalAccountsList');
                const hasDefaultPaymentMethod = JSON.parse($restPaypalAccountsList.getAttribute(that.dataAttributes.DEFAULT_ACCOUNT));
                const hasPPSavedAccount = JSON.parse($restPaypalAccountsList.getAttribute(that.dataAttributes.SAVED_ACCOUNT));
                const isSessionPaymentsEnabled = JSON.parse(document.querySelector('.js-payment-information').dataset.sessionPaymentsEnabled);
                let billingAddressFields = [];

                billingAgreementHelper.setBAFormValues(id, payerInfo.email);

                if (hasDefaultPaymentMethod && !hasPPSavedAccount) {
                    $restPaypalAccountsList.setAttribute(that.dataAttributes.DEFAULT_ACCOUNT, false);
                    $('#restPaypalAccountsList').data(that.dataAttributes.DEFAULT_ACCOUNT, false); // MFRA jquery hack
                }

                const contactInfoFields = [].slice.call(document.querySelectorAll('.contact-info-block input[required]'));

                const keysValues = {
                    email: payerInfo.email,
                    phoneNumber: payerInfo.phone,
                    billingFirstName: payerInfo.first_name,
                    billingLastName: payerInfo.last_name,
                    billingAddressOne: billingAddress.line1,
                    billingCountry: billingAddress.country_code,
                    billingState: billingAddress.state,
                    billingAddressCity: billingAddress.city,
                    billingZipCode: decodeURIComponent(billingAddress.postal_code)
                };

                const $billinAddressBlock = document.querySelector('.billing-address-block');

                if ($billinAddressBlock.querySelector('#billingAddressSelector option:checked').value === 'new') {
                    billingAddressFields = [].slice.call($billinAddressBlock.querySelectorAll('input[required], select[required]'));
                }

                // Rewrite phone number
                document.getElementById('phoneNumber').value = '';

                (contactInfoFields.concat(billingAddressFields)
                    .filter(el => el.value.trim() === ''))
                    .forEach(function(el) {
                        el.value = keysValues[el.id];
                    });

                if (isSessionPaymentsEnabled) {
                    document.getElementById('sessionPaypalAccount').setAttribute(that.dataAttributes.ID, id);

                    const sameAttribute = [].slice.call($restPaypalAccountsList.options)
                        .find(el => el.value === payerInfo.email);

                    (sameAttribute && sameAttribute.id !== 'sessionPaypalAccount')
                        ? billingAgreementHelper.clearSessionOption()
                        : billingAgreementHelper.updateSessionOption(payerInfo.email);
                }

                document.querySelector('button.submit-payment').click();
                that.loader.hide();
            })
            .fail(() => {
                that.loader.hide();
            });
    }

    /**
     * Shows errors if paypal widget was closed with errors
     */
    onError() {
        super.onError();

        this.alertHandler.showError(window.paypalConstants.FLASH_MESSAGE_ERROR_INTERNAL_SERVER);
    }

    /**
     * Hides loader on paypal widget
     */
    onClose() {
        this.loader.hide();
    }

    /**
     * Inits paypal Billing Agreement button on billing checkout page
     */
    initPayPalButton() {
        const that = this;

        super.initPayPalButton();

        this.payPalInstance.render(that.selector)
            .then(() => {
                const PayPalBaseModel = require('../../models/buttons/payPalBase');
                const PAYPAL_FS = window.paypal.FUNDING.PAYPAL;

                PayPalBaseModel.prototype.renderButtonMarks.call({
                    fundingSource: PAYPAL_FS
                });

                that.loader.hide();

                PayPalBaseModel.prototype.showButtonTab(PAYPAL_FS);
            });
    }
}

module.exports = PayPalBillingBAModel;
