'use strict';

/**
 * @namespace FlashMessages
 */

const server = require('server');

server.get('Get',
    server.middleware.include,
    function(req, res, next) {
        const Transaction = require('dw/system/Transaction');
        const BasketMgr = require('dw/order/BasketMgr');

        const CustomerModel = require('*/cartridge/models/customer');
        const utils = require('*/cartridge/scripts/paypal/paypalUtils');

        const currentBasket = BasketMgr.currentBasket;
        let flashMessages = [];

        if (customer.authenticated && customer.registered) {
            const customerInstance = new CustomerModel(customer);

            Transaction.wrap(function() {
                flashMessages = customerInstance.pullFlashMessages();
            });
        }

        if (currentBasket && currentBasket.custom.flashMessages) {
            flashMessages = utils.tryParseJSON(currentBasket.custom.flashMessages);

            Transaction.wrap(function() {
                currentBasket.custom.flashMessages = '';
            });
        }

        res.render('components/footer/flashMessages', {
            flashMessages: flashMessages
        });

        return next();
    });

module.exports = server.exports();
