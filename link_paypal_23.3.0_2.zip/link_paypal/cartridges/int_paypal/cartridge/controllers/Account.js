'use strict';

const page = module.superModule;
const server = require('server');

const Resource = require('dw/web/Resource');

const prefs = require('*/cartridge/config/paypalPreferences');
const loginPayPalAddressHelper = require('*/cartridge/scripts/paypal/helpers/loginPayPalAddressHelper');
const BillingAgreementModel = require('*/cartridge/models/billingAgreement');
const paypalSDK = require('*/cartridge/config/paypalSDK');
const paypalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');

server.extend(page);

server.append('Show',
    function(req, res, next) {
        if (!prefs.isPayPalPmActive) {
            return next();
        }

        const billingAgreementModel = new BillingAgreementModel();
        const savedBA = billingAgreementModel.getBillingAgreements(true);
        const lippAddress = customer.addressBook ? loginPayPalAddressHelper.getCWPPCustomerAddress() : null;

        // Updates a customer address from 'Connect with paypal feature' (LIPP-login-PayPal) with phone number
        // as 'Not Provided' in case if phone === null
        if (lippAddress && lippAddress.phone === null) {
            loginPayPalAddressHelper.savePhoneNumberInCWPPAddress(lippAddress,
                Resource.msg('paypal.account.address.phonenumber.notprovided', 'locale', null));

            res.viewData.account.addresses.forEach(function(address) {
                if (address.ID === lippAddress.ID) {
                    address.phone = lippAddress.phone;
                }
            });

            if (res.viewData.account.preferredAddress.address.ID === lippAddress.ID) {
                res.viewData.account.preferredAddress.address.phone = lippAddress.phone;
            }
        }

        const AccountModel = require('*/cartridge/models/account');
        const CustomerModel = require('*/cartridge/models/customer');
        const customerHelper = require('*/cartridge/scripts/paypal/helpers/customerHelper');

        const customerInstance = new CustomerModel(customer);
        const customerSavedCreditCards = AccountModel.getCustomerPaymentInstruments(customerHelper
            .getCustomerPaymentInstruments(prefs.paymentMethods.CREDIT_CARD.paymentMethodId));

        const viewData = res.getViewData();
        const orderHistory = viewData.account.orderHistory;

        if (orderHistory) {
            const orderHelper = require('*/cartridge/scripts/paypal/helpers/orderHelper');
            const orders = orderHelper.fillOrderDetails(req, [orderHistory]);

            if (orders.length) {
                viewData.account.orderHistory = orders[0];
            }
        }

        const billingAddressForm = server.forms.getForm('address');
        const creditCardForm = server.forms.getForm('paypalCreditCard');

        billingAddressForm.clear();
        creditCardForm.clear();

        viewData.paypal = {
            prefs: prefs,
            savedBA: savedBA,
            customerSavedCreditCards: customerSavedCreditCards,
            billingAgreementEnabled: prefs.billingAgreementEnabled,
            isBaLimitReached: billingAgreementModel.isBaLimitReached(),
            sdkUrl: paypalSDK.accountSDKUrl,
            isExternalProfile: customerInstance.isExternalProfile(),
            billingAddressForm: billingAddressForm,
            creditCardForm: creditCardForm
        };

        res.setViewData(viewData);

        paypalHelper.updateViewDataForFraudNet(res);

        return next();
    });

server.append('Login',
    server.middleware.https,
    function(req, res, next) {
        const Transaction = require('dw/system/Transaction');
        const CustomerModel = require('*/cartridge/models/customer');

        if (customer.authenticated && customer.registered) {
            const externalProfileExist = CustomerModel.externalProfileExist(customer.profile.email);

            if (externalProfileExist) {
                const customerInstance = new CustomerModel(customer);

                Transaction.wrap(function() {
                    customerInstance.addFlashMessage(Resource.msg('account.legacy', 'notifications', null),
                        CustomerModel.FLASH_MESSAGE_INFO);
                });
            }

            // CC expire notification is enabled
            if (prefs.creditCardExpireNotification !== -1) {
                const paymentHelper = require('*/cartridge/scripts/paypal/helpers/paymentHelper');
                const customerHelper = require('*/cartridge/scripts/paypal/helpers/customerHelper');

                const customerSavedCreditCards = customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.CREDIT_CARD.paymentMethodId);

                paymentHelper.addExpirationNotificationForCC(customerSavedCreditCards);
            }
        }

        next();
    });

module.exports = server.exports();
