'use strict';

const page = module.superModule;
const server = require('server');

const OrderMgr = require('dw/order/OrderMgr');

const {
    getPaypalPaymentInstrument
} = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');

server.extend(page);

server.append('Confirm', function(req, res, next) {
    const prefs = require('*/cartridge/config/paypalPreferences');
    const payPalConstants = require('*/cartridge/config/paypalConstants');
    const { disableFunds } = require('*/cartridge/config/sdkConfig');

    const order = OrderMgr.getOrder(req.form.orderID, req.form.orderToken);
    const paypalPaymentInstrument = getPaypalPaymentInstrument(order);

    if (!paypalPaymentInstrument) {
        return next();
    }

    const fundigSource = paypalPaymentInstrument.custom.paymentId;

    res.setViewData({
        paypal: {
            // Indicates whether to show shipping info message in case of PayNow flow
            isShippingInfoMsg: prefs.isPayNowFlowEnabled && disableFunds.concat([
                payPalConstants.PAYMENT_METHOD_ID_PAYPAL, payPalConstants.PAYMENT_METHOD_ID_VENMO
            ]).indexOf(fundigSource) !== -1
        }
    });

    return next();
});

server.append('History', function(req, res, next) {
    const orderHelper = require('*/cartridge/scripts/paypal/helpers/orderHelper');

    const viewData = res.getViewData();
    const orders = orderHelper.fillOrderDetails(req, viewData.orders);

    if (orders.length) {
        viewData.orders = orders;

        res.setViewData(viewData);
    }

    next();
});

module.exports = server.exports();
