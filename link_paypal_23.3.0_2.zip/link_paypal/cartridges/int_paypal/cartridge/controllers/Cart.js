'use strict';

const page = module.superModule;
const server = require('server');

const BasketMgr = require('dw/order/BasketMgr');
const Transaction = require('dw/system/Transaction');
const Resource = require('dw/web/Resource');

const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const paypalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');
const paypalUtils = require('*/cartridge/scripts/paypal/paypalUtils');
const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');
const BillingAgreementModel = require('*/cartridge/models/billingAgreement');
const prefs = require('*/cartridge/config/paypalPreferences');
const paypalConstants = require('~/cartridge/config/paypalConstants');
const paypalSDK = require('*/cartridge/config/paypalSDK');

server.extend(page);

/**
 * General function for cart and minicart enpoints until logic are the same
 * @param  {Object} req request
 * @param  {Object} res response
 * @param  {Object} next next call
 * @returns {void}
 */
function payPalCartHandler(req, res, next) {
    const basket = BasketMgr.getCurrentBasket();
    const endpointName = this.name.toLowerCase() === 'show' ? 'cart' : 'minicart';
    const isCartButtonEnabled = paypalHelper.isPaypalButtonEnabled(endpointName);

    if (!basket || !prefs.isPayPalPmActive || !isCartButtonEnabled) {
        return next();
    }

    const paypalPaymentInstrument = paymentInstrumentHelper.getPaypalPaymentInstrument(basket) || null;
    const paypalEmail = paypalPaymentInstrument && paypalPaymentInstrument.custom.currentPaypalEmail;
    const isVenmoUsed = paypalPaymentInstrument && paypalPaymentInstrument.custom.paymentId === paypalConstants.PAYMENT_METHOD_ID_VENMO;
    let defaultBA = {};
    // for guest with paypalEmail from PI
    let showStaticImage = !!paypalEmail && prefs.isSessionPaymentsEnabled;

    if (customer.authenticated && prefs.billingAgreementEnabled) {
        const billingAgreementModel = new BillingAgreementModel();
        const savedPaypalBillingAgreements = billingAgreementModel.getBillingAgreements(true);

        if (!empty(savedPaypalBillingAgreements)) {
            defaultBA = billingAgreementModel.getDefaultBillingAgreement();
            showStaticImage = true;
        }
    }

    // Setting orderDataHash explisitly for route Paypal-UpdateOrderDetails when isUpdateRequired(isPaypalInstrumentExist)
    const purchaseUnits = [paypalHelper.getPurchaseUnit(basket, true)];

    session.privacy.orderDataHash = paypalUtils.encodeString(purchaseUnits[0]);

    res.setViewData({
        paypal: {
            sdkUrl: paypalSDK.cartSdkUrl,
            partnerAttributionId: prefs.partnerAttributionId,
            cartButtonEnabled: isCartButtonEnabled,
            buttonConfig: endpointName === 'cart' ? prefs.paypalCartButtonConfig : prefs.paypalMinicartButtonConfig,
            billingFormFields: paypalHelper.getPreparedBillingFormFields(paypalPaymentInstrument, defaultBA),
            paypalEmail: paypalEmail,
            showStaticImage: showStaticImage,
            paypalStaticImageLink: prefs.paypalStaticImageLink,
            defaultBAemail: defaultBA.email,
            isPaypalInstrumentExist: paypalPaymentInstrument && !empty(paypalPaymentInstrument),
            billingAgreementEnabled: prefs.billingAgreementEnabled,
            isVenmoUsed: isVenmoUsed,
            payNowData: {
                isPayNowFlowEnabled: prefs.isPayNowFlowEnabled
            }
        }
    });

    if (prefs.isPayNowFlowEnabled) {
        res.viewData.paypal.payNowData.currentBasketShipmentUUID = basket.defaultShipment.UUID;
    }

    paypalHelper.updateViewDataForFraudNet(res);

    return next();
}

/**
 * It removes all products from the current basket.
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 * @param {Object} next - The next function in the Express middleware chain.
 * @returns {void}
 */
function removeAllProductsHandler(req, res, next) {
    const basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

    const currentBasket = BasketMgr.getCurrentBasket();

    if (!currentBasket) {
        res.setStatusCode(500);
        res.json({
            error: true,
            message: Resource.msg('paypal.server.error', 'locale', null)
        });

        return next();
    }

    const productLineItems = currentBasket.getAllProductLineItems().toArray();

    Transaction.wrap(function() {
        productLineItems.forEach(function(item) {
            const shipmentToRemove = item.shipment;

            currentBasket.removeProductLineItem(item);

            if (shipmentToRemove && shipmentToRemove.productLineItems.empty && !shipmentToRemove.default) {
                currentBasket.removeShipment(shipmentToRemove);
            }
        });

        basketCalculationHelpers.calculateTotals(currentBasket);
    });

    res.json();

    return next();
}

server.append('Show', payPalCartHandler);

server.append('MiniCartShow', csrfProtection.generateToken, payPalCartHandler);

server.get('RemoveAllProductsFromCart', server.middleware.https, csrfProtection.validateAjaxRequest, removeAllProductsHandler);

module.exports = server.exports();
