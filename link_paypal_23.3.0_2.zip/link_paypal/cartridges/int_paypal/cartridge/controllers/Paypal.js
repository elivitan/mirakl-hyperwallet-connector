/* eslint-disable no-shadow */

'use strict';

const server = require('server');

const Transaction = require('dw/system/Transaction');
const HookMgr = require('dw/system/HookMgr');
const PaymentMgr = require('dw/order/PaymentMgr');
const Money = require('dw/value/Money');
const BasketMgr = require('dw/order/BasketMgr');
const OrderMgr = require('dw/order/OrderMgr');
const Order = require('dw/order/Order');
const Status = require('dw/system/Status');
const URLUtils = require('dw/web/URLUtils');
const Resource = require('dw/web/Resource');

const paypalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');
const middleware = require('*/cartridge/scripts/paypal/middleware');
const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
const paypalApi = require('*/cartridge/scripts/paypal/paypalApi');
const utils = require('*/cartridge/scripts/paypal/paypalUtils');
const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');
const addressHelper = require('*/cartridge/scripts/paypal/helpers/addressHelper');
const prefs = require('*/cartridge/config/paypalPreferences');
const COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
const BillingAgreementModel = require('*/cartridge/models/billingAgreement');
const CustomerModel = require('*/cartridge/models/customer');
const paypalConstants = require('*/cartridge/config/paypalConstants');
const paypalSDK = require('*/cartridge/config/paypalSDK');
const connectWithPaypalHelper = require('*/cartridge/scripts/paypal/helpers/connectWithPaypalHelper');

server.get('GetPaypalOrderId', server.middleware.https, csrfProtection.validateAjaxRequest, function(req, res, next) {
    const currentBasket = BasketMgr.currentBasket;

    let paymentSourceData;

    if (req.querystring.paymentSourceData) {
        try {
            paymentSourceData = JSON.parse(req.querystring.paymentSourceData);
        } catch (error) {
            paymentSourceData = null;
        }
    }

    // Sets a zero amount shiping method to the basket in case of the Pay Now flow
    if (prefs.isPayNowFlowEnabled) {
        addressHelper.applyOnlinePickupShippingMethodToBasket(currentBasket);
    }

    const purchaseUnit = paypalHelper.getPurchaseUnit(currentBasket);
    const result = paypalApi.createOrder(purchaseUnit, currentBasket, paymentSourceData);

    if (result.err) {
        utils.createErrorLog(result.err);
        res.setStatusCode(500);
        res.json({
            error: true
        });

        return next();
    }

    session.privacy.paypalOrderID = result.resp.id;

    res.json({ id: result.resp.id });

    return next();
});

server.use('UpdateOrderDetails',
    csrfProtection.validateAjaxRequest,
    server.middleware.https,
    function(req, res, next) {
        const {
            currentBasket
        } = BasketMgr;

        const isCartFlow = req.querystring.isCartFlow === 'true';
        const purchaseUnit = paypalHelper.getPurchaseUnit(currentBasket, isCartFlow);
        const paymentInstrument = paymentInstrumentHelper.getPaypalPaymentInstrument(currentBasket);
        const isUpdateRequired = paypalHelper.isPurchaseUnitChanged(purchaseUnit, paymentInstrument);

        const isAddressNeedChange = req.querystring.isAddressNeedChange === 'true';

        let shippingAddress;

        if (isAddressNeedChange) {
            const shipping = customer.addressBook.preferredAddress;

            shippingAddress = {
                city: shipping.city,
                country_code: shipping.countryCode.value,
                line1: shipping.address1,
                phone: shipping.phone,
                postal_code: shipping.postalCode,
                recipient_name: shipping.fullName,
                state: shipping.stateCode
            };

            addressHelper.updateShippingAddress(currentBasket, shippingAddress, paymentInstrument);
        }

        if (paypalHelper.isExpiredTransaction(paymentInstrument)) {
            paymentInstrumentHelper.removePaypalPaymentInstrument(currentBasket);

            res.setStatusCode(500);
            res.json({
                errorMsg: utils.createErrorMsg('expiredpayment')
            });

            return next();
        }

        if (paymentInstrument.custom.PP_API_ActiveBillingAgreement) {
            if (paymentInstrument.paymentTransaction.amount.value.toString() !== purchaseUnit.amount.value) {
                const newAmount = new Money(purchaseUnit.amount.value, purchaseUnit.amount.currency_code);

                Transaction.wrap(function() {
                    paymentInstrument.paymentTransaction.setAmount(newAmount);
                });
            }

            res.json({});

            return next();
        }

        if (isUpdateRequired) {
            if (purchaseUnit.amount.value === '0') {
                res.setStatusCode(500);
                res.json({
                    errorMsg: utils.createErrorMsg('zeroamount')
                });

                return next();
            }

            const {
                err
            } = paypalApi.updateOrderDetails(paymentInstrument, purchaseUnit);

            if (err) {
                res.setStatusCode(500);
                res.json({
                    errorMsg: err
                });

                return next();
            }

            session.privacy.orderDataHash = utils.encodeString(purchaseUnit);

            res.json({});

            return next();
        }

        return '';
    }
);

server.post('ReturnFromCart',
    csrfProtection.validateAjaxRequest,
    server.middleware.https,
    middleware.removeNonPaypalPayment,
    middleware.validateProcessor,
    middleware.validateHandleHook,
    middleware.validateGiftCertificateAmount,
    function(req, res, next) {
        const {
            currentBasket
        } = BasketMgr;

        const isAddressNeedChange = req.querystring.isAddressNeedChange === 'true';

        let shippingAddress;

        if (isAddressNeedChange) {
            shippingAddress = addressHelper.getPreferredShippingAddressShortObj();
        }

        const paymentForm = server.forms.getForm('billing');
        const processorId = PaymentMgr.getPaymentMethod(paypalConstants.PAYMENT_METHOD_ID_PAYPAL).getPaymentProcessor().ID.toLowerCase();

        let paymentFormResult;

        if (HookMgr.hasHook('app.payment.form.processor.' + processorId)) {
            paymentFormResult = HookMgr.callHook('app.payment.form.processor.' + processorId,
                'processForm',
                req,
                paymentForm,
                {});
        } else {
            paymentFormResult = HookMgr.callHook('app.payment.form.processor.default_form_processor', 'processForm');
        }

        if (!paymentFormResult || paymentFormResult.error) {
            res.setStatusCode(500);
            res.print(utils.createErrorMsg());

            return next();
        }

        const processorHandle = HookMgr.callHook('app.payment.processor.' + processorId,
            'Handle',
            currentBasket,
            paymentFormResult.viewData.paymentInformation,
            shippingAddress);

        if (!processorHandle || !processorHandle.success) {
            res.setStatusCode(processorHandle.statusCode || 500);
            res.print(processorHandle.serverErrors || utils.createErrorMsg(processorHandle.errorName));

            return next();
        }

        if (!shippingAddress) {
            shippingAddress = processorHandle.shippingAddress;
        }

        try {
            addressHelper.updateShippingAddress(currentBasket, shippingAddress, processorHandle.paymentInstrument);
            res.json();
        } catch (error) {
            const paypalUrls = require('~/cartridge/config/paypalUrls');

            Transaction.wrap(function() {
                utils.addFlashMessagesCustomAttribute(currentBasket, error.message, 'danger');
            });

            res.json({
                error: true,
                redirectURL: paypalUrls.chooseShippingUrl
            });
        }

        return next();
    });

server.post('ValidateHostedFields',
    csrfProtection.validateAjaxRequest,
    function(req, res, next) {
        const creditCardHelper = require('*/cartridge/scripts/paypal/helpers/creditCardHelper');

        const reqBody = utils.tryParseJSON(request.httpParameterMap.requestBodyAsString);

        const fieldsErrors = Object.keys(reqBody.fields).reduce((accum, field) => {
            const validationResult = creditCardHelper.validateCcFields(field, reqBody.fields[field]);

            if (validationResult.isError) {
                accum[field] = validationResult;
            }

            return accum;
        }, {});

        if (Object.keys(fieldsErrors).length > 0) {
            res.json({
                error: true,
                fieldsErrors: fieldsErrors
            });

            res.setStatusCode(400);

            return next();
        }

        res.json({
            error: false
        });

        return next();
    }
);

server.get('GetBillingAgreementToken', server.middleware.https, function(req, res, next) {
    const isCartFlow = req.querystring.isCartFlow === 'true';
    const isSkipShippingAddress = req.querystring.isSkipShippingAddress === 'true';
    const {
        billingAgreementToken,
        err
    } = paypalApi.getBillingAgreementToken(paypalHelper.getBARestData(isCartFlow, isSkipShippingAddress));

    if (err) {
        res.setStatusCode(500);
        res.print(err);

        return next();
    }

    res.json({
        token: billingAgreementToken
    });

    session.privacy.baToken = billingAgreementToken;

    return next();
});

server.post('CreateBillingAgreement',
    csrfProtection.validateAjaxRequest,
    server.middleware.https,
    function(_, res, next) {
        const response = paypalApi.createBillingAgreement(session.privacy.baToken);

        const errObject = {
            error: false
        };

        if (response.shipping_address && !response.shipping_address.id) {
            const payload = addressHelper.generateShippingAddressesPayloadFromBA(response);
            const addressValidation = addressHelper.validateShippingAddressForm(payload);

            if (addressValidation.error) {
                res.setStatusCode(500);

                Object.assign(errObject, addressValidation);
            }
        }

        if (response.err) {
            Object.assign(errObject, {
                error: true,
                errorName: response.err
            });
        }

        if (errObject.error) {
            res.json(errObject);
        } else {
            res.json(response);
        }

        session.privacy.baToken = null;

        return next();
    }
);

server.use('RemoveBillingAgreement',
    csrfProtection.validateAjaxRequest,
    server.middleware.https,
    function(req, res, next) {
        const billingAgreementModel = new BillingAgreementModel();

        const baEmail = req.querystring.billingAgreementEmail;
        const billingAgreement = billingAgreementModel.getBillingAgreementByEmail(baEmail);

        billingAgreementModel.removeBillingAgreement(billingAgreement);
        paypalApi.cancelBillingAgreement(billingAgreement.baID);

        if (BasketMgr.currentBasket) {
            paymentInstrumentHelper.removePayPalPaymentInstrumentByEmail(BasketMgr.currentBasket, baEmail);
        }

        res.json({});

        return next();
    }
);

server.post('SaveBillingAgreement',
    csrfProtection.validateAjaxRequest,
    server.middleware.https,
    middleware.parseBody,
    function(req, res, next) {
        const billingAgreementModel = new BillingAgreementModel();
        const baData = res.parsedBody;
        const isAutomaticPmAddingFlow = baData && baData.isAutomaticPmAddingFlow;
        const customerInstance = new CustomerModel(customer);

        try {
            if (baData) {
                const savedBA = billingAgreementModel.getBillingAgreements();
                const isAccountAlreadyExist = billingAgreementModel.isAccountAlreadyExist(baData.email);

                if (!isAccountAlreadyExist) {
                    if (empty(savedBA)) {
                        baData.default = true;
                    }

                    baData.saveToProfile = true;
                    delete baData.isAutomaticPmAddingFlow;
                    billingAgreementModel.saveBillingAgreement(baData);

                    if (isAutomaticPmAddingFlow) {
                        Transaction.wrap(function() {
                            const resource = 'paypal.account.paymentmethodadded.notification.msg';

                            customerInstance.addFlashMessage(Resource.msg(resource, 'locale', null),
                                CustomerModel.FLASH_MESSAGE_SUCCESS);
                        });
                    }
                }
            }
        } catch (err) {
            if (isAutomaticPmAddingFlow) {
                Transaction.wrap(function() {
                    const resource = 'paypal.account.paymentmethodnotadded.notification.msg';

                    customerInstance.addFlashMessage(Resource.msg(resource, 'locale', null),
                        CustomerModel.FLASH_MESSAGE_DANGER);
                });
            }

            utils.createErrorLog(err);
        }

        res.json({});

        return next();
    }
);

server.post('ValidateStaticImage',
    csrfProtection.validateAjaxRequest,
    server.middleware.https,
    middleware.parseBody,
    function(req, res, next) {
        let formFields;

        try {
            formFields = JSON.parse(res.parsedBody.formFields);
        } catch (er) {
            formFields = null;
        }

        const addressBook = customer.addressBook.preferredAddress;

        let isAddressNeedChange = false;

        if (addressBook && formFields) {
            const billingAgreementDetails = paypalApi.getBADetailsById(formFields.billingAgreementID.value);

            const billingAgreementShippingAddress = addressHelper.generateShippingAddressesPayloadFromBA(billingAgreementDetails);
            const addressBookAddress = addressHelper.generateShippingAddressesPayloadFromAddressBook(addressBook);

            isAddressNeedChange = !addressHelper.compareShippingAddresses(billingAgreementShippingAddress, addressBookAddress);
        }

        res.json({
            isAddressNeedChange: isAddressNeedChange
        });

        next();
    }
);

server.post('FinishPayNowFlow',
    csrfProtection.validateAjaxRequest,
    server.middleware.https,
    middleware.parseBody,
    function(_, res, next) {
        const { pmName } = res.parsedBody;
        const { currentBasket } = BasketMgr;

        currentBasket.paymentInstruments.toArray().forEach(function(payment) {
            if (payment.paymentMethod !== 'GIFT_CERTIFICATE') {
                Transaction.wrap(function() {
                    currentBasket.removePaymentInstrument(payment);
                });
            }
        });

        const lpmsList = prefs.enabledLPMs;
        const paymentInstrument = paymentInstrumentHelper.createPaymentInstrument(currentBasket,
            paypalConstants.PAYMENT_METHOD_ID_PAYPAL);

        Transaction.wrap(function() {
            paymentInstrument.custom.paypalOrderID = session.privacy.paypalOrderID;

            paymentInstrument.custom.paymentId = pmName;
        });

        const createTransactionResponse = paypalApi.createTransaction(paymentInstrument).response;
        const transactionId = paypalHelper.getTransactionId(createTransactionResponse);
        const payer = createTransactionResponse.payer;
        const paymentTransaction = paymentInstrument.paymentTransaction;
        const paymentSource = createTransactionResponse.payment_source;
        const paymentSourceName = Object.keys(paymentSource)[0];

        // Fills data to the payment instrument, payment transaction from transaction response
        Transaction.wrap(function() {
            paymentInstrument.custom.currentPaypalEmail = payer ? payer.email_address : null;
            paymentInstrument.custom.paypalLpmAccountHolderName = lpmsList.indexOf(paymentSourceName) !== -1
                ? paymentSource[paymentSourceName].name : null;
            paymentInstrument.getPaymentTransaction().setTransactionID(transactionId);
            paymentInstrument.custom.paypalPaymentStatus = paypalHelper.getTransactionStatus(createTransactionResponse);
            paymentInstrument.custom.paypalRequest = JSON.stringify({});
            paymentInstrument.custom.paypalResponse = JSON.stringify(createTransactionResponse);

            paymentTransaction.custom.paypalTransactionHistory = paypalHelper.prepareTransactionHistory(paymentTransaction,
                createTransactionResponse);
        });

        // Update billing address.
        // Only PayPal payment source contains information about payer. LPM won't update billing address from payment method.
        if (paymentSource.paypal || paymentSource.venmo) {
            addressHelper.updateOrderBillingAddress(currentBasket, payer);
        }

        // Creates a new order.
        const order = COHelpers.createOrder(currentBasket);

        if (!order) {
            res.setStatusCode(500);
            res.print(utils.createErrorMsg());

            return next();
        }

        // Places the order.
        try {
            Transaction.begin();
            const placeOrderStatus = OrderMgr.placeOrder(order);

            if (placeOrderStatus.status === Status.ERROR) {
                throw new Error();
            }

            order.setConfirmationStatus(Order.CONFIRMATION_STATUS_CONFIRMED);
            order.setExportStatus(Order.EXPORT_STATUS_READY);
            order.custom.paypalPaymentMethod = 'express';
            order.custom.PP_API_TransactionID = transactionId;
            Transaction.commit();
        } catch (e) {
            Transaction.wrap(function() {
                OrderMgr.failOrder(order, true);
            });
            utils.createErrorLog(e);
            res.setStatusCode(500);
            res.print(e.message);

            return next();
        }

        res.json({
            redirectUrl: URLUtils.https('Order-Confirm', 'orderID', order.orderNo, 'orderToken', order.orderToken).toString()
        });

        return next();
    });

server.get('RenderCWPP', server.middleware.include, function(req, res, next) {
    const config = connectWithPaypalHelper.getBtnConfig(req, res);

    res.render('/paypal/components/cwppButton', config);

    return next();
});

server.get('ConnectWithPaypal', middleware.validateConnectWithPaypalUrl, function(req, res, next) {
    try {
        // Gets the access token according to the authentification code
        const accessToken = paypalApi.exchangeAuthCodeForAccessToken(request.httpParameterMap.code.value);
        // Gets the Paypal customer information according to the access token
        const payPalCustomerInfo = paypalApi.getPaypalCustomerInfo(accessToken);

        const nextStepUrl = connectWithPaypalHelper.handleConnectWithPaypalFlow(req, res, payPalCustomerInfo);

        res.redirect(nextStepUrl);
    } catch (err) {
        res.render('/error', {
            message: err
        });

        utils.createErrorLog(err);
    }

    return next();
});

server.post('PaymentAuthorizationAndCaptureHook', function(req, res, next) {
    const AuthorizationAndCaptureWhMgr = require('*/cartridge/models/authorizationAndCaptureWhMgr');
    const responseObject = {};

    let authorizationAndCaptureWhMgr;

    try {
        const whEvent = JSON.parse(request.httpParameterMap.requestBodyAsString);
        const eventType = whEvent.event_type;
        const eventResource = whEvent.resource;

        authorizationAndCaptureWhMgr = new AuthorizationAndCaptureWhMgr();

        // Cheks if endpoint received an appropriate event
        const isApproppriateEventType = authorizationAndCaptureWhMgr.isApproppriateEventType(eventType);

        // Proceeds only with the appropriate event type
        if (!isApproppriateEventType) {
            return;
        }

        // Verify webhook event notifications
        const verifiedResponse = authorizationAndCaptureWhMgr.verifyWhSignature(whEvent,
            request.httpHeaders,
            prefs.authorizationAndCaptureWhId);

        const verificationStatus = verifiedResponse.verification_status;

        if (verificationStatus === paypalConstants.STATUS_SUCCESS) {
            const orderNo = eventResource.invoice_id;
            const paymentStatus = eventResource.status;

            if (!orderNo || !paymentStatus) {
                return;
            }

            // Gets order needed to update payment status
            const order = paypalHelper.getOrderByOrderNo(orderNo);

            // The webhook will process only the orders related to the current host
            if (!order) {
                return;
            }

            // Handles different WebHook scenarios in depends of received webHook event
            switch (eventType) {
                case paypalConstants.PAYMENT_AUTHORIZATION_VOIDED:
                    authorizationAndCaptureWhMgr.voidPaymentOnDwSide(order, paymentStatus, whEvent);

                    break;
                case paypalConstants.PAYMENT_CAPTURE_REFUNDED:
                    authorizationAndCaptureWhMgr.refundPaymentOnDwSide(order, paypalConstants.PAYMENT_STATUS_REFUNDED, whEvent);

                    break;
                case paypalConstants.PAYMENT_CAPTURE_COMPLETED:
                    authorizationAndCaptureWhMgr.completePaymentOnDwSide(order, paymentStatus, whEvent);

                    break;
                default:
                    break;
            }
        } else {
            throw Resource.msgf('paypal.webhook.verified.error', 'paypalerrors', null, verificationStatus);
        }
    } catch (err) {
        responseObject.error = err;
        responseObject.success = false;

        res.json(responseObject);

        utils.createErrorLog(err);

        return next();
    }

    res.setStatusCode(200);
    responseObject.success = true;
    res.json(responseObject);

    return next();
});

server.get('RenderAccountLinkingSecurityLayer',
    csrfProtection.generateToken,
    server.middleware.https,
    function(req, res, next) {
        const payPalCustomerInfo = req.querystring.payPalCustomerInfo ? JSON.parse(decodeURIComponent(req.querystring.payPalCustomerInfo)) : null;
        const isCanceled = req.querystring.isCancel ? JSON.parse(decodeURIComponent(req.querystring.isCancel)) : false;

        if (isCanceled) {
            res.render('paypal/accountLinkingSecurityLayer/canceledAccountLinkingSecurityLayer', {
                redirectUrl: URLUtils.url('Login-Show').toString()
            });

            return next();
        }

        if (!payPalCustomerInfo) {
            res.setStatusCode(404);

            res.render('/error/notFound');

            return next();
        }

        const config = connectWithPaypalHelper.getAccountLinkingSecurityLayerConfig(payPalCustomerInfo);

        res.render('paypal/accountLinkingSecurityLayer/accountLinkingSecurityLayer', config);

        return next();
    }
);

server.post('HandleAccountLinkingSecurityLayer',
    csrfProtection.validateAjaxRequest,
    server.middleware.https,
    middleware.parseBody,
    function(req, res, next) {
        try {
            const payPalCustomerInfo = req.querystring.payPalCustomerInfo ? JSON.parse(decodeURIComponent(req.querystring.payPalCustomerInfo)) : null;
            const isCanceled = req.querystring.isCancel ? JSON.parse(decodeURIComponent(req.querystring.isCancel)) : false;

            if (isCanceled) {
                res.json({
                    redirectUrl: URLUtils.url('Paypal-RenderAccountLinkingSecurityLayer', 'isCancel', isCanceled).toString()
                });

                return next();
            }

            const nextStep = connectWithPaypalHelper.handleAccountLinkingSecurityLayerFlow(req, res, payPalCustomerInfo);

            if (nextStep.error) {
                res.json({
                    error: nextStep.errorMsg
                });

                return next();
            }

            res.json({
                redirectUrl: nextStep.nextStepUrl.toString()
            });
        } catch (err) {
            res.render('/error', {
                message: err
            });

            utils.createErrorLog(err);
        }

        return next();
    }
);

server.get('APMA',
    server.middleware.https,
    csrfProtection.generateToken,
    userLoggedIn.validateLoggedIn,
    function(req, res, next) {
        if (!req.querystring.redirectURL || !req.querystring.addressObject) {
            res.redirect(URLUtils.url(paypalConstants.ENDPOINT_HOME_SHOW));

            return next();
        }

        const customerInstance = new CustomerModel(customer);
        const hasBillingAgreement = customerInstance.hasBillingAgreement();
        const addressObjectString = decodeURIComponent(req.querystring.addressObject);

        const addressValidation = {
            error: false
        };

        if (addressObjectString) {
            const addressObject = JSON.parse(addressObjectString);
            const payload = {
                firstName: addressObject.firstName,
                lastName: addressObject.lastName,
                phone: addressObject.phone,
                shippingAddress: {
                    city: addressObject.city,
                    countryCode: addressObject.countryCode,
                    state: addressObject.stateCode,
                    line1: addressObject.address1,
                    postalCode: addressObject.postalCode
                }
            };

            Object.assign(addressValidation, addressHelper.validateShippingAddressForm(payload));
        }

        const hasAddress = customerInstance.hasAddress(JSON.parse(addressObjectString));

        if (!customerInstance.isEnabledFeatureAPMA()
        || (hasBillingAgreement && hasAddress)
        || addressValidation.error
        || (hasAddress && !prefs.billingAgreementEnabled)) {
            res.redirect(req.querystring.redirectURL);

            return next();
        }

        Transaction.wrap(function() {
            customerInstance.disableFeatureAPMA();
        });

        let addingStage = paypalConstants.APMA_STAGE_COMPLETE;

        if (hasBillingAgreement || !prefs.billingAgreementEnabled) {
            addingStage = paypalConstants.APMA_STAGE_ADDRESS;
        }

        if (hasAddress && prefs.billingAgreementEnabled) {
            addingStage = paypalConstants.APMA_STAGE_ACCOUNT;
        }

        res.render('paypal/automaticPaymentMethodAdding/automaticPaymentMethodAdding', {
            paypal: {
                sdkUrl: paypalSDK.accountSDKUrl
            },
            addingStage: addingStage,
            addressObject: addressObjectString,
            redirectURL: req.querystring.redirectURL
        });

        return next();
    }
);

/**
 * Uses only for 'Automatic payment method adding' flow due Connect with PayPal button
 */
server.post('SavePaypalDefaultAddress', server.middleware.https, middleware.parseBody, function(req, res, next) {
    const customerInstance = new CustomerModel(customer);

    try {
        // Creates a customer address from the address provided by 'Connect with PayPal' feature
        Transaction.wrap(function() {
            customerInstance.addAddress(res.parsedBody.addressObject);
        });

        const StringUtils = require('dw/util/StringUtils');
        const resourceContext = res.parsedBody.isAccountPage ? 'account' : 'checkout';

        Transaction.wrap(function() {
            const resource = StringUtils.format('paypal.{0}.shippingaddressadded.notification.msg', resourceContext);

            customerInstance.addFlashMessage(Resource.msg(resource, 'locale', null), CustomerModel.FLASH_MESSAGE_SUCCESS);
        });
    } catch (err) {
        Transaction.wrap(function() {
            const resource = 'paypal.account.shippingaddressnotadded.notification.msg';

            customerInstance.addFlashMessage(Resource.msg(resource, 'locale', null), CustomerModel.FLASH_MESSAGE_DANGER);
        });

        utils.createErrorLog(err);
    }

    res.json({});

    return next();
});

server.post('UnlinkCWPP',
    server.middleware.https,
    userLoggedIn.validateLoggedInAjax,
    csrfProtection.validateAjaxRequest,
    function(req, res, next) {
        const customerInstance = new CustomerModel(customer);

        try {
            Transaction.wrap(function() {
                customerInstance.setIsExternalProfile(false);
            });

            customerInstance.sendUnlinkedAccountConfirmationEmail();
        } catch (err) {
            utils.createErrorLog(err);

            res.setStatusCode(400);
            res.json({
                errorMessage: Resource.msg('paypal.error.general', 'paypalerrors', null)
            });

            return next();
        }

        res.json({
            alertMessage: Resource.msg('label.unlink.notification', 'account', null)
        });

        return next();
    }
);

server.post('AccountAddCreditCardHandle',
    server.middleware.https,
    userLoggedIn.validateLoggedIn,
    csrfProtection.validateAjaxRequest,
    function(req, res, next) {
        const Encoding = require('dw/crypto/Encoding');

        const paypalUrls = require('*/cartridge/config/paypalUrls');
        const creditCardHelper = require('*/cartridge/scripts/paypal/helpers/creditCardHelper');
        const customerHelper = require('*/cartridge/scripts/paypal/helpers/customerHelper');

        const creditCardForm = utils.tryParseJSON(Encoding.fromBase64(req.body));
        const formFields = creditCardHelper.getCreditCardFields(creditCardForm);
        const preparedForm = creditCardHelper.prepareCardFieldsAccountPage(formFields);

        const fieldsErrors = Object.keys(preparedForm).reduce((accum, field) => {
            const validationResult = creditCardHelper.validateCardAccountPage(field, preparedForm[field]);

            if (validationResult.isError) {
                accum[field] = validationResult;
            }

            return accum;
        }, {});

        if (Object.keys(fieldsErrors).length > 0) {
            res.json({
                error: true,
                fieldsErrors: fieldsErrors
            });

            res.setStatusCode(400);

            return next();
        }

        const setupTokenResponse = paypalApi.createSetupToken(preparedForm);

        if (setupTokenResponse.err) {
            res.json({
                error: true,
                message: setupTokenResponse.err
            });

            res.setStatusCode(400);

            return next();
        }

        const customerId = customerHelper.getPaypalCustomerId(setupTokenResponse);
        const paymentTokenResponse = paypalApi.createPaymentToken(setupTokenResponse.id, customerId);

        if (paymentTokenResponse.err) {
            res.json({
                error: true,
                message: paymentTokenResponse.err
            });

            res.setStatusCode(400);

            return next();
        }

        const billingAddressToSave = addressHelper.getBillingAddressToSave(creditCardForm);
        const billingAddressAsString = paypalHelper.stringifyBillingAddress(billingAddressToSave);

        creditCardHelper.saveCreditCardToCustomerWallet(paymentTokenResponse, billingAddressAsString);

        res.json({
            error: false,
            renderAccountsUrl: paypalUrls.renderAccountsUrl
        });

        return next();
    }
);

server.get('RenderAccountsList', server.middleware.https, function(req, res, next) {
    const AccountModel = require('*/cartridge/models/account');
    const customerHelper = require('*/cartridge/scripts/paypal/helpers/customerHelper');

    const customerSavedCreditCards = AccountModel.getCustomerPaymentInstruments(
        customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.PAYPAL_CREDIT_CARD.paymentMethodId)
    );

    const renderData = {
        paypal: {
            customerSavedCreditCards: customerSavedCreditCards
        }
    };

    res.render('account/paypal/creditCardsLoop', renderData);

    return next();
});

server.get('DeleteCreditCard',
    server.middleware.https,
    userLoggedIn.validateLoggedIn,
    csrfProtection.validateAjaxRequest,
    function(req, res, next) {
        const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');
        const creditCardHelper = require('*/cartridge/scripts/paypal/helpers/creditCardHelper');

        const uuid = req.querystring.uuid;
        const piToDelete = paymentInstrumentHelper.getCustomerPiByUUID(uuid);
        const isDefaultCard = piToDelete.custom && piToDelete.custom.payPalDefaultCard;

        const response = paypalApi.deletePaymentToken(piToDelete.creditCardToken);

        if (response.err) {
            res.json({
                error: true,
                message: response.err
            });

            return next();
        }

        let newDefaultCreditCard;

        creditCardHelper.deleteCreditCardFromWallet(piToDelete);

        if (isDefaultCard) {
            creditCardHelper.setDefaultCard();
            newDefaultCreditCard = creditCardHelper.getDefaultCard();
        }

        res.json({
            error: false,
            newDefaultCreditCardId: newDefaultCreditCard ? newDefaultCreditCard.UUID : null
        });

        return next();
    }
);

server.get('IncludeConstants', server.middleware.include, function(req, res, next) {
    res.render('common/paypalConstants', {
        paypalConstantsString: JSON.stringify(paypalConstants)
    });

    next();
});

server.get('IncludeUrls', server.middleware.include, function(req, res, next) {
    const paypalUrls = require('*/cartridge/config/paypalUrls');

    res.render('common/paypalUrls', {
        paypalUrlsString: JSON.stringify(paypalUrls)
    });

    next();
});

server.get('IncludeSDK', server.middleware.include, function(req, res, next) {
    res.render('common/paypalSDK', {
        paypalSDKString: JSON.stringify(paypalSDK)
    });

    next();
});

server.get('IncludePreferences', server.middleware.include, function(req, res, next) {
    res.render('common/paypalPreferences', {
        // eslint-disable-next-line no-underscore-dangle
        paypalPreferencesString: JSON.stringify(prefs._whiteListedForStorefront)
    });

    next();
});

module.exports = server.exports();
