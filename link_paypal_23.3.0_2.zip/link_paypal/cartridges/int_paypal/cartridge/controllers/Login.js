'use strict';

/**
 * @namespace Login
 */

const server = require('server');

server.extend(module.superModule);

server.append('Show', function(req, res, next) {
    const prefs = require('*/cartridge/config/paypalPreferences');
    const viewData = res.getViewData();

    viewData.paypal = {
        sdkUrl: require('*/cartridge/config/paypalSDK').cartSdkUrl,
        isPayPalEnabled: prefs.isPayPalPmActive
    };

    res.setViewData(viewData);

    next();
});

module.exports = server.exports();
