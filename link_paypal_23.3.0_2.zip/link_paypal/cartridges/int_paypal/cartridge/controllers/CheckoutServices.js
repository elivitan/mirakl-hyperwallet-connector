/* eslint-disable no-shadow */

'use strict';

const page = module.superModule;
const server = require('server');

const Transaction = require('dw/system/Transaction');
const HookMgr = require('dw/system/HookMgr');
const BasketMgr = require('dw/order/BasketMgr');

const middleware = require('*/cartridge/scripts/paypal/middleware');
const paypalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');
const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');
const paypalApi = require('*/cartridge/scripts/paypal/paypalApi');
const paypalUtils = require('*/cartridge/scripts/paypal/paypalUtils');
const addressHelper = require('*/cartridge/scripts/paypal/helpers/addressHelper');

server.extend(page);

server.append('SubmitPayment',
    middleware.validatePaymentMethod,
    middleware.validateGiftCertificateAmount,
    function(req, res, next) {
        this.on('route:BeforeComplete', function(_, res) {
            const currentBasket = BasketMgr.getCurrentBasket();
            const paypalPaymentInstrument = paymentInstrumentHelper.getPaypalPaymentInstrument(currentBasket);
            const billingForm = server.forms.getForm('billing');

            if (!paypalPaymentInstrument) {
                return;
            }

            if (paypalHelper.isExpiredTransaction(paypalPaymentInstrument)) {
                const paypalUrls = require('*/cartridge/config/paypalUrls');

                paymentInstrumentHelper.removePaypalPaymentInstrument(currentBasket);

                res.json({
                    form: billingForm,
                    fieldErrors: [],
                    serverErrors: [paypalUtils.createErrorMsg('expiredpayment')],
                    error: true,
                    redirectUrl: paypalUrls.paymentStage,
                    cartError: true
                });

                return;
            }

            const currencyCode = currentBasket.getCurrencyCode();
            const billingData = res.getViewData();

            const {
                noOrderIdChange,
                isOrderIdChanged
            } = paymentInstrumentHelper.getPaymentInstrumentAction(paypalPaymentInstrument);

            paypalHelper.updateCustomerPhone(currentBasket, billingData);

            // if user goes through checkout with the same session account we update order details if needed
            if (noOrderIdChange) {
                const purchaseUnit = paypalHelper.getPurchaseUnit(currentBasket);

                paypalUtils.handleError(purchaseUnit.amount.value === '0',
                    paypalUtils.errorHandle,
                    [req, res, null, 'zeroamount']);

                const isUpdateRequired = paypalHelper.isPurchaseUnitChanged(purchaseUnit, paypalPaymentInstrument);

                if (isUpdateRequired) {
                    const { err: updateOrderDetailsError } = paypalApi.updateOrderDetails(paypalPaymentInstrument, purchaseUnit);

                    paypalUtils.handleError(updateOrderDetailsError,
                        paypalUtils.errorHandle,
                        [req, res, updateOrderDetailsError]);
                    session.privacy.orderDataHash = paypalUtils.encodeString(purchaseUnit);
                }
            }

            // if user changes one session account to another we update billing address and email
            if (isOrderIdChanged) {
                Transaction.wrap(function() {
                    paypalPaymentInstrument.custom.paypalOrderID = session.privacy.paypalOrderID;

                    // update paymentId depending on whether it's venmo account or not
                    paypalHelper.updatePaymentId(paypalPaymentInstrument, billingForm);
                });

                const { payer, err: OrderDetailsError } = paypalApi.getOrderDetails(paypalPaymentInstrument);

                paypalUtils.handleError(OrderDetailsError, paypalUtils.errorHandle, [req, res, OrderDetailsError]);
                addressHelper.updateOrderBillingAddress(currentBasket, payer);
                session.privacy.paypalPayerEmail = payer.email_address;
            }

            Transaction.wrap(function() {
                HookMgr.callHook('dw.order.calculate', 'calculate', currentBasket);
            });

            const usingMultiShipping = false; // Current integration support only single shpping

            req.session.privacyCache.set('usingMultiShipping', usingMultiShipping);

            const viewData = res.getViewData();

            paypalHelper.updatePayPalEmail({
                basketModel: viewData.order,
                paypalPI: paymentInstrumentHelper.getPaypalPaymentInstrument(currentBasket)
            });

            viewData.order.paymentMethodId = paypalPaymentInstrument.custom.paymentId;

            paypalHelper.basketModelHack(viewData.order, currencyCode, paypalPaymentInstrument.custom);

            res.json(viewData);
        });

        next();
    });

server.append('PlaceOrder', function(req, res, next) {
    delete session.privacy.paypalOrderID;

    next();
});

module.exports = server.exports();
