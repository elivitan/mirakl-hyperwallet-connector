'use strict';

const Transaction = require('dw/system/Transaction');
const Money = require('dw/value/Money');
const Resource = require('dw/web/Resource');
const UUIDUtils = require('dw/util/UUIDUtils');

const paypalRestService = require('*/cartridge/scripts/service/paypalRestService');
const paypalTokenService = require('*/cartridge/scripts/service/paypalTokenService');

const paypalPreferences = require('*/cartridge/config/paypalPreferences');

const {
    createErrorLog,
    createErrorMsg
} = require('*/cartridge/scripts/paypal/paypalUtils');

const paypalConstants = require('*/cartridge/config/paypalConstants');
const PATH_CHECKOUT_ORDERS = 'v2/checkout/orders/';
const PATH_BILLING_AGREEMENT = 'v1/billing-agreements/agreements/';
const messageOrderIdNotFound = Resource.msg('paypal.error.api_order_id_notfound', 'paypalerrors', null);

// A paypalTokenService instance
const service = paypalTokenService();

/**
 * Creates a billing address object for the Order Create Api call.
 * @param {Object} billingAddress - a billing address object.
 * @returns {Object} properly formatted billing address.
 */
function createBillingAddressObject(billingAddress) {
    return {
        address_line_1: billingAddress.address1,
        address_line_2: billingAddress.address2 || '',
        admin_area_2: billingAddress.city,
        admin_area_1: billingAddress.stateCode,
        postal_code: decodeURIComponent(billingAddress.postalCode),
        country_code: billingAddress.countryCode.value
    };
}

/**
 * Returns a payer object for the Order Create Api call
 * @param {Object} billingAddress A billing address object
 * @param {dw.order.LineItemCtnr} lineItemCtnr - lineItemCntr basket/order
 * @returns {Object} A payer object
 */
function createPayerObject(billingAddress, lineItemCtnr) {
    const regExpEmail = new RegExp(paypalConstants.REGEXP_EMAIL);

    return {
        name: {
            given_name: billingAddress.firstName,
            surname: billingAddress.lastName
        },
        email_address: regExpEmail.test(lineItemCtnr.customerEmail) ? lineItemCtnr.customerEmail : '',
        phone: {
            phone_number: {
                national_number: billingAddress.phone
            }
        },
        address: createBillingAddressObject(billingAddress)
    };
}

/**
 * Function to get information about an order
 *
 * @param {Object} paymentInstrument - paypalPaymentInstrument
 * @returns {Object} Call handling result
 */
function getOrderDetails(paymentInstrument) {
    try {
        if (!paymentInstrument.custom.paypalOrderID) {
            createErrorLog(messageOrderIdNotFound);
            throw new Error();
        }

        var resp = paypalRestService.call({
            path: PATH_CHECKOUT_ORDERS + paymentInstrument.custom.paypalOrderID,
            method: 'GET',
            body: {},
            payPalRequestId: UUIDUtils.createUUID()
        });

        if (resp) {
            return {
                payer: resp.payer,
                purchase_units: resp.purchase_units
            };
        }

        createErrorLog(Resource.msgf('paypal.error.log.no.payer.info.found', 'paypalerrors', null, paymentInstrument.custom.paypalOrderID));
        throw new Error();
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Function to update information about an order
 *
 * @param {Object} paymentInstrument - paypalPaymentInstrument
 * @param {Object} purchaseUnit - purchase unit
 * @returns {Object} Call handling result
 */
function updateOrderDetails(paymentInstrument, purchaseUnit) {
    try {
        if (!paymentInstrument.custom.paypalOrderID) {
            createErrorLog(messageOrderIdNotFound);
            throw new Error();
        }

        paypalRestService.call({
            path: PATH_CHECKOUT_ORDERS + paymentInstrument.custom.paypalOrderID,
            method: 'PATCH',
            body: [
                {
                    op: 'replace',
                    path: '/purchase_units/@reference_id==\'default\'',
                    value: purchaseUnit
                }
            ],
            payPalRequestId: UUIDUtils.createUUID()
        });

        if (paymentInstrument.paymentTransaction.amount.value !== purchaseUnit.amount.value) {
            Transaction.wrap(function() {
                paymentInstrument.paymentTransaction.setAmount(new Money(purchaseUnit.amount.value, purchaseUnit.amount.currency_code));
            });
        }

        return { isOkUpdate: true };
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Function to create transaction
 * If BA exists it is used as payment source in body
 *
 * @param {Object} paymentInstrument - paypalPaymentInstrument
 * @param {Object} bodyObj - payment source with BA id if BA exists
 * @returns {Object} Call handling result
 */
function createTransaction(paymentInstrument, bodyObj) {
    try {
        if (!paymentInstrument.custom.paypalOrderID) {
            createErrorLog(messageOrderIdNotFound);
            throw new Error();
        }

        var actionType = paypalPreferences.isCapture ? 'capture' : 'authorize';
        var response = paypalRestService.call({
            path: [PATH_CHECKOUT_ORDERS, paymentInstrument.custom.paypalOrderID, '/', actionType].join(''),
            body: bodyObj || {},
            payPalRequestId: UUIDUtils.createUUID()
        });

        return {
            response: response
        };
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Create a billing agreement token
 * Pass the agreement details including the description, payer, and billing plan in the JSON request body.
 *
 * @param {Object} restRequestData data
 * @returns {Object} Call returns the HTTP 201 Created status code and a JSON response that includes an approval URL:
 */
function getBillingAgreementToken(restRequestData) {
    try {
        var resp = paypalRestService.call(restRequestData);

        if (resp) {
            return { billingAgreementToken: resp.token_id };
        }

        createErrorLog(Resource.msg('paypal.error.log.no.billing.agreement.tokens.found', 'paypalerrors', null));
        throw new Error();
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Makes post call using facilitator Access Token and transfers billingToken
 *  save's billingAgreementID & billingAgreementPayerEmail to input field
 *  and triggers checkout place order stage
 *
 * @param {string} billingToken - billing agreement token
 * @returns {Object} JSON response that includes the billing agreement ID and information about the payer
 */
function createBillingAgreement(billingToken) {
    try {
        if (!billingToken) {
            createErrorLog(Resource.msg('paypal.error.log.no.billing.token.provided', 'paypalerrors', null));
            throw new Error();
        }

        var resp = paypalRestService.call({
            path: PATH_BILLING_AGREEMENT,
            method: 'POST',
            body: {
                token_id: billingToken
            },
            payPalRequestId: UUIDUtils.createUUID()
        });

        if (resp) {
            return resp;
        }

        createErrorLog(Resource.msg('paypal.error.log.no.billing.agreement.id.found', 'paypalerrors', null));
        throw new Error();
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Saves Order by PayPal Order ID.
 *
 * @param {string} orderId paypal order Id
 * @returns {Object} Call handling result
 */
function saveOrder(orderId) {
    try {
        if (!orderId) {
            throw new Error(Resource.msg('paypal.account.order.id.notprovided', 'locale', null));
        }

        const resp = paypalRestService.call({
            path: ['v2/checkout/orders/', orderId, '/save'].join(''),
            payPalRequestId: UUIDUtils.createUUID()
        });

        if (!resp) {
            throw new Error(Resource.msg('paypal.account.order.notfound', 'locale', null));
        }

        return resp;
    } catch (err) {
        createErrorLog(err.message);

        return {
            err: createErrorMsg(err.message)
        };
    }
}

/**
 * Function to create order if BA exists
 * If BA exists it is used as payment source in body
 *
 * @param {Object} purchaseUnit - purchaseUnit
 * @param {dw.order.LineItemCtnr} lineItemCtnr - lineItemCntr basket/order
 * @param {Object} paymentSourceData The payment source data
 * @returns {Object} Call handling result
 */
function createOrder(purchaseUnit, lineItemCtnr, paymentSourceData) {
    try {
        if (!purchaseUnit) {
            createErrorLog(Resource.msg('paypal.error.log.no.purchase.unit.found', 'paypalerrors', null));
            throw new Error();
        }

        const orderData = {
            path: 'v2/checkout/orders',
            body: {
                intent: paypalPreferences.isCapture ? 'CAPTURE' : 'AUTHORIZE',
                purchase_units: [purchaseUnit],
                processing_instruction: paypalPreferences.saveOrderFlow ? paypalConstants.ORDER_SAVED_EXPLICITLY : paypalConstants.NO_INSTRUCTION,
                application_context: {
                    shipping_preference: purchaseUnit.shipping_preference
                }
            },
            partnerAttributionId: paypalPreferences.partnerAttributionId,
            payPalRequestId: UUIDUtils.createUUID()
        };

        // Adds a payer object to the request. Basically  is used for LPM payment method
        if (lineItemCtnr && lineItemCtnr.billingAddress && !paymentSourceData) {
            const regExpPhone = new RegExp(paypalConstants.REGEXP_PHONE);
            const billingAddress = lineItemCtnr.billingAddress;

            if (regExpPhone.test(billingAddress.phone) && billingAddress.countryCode) {
                orderData.payer = createPayerObject(billingAddress, lineItemCtnr);
            }
        }

        if (paymentSourceData && paymentSourceData.card) {
            const creditCardHelper = require('*/cartridge/scripts/paypal/helpers/creditCardHelper');

            paymentSourceData.card.attributes.customer = creditCardHelper.getCustomerData(lineItemCtnr);
            orderData.body.payment_source = paymentSourceData;
        }

        const resp = paypalRestService.call(orderData);

        return {
            resp: resp,
            requestBody: orderData.body
        };
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Function to get BA details
 * If BA exists it is used as payment source in body
 *
 * @param {Object} paymentInstrument - paymentInstrument
 * @returns {Object} Call handling result
 */
function getBADetails(paymentInstrument) {
    try {
        if (!paymentInstrument.custom.PP_API_ActiveBillingAgreement) {
            createErrorLog(Resource.msg('paypal.error.log.no.active.billing.agreement.found', 'paypalerrors', null));
            throw new Error();
        }

        var baID;

        try {
            baID = JSON.parse(paymentInstrument.custom.PP_API_ActiveBillingAgreement).baID;
        } catch (error) {
            createErrorLog(error);

            return new Error(error);
        }

        var resp = paypalRestService.call({
            path: PATH_BILLING_AGREEMENT + baID,
            method: 'GET'
        });

        if (resp.state !== 'ACTIVE') {
            return { active: false };
        }

        return {
            id: resp.id,
            billing_info: resp.payer.payer_info,
            shipping_address: resp.shipping_address,
            active: true
        };
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Function to get BA details by ID
 * @param {string} baID - Billing Agreements ID
 * @returns {Object} Call handling result
 */
function getBADetailsById(baID) {
    try {
        return paypalRestService.call({
            path: PATH_BILLING_AGREEMENT + baID,
            method: 'GET'
        });
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Function to cancel BA
 * If BA exists it is used as payment source in body
 *
 * @param {Object} baID - billing agreement ID to cancel
 * @returns {Object} Call handling result
 */
function cancelBillingAgreement(baID) {
    try {
        if (!baID) {
            createErrorLog(Resource.msg('paypal.error.log.no.billing.agreement.id.found', 'paypalerrors', null));
            throw new Error();
        }

        return paypalRestService.call({
            path: [PATH_BILLING_AGREEMENT, baID, '/cancel'].join(''),
            method: 'POST',
            paypalRequestId: UUIDUtils.createUUID()
        });
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Generates and returns an access token
 * @returns {Object} An object represented an access token
 */
function generateAccessToken() {
    try {
        return service.setThrowOnError().call({
            method: paypalConstants.METHOD_POST,
            requestType: paypalConstants.HOSTED_FIELD_ACCESS_TOKEN,
            path: 'oauth2/token',
            paypalRequestId: UUIDUtils.createUUID()
        });
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Returns a client token for hosted fields rendering
 * @returns {string|Object} A client token
 */
function generateClientToken() {
    try {
        service.addHeader('Accept-Language', request.locale);

        const accessTokenResponse = generateAccessToken(); // time life 32949

        const response = service.setThrowOnError().call({
            path: 'identity/generate-token',
            method: paypalConstants.METHOD_POST,
            requestType: paypalConstants.USER_INFO,
            accessToken: accessTokenResponse.object.access_token,
            paypalRequestId: UUIDUtils.createUUID()
        });

        return response.object.client_token; // time life 3600;
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Gets access token according a paypal user autherization code
 * @param {string} authCode Autherization code of paypal user
 * @returns {string} access token
 */
function exchangeAuthCodeForAccessToken(authCode) {
    var result = service.setThrowOnError().call({
        code: authCode,
        requestType: paypalConstants.ACCESS_TOKEN,
        path: 'oauth2/token',
        method: paypalConstants.METHOD_POST,
        paypalRequestId: UUIDUtils.createUUID()
    });

    if (!result.ok) {
        var errorObject = JSON.parse(result.errorMessage);
        var error = errorObject.error_description;

        createErrorLog(error);
        throw error;
    }

    return result.object.access_token;
}

/**
 * Gets paypal customer info according access token
 * @param {string} accessToken Access Token
 * @returns {Object} Object with the customer info
 */
function getPaypalCustomerInfo(accessToken) {
    const response = service.setThrowOnError().call({
        accessToken: accessToken,
        requestType: paypalConstants.USER_INFO,
        path: 'identity/oauth2/userinfo?schema=paypalv1.1',
        method: paypalConstants.METHOD_GET
    });

    const payPalCustomerInfo = response.isOk() ? response.object : null;

    if (!payPalCustomerInfo || !payPalCustomerInfo.emails || !payPalCustomerInfo.name || !payPalCustomerInfo.address) {
        return null;
    }

    const [firstName, middleName, lastName] = payPalCustomerInfo.name.trim().split(/\s+/);

    payPalCustomerInfo.firstName = firstName;
    payPalCustomerInfo.lastName = lastName || middleName;

    const primaryEmail = payPalCustomerInfo.emails.find(function(email) {
        return email.primary;
    });

    payPalCustomerInfo.email = primaryEmail.value;
    payPalCustomerInfo.emailConfirmed = primaryEmail.confirmed;

    delete payPalCustomerInfo.emails;

    payPalCustomerInfo.addressObjectFromPayPal = {
        id: [paypalConstants.LOGIN_PAYPAL, payPalCustomerInfo.address.postal_code].join(' - '),
        address1: payPalCustomerInfo.address.street_address,
        city: payPalCustomerInfo.address.locality,
        countryCode: payPalCustomerInfo.address.country,
        firstName: payPalCustomerInfo.firstName,
        lastName: payPalCustomerInfo.lastName,
        postalCode: payPalCustomerInfo.address.postal_code,
        stateCode: payPalCustomerInfo.address.region,
        phone: Resource.msg('paypal.account.address.phonenumber.notprovided', 'locale', null)
    };

    return payPalCustomerInfo;
}

/**
 * The function creates a setup token for a credit card form using PayPal REST API.
 * @param {Object} creditCardForm - The object that contains the credit card information entered by the customer.
 * @returns {Object} - The result of the service call or an object containing the error message.
 */
function createSetupToken(creditCardForm) {
    const profile = customer.profile;
    const body = {
        payment_source: {
            card: creditCardForm
        }
    };

    if (profile.custom.payPalCustomerId) {
        body.customer = {
            id: profile.custom.payPalCustomerId
        };
    }

    try {
        return paypalRestService.call({
            path: 'v3/vault/setup-tokens',
            method: 'POST',
            body: body,
            paypalRequestId: UUIDUtils.createUUID()
        });
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * The function creates a payment token using a provided token and PayPal customer ID.
 * The retrieved token is used for vaulting and orders creation.
 * @param {string} token - The unique identifier for the specific payment method or payment source.
 * @param {string} payPalCustomerId - The unique identifier for the PayPal customer.
 * It is used to associate the payment token with the customer's account.
 * @returns {Object} - The result of the service call or an object containing the error message.
 */
function createPaymentToken(token, payPalCustomerId) {
    const body = {
        payment_source: {
            token: {
                id: token,
                type: 'SETUP_TOKEN'
            }
        },
        customer: {
            id: payPalCustomerId
        }
    };

    try {
        return paypalRestService.call({
            path: 'v3/vault/payment-tokens',
            method: 'POST',
            body: body,
            paypalRequestId: UUIDUtils.createUUID()
        });
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * The function makes a DELETE call to delete the payment token from the PP side.
 * @param {string} token - The unique identifier for the specific payment method or payment source.
 * @returns {Object} - The result of the service call or an object containing the error message.
 */
function deletePaymentToken(token) {
    try {
        return paypalRestService.call({
            path: ['v3/vault/payment-tokens/', token].join(''),
            method: 'DELETE'
        });
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

module.exports = {
    createTransaction: createTransaction,
    updateOrderDetails: updateOrderDetails,
    getOrderDetails: getOrderDetails,
    getBillingAgreementToken: getBillingAgreementToken,
    createBillingAgreement: createBillingAgreement,
    createOrder: createOrder,
    saveOrder: saveOrder,
    getBADetails: getBADetails,
    getBADetailsById: getBADetailsById,
    cancelBillingAgreement: cancelBillingAgreement,
    exchangeAuthCodeForAccessToken: exchangeAuthCodeForAccessToken,
    getPaypalCustomerInfo: getPaypalCustomerInfo,
    generateClientToken: generateClientToken,
    createSetupToken: createSetupToken,
    createPaymentToken: createPaymentToken,
    deletePaymentToken: deletePaymentToken
};
