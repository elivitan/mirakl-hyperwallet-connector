'use strict';

/**
 * Get PayPal Billing Agreement
 *
 * @param {Object} billingForm - current customer billing Form
 * @returns {Object} billingAgreement - selected Billing Agreement
 */
function createBaFromForm(billingForm) {
    return {
        baID: billingForm.paypal.billingAgreementID.htmlValue,
        default: billingForm.paypal.makeDefaultPaypalAccount.checked,
        email: billingForm.paypal.billingAgreementPayerEmail.htmlValue,
        saveToProfile: billingForm.paypal.savePaypalAccount.checked
    };
}

/**
 * Compare form billing agreement email with saved billing agreement email under paypal Payment Instrument
 *
 * @param {string} activeBA - current saved paypal Payment Instrument ba
 * @param {Object} formBA - current customer  ba billingForm
 * @returns {boolean} true or false
 */
function isSameBillingAgreement(activeBA, formBA) {
    return activeBA.email === formBA.email
        && activeBA.default === formBA.default
        && activeBA.saveToProfile === formBA.saveToProfile;
}

/**
 * Get PayPal Billing Agreement from Payment Instrument
 * @param {dw.order.PaymentInstrument} paymentInstrument - payment instrument
 * @returns {Object} - billing agreeament data
 */
function getBaFromPaymentInstument(paymentInstrument) {
    if (paymentInstrument.custom.PP_API_ActiveBillingAgreement) {
        return JSON.parse(paymentInstrument.custom.PP_API_ActiveBillingAgreement);
    }

    return null;
}

/**
 * @param {Object} billingForm - a billing form data
 * @returns {boolean} - returns true if the value of billing agreement ID exists
 */
function isBillingAgreementID(billingForm) {
    return billingForm.paypal.billingAgreementID && !empty(billingForm.paypal.billingAgreementID.htmlValue);
}

/**
 * Create a request body object for createOrder call with BA
 * @param  {dw.order.OrderPaymentInstrument} paymentInstrument current active paypal payment instrument
 * @returns {Object} body for request
 */
function createBAReqBody(paymentInstrument) {
    const activeBillingAgreement = JSON.parse(paymentInstrument.custom.PP_API_ActiveBillingAgreement);
    const billingAgreementId = activeBillingAgreement.baID;

    return {
        payment_source: {
            token: {
                id: billingAgreementId,
                type: 'BILLING_AGREEMENT'
            }
        }
    };
}

module.exports = {
    createBAReqBody: createBAReqBody,
    createBaFromForm: createBaFromForm,
    isBillingAgreementID: isBillingAgreementID,
    isSameBillingAgreement: isSameBillingAgreement,
    getBaFromPaymentInstument: getBaFromPaymentInstument
};
