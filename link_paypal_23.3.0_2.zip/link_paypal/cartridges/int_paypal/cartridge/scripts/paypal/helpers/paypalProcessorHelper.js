'use strict';

const paypalProcessorHelper = {};

/**
* Handle PayPal payment instrument
* @param {dw.order.LineItemCtnr} basket - current basket
* @param {Object} billingForm - billing from
* @returns {dw.order.PaymentInstrument} - PayPal payment instrument
*/
paypalProcessorHelper.handlePaymentInstrument = function(basket, billingForm) {
    const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');

    const paymentInstrument = paymentInstrumentHelper.getPaypalPaymentInstrument(basket);

    if (!paymentInstrument) {
        return paymentInstrumentHelper.createPaymentInstrument(basket, paypalProcessorHelper.getPaymentMethodId(billingForm));
    }

    return paymentInstrument;
};

/**
 * Handle Billing Agreement Shipping Address
 * @param {Object} shippingAddress -
 * @param {Object} billingAgreementDetails -
 * @returns {Object} -
 */
paypalProcessorHelper.handleBaShippingAddress = function(shippingAddress, billingAgreementDetails) {
    // Empty shipping_address in case when only gift certificate in the basket
    if (!billingAgreementDetails.shipping_address) {
        billingAgreementDetails.shipping_address = billingAgreementDetails.billing_info.billing_address;
        billingAgreementDetails.shipping_address.recipient_name = [billingAgreementDetails.billing_info.first_name,
            billingAgreementDetails.billing_info.last_name].join(' ');
    }

    billingAgreementDetails.shipping_address.phone = billingAgreementDetails.billing_info.phone;

    return billingAgreementDetails.shipping_address;
};

/**
 * Remove current PayPal email from Payment Instrument
 * @param {dw.order.PaymentInstrument} paymentInstrument - the payment instrument
 */
paypalProcessorHelper.clearCurrentPaypalEmail = function(paymentInstrument) {
    const Transaction = require('dw/system/Transaction');

    Transaction.wrap(function() {
        paymentInstrument.custom.currentPaypalEmail = null;
    });
};

/**
 * Returns the appropriate payment method id (PayPal or PAYPAL_CREDIT_CARD)
 * @param {Object} billingForm Billing form
 * @returns {string} Payment method id
 */
paypalProcessorHelper.getPaymentMethodId = function(billingForm) {
    const payPalConstants = require('*/cartridge/config/paypalConstants');

    let paymentMethodId;

    if (billingForm.paypal.usedPaymentMethod.value === payPalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD) {
        paymentMethodId = payPalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD;
    } else {
        paymentMethodId = billingForm.paymentMethod.value;
    }

    return paymentMethodId;
};

/**
 * Saves general transaction data
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Current payment instrument
 * @param {Object} response A transaction create response object
 * @param {Object} request A transaction create request object
 */
paypalProcessorHelper.saveGeneralTransactionData = function(paymentInstrument, response, request) {
    const Transaction = require('dw/system/Transaction');
    const payPalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');

    const transactionId = payPalHelper.getTransactionId(response);
    const paymentTransaction = paymentInstrument.paymentTransaction;

    Transaction.wrap(function() {
        paymentInstrument.getPaymentTransaction().setTransactionID(transactionId);
        paymentInstrument.custom.paypalRequest = JSON.stringify(request);
        paymentInstrument.custom.paypalResponse = JSON.stringify(response);
        paymentInstrument.custom.paypalPaymentStatus = payPalHelper.getTransactionStatus(response);
        paymentTransaction.custom.paypalTransactionHistory = payPalHelper.prepareTransactionHistory(paymentTransaction, response);
    });
};

module.exports = paypalProcessorHelper;
