'use strict';

const customerHelper = {};

/**
 * Return specific payment method from customers payment methods list
 * @param {string} paymentMethodName Name of the payment method
 * @return {Array<Object>} Payment method from customers payment methods list
 */
customerHelper.getCustomerPaymentInstruments = function(paymentMethodName) {
    if (customer.authenticated) {
        return customer.profile.wallet.getPaymentInstruments(paymentMethodName).toArray();
    }

    return [];
};

/**
 * Returns paypal customer id from profile or from API response.
 * @param {Object} payload - The response from REST API.
 * @return {string} - The paypal customer id.
 */
customerHelper.getPaypalCustomerId = function(payload) {
    return customer.profile.custom.payPalCustomerId ? customer.profile.custom.payPalCustomerId : payload.customer.id;
};

module.exports = customerHelper;
