'use strict';

const Transaction = require('dw/system/Transaction');
const Resource = require('dw/web/Resource');

const paypalConstants = require('*/cartridge/config/paypalConstants');
const paypalPreferences = require('*/cartridge/config/paypalPreferences');
const paypalApi = require('*/cartridge/scripts/paypal/paypalApi');

/**
 * Returns all applicable PAYPAL_CREDIT_CARD Payment Instruments for current customer
 * @returns {Array} Array of applicable payment instruments of current site
 */
function getApplicablePayPalCcPi() {
    if (!customer.authenticated) {
        return [];
    }

    const customerWalletPaymentInstruments = customer.profile.wallet.paymentInstruments;

    return Array.filter(customerWalletPaymentInstruments, function(paymentInstrument) {
        return paymentInstrument.paymentMethod === paypalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD;
    });
}

/**
 * Returns a configurataion object for hosted fields generation
 * @param {Object} viewData A view data object
 * @returns {Object} A hosted fields config object
 */
function getHostedFieldsConfigs(viewData) {
    const paymentHelper = require('*/cartridge/scripts/paypal/helpers/paymentHelper');

    const applicableCc = getApplicablePayPalCcPi();

    const expirationCreditCards = applicableCc.reduce(function(accum, creditCard) {
        const data = paymentHelper.getExpirationDataForCC(creditCard);

        if (data) {
            accum[creditCard.UUID] = data;
        }

        return accum;
    }, {});

    return {
        fieldsConfig: {
            numberHtmlName: viewData.forms.billingForm.creditCardFields.cardNumber.htmlName,
            styles: paypalPreferences.hostedFieldsStyles
        },
        fieldsPlaceholders: {
            number: Resource.msg('paypal.creditcard.field.cardNumber.placeholder', 'locale', null),
            cvv: Resource.msg('paypal.creditcard.field.cvv.placeholder', 'locale', null),
            expirationDate: Resource.msg('paypal.creditcard.field.expirationdate.placeholder', 'locale', null)
        },
        fieldsGeneralNotificationError: Resource.msg('paypal.error.creditcard.field.general.notification', 'paypalerrors', null),
        clientToken: paypalApi.generateClientToken(),
        creditCardPmId: paypalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD,
        threeDSecureValue: paypalPreferences.threeDSecureFlow,
        isShowCheckbox: customer.authenticated && paypalPreferences.isCreditCardVaultEnabled,
        customerSavedCreditCards: applicableCc,
        expirationCreditCards: expirationCreditCards,
        isNewCardOptionSelected: !applicableCc.some(function(card) {
            return card.custom.payPalDefaultCard;
        }),
        errorMessages: {
            threeDSVerificationFailed: Resource.msg('paypal.creditcard.3ds.verification.failed', 'paypalerrors', null)
        }
    };
}

/**
 * Checks if hosted fields is enabled (temporary disabled)
 * @returns {boolean} True/false
 */
function isHostedFieldsEnabled() {
    return false;
}

/**
 * @param {string} brandCode credit card brand code
 * @returns {string} properly formatted variant of credit card brand code
 */
function formatComplexCCBrandCode(brandCode) {
    const creditCardComplexBrandCode = paypalConstants.CREDIT_CARD_COMPLEX_BRAND_CODE.find(function(formattedBrandCode) {
        return formattedBrandCode.toLowerCase().includes(brandCode)
            || brandCode.replace(/_/g, ' ').includes(formattedBrandCode.toLowerCase())
            || brandCode.replace(/_/g, '').includes(formattedBrandCode.toLowerCase());
    });

    return creditCardComplexBrandCode || brandCode.replace(brandCode.charAt(0), brandCode.charAt(0).toUpperCase());
}

/**
 * Checks whether is saved credict card used
 * @returns {boolean} True/False
 */
function isSavedCardFlow() {
    const httpParameterMap = request.httpParameterMap;

    return customer.registered && !httpParameterMap.paypalCreditCardList.empty && httpParameterMap.paypalCreditCardList.stringValue !== 'newcard';
}

/**
 * Saves the Credit card to the customer wallet.
 * @param {Object} responseData - The API response object.
 * @param {string} billingAddressAsString - Stringified billing address to save.
 * @param {string} [cardHolderName] - The name of the card holder.
 */
function saveCreditCardToCustomerWallet(responseData, billingAddressAsString, cardHolderName) {
    const cardData = responseData.payment_source.card;
    const attributes = cardData.attributes;
    const isMyAccountFlow = cardData && !attributes && !cardHolderName;

    if (attributes && attributes.vault.status === paypalConstants.CREDIT_CARD_SAVE_STATUS_VAULTED || isMyAccountFlow) {
        const profile = customer.profile;
        const customerWallet = profile.wallet;

        const expiry = cardData.expiry.split('-');
        const isPaymentInstrumentsExist = !empty(customerWallet.getPaymentInstruments(paypalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD));

        let creditCardToken;
        let creditCardHolderName;
        let customerId;
        let makeCardDefault = true;

        if (isPaymentInstrumentsExist) {
            makeCardDefault = false;
        }

        if (isMyAccountFlow) {
            creditCardToken = responseData.id;
            creditCardHolderName = cardData.name;
            customerId = responseData.customer.id;
        } else {
            creditCardToken = attributes.vault.id;
            creditCardHolderName = cardHolderName;
            customerId = attributes.vault.customer.id;
        }

        Transaction.wrap(function() {
            if (!profile.custom.payPalCustomerId) {
                profile.custom.payPalCustomerId = customerId;
            }

            const customerPaymentInstrument = customerWallet.createPaymentInstrument(paypalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD);

            customerPaymentInstrument.setCreditCardHolder(creditCardHolderName);
            customerPaymentInstrument.setCreditCardNumber(Date.now().toString().substr(
                paypalConstants.CC_NUMBER_LIMIT_NUMBER_START, paypalConstants.CC_NUMBER_LIMIT_NUMBER_END) + cardData.last_digits
            );
            customerPaymentInstrument.setCreditCardExpirationMonth(parseInt(expiry[1], 10));
            customerPaymentInstrument.setCreditCardExpirationYear(parseInt(expiry[0], 10));
            customerPaymentInstrument.setCreditCardType(formatComplexCCBrandCode(cardData.brand.toLowerCase()));
            customerPaymentInstrument.creditCardToken = creditCardToken;
            customerPaymentInstrument.custom.payPalDefaultCard = makeCardDefault;
            customerPaymentInstrument.custom.paypalCreditCardBillingAddress = billingAddressAsString;
        });
    }
}

/**
 * The function updates the billing address of a saved credit card payment instrument
 * if it has changed.
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument - an order payment instrument.
 * @returns {void}
 */
function updateSavedCreditCardBA(paymentInstrument) {
    const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');

    const piToUpdate = paymentInstrumentHelper.getCustomerPiByCreditCardToken(paymentInstrument.creditCardToken);

    if (piToUpdate.custom.paypalCreditCardBillingAddress !== paymentInstrument.custom.paypalCreditCardBillingAddress) {
        Transaction.wrap(function() {
            piToUpdate.custom.paypalCreditCardBillingAddress = paymentInstrument.custom.paypalCreditCardBillingAddress;
        });
    }
}

/**
 * Completes a saved Credit card order (Capture or Authorization)
 * @param {Object} purchaseUnit A purchase unit object
 * @param {dw.order.LineItemCtnr} order - Order object
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument - current payment instrument
 * @returns {Object} An object
 */
function completeSavedCcOrder(purchaseUnit, order, paymentInstrument) {
    const paypalProcessorHelper = require('*/cartridge/scripts/paypal/helpers/paypalProcessorHelper');
    const paypalUtils = require('*/cartridge/scripts/paypal/paypalUtils');

    const creditCardOrder = paypalApi.createOrder(purchaseUnit, order, {
        card: {
            vault_id: paymentInstrument.creditCardToken,
            attributes: {}
        }
    });

    let result = {
        authorized: true
    };

    if (creditCardOrder.err) {
        paypalUtils.createErrorLog(creditCardOrder.err);

        result = {
            error: true,
            authorized: false,
            fieldErrors: [],
            serverErrors: [creditCardOrder.err],
            message: creditCardOrder.err
        };
    } else {
        const response = creditCardOrder.resp;

        paypalProcessorHelper.saveGeneralTransactionData(paymentInstrument, response, creditCardOrder.requestBody);

        Transaction.wrap(function() {
            paymentInstrument.custom.paypalOrderID = response.id;
            order.custom.PP_API_TransactionID = paymentInstrument.paymentTransaction.transactionID;
        });
    }

    return result;
}

/**
 * Returns customer object to be passed into Credit card payment source
 * @param {dw.order.LineItemCtnr} lineItemCtnr - lineItemCntr basket/order
 * @return {Object} An object
 */
function getCustomerData(lineItemCtnr) {
    const profile = customer.profile;

    const data = {
        email_address: lineItemCtnr.customerEmail,
        phone: {
            phone_number: {
                national_number: lineItemCtnr.billingAddress.phone
            }
        }
    };

    if (profile && profile.custom.payPalCustomerId) {
        data.id = profile.custom.payPalCustomerId;
    }

    return data;
}

/**
 * The function returns the verification method based on the value of the custom preference.
 * @returns {string|null} - verification method or null.
 */
function getVerificationMethod() {
    if (paypalPreferences.verifyCardOnAccountPage) {
        return paypalConstants.SCA_WHEN_REQUIRED;
    }

    return null;
}

/**
 * The function retrieves credit card information from a form and returns an object containing the card details.
 * @param {Object} form - The object that represents the form data submitted by the user.
 * @returns {Object} - an object which contains all the properties required for API request.
 */
function getCreditCardFields(form) {
    const paypalUrls = require('*/cartridge/config/paypalUrls');
    const addressHelper = require('*/cartridge/scripts/paypal/helpers/addressHelper');

    const card = {
        name: form.dwfrm_paypalCreditCard_cardName,
        number: form.dwfrm_paypalCreditCard_cardNumber,
        expiry: form.dwfrm_paypalCreditCard_cardExpirationDate,
        security_code: form.dwfrm_paypalCreditCard_cardSecurityCode,
        billing_address: addressHelper.getBillingAddressFromForm(form),
        experience_context: {
            return_url: paypalUrls.myAccountUrl,
            cancel_url: paypalUrls.myAccountUrl
        }
    };

    const verificationMethod = getVerificationMethod();

    if (verificationMethod) {
        card.verification_method = verificationMethod;
    }

    return card;
}

/**
 * Returns validation object of hosted fields on Checkout page
 * @param {string} fieldName Name of the field
 * @param {string|Object} fieldValue string if fields name is cardholderName and Object with validation from PP if field returns from hosted fields
 * @return {Object} validation of hosted fields
 */
function validateCcFields(fieldName, fieldValue) {
    const errorMessages = {
        empty: Resource.msg('paypal.error.creditcard.field.empty', 'paypalerrors', null),
        invalid: Resource.msg('paypal.error.creditcard.field.invalid', 'paypalerrors', null)
    };

    const errorObj = {
        isError: true,
        errorMessage: errorMessages.empty
    };

    if (fieldName === 'cardholderName') {
        errorObj.fieldName = 'holder_name';

        if (fieldValue === '') {
            return errorObj;
        }

        const regExpName = new RegExp(paypalConstants.REGEXP_NAME);

        if (!regExpName.test(fieldValue)) {
            errorObj.errorMessage = errorMessages.invalid;

            return errorObj;
        }
    } else {
        errorObj.fieldName = fieldName === 'cvv' ? 'security_code' : fieldName;

        if (fieldValue.isEmpty) {
            return errorObj;
        }

        if (!fieldValue.isValid) {
            errorObj.errorMessage = errorMessages.invalid;

            return errorObj;
        }
    }

    return {
        isError: false
    };
}

/**
 * Prepare form fields for submitting to PP server
 * @param {Object} formFields object with form fields
 * @returns {Object} with prepared form fields
 */
function prepareCardFieldsAccountPage(formFields) {
    const preparedForm = JSON.parse(JSON.stringify(formFields));

    // prepare card number field
    while (preparedForm.number.includes(' ')) {
        preparedForm.number = preparedForm.number.replace(' ', '');
    }

    // prepare expiration date field
    let [month, year] = preparedForm.expiry.split(' / ');

    if (year.length === 2) {
        const currentYear = new Date().getFullYear().toString();

        year = currentYear.slice(0, 2) + year;
    }

    preparedForm.expiry = [year, month].join('-');

    return preparedForm;
}

/**
 * Returns validation object of hosted fields on My Account page
 * @param {string} fieldName field name
 * @param {string} fieldValue field value
 * @returns {Object} with the validation results
 */
function validateCardAccountPage(fieldName, fieldValue) {
    const errorObj = {
        isError: true,
        errorMessage: Resource.msg('paypal.error.creditcard.field.invalid', 'paypalerrors', null)
    };

    switch (fieldName) {
        case 'name':
            const regExpName = new RegExp(paypalConstants.REGEXP_NAME);

            if (!regExpName.test(fieldValue)) {
                errorObj.fieldName = 'card-holder-name';

                return errorObj;
            }

            break;
        case 'expiry':
            const [year, month] = fieldValue.split('-');
            const cardDate = new Date(`${month}/01/${year}`);
            const currentDate = new Date();

            errorObj.fieldName = 'expiration-date';

            if (parseInt(month) >= 13) {
                return errorObj;
            }

            if (cardDate < currentDate) {
                errorObj.errorMessage = Resource.msg('paypal.creditcard.expired', 'locale', null);

                return errorObj;
            }

            break;
    }

    return {
        isError: false
    };
}

/**
 * The function deletes a specified credit card from a customer's wallet.
 * @param {dw.customer.CustomerPaymentInstrument} paymentInstrumentToDelete - The payment instrument that needs to be deleted from the customer's wallet.
 * @returns {void}
 */
function deleteCreditCardFromWallet(paymentInstrumentToDelete) {
    const wallet = customer.profile.wallet;

    Transaction.wrap(function() {
        wallet.removePaymentInstrument(paymentInstrumentToDelete);
    });
}

/**
 * The function sets a new default credit card for a customer if they have any saved credit cards.
 * @returns {void}
 */
function setDefaultCard() {
    const customerHelper = require('*/cartridge/scripts/paypal/helpers/customerHelper');

    const customerSavedCreditCards = customerHelper.getCustomerPaymentInstruments(paypalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD);

    if (!empty(customerSavedCreditCards)) {
        const newDefaultCreditCard = customerSavedCreditCards.pop();

        Transaction.wrap(function() {
            newDefaultCreditCard.custom.payPalDefaultCard = true;
        });
    }
}

/**
 * The function retrieves the default PayPal credit card payment instrument for a customer wallet.
 * @returns {dw.customer.CustomerPaymentInstrument|undefined} - the default PayPal credit card payment instrument for the customer.
 */
function getDefaultCard() {
    const customerHelper = require('*/cartridge/scripts/paypal/helpers/customerHelper');

    const customerSavedCreditCards = customerHelper.getCustomerPaymentInstruments(paypalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD);

    return customerSavedCreditCards.find(function(card) {
        return card.custom.payPalDefaultCard;
    });
}

module.exports = {
    formatComplexCCBrandCode: formatComplexCCBrandCode,
    isHostedFieldsEnabled: isHostedFieldsEnabled,
    getHostedFieldsConfigs: getHostedFieldsConfigs,
    isSavedCardFlow: isSavedCardFlow,
    saveCreditCardToCustomerWallet: saveCreditCardToCustomerWallet,
    completeSavedCcOrder: completeSavedCcOrder,
    updateSavedCreditCardBA: updateSavedCreditCardBA,
    getCustomerData: getCustomerData,
    getCreditCardFields: getCreditCardFields,
    validateCcFields: validateCcFields,
    deleteCreditCardFromWallet: deleteCreditCardFromWallet,
    setDefaultCard: setDefaultCard,
    getDefaultCard: getDefaultCard,
    prepareCardFieldsAccountPage: prepareCardFieldsAccountPage,
    validateCardAccountPage: validateCardAccountPage
};
