'use strict';

const URLUtils = require('dw/web/URLUtils');
const Resource = require('dw/web/Resource');

const paypalPreferences = require('*/cartridge/config/paypalPreferences');
const paypalConstants = require('*/cartridge/config/paypalConstants');
const accountHelpers = require('*/cartridge/scripts/helpers/accountHelpers');

/**
 * Create config object for the button
 * @param  {Object} req request object
 * @param  {Object} res response object
 * @returns {Object} config object
 */
function getBtnConfig(req, res) {
    const paypalUtils = require('*/cartridge/scripts/paypal/paypalUtils');
    const buttonConfigHelper = require('~/cartridge/scripts/paypal/helpers/buttonConfigHelper');

    const locations = { 1: 'login', 2: 'billing' };
    const currentFlow = locations[req.querystring.oauthLoginTargetEndPoint];

    const cwppButtonParameters = buttonConfigHelper.createCwppButtonConfig(currentFlow);

    // Fixed "Authorization code not found in cache" for session login user
    cwppButtonParameters.prompt = 'login';

    return {
        CWPPButtonEnabled: paypalPreferences.isCWPPEnabled,
        CWPPSdkLink: paypalPreferences.payPalExternalApiSdk,
        CWPPButtonParameters: JSON.stringify(cwppButtonParameters),
        CWPPStaticImageLink: paypalPreferences.CWPPStaticImageLink,
        CWPPButtonUrl: paypalUtils.createCWPPButtonUrl(res.viewData.queryString),
        CWPPStaticImageAlt: Resource.msg('paypal.connect.with.paypal.image.alt', 'locale', null)
    };
}

/**
 * Handle main CwPP flow
 * @param  {Object} req request object
 * @param  {Object} res response object
 * @param  {Object} payPalCustomerInfo object with customer information
 * @returns {string} redirect url for the next step
 */
function handleConnectWithPaypalFlow(req, res, payPalCustomerInfo) {
    const AgentUserMgr = require('dw/customer/AgentUserMgr');
    const Transaction = require('dw/system/Transaction');
    const BasketMgr = require('dw/order/BasketMgr');

    const loginPayPalAddressHelper = require('*/cartridge/scripts/paypal/helpers/loginPayPalAddressHelper');
    const CustomerModel = require('*/cartridge/models/customer');

    const errorMessage = Resource.msg('error.oauth.login.failure', 'login', null);

    if (!payPalCustomerInfo) {
        throw errorMessage;
    }

    if (!payPalCustomerInfo.emailConfirmed) {
        throw Resource.msg('paypal.error.email.unconfirmed', 'paypalerrors', null);
    }

    const customerEmail = payPalCustomerInfo.email;
    let newlyRegisteredUser = false;
    let customerInstance = CustomerModel.get(customerEmail);

    if (!customerInstance) {
        Transaction.wrap(function() {
            customerInstance = CustomerModel.create(customerEmail);
            customerInstance.setEmail(customerEmail);
            customerInstance.setIsExternalProfile(true);
            customerInstance.setFirstName(payPalCustomerInfo.firstName);
            customerInstance.setLastName(payPalCustomerInfo.lastName);
            customerInstance.setPhone(Resource.msg('paypal.account.address.phonenumber.notprovided', 'locale', null));

            customerInstance.sendRegistrationEmail();
            newlyRegisteredUser = true;
        });
    } else if (paypalPreferences.accountLinkingSecurityLayerEnabled
            && !customerInstance.isExternalProfile()
            && !payPalCustomerInfo.isPassedAccountLinkingSecurityLayer) {
        // Account Linking Security Layer flow

        return URLUtils.url('Paypal-RenderAccountLinkingSecurityLayer', 'payPalCustomerInfo', encodeURIComponent(JSON.stringify(payPalCustomerInfo)));
    }

    if (CustomerModel.externalProfileExist(customerEmail)) {
        Transaction.wrap(function() {
            customerInstance.addFlashMessage(Resource.msg('account.legacy', 'notifications', null),
                CustomerModel.FLASH_MESSAGE_INFO);
        });
    }

    if (!customerInstance.isExternalProfile()) {
        customerInstance.sendLinkedAccountConfirmationEmail();

        Transaction.wrap(function() {
            customerInstance.setIsExternalProfile(true);
            customerInstance.addFlashMessage(Resource.msg('account.exists', 'notifications', null),
                CustomerModel.FLASH_MESSAGE_INFO);
        });
    }

    const requestLocale = request.getLocale();

    const guestBasket = BasketMgr.getCurrentBasket();

    if (session.customerAuthenticated) {
        AgentUserMgr.logoutAgentUser();
    }

    if (AgentUserMgr.loginAgentUser(paypalPreferences.PP_CWPP_Agent_Login, paypalPreferences.PP_CWPP_Agent_Password).error) {
        throw errorMessage;
    }

    if (AgentUserMgr.loginOnBehalfOfCustomer(customerInstance.dw).error) {
        throw errorMessage;
    }

    if (!customerInstance.getPreferredLocale()) {
        request.setLocale(requestLocale);
    }

    if (guestBasket) {
        Transaction.wrap(function() {
            customerInstance.restoreBasket(guestBasket);
        });
    }

    const oauthReentryEndpoint = req.querystring.state;
    // req.querystring.state - oAuth reentry endpoint(Account - 1 or Checkout - 2)
    const redirectURL = accountHelpers.getLoginRedirectURL(oauthReentryEndpoint,
        req.session.privacyCache,
        newlyRegisteredUser);

    // Automatic payment method adding flow
    if (paypalPreferences.automaticPmAddingEnabled && customerInstance.isEnabledFeatureAPMA()) {
        return URLUtils.url(paypalConstants.ENDPOINT_PAYPAL_APMA,
            'redirectURL',
            redirectURL,
            'addressObject',
            encodeURIComponent(JSON.stringify(loginPayPalAddressHelper.getAddressObjectFromPayPal(payPalCustomerInfo))));
    }

    return redirectURL;
}

/**
 * Create config object for the Account Linking Security Layer page
 * @param  {Object} payPalCustomerInfo object with customer information
 * @returns {Object} config object
 */
function getAccountLinkingSecurityLayerConfig(payPalCustomerInfo) {
    const actionUrl = URLUtils.url('Paypal-HandleAccountLinkingSecurityLayer',
        'payPalCustomerInfo',
        encodeURIComponent(JSON.stringify(payPalCustomerInfo)));

    return {
        actionUrl: actionUrl,
        paypal: {
            payPalEmail: payPalCustomerInfo.email,
            payPalCustomerInfo: JSON.stringify(payPalCustomerInfo)
        }
    };
}

/**
 * Handle Account Linking Security Layer flow
 * @param  {Object} req request object
 * @param  {Object} res response object
 * @param  {Object} payPalCustomerInfo object with customer information
 * @returns {Object} with next step url
 */
function handleAccountLinkingSecurityLayerFlow(req, res, payPalCustomerInfo) {
    const email = req.form.loginEmail;
    const password = req.form.loginPassword;

    const customerLoginResult = accountHelpers.loginCustomer(email, password, false);

    if (customerLoginResult.error) {
        return {
            error: true,
            errorMsg: [customerLoginResult.errorMessage || Resource.msg('error.message.login.form', 'login', null)]
        };
    }

    Object.assign(payPalCustomerInfo, { isPassedAccountLinkingSecurityLayer: true });

    return {
        error: false,
        nextStepUrl: handleConnectWithPaypalFlow(req, res, payPalCustomerInfo)
    };
}

module.exports = {
    getBtnConfig: getBtnConfig,
    handleConnectWithPaypalFlow: handleConnectWithPaypalFlow,
    getAccountLinkingSecurityLayerConfig: getAccountLinkingSecurityLayerConfig,
    handleAccountLinkingSecurityLayerFlow: handleAccountLinkingSecurityLayerFlow
};
