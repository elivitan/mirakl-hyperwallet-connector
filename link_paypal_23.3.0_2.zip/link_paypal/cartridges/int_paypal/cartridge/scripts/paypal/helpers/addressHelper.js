'use strict';

const Resource = require('dw/web/Resource');
const Transaction = require('dw/system/Transaction');
const basicHelpers = require('*/cartridge/scripts/util/basicHelpers');
const paypalConstants = require('*/cartridge/config/paypalConstants');

/**
 * @param {dw.order.Basket} basket - current user's basket
 * @returns {void}
 */
function updateShippingMethodsList(basket) {
    const shippingHelper = require('*/cartridge/scripts/checkout/shippingHelpers');
    const basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

    let shippingMethodID;
    const shipment = basket.defaultShipment;

    if (shipment.shippingMethod) {
        shippingMethodID = shipment.shippingMethod.ID;
    }

    const orderAddress = shipment.getShippingAddress();
    const shippingAddressObj = {
        city: orderAddress.getCity(),
        stateCode: orderAddress.getStateCode(),
        countryCode: orderAddress.getCountryCode(),
        postalCode: orderAddress.getPostalCode()
    };

    const isShippingMethodApplicable = shippingHelper.getApplicableShippingMethods(shipment, shippingAddressObj).find(function(shippingMethod) {
        return shippingMethod.ID === shippingMethodID;
    });

    if (isShippingMethodApplicable || !shippingMethodID) {
        shippingHelper.selectShippingMethod(shipment, shippingMethodID);
        basketCalculationHelpers.calculateTotals(basket);
    } else {
        throw new Error(Resource.msg('shippingoption.invalid.error', 'locale', null));
    }
}

const addressHelper = {};

/**
 * Returns Object with first, second, last names from a simple string person name
 *
 * @param {string} name Person Name
 * @returns {Object} person name Object
 */
addressHelper.createPersonNameObject = function(name) {
    const nameNoLongSpaces = name.trim().replace(/\s+/g, ' ').split(' ');
    const personNameObject = {
        firstName: null,
        lastName: null
    };

    if (nameNoLongSpaces.length === 1) {
        personNameObject.firstName = name;
    } else if (nameNoLongSpaces.length === 2) {
        personNameObject.firstName = nameNoLongSpaces[0];
        personNameObject.lastName = nameNoLongSpaces[1];
    } else {
        personNameObject.firstName = nameNoLongSpaces.slice(0, 2).join(' ');
        personNameObject.lastName = nameNoLongSpaces.slice(2).join(' ');
    }

    return personNameObject;
};

/**
 * Sets customer preferred address in the PayPal BA/Order id flow address format
 * @param {Object} basket basket
 * @param {boolean} isBaFlow whether BA flow or not
 * @returns {Object} adress object
 */
addressHelper.setAddressInPPAddressFormat = function(basket, isBaFlow) {
    if (!customer.addressBook || customer.addressBook.addresses.empty) {
        throw new Error(Resource.msg('addressbook.empty.error', 'locale', null));
    }

    const customerPreferredAddress = basicHelpers.getPreferredAddress(basket);

    if (isBaFlow) {
        return {
            country_code: customerPreferredAddress.getCountryCode(),
            city: customerPreferredAddress.getCity(),
            line1: customerPreferredAddress.getAddress1(),
            line2: customerPreferredAddress.getAddress2(),
            postal_code: customerPreferredAddress.getPostalCode(),
            state: customerPreferredAddress.getStateCode(),
            recipient_name: customerPreferredAddress.getFullName(),
            phone: customerPreferredAddress.getPhone()
        };
    }

    return {
        country_code: customerPreferredAddress.getCountryCode(),
        admin_area_2: customerPreferredAddress.getCity(),
        address_line_1: customerPreferredAddress.getAddress1(),
        address_line_2: customerPreferredAddress.getAddress2(),
        postal_code: customerPreferredAddress.getPostalCode(),
        admin_area_1: customerPreferredAddress.getStateCode()
    };
};

/**
 * Update Billing Address for order with order id
 * @param  {dw.order.Basket} basket - Current users's basket
 * @param  {Object} billingAddress user's billing address
 */
addressHelper.updateOrderBillingAddress = function(basket, billingAddress) {
    const {
        name,
        address,
        phone,
        email_address
    } = billingAddress;

    Transaction.wrap(function() {
        const billing = basket.getBillingAddress() || basket.createBillingAddress();

        billing.setFirstName(name.given_name || '');
        billing.setLastName(name.surname || '');
        billing.setCountryCode(address.country_code);
        billing.setCity(address.admin_area_2 || '');
        billing.setAddress1(address.address_line_1 || '');
        billing.setAddress2(address.address_line_2 || '');
        billing.setPostalCode(decodeURIComponent(address.postal_code) || '');
        billing.setStateCode(address.admin_area_1 || '');
        billing.setPhone(phone.phone_number.national_number || (billing.phone || ''));

        if (empty(basket.customerEmail)) {
            basket.setCustomerEmail(basket.customer.authenticated
                ? basket.customer.profile.email : email_address);
        }
    });
};

/**
 * Update Shipping Address for order with order id
 * @param  {dw.order.Basket} basket basket - Current users's basket
 * @param  {Object} shippingInfo - user's shipping address
 */
addressHelper.updateOrderShippingAddress = function(basket, shippingInfo) {
    const fullShippingName = shippingInfo.shipping.name.full_name;
    const fullName = addressHelper.createPersonNameObject(fullShippingName);
    const shippingAddress = shippingInfo.shipping.address;
    const orderShipping = shippingAddress || this.setAddressInPPAddressFormat(basket, false);

    Transaction.wrap(function() {
        const shipping = basket.getDefaultShipment().getShippingAddress() || basket.getDefaultShipment().createShippingAddress();

        shipping.setCountryCode(orderShipping.country_code);
        shipping.setCity(basicHelpers.getValueByKey(orderShipping, 'admin_area_2', ''));
        shipping.setAddress1(basicHelpers.getValueByKey(orderShipping, 'address_line_1', ''));
        shipping.setAddress2(basicHelpers.getValueByKey(orderShipping, 'address_line_2', ''));
        shipping.setPostalCode(decodeURIComponent(basicHelpers.getValueByKey(orderShipping, 'postal_code') || ''));
        shipping.setStateCode(basicHelpers.getValueByKey(orderShipping, 'admin_area_1', ''));
        shipping.setPhone(basicHelpers.getValueByKey(shippingInfo, 'phone.phone_number.national_number', ''));

        if (!empty(fullName.firstName)) {
            shipping.setFirstName(basicHelpers.getValueByKey(fullName, 'firstName', ''));
        }

        if (!empty(fullName.lastName)) {
            shipping.setLastName(basicHelpers.getValueByKey(fullName, 'lastName', ''));
        }

        updateShippingMethodsList(basket);
    });
};

/**
 * Creates shipping address
 * @param {Object} shippingAddress - user's shipping address
 * @returns {Object} with created shipping address
 */
addressHelper.createShippingAddress = function(shippingAddress) {
    return {
        name: {
            full_name: shippingAddress.fullName
        },
        address: {
            address_line_1: shippingAddress.address1,
            address_line_2: shippingAddress.address2,
            admin_area_1: shippingAddress.stateCode,
            admin_area_2: shippingAddress.city,
            postal_code: decodeURIComponent(shippingAddress.postalCode),
            country_code: shippingAddress.countryCode.value.toUpperCase()
        }
    };
};

/**
 * Creating Billing Agreement shipping_address
 * To create a billing agreement token, customer shipping_address needed
 * @param {string} shippingAddress - current customer shipping address
 * @returns {Object} object - BA filled shipping address
 */
addressHelper.getBAShippingAddress = function(shippingAddress) {
    return {
        line1: shippingAddress.getAddress1(),
        city: shippingAddress.getCity(),
        state: shippingAddress.getStateCode(),
        postal_code: decodeURIComponent(shippingAddress.getPostalCode()),
        country_code: shippingAddress.getCountryCode().getValue(),
        recipient_name: shippingAddress.getFullName()
    };
};

/**
 * Update Billing Address for order with BA id
 * @param  {dw.order.Basket} basket - Current users's basket
 * @param  {Object} billingAddress user's billing address
 */
addressHelper.updateBABillingAddress = function(basket, billingAddress) {
    const {
        first_name,
        last_name,
        billing_address,
        phone,
        email
    } = billingAddress;

    Transaction.wrap(function() {
        const billing = basket.getBillingAddress() || basket.createBillingAddress();

        billing.setFirstName(first_name || '');
        billing.setLastName(last_name || '');
        billing.setCountryCode(billing_address.country_code);
        billing.setCity(billing_address.city || '');
        billing.setAddress1(billing_address.line1 || '');
        billing.setAddress2(billing_address.line2 || '');
        billing.setPostalCode(decodeURIComponent(billing_address.postal_code) || '');
        billing.setStateCode(billing_address.state || '');

        if (empty(billing.phone)) {
            billing.setPhone(phone || '');
        }

        if (empty(basket.customerEmail)) {
            basket.setCustomerEmail(basket.customer.authenticated
                ? basket.customer.profile.email : email);
        }
    });
};

/**
 * Update Shipping Address for order with BA id
 * @param  {dw.order.Basket} basket basket - Current user's basket
 * @param  {Object} shippingAddress - user's shipping address
 */
addressHelper.updateBAShippingAddress = function(basket, shippingAddress) {
    const orderShipping = shippingAddress || this.setAddressInPPAddressFormat(basket, true);

    const {
        country_code,
        city,
        line1,
        line2,
        postal_code,
        state,
        recipient_name,
        phone
    } = orderShipping;

    const fullName = addressHelper.createPersonNameObject(recipient_name);

    Transaction.wrap(function() {
        const shipping = basket.getDefaultShipment().getShippingAddress() || basket.getDefaultShipment().createShippingAddress();

        shipping.setCountryCode(country_code);
        shipping.setCity(basicHelpers.getValueOr(city, ''));
        shipping.setAddress1(basicHelpers.getValueOr(line1, ''));
        shipping.setAddress2(basicHelpers.getValueOr(line2, ''));
        shipping.setPostalCode(decodeURIComponent(basicHelpers.getValueOr(postal_code, '')) || '');
        shipping.setStateCode(basicHelpers.getValueOr(state, ''));
        shipping.setPhone(basicHelpers.getValueOr(phone, ''));

        if (!empty(fullName.firstName)) {
            shipping.setFirstName(basicHelpers.getValueByKey(fullName, 'firstName', ''));
        }

        if (!empty(fullName.lastName)) {
            shipping.setLastName(basicHelpers.getValueByKey(fullName, 'lastName', ''));
        }

        updateShippingMethodsList(basket);
    });
};

/**
 * Returns shipping address object from provided HTTP parameter map with shippings fileds
 * @param {dw.sweb.HttpParameterMap} httpParameterMap A map of HTTP parameters.
 * @returns {Object} A Shipping address object
 */
addressHelper.getShippingAddressFromHttpParameterMap = function(httpParameterMap) {
    return {
        address1: httpParameterMap.get('dwfrm_shipping_shippingAddress_addressFields_address1').value,
        city: httpParameterMap.get('dwfrm_shipping_shippingAddress_addressFields_city').value,
        countryCode: httpParameterMap.get('dwfrm_shipping_shippingAddress_addressFields_country').value,
        firstName: httpParameterMap.get('dwfrm_shipping_shippingAddress_addressFields_firstName').value,
        lastName: httpParameterMap.get('dwfrm_shipping_shippingAddress_addressFields_lastName').value,
        postalCode: httpParameterMap.get('dwfrm_shipping_shippingAddress_addressFields_postalCode').value,
        stateCode: httpParameterMap.get('dwfrm_shipping_shippingAddress_addressFields_states_stateCode').value
    };
};

/**
 * @param {Object} addressData - the address data
 * @returns {Object} - the prepared address object
 */
function prepareAddressData(addressData) {
    return {
        addressId: addressData.addressId,
        firstName: addressData.firstName,
        lastName: addressData.lastName,
        address1: addressData.line1,
        address2: addressData.line2 || '',
        city: addressData.city,
        postalCode: decodeURIComponent(addressData.postalCode || addressData.postal_code),
        countryCode: addressData.countryCode || addressData.country_code,
        stateCode: addressData.stateCode,
        phone: addressData.phone.replace(/-/g, '')
    };
}

/**
 * @param {Object} payload - the payload data
 * @returns {Object} - the prepared billing address object
 */
addressHelper.prepareBillingAddressData = function(payload) {
    const billingAddress = payload.billingAddress;

    billingAddress.addressId = paypalConstants.BILLING_ADDRESS_ID;
    billingAddress.phone = payload.phone;
    billingAddress.lastName = payload.lastName;
    billingAddress.firstName = payload.firstName;
    billingAddress.stateCode = billingAddress.state;

    return prepareAddressData(billingAddress);
};

/**
 * @param {Object} payload - the payload data
 * @returns {Object} - the prepared shipping address object
 */
addressHelper.prepareShippingAddressData = function(payload) {
    const shippingAddress = payload.shippingAddress;

    shippingAddress.addressId = paypalConstants.SHIPPING_ADDRESS_ID;
    shippingAddress.phone = payload.phone;
    shippingAddress.lastName = payload.lastName;
    shippingAddress.firstName = payload.firstName;
    shippingAddress.stateCode = shippingAddress.state;

    return prepareAddressData(shippingAddress);
};

/**
 * @param {Object} form - the target of address form (billing, shipping)
 * @param {Object} data - the data for validation process
 * @returns {Object} - an object that contain the error in the form
 */
addressHelper.validateAddressForm = function(form, data) {
    const AddressValidatorModel = require('*/cartridge/models/addressValidator');

    form.clear();
    form.copyFrom(data);
    form.country.value = data.countryCode;
    form.states.stateCode.value = data.stateCode;

    return (new AddressValidatorModel(form)).validate();
};

/**
 * @param {Object} form - the target of address form (billing, shipping)
 * @param {Object} data - the data for validation process
 * @returns {Object} - an object that contain the error in the form
 */
addressHelper.validateBillingAddressForm = function(form, data) {
    const billingData = addressHelper.prepareBillingAddressData(data);
    const billingFields = addressHelper.validateAddressForm(form, billingData);

    return {
        error: Object.keys(billingFields).length > 0,
        errorName: 'billing.address.invalid',
        fields: billingFields,
        message: Resource.msg('error.billing.address.invalid', 'paypalerrors', null)
    };
};

/**
 * @returns {Object} - returns an address form object
 */
function getFormAddress() {
    return require('server').forms.getForm('address');
}

/**
 * @param {Object} data - the data for validation process
 * @param {Object} form - the target of address form (billing, shipping)
 * @returns {Object} - an object that contain the error in the form
 */
addressHelper.validateShippingAddressForm = function(data, form) {
    if (!form) {
        form = getFormAddress();
    }

    const shippingData = this.prepareShippingAddressData(data);
    const shippingFields = this.validateAddressForm(form, shippingData);

    return {
        error: Object.keys(shippingFields).length > 0,
        errorName: 'shipping.address.invalid',
        fields: shippingFields,
        message: Resource.msg('paypal.error.shipping.address.invalid', 'paypalerrors', null)
    };
};

/**
 * @param {Object} address - the data to be converted
 * @returns {Object} - the result of address data conversion
 */
function convertCheckoutOrdersPaypalAddress(address) {
    return {
        line1: address.address_line_1,
        line2: basicHelpers.getValueOr(address.address_line_2, ''),
        city: address.admin_area_2,
        state: basicHelpers.getValueOr(address.admin_area_1, ''),
        postalCode: address.postal_code,
        countryCode: address.country_code
    };
}

/**
 * @param {Object} data - the data to prepare the output
 * @returns {Object} - the prepared checkout orders paypal addresses object
 */
function prepareForCheckoutOrdersPaypalAddresses(data) {
    const billingData = basicHelpers.getValueByKey(data, 'payer.address', {});
    const shippingData = basicHelpers.getValueByKey(data, 'purchase_units.0.shipping', {});
    const shippingFullName = addressHelper.createPersonNameObject(shippingData.name.full_name);

    const billingAddress = convertCheckoutOrdersPaypalAddress(billingData);
    const shippingAddress = convertCheckoutOrdersPaypalAddress(shippingData.address);

    return {
        billingAddress: billingAddress,
        shippingAddress: shippingAddress,
        phone: basicHelpers.getValueByKey(data, 'payer.phone.phone_number.national_number', ''),
        lastName: basicHelpers.getValueByKey(data, 'payer.name.surname', shippingFullName.lastName),
        firstName: basicHelpers.getValueByKey(data, 'payer.name.given_name', shippingFullName.firstName)
    };
}

/**
 * @param {Object} data - the data for validation process
 * @param {boolean} [verify] - an optional flag for validation or not
 * @returns {Object} - an object that contain the error in the form
 */
addressHelper.validateCheckoutOrdersPaypalAddresses = function(data, verify) {
    const result = {
        error: false
    };

    if (verify === false) {
        return result;
    }

    const payload = prepareForCheckoutOrdersPaypalAddresses(data);
    const addressForm = getFormAddress();

    const validationShippingResult = addressHelper.validateShippingAddressForm(payload, addressForm);

    if (validationShippingResult.error) {
        return validationShippingResult;
    }

    return result;
};

/**
 * @param {Object} data - the data for validation process
 * @returns {Object} - an object that contain the error in the form
 */
addressHelper.validateBaPaypalAddresses = function(data) {
    const result = {
        error: false
    };

    // make a copy of the object without changing the original
    const dataCopy = JSON.parse(JSON.stringify(data));

    dataCopy.billing_info.shipping_address = dataCopy.shipping_address;

    const payload = basicHelpers.convertKeysToCamelCase(dataCopy.billing_info);
    const addressForm = getFormAddress();

    const validationShippingResult = addressHelper.validateShippingAddressForm(payload, addressForm);

    if (validationShippingResult.error) {
        return validationShippingResult;
    }

    return result;
};

/**
 * Applies the free shipping method to the basket according the basket currencyCode
 * @param {dw.order.Basket} basket The current basket
 */
addressHelper.applyOnlinePickupShippingMethodToBasket = function(basket) {
    const checkoutHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
    const shippingHelpers = require('*/cartridge/scripts/checkout/shippingHelpers');

    const onlinePickupShippingMethod = shippingHelpers.getOnlinePickupShippingMethod(basket.currencyCode);

    Transaction.wrap(function() {
        basket.defaultShipment.setShippingMethod(onlinePickupShippingMethod);
    });

    checkoutHelpers.recalculateBasket(basket);
};

/**
 * Compare addresses
 * @param {Object} address1 - first address object
 * @param {Object} address2 - second address object
 * @return {boolean} true if addresses are the same
 */
addressHelper.compareShippingAddresses = function(address1, address2) {
    let isSame = true;

    Object.keys(address1).forEach(function(key) {
        if (key === 'phone') {
            return;
        }

        if (basicHelpers.isObject(address1[key])) {
            if (!addressHelper.compareShippingAddresses(address1[key], address2[key])) {
                isSame = false;
            }
        } else if (address1[key] !== address2[key]) {
            isSame = false;
        }
    });

    return isSame;
};

/**
 * Creates a payload object with shipping addresses from billing agreement
 * @param {Object} billingAgreement - billingAgreement object
 * @return {Object} payload object
 */
addressHelper.generateShippingAddressesPayloadFromBA = function(billingAgreement) {
    return {
        firstName: billingAgreement.payer.payer_info.first_name,
        lastName: billingAgreement.payer.payer_info.last_name,
        phone: billingAgreement.payer.payer_info.phone,
        shippingAddress: {
            city: billingAgreement.shipping_address.city,
            countryCode: billingAgreement.shipping_address.country_code.toUpperCase(),
            state: billingAgreement.shipping_address.state,
            line1: billingAgreement.shipping_address.line1,
            postalCode: billingAgreement.shipping_address.postal_code
        }
    };
};

/**
 * Creates a payload object with shipping addresses from address book
 * @param {Object} addressBookAddress - addressBook preferredAddress object
 * @return {Object} payload object
 */
addressHelper.generateShippingAddressesPayloadFromAddressBook = function(addressBookAddress) {
    return {
        firstName: addressBookAddress.firstName,
        lastName: addressBookAddress.lastName,
        phone: addressBookAddress.phone,
        shippingAddress: {
            city: addressBookAddress.city,
            countryCode: addressBookAddress.countryCode.value.toUpperCase(),
            state: addressBookAddress.stateCode,
            line1: addressBookAddress.address1,
            postalCode: addressBookAddress.postalCode
        }
    };
};

/**
 * creates a short shipping address object from address book
 * @return {Object} short shipping address object
 */
addressHelper.getPreferredShippingAddressShortObj = function() {
    const shipping = customer.addressBook.preferredAddress;

    return {
        city: shipping.city,
        country_code: shipping.countryCode.value.toUpperCase(),
        line1: shipping.address1,
        phone: shipping.phone,
        postal_code: shipping.postalCode,
        recipient_name: shipping.fullName,
        state: shipping.stateCode
    };
};

/**
 * Updates shipping address if needed to change
 * @param {dw.order.Basket} currentBasket -  The current basket
 * @param {Object} shippingAddress - The shipping address object
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument - Payment instrument
 * @returns {void}
 */
addressHelper.updateShippingAddress = function(currentBasket, shippingAddress, paymentInstrument) {
    if (paymentInstrument.custom.paypalOrderID) {
        const paypalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');

        if (!paypalHelper.hasOnlyGiftCertificates(currentBasket)) {
            addressHelper.updateOrderShippingAddress(currentBasket, shippingAddress);
        }
    } else {
        addressHelper.updateBAShippingAddress(currentBasket, shippingAddress);
    }
};

/**
 * The function returns billing address in appropriate format for API request.
 * @param {Object} form - The form object that contains all required fields.
 * @returns {Object} - properly formatted billing address object.
 */
addressHelper.getBillingAddressFromForm = function(form) {
    return {
        address_line_1: form.dwfrm_address_address1,
        address_line_2: form.dwfrm_address_address2 || '',
        admin_area_1: form.dwfrm_address_states_stateCode,
        admin_area_2: form.dwfrm_address_city,
        postal_code: decodeURIComponent(form.dwfrm_address_postalCode),
        country_code: form.dwfrm_address_country
    };
};

/**
 * The function returns billing address in appropriate format for saving in PI custom attribute.
 * @param {Object} form - The form object that contains all required fields.
 * @returns {Object} - properly formatted billing address object.
 */
addressHelper.getBillingAddressToSave = function(form) {
    return {
        firstName: form.dwfrm_address_firstName,
        lastName: form.dwfrm_address_lastName,
        address1: form.dwfrm_address_address1,
        address2: form.dwfrm_address_address2 || '',
        city: form.dwfrm_address_city,
        stateCode: form.dwfrm_address_states_stateCode,
        postalCode: decodeURIComponent(form.dwfrm_address_postalCode),
        countryCode: { value: form.dwfrm_address_country },
        phone: form.dwfrm_address_phone
    };
};

module.exports = addressHelper;
