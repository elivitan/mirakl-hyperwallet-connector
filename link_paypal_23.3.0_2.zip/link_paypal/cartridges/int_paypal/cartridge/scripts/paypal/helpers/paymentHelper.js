'use scrict';

const Transaction = require('dw/system/Transaction');

const paymentHelper = {};

/**
 * Returns Active Payment Methods
 *
 * Setting isActive to true
 * Saves paymentMethodId to prefs.paymentMethods
 *
 * @returns {Object} an object with active payment Methods
 */
paymentHelper.getActivePaymentMethods = function() {
    const activePaymentMethods = require('dw/order/PaymentMgr').getActivePaymentMethods().toArray();

    return activePaymentMethods.reduce(function(paymentMethods, paymentMethod) {
        paymentMethods[paymentMethod.ID] = {
            isActive: paymentMethod.active,
            paymentMethodId: paymentMethod.ID
        };

        return paymentMethods;
    }, {});
};

/**
 * Get a credit card expiration data
 * @param {Object} creditCard - Credit card information from Payment Instrument
 * @returns {Object} - Credit card expiration data
 */
paymentHelper.getExpirationDataForCC = function(creditCard) {
    const Resource = require('dw/web/Resource');
    const prefs = require('*/cartridge/config/paypalPreferences');
    const basicHelpers = require('*/cartridge/scripts/util/basicHelpers');
    const paypalConstants = require('*/cartridge/config/paypalConstants');

    const creditCardData = {};
    const isCcExpireNotification = prefs.creditCardExpireNotification !== -1;
    const monthDiff = basicHelpers.getExpirationMonthDiff(creditCard.creditCardExpirationYear, creditCard.creditCardExpirationMonth) + 1;

    if (isCcExpireNotification && monthDiff <= prefs.creditCardExpireNotification) {
        creditCardData.expireNotification = true;

        creditCardData.expireStyle = paypalConstants.FLASH_MESSAGE_DANGER;
        creditCardData.expireMessage = Resource.msg('paypal.creditcard.expired', 'locale', null);

        if (monthDiff > 0) {
            creditCardData.expireStyle = paypalConstants.FLASH_MESSAGE_WARNING;
            creditCardData.expireMessage = Resource.msgf('paypal.creditcard.expires',
                'locale',
                null,
                monthDiff,
                basicHelpers.pluralize(monthDiff, 'month'));
        }

        return creditCardData;
    }

    return null;
};

/**
 * Get Expitation Notification For Credit Card
 * @param {Object} notificationObj - Notification object
 * @param {Object} ccExpirationData - Credit Card expiration information
 * @param {dw.customer.CustomerPaymentInstrument} paymentInstrument - Customer Payment Instrument
 * @returns {void}
 */
paymentHelper.getExpirationNotificationForCC = function(notificationObj, ccExpirationData, paymentInstrument) {
    if (!ccExpirationData.expireNotification) {
        return;
    }

    const Resource = require('dw/web/Resource');
    const CustomerModel = require('*/cartridge/models/customer');

    if (ccExpirationData.expireStyle === CustomerModel.FLASH_MESSAGE_DANGER && session.custom.ccExpiredNotice) {
        notificationObj.type = CustomerModel.FLASH_MESSAGE_DANGER;
        notificationObj.message = Resource.msg('creditcard.notification.expired', 'account', null);

        delete session.custom.ccExpiredNotice;
    }

    const isCustomerPaymentInstrument = paymentInstrument instanceof dw.customer.CustomerPaymentInstrument;

    const expirationNotice = isCustomerPaymentInstrument ? paymentInstrument.custom.paypalCreditCardExpirationNotice : null;

    if (!expirationNotice
        && ccExpirationData.expireStyle === CustomerModel.FLASH_MESSAGE_WARNING
        && notificationObj.type !== CustomerModel.FLASH_MESSAGE_DANGER) {
        notificationObj.type = CustomerModel.FLASH_MESSAGE_WARNING;
        notificationObj.message = Resource.msg('creditcard.notification.expiresoon', 'account', null);

        if (isCustomerPaymentInstrument) {
            Transaction.wrap(function() {
                paymentInstrument.custom.paypalCreditCardExpirationNotice = true;
            });
        }
    }
};

/**
 * Add a credit card expiration data
 * @param {Object} creditCard - Credit card information from Payment Instrument
 */
paymentHelper.addExpirationDataForCC = function(creditCard) {
    const ccExpirationData = paymentHelper.getExpirationDataForCC(creditCard);

    if (ccExpirationData) {
        Object.assign(creditCard, ccExpirationData);
    }
};

/**
 * Add a credit card expiration notification
 * @param {Array} creditCardList - List of credit cards
 * @returns {void}
 */
paymentHelper.addExpirationNotificationForCC = function(creditCardList) {
    if (!creditCardList.length) {
        return;
    }

    const flashNotification = {};

    session.custom.ccExpiredNotice = true;

    creditCardList.forEach(function(creditCard) {
        const ccExpirationData = paymentHelper.getExpirationDataForCC(creditCard);

        if (ccExpirationData) {
            paymentHelper.getExpirationNotificationForCC(flashNotification, ccExpirationData, creditCard);
        }
    });

    if (Object.keys(flashNotification).length) {
        const CustomerModel = require('*/cartridge/models/customer');

        const customerInstance = new CustomerModel(customer);

        Transaction.wrap(function() {
            customerInstance.addFlashMessage(flashNotification.message, flashNotification.type);
        });
    }
};

module.exports = paymentHelper;
