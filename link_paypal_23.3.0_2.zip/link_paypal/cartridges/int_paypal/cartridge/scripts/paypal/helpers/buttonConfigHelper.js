'use strict';

const payPalPrefs = require('*/cartridge/config/paypalPreferences');

const buttonConfigHelper = {};

/**
 * @param {string} currentFlow - the current page flow
 * @returns {Object} - return the object with necessary configuration for PayPal login
 */
buttonConfigHelper.createCwppButtonConfig = function(currentFlow) {
    let cwppButtonConfig = {};

    const paypalConstants = require('*/cartridge/config/paypalConstants');
    const availablePageFlows = [paypalConstants.PAGE_FLOW_LOGIN, paypalConstants.PAGE_FLOW_BILLING];

    if (availablePageFlows.includes(currentFlow)) {
        const sdkConfig = require('*/cartridge/config/sdkConfig');
        const paypalUrls = require('*/cartridge/config/paypalUrls');
        const paypaUtils = require('*/cartridge/scripts/paypal/paypalUtils');
        const basicHelpers = require('*/cartridge/scripts/util/basicHelpers');

        const buttonConfig = payPalPrefs.cwppButtonStyles[currentFlow];

        cwppButtonConfig = {
            fullPage: 'true',
            responseType: 'code',
            containerid: 'js-cwpp-button',
            scopes: sdkConfig.cwppScopes,
            theme: buttonConfig.theme,
            buttonSize: buttonConfig.buttonSize,
            buttonShape: buttonConfig.buttonShape,
            buttonType: buttonConfig.buttonType,
            appid: paypaUtils.getClientId(),
            locale: basicHelpers.getLocaleWithHyphen(request.getLocale()),
            returnurl: paypalUrls.cwppUrl,
            authend: payPalPrefs.instanceType
        };
    }

    return cwppButtonConfig;
};

/**
 * Returns a filtered array of LPMS available for rendering on storefront
 * @returns {Array} An array
 */
buttonConfigHelper.getAvailableLPMSArray = function() {
    const disabledLpms = payPalPrefs.disableFundingList.filter(function(el) {
        return payPalPrefs.enabledLPMs.includes(el);
    });

    return payPalPrefs.enabledLPMs.filter(function(el) {
        return !disabledLpms.includes(el);
    });
};

module.exports = buttonConfigHelper;
