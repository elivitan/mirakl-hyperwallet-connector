'use strict';

const Transaction = require('dw/system/Transaction');
const Resource = require('dw/web/Resource');
const Order = require('dw/order/Order');

const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');
const billingAgreementHelper = require('*/cartridge/scripts/paypal/helpers/billingAgreementHelper');
const paypalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');
const paypalUtils = require('*/cartridge/scripts/paypal/paypalUtils');
const addressHelper = require('*/cartridge/scripts/paypal/helpers/addressHelper');
const paypalApi = require('*/cartridge/scripts/paypal/paypalApi');
const paypalConstants = require('*/cartridge/config/paypalConstants');
const paypalProcessorHelper = require('*/cartridge/scripts/paypal/helpers/paypalProcessorHelper');
const creditCardHelper = require('*/cartridge/scripts/paypal/helpers/creditCardHelper');
const prefs = require('*/cartridge/config/paypalPreferences');

const paypalErrors = {
    GENERAL: 'paypal.error.general',
    ZEROAMOUNT: 'paypal.error.zeroamount'
};

/**
 * Handles an error form the get Order details api call
 * @param {string} errorMessage An error message
 * @returns {Object} An error object
 */
function handleOrderDetailsError(errorMessage) {
    paypalUtils.createErrorLog(errorMessage);

    return {
        error: true,
        fieldErrors: [],
        serverErrors: [
            Resource.msg(paypalErrors.GENERAL, 'paypalerrors', null)
        ]
    };
}

/**
 * @param {dw.order.LineItemCtnr} basket - current basket
 * @param {Object} billingForm - billing from
 * @param {Object} shippingAddress - shipping address
 * @param {dw.order.PaymentInstrument} paymentInstrument - PayPal payment instrument
 * @returns {Object} -
 */
function handleBillingAgreementFlow(basket, billingForm, shippingAddress, paymentInstrument) {
    const activeBA = billingAgreementHelper.createBaFromForm(billingForm);
    const baFromPaymentInstrument = billingAgreementHelper.getBaFromPaymentInstument(paymentInstrument);

    Transaction.wrap(function() {
        paymentInstrument.custom.PP_API_ActiveBillingAgreement = JSON.stringify(activeBA);
        paymentInstrument.custom.currentPaypalEmail = activeBA.email;
        session.privacy.paypalPayerEmail = activeBA.email;
    });

    const billingAgreementDetails = paypalApi.getBADetails(paymentInstrument);
    const baDetailsError = billingAgreementDetails.err;

    if (baFromPaymentInstrument && !billingAgreementHelper.isSameBillingAgreement(baFromPaymentInstrument, activeBA)) {
        paypalHelper.updateBillingInfoIfAccountChanged({
            baFromPI: baFromPaymentInstrument,
            activeBA: activeBA,
            paypalPI: paymentInstrument,
            basket: basket,
            billing_info: billingAgreementDetails.billing_info,
            BADetailsError: baDetailsError,
            handleError: paypalUtils.handleError(baDetailsError, paypalUtils.errorHandle, [baDetailsError])
        });
    } else {
        addressHelper.updateBABillingAddress(basket, billingAgreementDetails.billing_info);
    }

    if (baDetailsError) {
        paypalUtils.createErrorLog(baDetailsError);

        return {
            error: true,
            fieldErrors: [],
            serverErrors: [
                Resource.msg(paypalErrors.GENERAL, 'paypalerrors', null)
            ]
        };
    }

    if (!shippingAddress || shippingAddress === 'undefined') {
        const validationResult = addressHelper.validateBaPaypalAddresses(billingAgreementDetails);

        if (validationResult.error) {
            paypalProcessorHelper.clearCurrentPaypalEmail(paymentInstrument);

            return {
                error: true,
                errorName: validationResult.errorName,
                statusCode: 422,
                fieldErrors: [
                    validationResult.fields
                ],
                serverErrors: [
                    validationResult.message
                ]
            };
        }

        shippingAddress = paypalProcessorHelper.handleBaShippingAddress(shippingAddress, billingAgreementDetails);
    }

    return {
        shippingAddress: shippingAddress
    };
}

/**
 * @param {dw.order.LineItemCtnr} basket - current basket
 * @param {Object} billingForm - billing from
 * @param {dw.order.PaymentInstrument} paymentInstrument - PayPal payment instrument
 * @returns {Object} -
 */
function handleOrderIdFlow(basket, billingForm, paymentInstrument) {
    Transaction.wrap(function() {
        paymentInstrument.custom.paypalOrderID = session.privacy.paypalOrderID;
    });

    const orderDetails = paypalApi.getOrderDetails(paymentInstrument);

    const {
        payer,
        purchase_units,
        err: OrderDetailsError
    } = orderDetails;

    if (OrderDetailsError) {
        return handleOrderDetailsError(OrderDetailsError);
    }

    const validationResult = addressHelper.validateCheckoutOrdersPaypalAddresses(orderDetails);

    if (validationResult.error) {
        paypalProcessorHelper.clearCurrentPaypalEmail(paymentInstrument);

        return {
            error: true,
            errorName: validationResult.errorName,
            statusCode: 422,
            fieldErrors: [
                validationResult.fields
            ],
            serverErrors: [
                validationResult.message
            ]
        };
    }

    addressHelper.updateOrderBillingAddress(basket, payer);

    Transaction.wrap(function() {
        paymentInstrument.custom.currentPaypalEmail = payer.email_address;
    });

    // in case of checkout via Venmo or PAYPAL Debit/Credit Card save it's name to payment instrument custom property
    if ([
        paypalConstants.PAYMENT_METHOD_ID_VENMO,
        paypalConstants.PAYMENT_METHOD_ID_Debit_Credit_Card,
        paypalConstants.PAYMENT_METHOD_ID_PAYPAL
    ].includes(billingForm.paypal.usedPaymentMethod.value)) {
        Transaction.wrap(function() {
            paymentInstrument.custom.paymentId = billingForm.paypal.usedPaymentMethod.value;
        });
    }

    session.privacy.paypalPayerEmail = payer.email_address;

    const shippingAddress = purchase_units[0];

    shippingAddress.phone = payer.phone;

    return {
        shippingAddress: shippingAddress
    };
}

/**
 * Processor Handle
 *
 * @param {dw.order.LineItemCtnr} basket - Current basket
 * @param {Object} paymentInformation - paymentForm from hook
 * @param {Object} shippingAddress - shippingAddress object
 * @returns {Object} Processor handling result
 */
function handle(basket, paymentInformation, shippingAddress) {
    let result = {};

    const billingForm = paymentInformation.billingForm;
    const paymentInstrument = paypalProcessorHelper.handlePaymentInstrument(basket, billingForm);

    if (billingAgreementHelper.isBillingAgreementID(billingForm)) {
        result = handleBillingAgreementFlow(basket, billingForm, shippingAddress, paymentInstrument);
    } else {
        result = handleOrderIdFlow(basket, billingForm, paymentInstrument);
    }

    if (result.error) {
        return result;
    }

    return {
        success: true,
        paymentInstrument: paymentInstrument,
        shippingAddress: result.shippingAddress
    };
}

/**
 * Check Order Validity
 * @param {dw.order.LineItemCtnr} order - Order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument - Payment instrument
 * @returns {Object} - result of checks
 */
function checkOrderValidity(order, paymentInstrument) {
    const result = {
        error: false,
        fieldErrors: [],
        serverErrors: []
    };

    if (empty(paymentInstrument) || empty(order) || order.status === Order.ORDER_STATUS_FAILED) {
        result.error = true;
        result.serverErrors.push(Resource.msg(paypalErrors.GENERAL, 'paypalerrors', null));

        return result;
    }

    if (paymentInstrument.paymentTransaction.amount.value === 0) {
        result.error = true;
        result.serverErrors.push(Resource.msg(paypalErrors.ZEROAMOUNT, 'paypalerrors', null));

        return result;
    }

    return result;
}

/**
 * Handle Authorize Billing Agreement
 * @param {dw.order.LineItemCtnr} order - Order object
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument - current payment instrument
 * @param {Object} purchaseUnit - PayPal Purchase Unit
 * @returns {Object} - Result
 */
function handleAuthorizeBillingAgreement(order, paymentInstrument, purchaseUnit) {
    let bodyObj = {};

    const isCreditCardPmUsed = paymentInstrument.paymentMethod === paypalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD;

    if (paymentInstrument.custom.PP_API_ActiveBillingAgreement && !isCreditCardPmUsed) {
        const paypalOrder = paypalApi.createOrder(purchaseUnit, order);

        if (paypalOrder.err) {
            paypalUtils.createErrorLog(paypalOrder.err);

            return {
                error: true,
                authorized: false,
                fieldErrors: [],
                serverErrors: [paypalOrder.err],
                message: paypalOrder.err
            };
        }

        Transaction.wrap(function() {
            paymentInstrument.custom.paypalOrderID = paypalOrder.resp.id;
        });

        try {
            bodyObj = billingAgreementHelper.createBAReqBody(paymentInstrument);
        } catch (error) {
            paypalUtils.createErrorLog(error);

            return {
                error: true,
                authorized: false,
                fieldErrors: [],
                serverErrors: [error]
            };
        }
    }

    return bodyObj;
}

/**
 * Save result of rest call and update order data
 *
 * @param {dw.order.LineItemCtnr} order - Order object
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument - current payment instrument
 * @returns {Object} Processor authorizing result
 */
function authorize(order, paymentInstrument) {
    delete session.privacy.paypalUsedOrderNo;

    const orderValidity = checkOrderValidity(order, paymentInstrument);
    const isCreditCardPmUsed = paymentInstrument.paymentMethod === paypalConstants.PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD;
    const isSavedCreditCardFlow = isCreditCardPmUsed && paymentInstrument.creditCardToken !== null;
    const paymentTransaction = paymentInstrument.paymentTransaction;
    const purchaseUnit = paypalHelper.getPurchaseUnit(order);

    if (orderValidity.error) {
        return orderValidity;
    }

    if (isSavedCreditCardFlow) {
        creditCardHelper.updateSavedCreditCardBA(paymentInstrument);

        return creditCardHelper.completeSavedCcOrder(purchaseUnit, order, paymentInstrument);
    }

    const bodyObj = handleAuthorizeBillingAgreement(order, paymentInstrument, purchaseUnit);

    if (bodyObj.error) {
        return bodyObj;
    }

    const isUpdateRequired = paypalHelper.isPurchaseUnitChanged(purchaseUnit, paymentInstrument);

    if (paymentInstrument.custom.paypalOrderID && isUpdateRequired) {
        const paypalOrderDetails = paypalApi.updateOrderDetails(paymentInstrument, purchaseUnit);

        if (paypalOrderDetails.err) {
            paypalUtils.createErrorLog(paypalOrderDetails.err);

            return {
                authorized: false,
                error: true,
                fieldErrors: [],
                serverErrors: [paypalOrderDetails.err],
                message: paypalOrderDetails.err
            };
        }

        session.privacy.orderDataHash = paypalUtils.encodeString(purchaseUnit);
    }

    Transaction.wrap(function() {
        order.custom.paypalPaymentMethod = 'express';
    });

    if (prefs.saveOrderFlow && !isCreditCardPmUsed) {
        const paypalOrderID = paymentInstrument.custom.paypalOrderID;
        const saveOrderResult = paypalApi.saveOrder(paypalOrderID);

        if (saveOrderResult.status === paypalConstants.STATUS_SAVED) {
            saveOrderResult.isSavedOrder = true;
            saveOrderResult.amount = paymentInstrumentHelper.calculateNonGiftCertificateAmount(order);

            Transaction.wrap(function() {
                order.custom.isSavedOrder = true;
                paymentInstrument.custom.paypalPaymentStatus = paypalConstants.STATUS_SAVED;
                paymentInstrument.custom.paypalRequest = JSON.stringify({ paypalOrderID: paypalOrderID });
                paymentInstrument.custom.paypalResponse = JSON.stringify(saveOrderResult);
                paymentTransaction.custom.paypalTransactionHistory = paypalHelper.prepareTransactionHistory(paymentTransaction, saveOrderResult);
            });

            return {
                authorized: false
            };
        }
    }

    const {
        response,
        err: createTransactionError
    } = paypalApi.createTransaction(paymentInstrument, bodyObj);

    if (createTransactionError) {
        paypalUtils.createErrorLog(createTransactionError);

        return {
            error: true,
            fieldErrors: [],
            serverErrors: [createTransactionError]
        };
    }

    paypalProcessorHelper.saveGeneralTransactionData(paymentInstrument, response, bodyObj);

    Transaction.wrap(function() {
        order.custom.PP_API_TransactionID = paymentTransaction.transactionID;
    });

    session.privacy.orderDataHash = null;

    return {
        authorized: true
    };
}

exports.handle = handle;
exports.authorize = authorize;
