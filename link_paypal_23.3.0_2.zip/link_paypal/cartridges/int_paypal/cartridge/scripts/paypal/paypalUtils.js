'use strict';

const server = require('server');

const Encoding = require('dw/crypto/Encoding');
const Bytes = require('dw/util/Bytes');
const URLUtils = require('dw/web/URLUtils');
const Resource = require('dw/web/Resource');
const LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
const Logger = require('dw/system/Logger');
const Site = require('dw/system/Site');

const prefs = require('*/cartridge/config/paypalPreferences');
const paypalConstants = require('*/cartridge/config/paypalConstants');

let paypalLogger;

/**
 * Gets client id from cache if it exists or creates it, saves to cache and returns from cache
 *
 * @returns {string} with client id
 */
function getClientId() {
    const serviceName = 'int_paypal.http.rest';
    const restService = LocalServiceRegistry.createService(serviceName, {});

    // Returns client ID
    return restService.configuration.credential.user;
}

/**
 * Encodes purchase unit object into encoded string
 *
 * @param {Object} purchaseUnit purchase unit
 * @returns {string} encoded string
 */
function encodeString(purchaseUnit) {
    const bytes = new Bytes(JSON.stringify(purchaseUnit));

    return Encoding.toBase64(bytes);
}

/**
 * Returns SDK url for Connect with Paypal button on Login page
 * @param {string} rurl rurl of the req.querystring
 * @returns {string} SDK Url
 */
function createCWPPButtonUrl(rurl) {
    const locale = Site.getCurrent().getDefaultLocale();
    const redirectUrl = [URLUtils.abs('Paypal-ConnectWithPaypal').toString(), '&state=', rurl.split('=').pop()].join('');
    const clientID = getClientId();

    return [prefs.CWPPButtonUrl, 'flowEntry=static&client_id=', clientID, '&locale=', locale,
        '&scope=openid profile email address&redirect_uri=', redirectUrl].join('');
}

/**
 * Get logger instance
 *
 * @param {string} err Error message
 */
function createErrorLog(err) {
    paypalLogger = paypalLogger || Logger.getLogger(paypalConstants.PAYPAL_FILE_NAME_PREFIX, paypalConstants.PAYPAL_CATEGORY);

    if (!empty(err)) {
        paypalLogger.error(err.stack ? (err.message + err.stack) : err);
    } else {
        paypalLogger.debug(Resource.msg('paypal.debug.log.empry.log.entry', 'paypalerrors', null));
    }
}

/**
 * Creates a debug log message
 * @param {string} err Error message
 * @returns {void}
 */
function createDebugLog(err) {
    paypalLogger = paypalLogger || Logger.getLogger(paypalConstants.PAYPAL_FILE_NAME_PREFIX, paypalConstants.PAYPAL_CATEGORY);
    paypalLogger.debug(err);
}

/**
 * Creates the Error Message
 *
 * @param {string} errorName error message name
 * @returns {string} errorMsg - Resource error massage
 */
function createErrorMsg(errorName) {
    const defaultMessage = Resource.msg('paypal.error.general', 'paypalerrors', null);

    return Resource.msg('paypal.error.' + errorName, 'paypalerrors', defaultMessage);
}

/**
 * Error handler for SubmitPayment endpoint
 * @param  {Object} req server request
 * @param  {Object} res server response
 * @param  {Error} error error instance
 * @param  {string} msg error text type for client
 * @returns {void}
 */
function errorHandle(req, res, error, msg) {
    if (error) {
        createErrorLog(error);
    }

    res.json({
        form: server.forms.getForm('billing'),
        fieldErrors: [],
        serverErrors: [createErrorMsg(msg)],
        error: true
    });
    this.emit('route:Complete', req, res);
}

/**
 * Handles errors at checkout
 * @param  {Error} errorTrigger error instance or statement that triggers an error
 * @param  {Object} callback function
 * @param  {Array} args errorHandle function arguments
 * @returns {Object} errorHandle function
 */
function handleError(errorTrigger, callback, args) {
    if (errorTrigger) {
        return callback.call(this, args);
    }

    return false;
}

/**
 * The function to proceed a safe JSON parsing.
 * @param {string} element - The string what should be parsed.
 * @returns {Object} - the result of parsing.
 */
function tryParseJSON(element) {
    let result;

    try {
        result = JSON.parse(element);
    } catch (error) {
        createErrorLog(['Unable to parse:  ', element, error.stack].join(' '));
    }

    return result;
}

/**
 * Adds custom attribute FlashMessages to a system object
 * @param {Object} systemObject System object for which custom attribute should be created
 * @param {string} messageText Resource key
 * @param {string} messageType Type of message, i.e. danger, info or warning
 * @returns {void}
 */
function addFlashMessagesCustomAttribute(systemObject, messageText, messageType) {
    const flashMessages = systemObject.custom.flashMessages ? tryParseJSON(systemObject.custom.flashMessages) : [];

    flashMessages.push({
        text: messageText,
        type: messageType
    });

    systemObject.custom.flashMessages = JSON.stringify(flashMessages);
}

module.exports = {
    getClientId: getClientId,
    createErrorLog: createErrorLog,
    encodeString: encodeString,
    createErrorMsg: createErrorMsg,
    errorHandle: errorHandle,
    createDebugLog: createDebugLog,
    createCWPPButtonUrl: createCWPPButtonUrl,
    handleError: handleError,
    tryParseJSON: tryParseJSON,
    addFlashMessagesCustomAttribute: addFlashMessagesCustomAttribute
};
