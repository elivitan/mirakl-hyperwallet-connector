'use strict';

const baseUtils = module.superModule;

const paypalConstants = require('*/cartridge/scripts/util/paypalConstants');

/**
 * Gets client id from service
 *
 * @returns {string} with client id
 */
function getClientId() {
    const LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');

    const serviceName = 'int_paypal.http.rest';
    const restService = LocalServiceRegistry.createService(serviceName, {});

    return restService.configuration.credential.user;
}

/**
 * Creates SDK url for paypal credit message banner based on client id
 *
 * @returns {string} created url
 */
baseUtils.createCreditMessageSDKUrl = function() {
    const clientID = getClientId();

    return paypalConstants.PAYPAL_SDK_HOST + clientID + paypalConstants.PAYPAL_SDK_COMPONENTS_MESSAGES;
};

module.exports = baseUtils;
