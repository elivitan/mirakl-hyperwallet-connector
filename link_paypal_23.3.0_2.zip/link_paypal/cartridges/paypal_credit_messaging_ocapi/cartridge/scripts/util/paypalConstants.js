'use strict';

const baseConstants = module.superModule;

const paypalConstants = {
    PAYMENT_METHOD_ID_DC_CARD: 'PayPal Debit/Credit Card',
    ALLOWED_PROCESSOR_ID: 'PAYPAL',
    PAYPAL_EXPRESS_PAYMENT_METHOD: 'express',
    PAYPAL_SDK_HOST: 'https://www.paypal.com/sdk/js?client-id=',
    PAYPAL_SDK_COMPONENTS_MESSAGES: '&components=messages',
    PDP_PAGE_ID: 'pdp',
    MINICART_PAGE_ID: 'minicart',
    // Intent types
    INTENT_AUTHORIZE: 'AUTHORIZE',
    INTENT_CAPTURE: 'CAPTURE',
    // Action type
    ACTION_TYPE_AUTHORIZE: 'authorize',
    ACTION_TYPE_CAPTURE: 'capture'
};

module.exports = Object.assign(baseConstants, paypalConstants);
