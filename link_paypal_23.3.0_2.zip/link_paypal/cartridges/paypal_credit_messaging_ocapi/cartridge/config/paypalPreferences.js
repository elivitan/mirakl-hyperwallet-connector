'use strict';

const basePreferences = module.superModule;
const paypalConstants = require('*/cartridge/scripts/util/paypalConstants');

/**
 * Returns paypal payment method ID
 * @returns {string} active paypal payment method id
 */
function getPaypalPaymentMethodId() {
    const PaymentMgr = require('dw/order/PaymentMgr');
    const activePaymentMethods = PaymentMgr.getActivePaymentMethods();
    let paypalPaymentMethodID;

    Array.some(activePaymentMethods, function(paymentMethod) {
        if (paymentMethod.paymentProcessor.ID === paypalConstants.ALLOWED_PROCESSOR_ID) {
            paypalPaymentMethodID = paymentMethod.ID;

            return true;
        }

        return false;
    });

    return paypalPaymentMethodID;
}

/**
 *  Returns PayPal custom and hardcoded preferences
 *
 * @returns {Object} statis preferences
 */
function getPreferences() {
    const currentSite = require('dw/system/Site').getCurrent();

    basePreferences.paypalPaymentMethodId = getPaypalPaymentMethodId();
    basePreferences.categoryCreditBannersEnabled = currentSite.getCustomPreferenceValue('PP_Show_On_Category');
    basePreferences.cartCreditBannersEnabled = currentSite.getCustomPreferenceValue('PP_Show_On_Cart');
    basePreferences.pdpCreditBannersEnabled = currentSite.getCustomPreferenceValue('PP_Show_On_PDP');

    return basePreferences;
}

module.exports = getPreferences();
