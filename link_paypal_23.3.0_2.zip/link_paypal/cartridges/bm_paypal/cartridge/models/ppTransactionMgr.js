var paypalUtils = require('*/cartridge/scripts/paypal/bmPaypalUtils');

var PPRestApiWrapper = require('*/cartridge/scripts/paypal/paypalApi/ppRestApiWrapper');
var ppRestApiWrapper = new PPRestApiWrapper();

/**
 * Gets transaction id for api call to get details for correspondent transaction
 * @param {dw.web.HttpParameterMap} hm request.httpParameterMap
 * @param {string} transactionIdFromOrder transaction id from current order
 * @returns {string} transaction id
 */
function getTransactionID(hm, transactionIdFromOrder) {
    var transactionID;

    if (!empty(hm.transactionId.stringValue) && !empty(transactionIdFromOrder)
        && hm.transactionId.stringValue !== transactionIdFromOrder || empty(hm.transactionId.stringValue)) {
        transactionID = transactionIdFromOrder;
    } else {
        transactionID = hm.transactionId.stringValue;
    }

    return transactionID;
}

/**
 * PP Transaction Mgr Model
 */
function TransactionMgrModel() { }

TransactionMgrModel.prototype.getTransactionData = function(hm, transactionIdFromOrder) {
    const Resource = require('dw/web/Resource');

    let orderDetails;

    try {
        const transactionID = getTransactionID(hm, transactionIdFromOrder);

        orderDetails = ppRestApiWrapper.getOrderDetails(transactionID);

        if (orderDetails.err) {
            const note = Resource.msg('transactions.note', 'paypalbm', null);

            throw new Error(orderDetails.responseData.l_longmessage0 + note);
        }
    } catch (error) {
        if (error.message !== Resource.msg('paypal.api.response.error.resource.not.found', 'paypalbm', null)) {
            paypalUtils.createErrorLog(error);
        }

        throw new Error(error);
    }

    return orderDetails;
};

module.exports = TransactionMgrModel;
