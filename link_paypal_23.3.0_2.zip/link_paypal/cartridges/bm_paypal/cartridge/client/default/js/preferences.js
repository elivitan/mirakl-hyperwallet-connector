'use strict';

require('./preferences/preferences');
