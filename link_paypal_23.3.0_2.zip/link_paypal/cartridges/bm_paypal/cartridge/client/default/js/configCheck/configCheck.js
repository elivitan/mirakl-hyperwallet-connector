'use strict';

/* eslint-disable no-console */

const Jobs = require('./jobs');
const Modal = require('./modal');
const ProgressBarModel = require('./progressBar');
const WebDAV = require('./webdav');
const OpenCommerceAPI = require('./ocapi');
const AlertHandlerModel = require('../components/alertHandler');

((win, doc) => {
    const alertHandler = new AlertHandlerModel();

    const $configCheck = doc.querySelector('.js-config-check');

    const config = JSON.parse($configCheck.dataset.apiConfig);
    const resources = JSON.parse($configCheck.dataset.resources);
    const additionalData = JSON.parse($configCheck.dataset.additionalData);
    const testConnectionUrl = $configCheck.dataset.testConnectionUrl;

    const OCAPI = new OpenCommerceAPI(config.ocapi);

    let ProgressBar;
    let modal;

    /**
     * Handle download archive file
     * @param {string} fileName - file name
     * @returns {void}
     */
    const handleDownloadFile = (fileName) => {
        const link = document.createElement('a');

        const WebDav = new WebDAV(config.webdav);

        WebDav.get(`impex/src/instance/${fileName}`)
            .then((response) => response.blob())
            .then((blob) => {
                link.href = URL.createObjectURL(blob);
                link.download = fileName;

                link.click();

                URL.revokeObjectURL(link.href);
            })
            .catch((error) => {
                throw new Error(`Error downloading the ZIP file: ${error.message}`);
            });
    };

    /**
     * Handle Generate Plugin Configuration
     * @param {Object} formData - form data object
     * @returns {void}
     */
    const handleGenerateConfig = (formData) => {
        const jobs = new Jobs(OCAPI, ProgressBar, resources);
        const selectedConfig = Object.keys(formData).filter(key => typeof formData[key] === 'boolean' && formData[key] === true);
        const totalSelected = selectedConfig.length;

        jobs.handleExportSite(formData)
            .then((isExportFinished) => {
                console.log('isExportFinished', isExportFinished);

                if (isExportFinished) {
                    return jobs.archiveFileProcessing(formData);
                }

                return isExportFinished;
            })
            .then((isChangesCompleted) => {
                console.log('isChangesCompleted', isChangesCompleted);

                if (isChangesCompleted) {
                    handleDownloadFile(formData.fileName);

                    modal.close();

                    alertHandler.showAlertMessage({
                        type: 'success',
                        message: resources[`export${totalSelected > 1 ? 'All' : 'General'}Success`]
                    });
                }
            })
            .catch((error) => {
                const hasFiles = error.message.includes('file(s)');

                if (hasFiles) {
                    handleDownloadFile(formData.fileName);
                }

                alertHandler.showAlertMessage({
                    type: hasFiles ? 'caution' : 'warning',
                    message: error.message
                });

                modal.close();
            });
    };

    /**
     * Handle Test Connection
     * @param {boolean} isExport - True if this is an export process, otherwise false
     * @returns {void}
     */
    const handleTestConnection = (isExport = false) => {
        alertHandler.fadeAlerts();

        return fetch(testConnectionUrl, {
            method: 'POST',
            body: JSON.stringify({ isExport })
        }).then((response) => response.json());
    };

    /**
     * Handle Submit Form
     * @param {Object} form - Form element
     * @returns {void}
     */
    const handleSubmitForm = (form) => {
        if (!form.checkValidity()) {
            form.reportValidity();
        } else {
            const isExport = true;
            const processedData = {};

            Array.from(form.elements).forEach((element) => {
                processedData[element.name] = element.type === 'checkbox' ? element.checked : element.value;
            });

            ProgressBar.showProgressBar();

            handleTestConnection(isExport)
                .then((response) => {
                    const STEP_ID = 'test-connection';
                    const result = response.result;

                    if (result.error) {
                        alertHandler.showAlertMessage({
                            message: result.message,
                            type: 'warning'
                        });
                    }

                    processedData.connectionData = result;
                    processedData.additionalData = additionalData;

                    ProgressBar.handleProgressBarNextStep(STEP_ID);
                    handleGenerateConfig(processedData);
                });
        }
    };

    /**
     * Handle Modal window
     * @returns {void}
     */
    const handleModal = () => {
        let $form;

        const $formTemplate = doc.querySelector('.js-form-template');

        modal = new Modal({
            title: resources.modalTitle,
            width: 600,
            height: 471,
            html: $formTemplate.innerHTML,
            modal: true,
            autoScroll: true,
            listeners: {
                show: () => {
                    $form = doc.querySelector('.js-form-generate-config');

                    $form.addEventListener('submit', (event) => event.preventDefault());
                }
            },
            buttons: [{
                text: resources.submit,
                handler: () => {
                    handleSubmitForm($form);
                }
            }, {
                text: resources.cancel,
                handler: () => {
                    modal.close();
                }
            }]
        });

        ProgressBar = new ProgressBarModel(modal, '.js-progress-bar-template');

        win.addEventListener('resize', () => {
            modal.center();
        });

        win.addEventListener('orientationchange', () => {
            modal.center();
        });

        modal.show();
    };

    doc.addEventListener('DOMContentLoaded', () => {
        const $buttonTestConnection = doc.querySelector('.js-test-connection');
        const $buttonGenerateConfig = doc.querySelector('.js-generate-config');

        $buttonGenerateConfig.addEventListener('click', handleModal);
        $buttonTestConnection.addEventListener('click', () => {
            handleTestConnection()
                .then((response) => {
                    const result = response.result;

                    alertHandler.showAlertMessage({
                        message: result.message,
                        type: result.error ? 'warning' : 'success'
                    });
                });
        });
    });
})(window, document);
