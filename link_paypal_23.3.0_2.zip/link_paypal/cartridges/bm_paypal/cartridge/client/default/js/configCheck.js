'use strict';

require('./configCheck/configCheck');
