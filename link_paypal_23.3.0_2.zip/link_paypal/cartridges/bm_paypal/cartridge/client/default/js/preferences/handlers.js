'use script';

const AlertHandlerModel = require('../components/alertHandler');

const doc = document;
const alertHandler = new AlertHandlerModel();

/**
 * Retrieves the value of an element by its name attribute.
 *
 * @param {string} name - The name attribute of the element to retrieve the value for.
 * @returns {string} The value of the element with the given name attribute, or an empty string if the element was not found.
 */
const getValueByName = (name) => {
    const elememnt = doc.querySelector(`[name="${name}"]`);

    return elememnt ? elememnt.value : '';
};

/**
 * Retrieves the value of an element by attribute name.
 *
 * @param {string} name - The name attribute of the element to retrieve the value for.
 * @returns {string} The attribute value of the element with the given name attribute, or an empty string if the element was not found.
 */
const getValueByAttr = (name) => {
    const elememnt = doc.querySelector(`[name="${name}"]`);

    return elememnt ? elememnt.getAttribute('data-old-value') : '';
};

/**
 * Handles the triggers for a relation.
 *
 * @param {Array<Object>} triggers - An array of trigger objects to handle.
 * @returns {void}
 */
const handlerTriggers = (triggers) => {
    for (let index = 0; index < triggers.length; index++) {
        const action = triggers[index];

        if (action.type === 'alert') {
            alertHandler.showAlertMessage({
                type: 'primary',
                message: action.message
            });
        }

        if (action.type === 'change') {
            doc.querySelector(`[name="${action.id}"`).value = action.value;
        }
    }
};

/**
 * Handles the conditions for a relation.
 *
 * @param {Array<Object>} conditions - An array of condition objects to handle.
 * @returns {boolean} Whether or not all conditions were met.
 */
const handlerConditions = (conditions) => {
    let conditionMatched = true;

    for (let index = 0; index < conditions.length; index++) {
        const condition = conditions[index];
        const { id: conditionId, value: conditionValue, operator } = condition;

        if (operator === 'and') {
            if (conditionValue !== getValueByName(conditionId)) {
                conditionMatched = false;

                break;
            }
        } else if (operator === 'or') {
            if (conditionValue === getValueByName(conditionId)) {
                conditionMatched = true;

                break;
            } else {
                conditionMatched = false;
            }
        }
    }

    return conditionMatched;
};

/**
 * Handles all relations in the document.
 *
 * @returns {void}
 */
const handlerRelations = () => {
    const relations = JSON.parse(doc.querySelector('[data-relations]').getAttribute('data-relations'));

    for (let index = 0; index < relations.length; index++) {
        const relation = relations[index];
        const conditionMatched = handlerConditions(relation.conditions);

        if (conditionMatched && relation.oldValue === getValueByAttr(relation.id) && relation.newValue === getValueByName(relation.id)) {
            handlerTriggers(relation.triggers);
        }
    }
};

/**
 * Data handler before form submission
 * @param {Object} event - ClickEvent
 */
const handlerBeforeSubmit = (event) => {
    alertHandler.fadeAlerts();

    const target = event.target;
    const site = target.form.querySelector('[name="site"]');

    site.value = target.name === 'apply-to-sites' ? 'multiple' : 'single';

    handlerRelations();
};

module.exports = {
    handlerBeforeSubmit
};
