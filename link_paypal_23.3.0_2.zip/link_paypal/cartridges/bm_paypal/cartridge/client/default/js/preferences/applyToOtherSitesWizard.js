'use strict';

const TEXT_SELECT_ALL = 'Select all';
const TEXT_UNSELECT_ALL = 'Unselect all';
const DW_ROW_SELECTOR = '.js-dw-row';
const DW_TBODY_SELECTOR = '.js-dw-tbody';
const DW_CHECKBOX_SELECTOR = '.js-dw-checkbox';
const DW_CHECKBOX_CLASSNAME = 'js-dw-checkbox';
const SELECT_ALL_SELECTOR = '.js-select-all';

class ApplyToOtherSitesWizard {
    PREF_SELECTION = 'preferenceSelection';

    SITE_SELECTION = 'siteSelection';

    SUMMARY = 'summary';

    IS_DISABLED = 'is-disabled';

    IS_ACTIVE = 'is-active';

    D_NONE = 'd-none';

    INSTANCES = {
        0: 'Sandbox',
        1: 'Staging',
        2: 'Production'
    };

    constructor() {
        this.$wizard = document.querySelector('.js-dw-wizard');
        this.$btnNext = document.querySelector('.js-button-next');
        this.$btnBack = document.querySelector('.js-button-back');
        this.$btnApply = document.querySelector('.js-button-apply');

        this.prefsNames = {};
        this.dataToSend = { prefs: {}, sites: {} };
        this.currentStage = null;
        this.currentSite = null;
        this.currentInstance = null;
    }

    /**
     * Handles click on a checkbox having it be checked/unchecked along with its siblings
     * @param {HTMLElement} $checkbox Input
     * @param {boolean} condition Condition that triggers whether cthe checkbox should be checked or not
     */
    handleMultiCheckboxClick($checkbox, condition) {
        if (condition) {
            $checkbox.checked = false;
            $checkbox.click();
        } else {
            $checkbox.checked = true;
            $checkbox.click();
        }
    }

    /**
     * Prepares data
     * @param {HTMLElement} $checkbox Input
     * @param {null} value If present, it means the checkbox was unchecked
     */
    prepDataToSend($checkbox, value) {
        const prefValue = $checkbox.dataset.prefValue || $checkbox.dataset.forInstance;

        if ((value === null || !$checkbox.dataset.prefValue) && $checkbox.dataset.prefId) {
            this.dataToSend.prefs[$checkbox.dataset.prefId] = '';
        } else if ($checkbox.dataset.prefId) {
            this.dataToSend.prefs[$checkbox.dataset.prefId] = prefValue;
        }

        if ($checkbox.closest(DW_ROW_SELECTOR)) {
            const siteId = $checkbox.closest(DW_ROW_SELECTOR).dataset.siteId;
            const siteName = $checkbox.closest(DW_ROW_SELECTOR).dataset.siteName;
            const siteData = this.dataToSend.sites[siteId];

            if (value === null) {
                const index = siteData.indexOf($checkbox.dataset.forInstance);

                siteData.splice(index, 1);
            } else if (siteData && !siteData.includes(prefValue)) {
                siteData.push(prefValue);
            } else if (!siteData) {
                const data = {};

                data[siteId] = [prefValue];
                data[siteId].siteName = siteName;

                Object.assign(this.dataToSend.sites, data);
            }
        }
    }

    handleCheckboxTextConditions($checkbox, $selectAllBtn, isAnyNotCheckedStagewide) {
        if (!$checkbox.checked && $selectAllBtn && $selectAllBtn.innerText === TEXT_UNSELECT_ALL) {
            $selectAllBtn.innerText = TEXT_SELECT_ALL;
        }

        if (!isAnyNotCheckedStagewide && $selectAllBtn && $selectAllBtn.innerText === TEXT_SELECT_ALL) {
            $selectAllBtn.innerText = TEXT_UNSELECT_ALL;
        }
    }

    /**
     * Handles checkbox click and how it influences other elements
     * @param {HTMLElement} $checkbox Input
     */
    handleCheckboxChangeEvent($checkbox) {
        $checkbox.addEventListener('change', () => {
            const $parentElem = $checkbox.closest('[data-wizard-stage]');
            const $nextStage = $parentElem.nextElementSibling;
            const $stageAfterNext = $nextStage.nextElementSibling;
            const $nextProgressItem = this.$wizard.querySelector(`[data-progress-id="${$nextStage.dataset.wizardStage}"]`);
            const $selectAllBtn = $parentElem.querySelector(SELECT_ALL_SELECTOR);

            let $checkAllBtn = $parentElem.querySelector('.js-dw-check-all');
            let $afterNextProgressItem;

            const isAnyCheckedInNextStage = $nextStage.querySelector('.js-dw-checkbox:checked');
            const isAnyNotCheckedStagewide = $parentElem.querySelector('.js-dw-checkbox:not(:checked)');
            const isAnyCheckedStagewide = $parentElem.querySelector('.js-dw-checkbox:checked');

            let isAnyNotChecked = $parentElem.querySelector('.js-dw-checkbox:not(:checked):not(.js-attr-selection-row.d-none .js-dw-checkbox)');

            if ($checkbox.dataset.forInstance) {
                $checkAllBtn = $parentElem.querySelector(`.js-dw-check-all[data-for-instance="${$checkbox.dataset.forInstance}"]`);
                isAnyNotChecked = $parentElem.querySelector(`.js-dw-checkbox[data-for-instance="${$checkbox.dataset.forInstance}"]:not(:checked)`);
            }

            if ($stageAfterNext) {
                $afterNextProgressItem = this.$wizard.querySelector(`[data-progress-id="${$stageAfterNext.dataset.wizardStage}"]`);
            }

            if ($checkbox.checked) {
                $nextProgressItem.classList.remove(this.IS_DISABLED);
                this.$btnNext.disabled = false;

                this.prepDataToSend($checkbox);
            } else if (!$checkbox.checked && !isAnyCheckedStagewide) {
                $nextProgressItem.classList.add(this.IS_DISABLED);
                this.$btnNext.disabled = true;
            }

            if (!$checkbox.checked && !isAnyCheckedStagewide && $stageAfterNext) {
                $afterNextProgressItem.classList.add(this.IS_DISABLED);
            } else if ($checkbox.checked && isAnyCheckedInNextStage && $stageAfterNext) {
                $afterNextProgressItem.classList.remove(this.IS_DISABLED);
            }

            if ($checkbox.checked && !isAnyNotChecked && !$checkAllBtn.checked) {
                $checkAllBtn.checked = true;
            }

            if (!$checkbox.checked) {
                this.prepDataToSend($checkbox, null);
            }

            if (!$checkbox.checked && $checkAllBtn.checked) {
                $checkAllBtn.checked = false;
            }

            this.handleCheckboxTextConditions($checkbox, $selectAllBtn, isAnyNotCheckedStagewide);
        });
    }

    /**
     * Handles click on checkbox which should select all other checkboxes
     * @param {HTMLElement} $checkbox Input
     */
    handleApplyToAllCheckboxChangeEvent($checkbox) {
        $checkbox.addEventListener('change', () => {
            const $parent = $checkbox.closest('[data-wizard-stage]');
            let $checkboxes = $parent.querySelectorAll(DW_CHECKBOX_SELECTOR);

            if ($checkbox.dataset.forInstance) {
                $checkboxes = $parent.querySelectorAll(`.js-dw-checkbox[data-for-instance="${$checkbox.dataset.forInstance}"]`);
            }

            $checkboxes.forEach(($input) => this.handleMultiCheckboxClick($input, $checkbox.checked));
        });
    }

    /**
     * Hides checkbox for the currently chosen site and instance
     */
    hideCurrentSiteAndInstanceCheckbox() {
        const $stageSiteSelection = this.$wizard.querySelector(`#${this.SITE_SELECTION}`);
        const $checkboxes = $stageSiteSelection.querySelectorAll(DW_CHECKBOX_SELECTOR);

        $checkboxes.forEach(($checkbox) => {
            if ($checkbox.dataset.forInstance === this.currentInstance
                && $checkbox.dataset.forSite === this.currentSite) {
                $checkbox.classList.add(this.D_NONE);
                $checkbox.classList.remove(DW_CHECKBOX_CLASSNAME);
            }
        });
    }

    /**
     * Initializes the popup by generating rows with preferences and its values,
     * Calls methods related to checkboxes
     * @param {string} formId Form ID
     */
    initialize(formId) {
        const $form = document.getElementById(formId);
        const $instanceType = document.querySelector(`.js-instance-type[data-group-id=${formId}]`);

        this.currentInstance = $instanceType.value;
        this.currentSite = $instanceType.dataset.siteId;
        this.$btnApply.setAttribute('form', formId);

        $form.querySelectorAll('.js-dw-attr-row .js-dw-attr-label').forEach((label) => {
            this.prefsNames[label.dataset.attrId] = label.innerText;
        });

        $form.querySelectorAll('[data-old-value]').forEach(($field) => {
            const $row = this.$wizard.querySelector('.js-attr-selection-row').cloneNode(true);
            const fieldValue = $field.dataset.oldValue;

            let value;

            if (fieldValue === 'true') {
                value = 'Yes';
            } else if (fieldValue === 'false') {
                value = 'No';
            } else if ($field.dataset.valueTypeCode === '13') {
                value = fieldValue.replace(/./g, '*');

                $row.querySelector(DW_CHECKBOX_SELECTOR).classList.add(this.D_NONE);
                $row.querySelector(DW_CHECKBOX_SELECTOR).classList.remove(DW_CHECKBOX_CLASSNAME);
            } else if ($field.dataset.valueTypeCode === '31') {
                value = $field.children[$field.selectedIndex].dataset.displayValue;
            } else if ($field.dataset.valueTypeCode === '33') {
                value = fieldValue.replaceAll(',', ', ');
            } else {
                value = `${fieldValue.charAt(0).toUpperCase()}${fieldValue.slice(1)}`;
            }

            $row.children[0].firstElementChild.dataset.prefId = $field.name;
            $row.children[0].firstElementChild.dataset.prefValue = fieldValue;

            $row.children[1].firstElementChild.append(this.prefsNames[$field.name]);
            $row.children[2].firstElementChild.append(value);

            $row.classList.remove(this.D_NONE);

            this.$wizard.querySelector(DW_TBODY_SELECTOR).append($row);
            this.currentStage = this.PREF_SELECTION;
        });

        this.$wizard.classList.remove(this.D_NONE);
        this.hideCurrentSiteAndInstanceCheckbox();

        this.$wizard.querySelectorAll('.js-dw-check-all').forEach(($checkbox) => this.handleApplyToAllCheckboxChangeEvent($checkbox));
        this.$wizard.querySelectorAll(DW_CHECKBOX_SELECTOR).forEach(($checkbox) => this.handleCheckboxChangeEvent($checkbox));
    }

    /**
     * Creates a row with preference data for summary stage
     * @param {string} prefId Preference ID
     */
    createSummaryPrefRow(prefId) {
        const $template = this.$wizard.querySelector('.js-summary-pref-row');
        const $rowPref = $template.cloneNode(true);

        $rowPref.children[0].firstElementChild.append(this.prefsNames[prefId]);
        $rowPref.children[1].firstElementChild.append(this.dataToSend.prefs[prefId]);

        $rowPref.dataset.prefId = prefId;
        $rowPref.classList.remove(this.D_NONE);

        $template.closest(DW_TBODY_SELECTOR).append($rowPref);
    }

    /**
     * Creates a row with site data for summary stage
     * @param {string} siteId Site ID
     * @param {string} instanceCode Instance code
     */
    createSummarySiteRow(siteId, instanceCode) {
        const $template = this.$wizard.querySelector('.js-summary-site-row');
        const $rowSite = $template.cloneNode(true);

        $rowSite.children[0].firstElementChild.append(`${this.dataToSend.sites[siteId].siteName} (${this.INSTANCES[instanceCode]})`);

        $rowSite.dataset.siteId = siteId;
        $rowSite.dataset.siteInstance = instanceCode;
        $rowSite.classList.remove(this.D_NONE);

        $template.closest(DW_TBODY_SELECTOR).append($rowSite);
    }

    /**
     * Prepares rows for stage summary
     */
    prepStageSummary() {
        Object.keys(this.dataToSend.prefs).forEach((key) => this.createSummaryPrefRow(key));

        Object.keys(this.dataToSend.sites).forEach((key) => {
            this.dataToSend.sites[key].forEach((value) => this.createSummarySiteRow(key, value));
        });
    }

    /**
     * Updates rows for stage summary in case if user goes to previous stages to correct data
     */
    updateStageSummary() {
        const $prefRows = this.$wizard.querySelectorAll('.js-summary-pref-row:not(.d-none)');
        const $siteRows = this.$wizard.querySelectorAll('.js-summary-site-row:not(.d-none)');

        const prefsInWizard = Array.from($prefRows).map(($row) => $row.dataset.prefId);
        const sitesInWizard = Array.from($siteRows).map(($row) => [$row.dataset.siteId, $row.dataset.siteInstance]);
        const savedPrefs = Object.keys(this.dataToSend.prefs);
        const savedSites = Object.keys(this.dataToSend.sites);

        Array.from($prefRows)
            .filter(($row) => !savedPrefs.includes($row.dataset.prefId))
            .forEach(($row) => $row.remove());

        Array.from($siteRows)
            .filter(($row) => !this.dataToSend.sites[$row.dataset.siteId].includes($row.dataset.siteInstance))
            .forEach(($row) => $row.remove());

        savedPrefs
            .filter((prefId) => !prefsInWizard.includes(prefId))
            .forEach((prefId) => this.createSummaryPrefRow(prefId));

        savedSites.forEach((siteId) => {
            const instancesInWizard = [];

            sitesInWizard
                .filter((pair) => pair[0] === siteId)
                .forEach((pair) => instancesInWizard.push(pair[1]));

            this.dataToSend.sites[siteId].forEach((instanceCode) => {
                if (!instancesInWizard.includes(instanceCode)) {
                    this.createSummarySiteRow(siteId, instanceCode);
                }
            });
        });
    }

    /**
     * Handles stage switch when next/back buttons or progress items are clicked
     * @param {string} currentStage Current stage
     * @param {string} futureStage Future stage
     */
    handleStageSwitch(currentStage, futureStage) {
        const $futureStageProgressItem = document.querySelector(`[data-progress-id="${futureStage}"]`);
        const $currentStageProgressItem = document.querySelector(`[data-progress-id="${currentStage}"]`);
        const $summaryStage = this.$wizard.querySelector(`#${this.SUMMARY}`);

        document.getElementById(currentStage).classList.add(this.D_NONE);
        document.getElementById(futureStage).classList.remove(this.D_NONE);

        $currentStageProgressItem.classList.remove(this.IS_ACTIVE);
        $futureStageProgressItem.classList.add(this.IS_ACTIVE);

        if (futureStage === this.SUMMARY && !$summaryStage.dataset.wizardStageStatus) {
            this.prepStageSummary();
            $summaryStage.dataset.wizardStageStatus = 'generated';
        }

        if ($summaryStage.dataset.wizardStageStatus) {
            this.updateStageSummary();
        }

        if (futureStage === this.PREF_SELECTION) {
            this.$btnBack.disabled = true;
            this.$btnNext.disabled = false;
        } else if (futureStage === this.SITE_SELECTION) {
            const isAnyCheckboxChecked = this.$wizard.querySelector(`#${this.SITE_SELECTION} .js-dw-checkbox:checked`);

            if (!isAnyCheckboxChecked) {
                this.$btnNext.disabled = true;
            }

            this.$btnBack.disabled = false;
        } else if (futureStage === this.SUMMARY) {
            this.$btnNext.classList.add('ng-hide');
            this.$btnApply.classList.remove('ng-hide');

            $futureStageProgressItem.classList.remove(this.IS_DISABLED);
        }

        if ((futureStage === this.PREF_SELECTION || futureStage === this.SITE_SELECTION)
            && !this.$btnApply.classList.contains('ng-hide')) {
            this.$btnApply.classList.add('ng-hide');
            this.$btnNext.classList.remove('ng-hide');
        }

        this.currentStage = futureStage;
    }

    /**
     * Moves to next stage on next button click
     */
    toNextStage() {
        if (this.currentStage === this.PREF_SELECTION) {
            this.handleStageSwitch(this.currentStage, this.SITE_SELECTION);
        } else if (this.currentStage === this.SITE_SELECTION) {
            this.handleStageSwitch(this.currentStage, this.SUMMARY);
        }
    }

    /**
     * Moves to previous stage on back button click
     */
    toPrevStage() {
        if (this.currentStage === this.SITE_SELECTION) {
            this.handleStageSwitch(this.currentStage, this.PREF_SELECTION);
        } else if (this.currentStage === this.SUMMARY) {
            this.handleStageSwitch(this.currentStage, this.SITE_SELECTION);
        }
    }

    /**
     * Shows corresponding stage based on which progress item was clicked
     * @param {HTMLElement} $item Progress item
     */
    handleProgressBarClick($item) {
        const $progressBarContainer = document.querySelector('.js-progress-bar');
        const $selectedElem = $progressBarContainer.querySelector('.is-active');

        const currentStage = $selectedElem.dataset.progressId;
        const futureStage = $item.dataset.progressId;

        this.handleStageSwitch(currentStage, futureStage);
    }

    /**
     * Restores next/back/apply buttons classes to their initial state
     */
    restoreButtonClasses() {
        if (this.$btnNext.classList.contains('ng-hide')) {
            this.$btnNext.classList.remove('ng-hide');
        }

        if (!this.$btnNext.disabled) {
            this.$btnNext.disabled = true;
        }

        if (!this.$btnBack.disabled) {
            this.$btnBack.disabled = true;
        }

        if (!this.$btnApply.classList.contains('ng-hide')) {
            this.$btnApply.classList.add('ng-hide');
        }
    }

    /**
     * Restores progress items classes to their initial state
     */
    restoreProgressBarClasses() {
        const $progressPrefSelection = document.querySelector(`[data-progress-id="${this.PREF_SELECTION}"]`);
        const $progressSiteSelection = document.querySelector(`[data-progress-id="${this.SITE_SELECTION}"]`);
        const $progressSummary = document.querySelector(`[data-progress-id="${this.SUMMARY}"]`);

        if (!$progressPrefSelection.classList.contains(this.IS_ACTIVE)) {
            $progressPrefSelection.classList.add(this.IS_ACTIVE);
        }

        if ($progressSiteSelection.classList.contains(this.IS_ACTIVE)) {
            $progressSiteSelection.classList.remove(this.IS_ACTIVE);
        }

        if (!$progressSiteSelection.classList.contains(this.IS_DISABLED)) {
            $progressSiteSelection.classList.add(this.IS_DISABLED);
        }

        if ($progressSummary.classList.contains(this.IS_ACTIVE)) {
            $progressSummary.classList.remove(this.IS_ACTIVE);
        }

        if (!$progressSummary.classList.contains(this.IS_DISABLED)) {
            $progressSummary.classList.add(this.IS_DISABLED);
        }
    }

    /**
     * Restores stages to there initial state
     */
    restoreStages() {
        const $stagePrefSelection = document.getElementById(this.PREF_SELECTION);
        const $stageSiteSelection = document.getElementById(this.SITE_SELECTION);
        const $stageSummary = document.getElementById(this.SUMMARY);

        if ($stagePrefSelection.classList.contains(this.D_NONE)) {
            $stagePrefSelection.classList.remove(this.D_NONE);
        }

        if (!$stageSiteSelection.classList.contains(this.D_NONE)) {
            $stageSiteSelection.classList.add(this.D_NONE);
        }

        if (!$stageSummary.classList.contains(this.D_NONE)) {
            $stageSummary.classList.add(this.D_NONE);
        }
    }

    /**
     * Cleans stage summary of its rows with data
     */
    cleanStageSummary() {
        const $summaryStage = this.$wizard.querySelector(`#${this.SUMMARY}`);
        const $summaryStageData = $summaryStage.querySelectorAll('.js-summary-pref-row:not(.d-none), .js-summary-site-row:not(.d-none)');

        $summaryStageData.forEach(($row) => $row.remove());
        $summaryStage.removeAttribute('data-wizard-stage-status');
    }

    /**
     * Shows hidden checkbox responsible for currect site and instance
     */
    showCurrentSiteAndInstanceCheckbox() {
        const $stageSiteSelection = this.$wizard.querySelector(`#${this.SITE_SELECTION}`);
        const $checkbox = $stageSiteSelection.querySelector('.d-none[data-for-instance]');

        $checkbox.classList.remove(this.D_NONE);
        $checkbox.classList.add(DW_CHECKBOX_CLASSNAME);
    }

    /**
     * Closes popup on close button
     */
    close() {
        this.$wizard.classList.add(this.D_NONE);

        this.$wizard.querySelectorAll('.js-attr-selection-row:not(.d-none)').forEach((elem) => elem.remove());

        this.$wizard.querySelectorAll('.js-dw-check-all:checked, .js-dw-checkbox:checked').forEach(($checkbox) => {
            $checkbox.checked = false;
        });

        this.$wizard.querySelector(SELECT_ALL_SELECTOR).innerText = TEXT_SELECT_ALL;

        this.restoreButtonClasses();
        this.restoreProgressBarClasses();
        this.restoreStages();
        this.cleanStageSummary();
        this.showCurrentSiteAndInstanceCheckbox();

        this.dataToSend = { prefs: {}, sites: {} };
    }

    /**
     * Check checkboxes for all instances and sites
     */
    selectAllSites() {
        const $button = this.$wizard.querySelector(SELECT_ALL_SELECTOR);
        const $checkboxes = this.$wizard.querySelectorAll(`#${this.SITE_SELECTION} .js-dw-check-all`);

        if ($button.innerText === TEXT_SELECT_ALL) {
            $button.innerText = TEXT_UNSELECT_ALL;
        } else {
            $button.innerText = TEXT_SELECT_ALL;
        }

        $checkboxes.forEach(($checkbox) => this.handleMultiCheckboxClick($checkbox, $button.innerText !== TEXT_SELECT_ALL));
    }

    /**
     * Calls savePreferencesHandler method with given data
     * @param {Object} event Event
     * @param {Function} callback savePreferencesHandler method
     */
    apply(event, callback) {
        Object.keys(this.dataToSend.sites)
            .filter((siteId) => this.dataToSend.sites[siteId].length !== 0)
            .forEach((siteId) => {
                this.dataToSend.sites[siteId].forEach((instance) => callback(event, {
                    prefs: this.dataToSend.prefs,
                    siteId: siteId,
                    instance: this.INSTANCES[instance].toLowerCase()
                }));
            });

        this.close();
    }

    /**
     * Shows popup/alert on Apply to other sites button click
     * @param {string} formId Form ID
     */
    show(formId) {
        const $form = document.getElementById(formId);
        const $formFields = $form.querySelectorAll('[data-old-value]');
        const $unsavedField = Array.from($formFields).some(($field) => {
            if ($field.dataset.oldValue.includes('.0') && !$field.value.includes('.0')) {
                return $field.dataset.oldValue.replace('.0', '') !== $field.value;
            }

            return $field.dataset.oldValue !== $field.value;
        });

        if ($unsavedField) {
            this.showAlert(formId);
        } else {
            this.initialize(formId);
        }
    }

    /**
     * Shows alert if the form contains unsaved data
     * @param {string} formId Form ID
     */
    showAlert(formId) {
        const $wizardAlert = document.querySelector('.js-wizard-alert');
        const $okBtn = $wizardAlert.querySelector('.js-wizard-alert-ok');
        const $cancelBtn = $wizardAlert.querySelector('.js-wizard-alert-cancel');

        $wizardAlert.classList.remove(this.D_NONE);
        $okBtn.setAttribute('form', formId);
        $cancelBtn.addEventListener('click', () => $wizardAlert.classList.add(this.D_NONE));
    }

    /**
     * Resets unsaved form data and initializes the wizard poup
     * @param {string} formId Form ID
     */
    proceedtoWizard(formId) {
        const $wizardAlert = document.querySelector('.js-wizard-alert');

        $wizardAlert.classList.add(this.D_NONE);
        this.initialize(formId);
    }
}

module.exports = ApplyToOtherSitesWizard;
