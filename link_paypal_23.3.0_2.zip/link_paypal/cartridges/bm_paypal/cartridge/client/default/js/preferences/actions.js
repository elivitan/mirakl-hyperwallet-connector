/* eslint-disable no-console */

'use strict';

const AlertHandlerModel = require('../components/alertHandler');

const alertHandler = new AlertHandlerModel();

const JS_DW_VALUES = '.js-dw-values';

const doc = document;
const csrfToken = doc.querySelector('[name="csrf_token"]');

const instanceTypesObj = {
    0: 'sandbox',
    1: 'staging',
    2: 'production'
};

/**
 * Gets the client ID from the DOM.
 * @returns {string} The client ID, or an empty string if not found.
 */
const getClientId = () => {
    const element = doc.querySelector('[name="client-id"]');

    return element ? element.value : '';
};

/**
 * Adds semi opaque background on form while instance is being changed
 * @param {string} formId form ID
 * @returns {Object} An object with two methods: show and hide
 */
const transitionAnimation = (formId) => {
    const form = doc.getElementById(formId);

    return {
        show: () => form.classList.add('semi-opaque'),
        hide: () => form.classList.remove('semi-opaque')
    };
};

/**
 * Handles the default value for a given field in a row. If a default value is found,
 * it sets the field value and old value to this default (in lowercase). If not, it clears the field.
 *
 * @param {HTMLElement} $row - The row element in which to find the field.
 * @param {HTMLElement} $field - The field element whose default value should be handled.
 */
const handleDefaultValue = ($row, $field) => {
    const $element = $row.querySelector('.js-default-value');

    if ($element) {
        const defaultValue = $element.dataset.defaultVal.toLowerCase();

        $field.value = defaultValue;
        $field.dataset.oldValue = defaultValue;
    } else {
        $field.value = '';
        $field.dataset.oldValue = '';
    }
};

/**
 * Changes values for preferences of another instance
 * @param {Object} data OCAPI response data
 * @param {Array} prefsWithChangedValues preferences which values have been changed
 * @param {HTMLElement} $row row where the preference is located
 */
const handleValuesChange = (data, prefsWithChangedValues, $row) => {
    const changedPrefValue = prefsWithChangedValues.find((pref) => $row.classList.contains(pref.toLowerCase()));
    const $field = $row.querySelector('.js-dw-collection-field').firstElementChild;
    const $setOfStringsValueField = $row.querySelector('[data-value-type-code="23"]');
    const $enumOfIntValueField = $row.querySelector('[data-value-type-code="31"]');
    const $enumOfStringsValueField = $row.querySelector('[data-value-type-code="33"]');

    if ($setOfStringsValueField) {
        const $valuesContainer = $row.querySelector(JS_DW_VALUES);

        Array.from($valuesContainer.children).forEach((elem) => {
            if (!elem.classList.contains('d-none')) {
                elem.remove();
            }
        });

        $setOfStringsValueField.value = '';
        $field.dataset.oldValue = '';

        if (changedPrefValue) {
            data[`c_${changedPrefValue}`].forEach((prefValue) => {
                const $valueContainer = $valuesContainer.firstElementChild.cloneNode(true);
                const $valueText = $valueContainer.firstElementChild;
                const value = $setOfStringsValueField.value.concat(`${$setOfStringsValueField.value.length ? ',' : ''}`, prefValue);

                $setOfStringsValueField.value = value;
                $field.dataset.oldValue = value;

                $valueText.append(prefValue);
                $valueContainer.prepend($valueText);
                $valuesContainer.append($valueContainer);

                $valueContainer.classList.remove('d-none');
            });
        }
    } else if ($enumOfIntValueField && !changedPrefValue) {
        $field.value = '-1';
        $field.dataset.oldValue = '-1';
    } else if (changedPrefValue) {
        $field.value = data[`c_${changedPrefValue}`];
        $field.dataset.oldValue = data[`c_${changedPrefValue}`];
    } else {
        handleDefaultValue($row, $field);
    }

    if ($enumOfStringsValueField) {
        const $checkboxes = $row.querySelectorAll('.js-input-checkbox');
        const checkedValues = $field.value.split(',');

        $checkboxes.forEach(($checkbox) => {
            $checkbox.checked = checkedValues.includes($checkbox.value);
        });
    }
};

/**
 * Stores the client ID in local storage and updates the client ID field in the DOM.
 */
const storeClientId = () => {
    const key = 'bm-client-id';
    const oneDayInMilliseconds = 24 * 60 * 60 * 1000;
    const value = JSON.parse(localStorage.getItem(key));
    const element = doc.querySelector('[name="client-id"]');

    if (value && value.expires > Date.now()) {
        element.value = value.clientId;
    } else {
        const url = new URL('on/demandware.store/Sites-Site/default/ViewApplication-BM#/?preference#site_preference_groups', location.origin);

        fetch(url, {
            method: 'GET'
        })
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const htmlDocument = parser.parseFromString(html, 'text/html');
                const clientIdElement = htmlDocument.getElementById('dw-ocapi.client-id');
                const clientId = clientIdElement.getAttribute('content');

                localStorage.setItem(key, JSON.stringify({
                    clientId: clientId,
                    expires: Date.now() + oneDayInMilliseconds
                }));

                element.value = clientId;
            })
            .catch(error => {
                console.error('Error fetching HTML:', error);
            });
    }
};

/**
 * Get Access Token object
 * @returns {void}
 */
const getAccessToken = () => {
    const searchParams = new URLSearchParams();
    const url = new URL('dw/oauth2/access_token', location.origin);

    url.searchParams.append('csrf_token', csrfToken.value);

    searchParams.append('client_id', getClientId());
    searchParams.append('grant_type', 'urn:demandware:params:oauth:grant-type:client-id:dwsid:dwsecuretoken');

    return fetch(url.toString(), {
        method: 'POST',
        body: searchParams
    })
        .then(response => response.json())
        .then(data => {
            return data;
        })
        .catch(error => {
            alertHandler.showAlertMessage({
                type: 'danger',
                message: error.message
            });
        });
};

/**
 * Send POST request to save preferences
 * @param {Object} event - SubmitEvent
 * @param {Object} data - data sent from apply to other sites popup
 */
const savePreferencesHandler = async(event, data) => {
    event.preventDefault();

    const $target = data ? event.target.form : event.target;
    const groupId = $target.id;

    const $instanceType = doc.querySelector(`.js-instance-type[data-group-id="${groupId}"]`);

    const siteId = data ? data.siteId : $instanceType.getAttribute('data-site-id');
    const instanceType = data ? data.instance : instanceTypesObj[$instanceType.value];

    const url = new URL(`s/-/dw/data/v99_9/sites/${siteId}/site_preferences/preference_groups/${groupId}/${instanceType}`, location.origin);
    const searchParams = url.searchParams;

    searchParams.append('mask_passwords', 'true');
    searchParams.append('display_locale', 'default');
    searchParams.append('csrf_token', csrfToken.value);

    const token = await getAccessToken();

    const prefIdsWithMultiValueType = Array.from($target.querySelectorAll('.js-multi-value')).map((input) => input.name);
    const prefIdsWithPasswordValueType = Array.from($target.querySelectorAll('[data-value-type-code="13"]')).map((input) => input.name);
    const prefIdsWithStringValueType = Array
        .from($target.querySelectorAll('[data-value-type-code="3"], [data-value-type-code="4"], [data-value-type-code="33"]'))
        .map((input) => input.name);

    const formData = data ? data.prefs : Object.fromEntries(new FormData($target));
    const dataToSend = {};

    Object.keys(formData).forEach((key) => {
        if (key.includes('PP')) {
            if (prefIdsWithMultiValueType.includes(key)) {
                dataToSend[`c_${key}`] = formData[key].split(',');
            } else if (prefIdsWithStringValueType.includes(key) || prefIdsWithPasswordValueType.includes(key)) {
                dataToSend[`c_${key}`] = formData[key];
            } else if (!formData[key]) {
                dataToSend[`c_${key}`] = null;
            } else {
                dataToSend[`c_${key}`] = JSON.parse(formData[key]);
            }
        }
    });

    return fetch(url, {
        method: 'PATCH',
        headers: {
            Authorization: `${token.token_type} ${token.access_token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(dataToSend)
    })
        .then((response) => response.json())
        .then((_data) => {
            _data.fault
                ? alertHandler.showAlertMessage({ type: 'danger', message: _data.fault.message })
                : alertHandler.showAlertMessage({
                    type: 'success',
                    message: `The custom preferences were saved for ${instanceType} instance of ${_data.site.id}.`
                });
        })
        .catch((error) => {
            alertHandler.showAlertMessage({
                type: 'danger',
                message: error.message
            });
        });
};

/**
 * Fetch Property Description
 * @param {Element} element - DOM element
 */
const fetchPropertyDescription = (element) => {
    const url = new URL('/on/demandware.store/Sites-Site/default/ViewApplication-GetTooltipJson', location.origin);
    const searchParams = url.searchParams;

    const attrId = element.getAttribute('data-dw-attr-id');

    searchParams.append('attrid', attrId);
    searchParams.append('tooltip', `c_${attrId}`);
    searchParams.append('attrtype', 'SitePreferences');
    searchParams.append('csrf_token', csrfToken.value);

    fetch(url.toString())
        .then(response => response.json())
        .then(response => {
            element.innerHTML = response.customText || 'Not set';
        })
        .catch(error => {
            alertHandler.showAlertMessage({
                type: 'danger',
                message: error.message
            });
        });
};

/**
 * Changes preferences values for a specific instance
 * @param {Object} event - SubmitEvent
 * @returns {Promise} - OCAPI call to get preferences with their values for specific site and isntance
 */
const handlerInstanceType = async(event) => {
    const target = event.target;

    const siteId = target.getAttribute('data-site-id');
    const groupId = target.getAttribute('data-group-id');
    const instanceType = instanceTypesObj[target.value];

    transitionAnimation(groupId).show();

    const url = new URL(`s/-/dw/data/v99_9/sites/${siteId}/site_preferences/preference_groups/${groupId}/${instanceType}`, location.origin);
    const searchParams = url.searchParams;

    searchParams.append('mask_passwords', 'true');
    searchParams.append('select', '(**)');
    searchParams.append('display_locale', 'default');
    searchParams.append('csrf_token', csrfToken.value);

    const token = await getAccessToken();

    return fetch(url, {
        method: 'GET',
        headers: {
            Authorization: `${token.token_type} ${token.access_token}`
        }
    })
        .then((response) => response.json())
        .then((data) => {
            const prefsWithChangedValues = [];

            Object.keys(data).forEach((key) => {
                if (key.match(/c_/g)) {
                    prefsWithChangedValues.push(key.replace(/c_/g, ''));
                }
            });

            const $attributeRows = doc.querySelectorAll(`#${groupId} .js-dw-attr-row`);

            $attributeRows.forEach(($row) => handleValuesChange(data, prefsWithChangedValues, $row));
            transitionAnimation(groupId).hide();
        })
        .catch(error => {
            alertHandler.showAlertMessage({
                type: 'danger',
                message: error.message
            });
        });
};

module.exports = {
    storeClientId,
    handlerInstanceType,
    savePreferencesHandler,
    fetchPropertyDescription
};
