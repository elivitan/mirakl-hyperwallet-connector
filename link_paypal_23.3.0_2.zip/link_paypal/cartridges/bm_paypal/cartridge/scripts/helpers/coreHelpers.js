'use strict';

/**
 * Pluralize
 * @param {number} value number value
 * @param {string} word word to pluralize
 * @param {string} plural word in plural
 * @returns {string} original or converted word
 */
function pluralize(value, word, plural) {
    return [1, -1].includes(Number(value)) ? word : (plural || word + 's');
}

/**
 * Sort array of objects by property
 * @param {Object[]} array array of objects
 * @param {string} property property of object
 * @returns {Object[]} array of objects
 */
function sortByProperty(array, property) {
    return array.sort(function(prev, next) {
        return prev[property] > next[property] ? 1 : -1;
    });
}

/**
 * Filter array of objects by property
 * @param {Object[]} array array of objects
 * @param {string} property property of object
 * @param {string} value by which value to filter
 * @returns {Object[]} filtered array of objects
 */
function filterByProperty(array, property, value) {
    return array.filter(function(item) {
        return item[property] === value;
    });
}

/**
 * Determines whether the given input is valid JSON or not.
 *
 * @param {string} input - The input value to check.
 * @returns {boolean} - `true` if the input is valid JSON, `false` otherwise.
 */
function isJson(input) {
    if (typeof input !== 'string') {
        return false;
    }

    try {
        const parsedJson = JSON.parse(input);
        const parsedType = Object.prototype.toString.call(parsedJson);

        return parsedType === '[object Object]' || parsedType === '[object Array]';
    } catch (error) {
        return false;
    }
}

/**
 * function to proceed a save parsing
 * @param {string} element string what should be parsed
 * @returns {Object} result of parsing
 */
function tryParseJSON(element) {
    let result;

    try {
        result = JSON.parse(element);
    } catch (error) {
        const Logger = require('dw/system/Logger');
        const logger = Logger.getLogger('PayPal-BM', 'PayPal_General');

        logger.error(['Unable to parse:  ', element, error.stack].join(' '));
    }

    return result;
}

/**
 * Returns the type of the instance
 * @returns {string} The type of the instance
 */
function getInstanceType() {
    const System = require('dw/system/System');
    const ppConstants = require('~/cartridge/config/paypalConstants');

    switch (System.instanceType) {
        case System.DEVELOPMENT_SYSTEM:
            return ppConstants.INSTANCE_DEVELOPMENT;
        case System.STAGING_SYSTEM:
            return ppConstants.INSTANCE_STAGING;
        case System.PRODUCTION_SYSTEM:
            return ppConstants.INSTANCE_PRODUCTION;
    }

    return '';
}

/**
 * Check Set Value
 * @param {mixed} value - Value
 * @returns {string} - The value passed is set or not
 */
function checkSetValue(value) {
    const Resource = require('dw/web/Resource');

    if (typeof value === 'string' && value.length) {
        return Resource.msg('value.set', 'paypalbm', null);
    }

    return Resource.msg('value.notset', 'paypalbm', null);
}

/**
 * Checks if the given value is an object excluding null.
 * Specifically checks for objects created using object literal notation or new Object.
 *
 * @param {*} obj - The value to check.
 * @returns {boolean} True if the value is an object excluding null; false otherwise.
 */
function isObject(obj) {
    return obj !== null && typeof obj === 'object' && Object.prototype.toString.call(obj) === '[object Object]';
}

module.exports = {
    isJson: isJson,
    isObject: isObject,
    pluralize: pluralize,
    sortByProperty: sortByProperty,
    filterByProperty: filterByProperty,
    tryParseJSON: tryParseJSON,
    getInstanceType: getInstanceType,
    checkSetValue: checkSetValue
};
