'use strict';

const URLUtils = require('dw/web/URLUtils');

module.exports = {
    testServiceConnection: URLUtils.url('ConfigCheck-TestServiceConnection').appendCSRFTokenBM().toString()
};
