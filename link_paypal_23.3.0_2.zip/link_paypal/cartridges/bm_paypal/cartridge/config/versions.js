'use strict';

const System = require('dw/system/System');
const ppConstants = require('~/cartridge/config/paypalConstants');
const coreHelpers = require('~/cartridge/scripts/helpers/coreHelpers');

module.exports = {
    SFRA: '6.3.0',
    PLUGIN: '23.3.0',
    PAYPAL: {
        PARTNER_ATTRIBUTION_ID: ppConstants.PARTNER_ATTRIBUTION_ID
    },
    INSTANCE_TYPE: coreHelpers.getInstanceType(),
    COMPATIBILITY_MODE: System.compatibilityMode
};
