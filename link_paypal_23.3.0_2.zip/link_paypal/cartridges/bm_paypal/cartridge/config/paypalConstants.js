'use strict';

module.exports = {
    // search types
    SEARCH_BY_TRANSACTION_ID: 'SEARCH_BY_TRANSACTION_ID',
    SEARCH_BY_ORDER_NUMBER: 'SEARCH_BY_ORDER_NUMBER',
    SEARCH_BY_PAYMENT_STATUS: 'SEARCH_BY_PAYMENT_STATUS',
    // intents
    INTENT_CAPTURE: 'CAPTURE',
    INTENT_AUTHORIZE: 'AUTHORIZE',
    // statuses
    STATUS_COMPLETED: 'COMPLETED',
    STATUS_CAPTURED: 'CAPTURED',
    STATUS_REFUNDED: 'REFUNDED',
    STATUS_CREATED: 'CREATED',
    STATUS_SAVED: 'SAVED',
    STATUS_VOIDED: 'VOIDED',
    STATUS_CANCELLED: 'CANCELLED',
    // payment actions
    PAYMENT_ACTION_AUTHORIZATION: 'Authorization',
    PAYMENT_ACTION_AUTHORIZE: 'authorize',
    PAYMENT_ACTION_CAPTURE: 'capture',
    // transaction actions
    ACTION_CREATE_TRANSACTION: 'CreateTransaction',
    ACTION_VOID: 'DoVoid',
    ACTION_REAUTHORIZE: 'DoReauthorize',
    ACTION_AUTHORIZE: 'DoAuthorize',
    ACTION_REFUND: 'DoRefundTransaction',
    ACTION_CAPTURE: 'DoCapture',
    // payment method id
    PAYMENT_METHOD_ID_PAYPAL: 'PayPal',
    PAYMENT_METHOD_ID_PAYPAL_CREDIT_CARD: 'PAYPAL_CREDIT_CARD',
    // service
    SERVICE_NAME: 'int_paypal.http.rest',
    // etc.
    UNKNOWN: 'Unknown',
    PARTNER_ATTRIBUTION_ID: 'SFCC_EC_B2C_23_3_0',
    ACTION_STATUS_SUCCESS: 'Success',
    TOKEN_TYPE_BILLING_AGREEMENT: 'BILLING_AGREEMENT',
    INVALID_CLIENT: 'invalid_client',
    // https://developer.paypal.com/docs/api/payments/v1/#definition-related_resources
    TRANSACTION_STATUSES: [
        'CREATED', 'PARTIALLY_CAPTURED', 'CAPTURED',
        'VOIDED', 'PENDING', 'AUTHORIZED', 'COMPLETED',
        'REFUNDED', 'PARTIALLY_REFUNDED', 'CANCELLED',
        'EXPIRED', 'DENIED', 'DECLINED', 'FAILED'
    ],
    TRANSACTION_FAILED_STATUSES: [
        'EXPIRED', 'DENIED', 'DECLINED', 'FAILED'
    ],
    // Instances
    INSTANCE_SANDBOX: 'sandbox',
    INSTANCE_STAGING: 'staging',
    INSTANCE_PRODUCTION: 'production',
    INSTANCE_DEVELOPMENT: 'development',
    VALUE_TYPE: {
        3: 'String',
        4: 'Text',
        5: 'HTML',
        1: 'Integer',
        2: 'Number',
        8: 'Boolean',
        6: 'Date',
        11: 'Date+Time',
        7: 'Image',
        12: 'Email',
        13: 'Password',
        23: 'Set of Strings',
        21: 'Set of Integers',
        22: 'Set of Numbers',
        33: 'Enum of Strings',
        31: 'Enum of Integers'
    },
    ERRORS_WHITE_LIST: [
        'INVALID_RESOURCE_ID',
        'REFUND_AMOUNT_EXCEEDED',
        'MAX_CAPTURE_AMOUNT_EXCEEDED'
    ]
};
