'use strict';

const currentSite = require('dw/system/Site').getCurrent();

const coreHelpers = require('~/cartridge/scripts/helpers/coreHelpers');

module.exports = {
    ocapiConfig: coreHelpers.tryParseJSON(currentSite.getCustomPreferenceValue('PP_OCAPI_Config')),
    webdavConfig: coreHelpers.tryParseJSON(currentSite.getCustomPreferenceValue('PP_WebDAV_Config'))
};
