'use strict';

/* global request response */

/**
 * Test service connection
 */
function testServiceConnection() {
    const Resource = require('dw/web/Resource');
    const responseHelper = require('*/cartridge/scripts/paypal/responseHelper');

    const result = {
        error: false,
        message: Resource.msg('testconnection.notificaion.success', 'paypalbm', null)
    };

    try {
        if (!(request.httpSecure && request.httpMethod === 'POST')) {
            throw new Error(Resource.msg('error.params.mismatch', 'commonbm', null));
        }

        if (!require('dw/web/CSRFProtection').validateRequest()) {
            throw new Error(Resource.msg('error.csrf.token.mismatch', 'commonbm', null));
        }

        const coreHelpers = require('~/cartridge/scripts/helpers/coreHelpers');
        const createPaypalRestService = require('*/cartridge/scripts/service/bmPaypalRestService');

        const service = createPaypalRestService();
        const path = 'v1/identity/openidconnect/userinfo?schema=openid';

        const serviceResult = service.call({
            method: 'GET',
            path: path
        });

        const serviceResponse = service.getResponse() || {
            msg: serviceResult.msg,
            error: serviceResult.error
        };

        result.service = {
            id: service.configuration.ID,
            status: serviceResult.status,
            request: service.requestData || path,
            response: JSON.stringify(serviceResponse),
            user: coreHelpers.checkSetValue(service.configuration.credential.user),
            password: coreHelpers.checkSetValue(service.configuration.credential.password)
        };

        const requestBody = coreHelpers.tryParseJSON(request.httpParameterMap.requestBodyAsString) || {};

        if (!serviceResult.ok || serviceResponse.error) {
            result.error = true;
            result.message = Resource.msg('testconnection.notificaion.failure', 'paypalbm', null);

            if (requestBody.isExport) {
                result.message = Resource.msg('configcheck.export.testconnection.failure', 'paypalbm', null);
            }
        }

        responseHelper.renderJson(result);
    } catch (error) {
        response.setStatus(400);

        const paypalUtils = require('*/cartridge/scripts/paypal/bmPaypalUtils');

        error.name = Object.getPrototypeOf(error).name;
        paypalUtils.createErrorLog(JSON.stringify(error, null, 4));

        result.error = true;
        result.message = error.message;

        responseHelper.renderJson(result);
    }
}

testServiceConnection.public = true;

exports.TestServiceConnection = testServiceConnection;
