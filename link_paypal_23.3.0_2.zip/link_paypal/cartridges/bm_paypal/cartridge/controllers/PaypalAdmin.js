'use strict';

/* global dw request response empty */

const Resource = require('dw/web/Resource');
const CSRFProtection = require('dw/web/CSRFProtection');
const currentSite = require('dw/system/Site').getCurrent();

const paypalUtils = require('*/cartridge/scripts/paypal/bmPaypalUtils');
const paypalHelper = require('*/cartridge/scripts/paypal/bmPaypalHelper');
const ppConstants = require('*/cartridge/config/paypalConstants');
const responseHelper = require('*/cartridge/scripts/paypal/responseHelper');

const PPOrderMgrModel = require('*/cartridge/models/ppOrderMgr');
const PPOrdersPagingModel = require('*/cartridge/models/ppOrdersPaging');
const PPTransactionMgrModel = require('*/cartridge/models/ppTransactionMgr');
const PPTransactionModel = require('*/cartridge/models/ppTransaction');
const PPTransactionActions = require('*/cartridge/models/ppTransactionActions');

const hm = request.httpParameterMap;
const PAYPAL_SERVER_ERROR = 'paypalbm/components/serverError';
const ppTransactionActions = new PPTransactionActions();

/**
 * Show template with create new transaction form
 */
function renderNewTransactionForm() {
    const invNum = paypalHelper.createCustomTransactionInvNum();
    const isCapture = currentSite.getCustomPreferenceValue('PP_Payment_Model').value === 'Sale';
    const allCurrencies = currentSite.getAllowedCurrencies();
    const defaultCurrency = currentSite.getDefaultCurrency();
    const countries = paypalHelper.getCountriesLabelsAndCodes();

    responseHelper.render('paypalbm/components/newTransaction', {
        CSRFProtection: CSRFProtection,
        invNum: invNum,
        isCapture: isCapture,
        allCurrencies: allCurrencies,
        defaultCurrency: defaultCurrency,
        countries: countries
    });
}

/**
 * Get orders list. Can be filtered by order number or transaction ID
 * @returns {Function} template render function call with required data
 */
function orders() {
    let orderPagingModel;
    let orderPagingModelParameters;
    let ordersList;
    let paymentStatuses;
    let transactionStatistics;
    let isSearchByOrderNo = hm.orderNo.submitted;
    const isSearchByTransaction = hm.transactionId.submitted;
    const isSearchByPaymentStatus = hm.paymentStatus.submitted;
    const ppOrderMgrModel = new PPOrderMgrModel();
    const ppOrdersPagingModel = new PPOrdersPagingModel();

    try {
        // if search query inputs are empty get full orders list
        if (paypalHelper.isSearchQueryEmpty(hm.transactionId, hm.orderNo, hm.paymentStatus)) {
            ordersList = ppOrderMgrModel.getAllOrders();
        } else {
            // define search type based on submitted search query
            const searchType = paypalHelper.getSearchType(hm.transactionId, hm.paymentStatus);

            switch (searchType) {
                case ppConstants.SEARCH_BY_TRANSACTION_ID:
                    ordersList = ppOrderMgrModel.getOrderByTransactionId(hm.transactionId.stringValue);

                    break;
                case ppConstants.SEARCH_BY_ORDER_NUMBER:
                    ordersList = ppOrderMgrModel.getOrderByOrderNo(hm.orderNo.stringValue);

                    break;
                case ppConstants.SEARCH_BY_PAYMENT_STATUS:
                    ordersList = ppOrderMgrModel.getOrderByPaymentStatus(hm.paymentStatus.stringValue);

                    break;
                default:
                    break;
            }
        }

        orderPagingModel = ppOrdersPagingModel.createPagingModel(ordersList, hm.page, hm.pagesize);
        orderPagingModelParameters = ppOrdersPagingModel.createOrderPagingModelParameters(orderPagingModel, hm);

        transactionStatistics = paypalHelper.getPaymentStatusTransactionStatistics();
        paymentStatuses = transactionStatistics.map(function(paymentStatus) {
            return { value: paymentStatus.value, label: paymentStatus.label, count: paymentStatus.count };
        }).sort(function(prevPaymentStatus, nextPaymentStatus) {
            return prevPaymentStatus.value > nextPaymentStatus.value ? 1 : -1;
        });
    } catch (error) {
        paypalUtils.createErrorLog(error);

        return responseHelper.render(PAYPAL_SERVER_ERROR);
    }

    // set which tab must be shown in case of first list render
    if (!isSearchByOrderNo && !isSearchByTransaction && !isSearchByPaymentStatus) {
        isSearchByOrderNo = true;
    }

    return responseHelper.render('paypalbm/orderList', {
        PagingModel: orderPagingModel,
        paymentStatuses: paymentStatuses,
        transactionStatistics: transactionStatistics,
        isSearchByOrderNo: isSearchByOrderNo,
        isSearchByTransaction: isSearchByTransaction,
        isSearchByPaymentStatus: isSearchByPaymentStatus,
        orderPagingModelParameters: orderPagingModelParameters
    });
}

/**
 * Get order transaction details
 * @returns {Function} template render function call with required data
 */
function orderTransaction() {
    let ppTransactionModel;
    // order transaction created via "New Transaction" form in BM
    const isCustomOrder = hm.isCustomOrder && !empty(hm.isCustomOrder.stringValue);
    const ppOrderMgrModel = new PPOrderMgrModel();
    const ppTransactionMgrModel = new PPTransactionMgrModel();

    try {
        const { order, transactionIdFromOrder } = ppOrderMgrModel.getOrderData(isCustomOrder, hm.orderNo.stringValue, hm.orderToken.stringValue);

        const transaction = ppTransactionMgrModel.getTransactionData(hm, transactionIdFromOrder);

        // expand transaction object with required data for actions and transaction view
        ppTransactionModel = new PPTransactionModel(transaction, order, isCustomOrder);
    } catch (error) {
        return responseHelper.render(PAYPAL_SERVER_ERROR, { errorMessage: error.message });
    }

    return responseHelper.render('paypalbm/orderTransaction', {
        transaction: ppTransactionModel
    });
}

/**
 * Process extended authorization
 * @returns {Function} template render function call with required data
 */
function extendedAuthorization() {
    const OrderMgr = require('dw/order/OrderMgr');
    const PPOrderModel = require('*/cartridge/models/ppOrder');
    const ppOrderModel = new PPOrderModel();
    const order = OrderMgr.getOrder(hm.orderNo);
    const orderToken = order.getOrderToken();
    const ppOrderID = ppOrderModel.getTransactionIdFromOrder(order);

    return responseHelper.render('paypalbm/components/extendedAuthorizationForm', {
        orderAmount: order.totalGrossPrice.value,
        currencycode: order.totalGrossPrice.currencyCode,
        ppOrderId: ppOrderID,
        orderNo: hm.orderNo,
        orderToken: orderToken
    });
}

/**
 * Do some action, like DoAuthorize, DoCapture, DoRefund and etc
 * @returns {Function} template render function call with required data
 */
function action() {
    const reqData = {};
    let callApiResponse = {};
    let responseResult = 'Success';

    if (!CSRFProtection.validateRequest()) {
        const errorMsg = {
            l_longmessage0: Resource.msg('transaction.action.token.mismatch', 'paypalbm', null)
        };

        return responseHelper.renderJson('Error', errorMsg);
    }

    const methodName = hm.methodName.stringValue;

    hm.parameterNames.toArray().forEach(function(name) {
        reqData[name] = hm[name].toString();
    });

    switch (methodName) {
        // case via "New Transaction" form in BM
        case ppConstants.ACTION_CREATE_TRANSACTION:
            callApiResponse = ppTransactionActions.createTransactionAction(reqData);

            break;
        case ppConstants.ACTION_VOID:
            callApiResponse = ppTransactionActions.voidAction(reqData);

            break;
        case ppConstants.ACTION_REAUTHORIZE:
            callApiResponse = ppTransactionActions.reauthorizeAction(reqData);

            break;
        case ppConstants.ACTION_REFUND:
            callApiResponse = ppTransactionActions.refundTransactionAction(reqData);

            break;
        case ppConstants.ACTION_CAPTURE:
            callApiResponse = ppTransactionActions.captureAction(reqData);

            break;

        case ppConstants.ACTION_AUTHORIZE:
            const orderAmount = reqData.orderAmount;

            let reqAuthAmount = parseFloat(reqData['item-amount']);

            if (isNaN(reqAuthAmount)) {
                reqAuthAmount = orderAmount;
            }

            // The authorization amount shouldn't be greater than the order amount
            const authAmount = (reqAuthAmount > orderAmount) ? orderAmount : reqAuthAmount;

            callApiResponse = ppTransactionActions.authorizeAction(reqData, authAmount.toFixed(2));

            paypalHelper.saveTransationRequestAndResponse(reqData, callApiResponse);

            let responseData = {};

            if (callApiResponse.err) {
                responseResult = 'Error';
            } else {
                responseData = {
                    ack: 'Success',
                    details: {
                        status: callApiResponse.status,
                        action: reqData.methodName,
                        orderNo: reqData.orderNo
                    }
                };
            }

            return responseHelper.renderJson(responseResult, responseData);

        default:
            break;
    }

    paypalHelper.saveTransationRequestAndResponse(reqData, callApiResponse);

    if (!callApiResponse.err) {
        paypalHelper.saveTransactionHistory(reqData, callApiResponse);
    }

    if (callApiResponse.err) {
        responseResult = 'Error';
    }

    let isCustomOrder;

    try {
        isCustomOrder = JSON.parse(reqData.isCustomOrder);
    } catch (error) {
        paypalUtils.createErrorLog(error);

        return responseHelper.render(PAYPAL_SERVER_ERROR, { errorMessage: error });
    }

    if (!isCustomOrder) {
        const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/bmPaymentInstrumentHelper');

        paymentInstrumentHelper.updatePaypalPaymentInstrument(hm, isCustomOrder);
    }

    return responseHelper.renderJson(responseResult, callApiResponse.responseData);
}

orders.public = true;
orderTransaction.public = true;
action.public = true;
renderNewTransactionForm.public = true;
extendedAuthorization.public = true;

exports.Orders = orders;
exports.OrderTransaction = orderTransaction;
exports.Action = action;
exports.RenderNewTransactionForm = renderNewTransactionForm;
exports.ExtendedAuthorization = extendedAuthorization;
