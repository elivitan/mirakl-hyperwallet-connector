'use strict';

/* global request response */

const Resource = require('dw/web/Resource');

const responseHelper = require('~/cartridge/scripts/paypal/responseHelper');
const customPreferencesConfig = require('~/cartridge/config/customPreferencesConfig');

const DEFAULT_ROWS = 10;
const NUMBER_OF_CURLY_BRACES = 2;

/**
 * Set Predefined Values
 * @param {dw.system.Site} currentSite - Current site
 * @returns {void}
 */
function setPredefinedValues(currentSite) {
    const Transaction = require('dw/system/Transaction');

    Transaction.wrap(function() {
        ['PP_OCAPI_Config', 'PP_WebDAV_Config'].forEach(function(name) {
            if (currentSite.getCustomPreferenceValue(name) === null) {
                currentSite.setCustomPreferenceValue(name, '{}');
            }
        });
    });
}

/**
 * Get site preference groups
 */
function groups() {
    const currentSite = require('dw/system/Site').current;

    setPredefinedValues(currentSite);

    const prefs = require('~/cartridge/config/paypalPreferences');
    const activeTabs = customPreferencesConfig.sections.reduce(function(accum, value) {
        const attributeGroup = currentSite.preferences.describe().getAttributeGroup(value.groupId);

        accum[value.groupId] = !!attributeGroup;

        return accum;
    }, {});

    responseHelper.render('preferences/preferenceList', {
        activeTabs: activeTabs,
        customPreferencesConfig: customPreferencesConfig,
        relations: JSON.stringify(customPreferencesConfig.relations),
        apiConfig: JSON.stringify({ ocapi: prefs.ocapiConfig, webdav: prefs.webdavConfig }),
        testConnectionUrl: require('~/cartridge/config/paypalUrls').testServiceConnection,
        additionalData: JSON.stringify(require('~/cartridge/config/versions')),
        resources: JSON.stringify({
            submit: Resource.msg('forms.submit', 'paypalbm', null),
            cancel: Resource.msg('forms.cancel', 'paypalbm', null),
            pleaseWait: Resource.msg('msg.pleasewait', 'paypalbm', null),
            modalTitle: Resource.msg('configcheck.modal.title', 'paypalbm', null),
            exportAllSuccess: Resource.msg('configcheck.export.success', 'paypalbm', null),
            exportAllFailure: Resource.msg('configcheck.export.failure', 'paypalbm', null),
            exportSomeFailure: Resource.msg('configcheck.export.some.failure', 'paypalbm', null),
            exportGeneralSuccess: Resource.msg('configcheck.export.general.success', 'paypalbm', null)
        })
    });
}

/**
 * Site preference by group id
 * @returns {mixed} responce
 */
function group() {
    if (!request.includeRequest) {
        return responseHelper.render('preferences/error', {
            errorMessage: Resource.msg('error.params.mismatch', 'commonbm', null)
        });
    }

    const Site = require('dw/system/Site');
    const currentSite = Site.current;

    const typeDefinition = currentSite.preferences.describe();
    const groupId = request.httpParameterMap.group_id.stringValue;
    const attributeGroup = typeDefinition.getAttributeGroup(groupId);

    if (!attributeGroup) {
        return responseHelper.render('preferences/error', {
            errorMessage: Resource.msgf('preference.incorrect.groupid', 'paypalbm', null, groupId)
        });
    }

    let paymentMethod;
    const attributeValues = {};

    const CSRFProtection = require('dw/web/CSRFProtection');
    const ObjectAttributeDefinition = require('dw/object/ObjectAttributeDefinition');

    const coreHelpers = require('~/cartridge/scripts/helpers/coreHelpers');

    const attributeDefinitions = attributeGroup.attributeDefinitions.toArray();

    attributeDefinitions.forEach(function(attribute) {
        const value = currentSite.getCustomPreferenceValue(attribute.ID);

        attributeValues[attribute.ID] = {
            value: value instanceof dw.value.EnumValue ? value.getValue() : value
        };

        if (attribute.valueTypeCode === ObjectAttributeDefinition.VALUE_TYPE_TEXT) {
            attributeValues[attribute.ID].rows = coreHelpers.isJson(value)
                ? Object.keys(coreHelpers.tryParseJSON(value)).length + NUMBER_OF_CURLY_BRACES
                : DEFAULT_ROWS;
        }
    });

    const section = customPreferencesConfig.sections.find(function(item) {
        return item.groupId === groupId;
    });

    if (section.paymentMethodId) {
        const paypalHelper = require('~/cartridge/scripts/paypal/bmPaypalHelper');

        paymentMethod = paypalHelper.getPaymentMethod(section.paymentMethodId);
    }

    return responseHelper.render('preferences/preferenceGroup', {
        paymentMethod: paymentMethod,
        attributeGroup: attributeGroup,
        attributeValues: attributeValues,
        attributeConstants: ObjectAttributeDefinition,
        attributeDefinitions: attributeDefinitions,
        valueType: require('~/cartridge/config/paypalConstants').VALUE_TYPE,
        csrf: {
            tokenName: CSRFProtection.getTokenName(),
            token: CSRFProtection.generateToken()
        }
    });
}

group.public = true;
groups.public = true;

exports.Group = group;
exports.Groups = groups;
