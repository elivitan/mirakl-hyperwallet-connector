/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./cartridges/bm_paypal/cartridge/client/default/js/configCheck.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/components/alertHandler.js":
/*!*************************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/components/alertHandler.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// eslint-disable-next-line no-unused-vars
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var AlertHandlerModel = /*#__PURE__*/function () {
  function AlertHandlerModel() {
    _classCallCheck(this, AlertHandlerModel);
    this.$alertsContainer = document.querySelector('.js-flash-messages-container');
  }

  /**
   * Appends Alerts message
   * Avaible alerts types:
   * primary,  secondary, success, danger, warning, info, alert, dark
   * @param {Object} alert Alerts and type messages
   */
  _createClass(AlertHandlerModel, [{
    key: "showAlertMessage",
    value: function showAlertMessage(alert) {
      var $alertTemplate = document.querySelector('.js-alert-template');
      var $alertContainer = $alertTemplate.cloneNode(true);
      $alertContainer.append(alert.message);
      this.$alertsContainer.append($alertContainer);
      $alertContainer.classList.add("alert-".concat(alert.type), 'show');
      $alertContainer.classList.remove('d-none');
    }

    /**
     * Fades Alerts message
     */
  }, {
    key: "fadeAlerts",
    value: function fadeAlerts() {
      var $alertContainers = document.querySelectorAll('.js-alert-template');
      $alertContainers.forEach(function (alert) {
        return alert.classList.add('d-none');
      });
    }

    /**
     * Closes an alert message
     */
  }, {
    key: "closeAlert",
    value: function closeAlert() {
      this.$alertsContainer.addEventListener('click', function (e) {
        if (e.target.parentElement.type === 'button') {
          var closeBtn = e.target.parentElement;
          closeBtn.parentElement.remove();
        }
      });
    }
  }]);
  return AlertHandlerModel;
}();
module.exports = AlertHandlerModel;

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck.js":
/*!*************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/configCheck.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(/*! ./configCheck/configCheck */ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/configCheck.js");

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/configCheck.js":
/*!*************************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/configCheck/configCheck.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/* eslint-disable no-console */
var Jobs = __webpack_require__(/*! ./jobs */ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/jobs.js");
var Modal = __webpack_require__(/*! ./modal */ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/modal.js");
var ProgressBarModel = __webpack_require__(/*! ./progressBar */ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/progressBar.js");
var WebDAV = __webpack_require__(/*! ./webdav */ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/webdav.js");
var OpenCommerceAPI = __webpack_require__(/*! ./ocapi */ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/ocapi.js");
var AlertHandlerModel = __webpack_require__(/*! ../components/alertHandler */ "./cartridges/bm_paypal/cartridge/client/default/js/components/alertHandler.js");
(function (win, doc) {
  var alertHandler = new AlertHandlerModel();
  var $configCheck = doc.querySelector('.js-config-check');
  var config = JSON.parse($configCheck.dataset.apiConfig);
  var resources = JSON.parse($configCheck.dataset.resources);
  var additionalData = JSON.parse($configCheck.dataset.additionalData);
  var testConnectionUrl = $configCheck.dataset.testConnectionUrl;
  var OCAPI = new OpenCommerceAPI(config.ocapi);
  var ProgressBar;
  var modal;

  /**
   * Handle download archive file
   * @param {string} fileName - file name
   * @returns {void}
   */
  var handleDownloadFile = function handleDownloadFile(fileName) {
    var link = document.createElement('a');
    var WebDav = new WebDAV(config.webdav);
    WebDav.get("impex/src/instance/".concat(fileName)).then(function (response) {
      return response.blob();
    }).then(function (blob) {
      link.href = URL.createObjectURL(blob);
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(link.href);
    }).catch(function (error) {
      throw new Error("Error downloading the ZIP file: ".concat(error.message));
    });
  };

  /**
   * Handle Generate Plugin Configuration
   * @param {Object} formData - form data object
   * @returns {void}
   */
  var handleGenerateConfig = function handleGenerateConfig(formData) {
    var jobs = new Jobs(OCAPI, ProgressBar, resources);
    var selectedConfig = Object.keys(formData).filter(function (key) {
      return typeof formData[key] === 'boolean' && formData[key] === true;
    });
    var totalSelected = selectedConfig.length;
    jobs.handleExportSite(formData).then(function (isExportFinished) {
      console.log('isExportFinished', isExportFinished);
      if (isExportFinished) {
        return jobs.archiveFileProcessing(formData);
      }
      return isExportFinished;
    }).then(function (isChangesCompleted) {
      console.log('isChangesCompleted', isChangesCompleted);
      if (isChangesCompleted) {
        handleDownloadFile(formData.fileName);
        modal.close();
        alertHandler.showAlertMessage({
          type: 'success',
          message: resources["export".concat(totalSelected > 1 ? 'All' : 'General', "Success")]
        });
      }
    }).catch(function (error) {
      var hasFiles = error.message.includes('file(s)');
      if (hasFiles) {
        handleDownloadFile(formData.fileName);
      }
      alertHandler.showAlertMessage({
        type: hasFiles ? 'caution' : 'warning',
        message: error.message
      });
      modal.close();
    });
  };

  /**
   * Handle Test Connection
   * @param {boolean} isExport - True if this is an export process, otherwise false
   * @returns {void}
   */
  var handleTestConnection = function handleTestConnection() {
    var isExport = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
    alertHandler.fadeAlerts();
    return fetch(testConnectionUrl, {
      method: 'POST',
      body: JSON.stringify({
        isExport: isExport
      })
    }).then(function (response) {
      return response.json();
    });
  };

  /**
   * Handle Submit Form
   * @param {Object} form - Form element
   * @returns {void}
   */
  var handleSubmitForm = function handleSubmitForm(form) {
    if (!form.checkValidity()) {
      form.reportValidity();
    } else {
      var isExport = true;
      var processedData = {};
      Array.from(form.elements).forEach(function (element) {
        processedData[element.name] = element.type === 'checkbox' ? element.checked : element.value;
      });
      ProgressBar.showProgressBar();
      handleTestConnection(isExport).then(function (response) {
        var STEP_ID = 'test-connection';
        var result = response.result;
        if (result.error) {
          alertHandler.showAlertMessage({
            message: result.message,
            type: 'warning'
          });
        }
        processedData.connectionData = result;
        processedData.additionalData = additionalData;
        ProgressBar.handleProgressBarNextStep(STEP_ID);
        handleGenerateConfig(processedData);
      });
    }
  };

  /**
   * Handle Modal window
   * @returns {void}
   */
  var handleModal = function handleModal() {
    var $form;
    var $formTemplate = doc.querySelector('.js-form-template');
    modal = new Modal({
      title: resources.modalTitle,
      width: 600,
      height: 471,
      html: $formTemplate.innerHTML,
      modal: true,
      autoScroll: true,
      listeners: {
        show: function show() {
          $form = doc.querySelector('.js-form-generate-config');
          $form.addEventListener('submit', function (event) {
            return event.preventDefault();
          });
        }
      },
      buttons: [{
        text: resources.submit,
        handler: function handler() {
          handleSubmitForm($form);
        }
      }, {
        text: resources.cancel,
        handler: function handler() {
          modal.close();
        }
      }]
    });
    ProgressBar = new ProgressBarModel(modal, '.js-progress-bar-template');
    win.addEventListener('resize', function () {
      modal.center();
    });
    win.addEventListener('orientationchange', function () {
      modal.center();
    });
    modal.show();
  };
  doc.addEventListener('DOMContentLoaded', function () {
    var $buttonTestConnection = doc.querySelector('.js-test-connection');
    var $buttonGenerateConfig = doc.querySelector('.js-generate-config');
    $buttonGenerateConfig.addEventListener('click', handleModal);
    $buttonTestConnection.addEventListener('click', function () {
      handleTestConnection().then(function (response) {
        var result = response.result;
        alertHandler.showAlertMessage({
          message: result.message,
          type: result.error ? 'warning' : 'success'
        });
      });
    });
  });
})(window, document);

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/jobs.js":
/*!******************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/configCheck/jobs.js ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/* eslint-disable no-console */
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var Jobs = /*#__PURE__*/function () {
  function Jobs(OCAPI, ProgressBar, resources) {
    _classCallCheck(this, Jobs);
    this.OCAPI = OCAPI;
    this.interval = 2000;
    this.maxAttempts = 10;
    this.resources = resources;
    this.ProgressBar = ProgressBar;
  }

  /**
   * Handle Job Execution Fault
   * @param {Object} jobExecution - Job Execution
   * @returns {void}
   */
  _createClass(Jobs, [{
    key: "handleJobExecutionFault",
    value: function handleJobExecutionFault(jobExecution) {
      var errorMessage = this.resources.exportAllFailure;
      if (jobExecution.fault) {
        throw new Error("".concat(jobExecution.fault.type, ": ").concat(jobExecution.fault.message));
      }
      if (jobExecution.status === 'ERROR') {
        var _jobExecution$step_ex = _slicedToArray(jobExecution.step_executions, 1),
          exit_status = _jobExecution$step_ex[0].exit_status;
        if (exit_status) {
          var message = exit_status.message;
          var indexStart = message.indexOf('{{');
          var indexEnd = message.indexOf('}}');
          if (![indexStart, indexEnd].includes(-1)) {
            message = message.substring(indexStart + 2, indexEnd);
            try {
              var fileList = JSON.parse(message).map(function (item) {
                return item.file;
              }).join(', ');
              if (fileList) {
                errorMessage = this.resources.exportSomeFailure.replace('{0}', fileList);
              }
            } catch (error) {
              console.error(error);
            }
          }
        }
        throw new Error(errorMessage);
      }
    }

    /**
     * Check Site Export With Limited Attempts
     * @param {string} jobId - Job ID
     * @param {number} id - Job execude id
     * @param {number} interval - Interval of checks in seconds
     * @param {number} maxAttempts - Max tries
     * @returns {Promise} - Promise
     */
  }, {
    key: "checkSiteExportWithLimitedAttempts",
    value: function checkSiteExportWithLimitedAttempts(jobId, id, interval, maxAttempts) {
      var _this = this;
      var attempt = 0;
      return new Promise(function (resolve, reject) {
        /** @returns {void} */
        var checkSiteExportWithInterval = function checkSiteExportWithInterval() {
          _this.OCAPI.jobStatus(jobId, id).then(function (jobExecution) {
            attempt++;
            console.log('checkSiteExportWithInterval', jobExecution);
            _this.handleJobExecutionFault(jobExecution);
            if (jobExecution.status === 'OK' && jobExecution.execution_status === 'finished') {
              _this.ProgressBar.handleProgressBarNextStep(jobId);
              resolve(true);
            }
            if (jobExecution.status === 'RUNNING') {
              if (attempt < maxAttempts) {
                setTimeout(function () {
                  checkSiteExportWithInterval();
                }, interval);
              } else {
                throw new Error('The maximum number of attempts has been reached.');
              }
            }
          }).catch(function (error) {
            return reject(error);
          });
        };
        checkSiteExportWithInterval();
      });
    }

    /**
     * Handle Export Site Archive
     * @param {Object} formData - Form Data Object
     * @returns {boolean|Promise} - result
     */
  }, {
    key: "handleExportSite",
    value: function handleExportSite(formData) {
      var _this2 = this;
      var jobId = 'sfcc-site-archive-export';
      return this.OCAPI.runJob(jobId, {
        data_units: {
          global_data: {
            services: formData.services,
            preferences: true,
            system_type_definitions: formData.systemTypeDefinitions
          },
          sites: _defineProperty({}, formData.siteId, {
            shipping: true,
            site_descriptor: true,
            site_preferences: true,
            payment_methods: formData.paymentMethods,
            payment_processors: formData.paymentMethods
          })
        },
        export_file: formData.fileName,
        overwrite_export_file: true
      }).then(function (jobExecution) {
        console.log(jobExecution.job_id, jobExecution);
        _this2.handleJobExecutionFault(jobExecution);
        return _this2.checkSiteExportWithLimitedAttempts(jobId, jobExecution.id, _this2.interval, _this2.maxAttempts);
      });
    }

    /**
     * Archive File Processing
     * @param {Object} formData - Form Data Object
     * @returns {boolean|Promise} - result
     */
  }, {
    key: "archiveFileProcessing",
    value: function archiveFileProcessing(formData) {
      var _this3 = this;
      var jobId = 'PpConfigCheckSiteArchiveProcessing';
      var connectionData = formData.connectionData;
      delete formData.connectionData;
      return this.OCAPI.runJob(jobId, {
        // JobExecutionParameter
        parameters: [{
          name: 'Options',
          // maxLength=256, minLength=1,
          value: JSON.stringify(formData) // maxLength=1000, minLength=0
        }, {
          name: 'ConnectionData',
          // maxLength=256, minLength=1,
          value: JSON.stringify(connectionData) // maxLength=1000, minLength=0
        }]
      }).then(function (jobExecution) {
        console.log(jobExecution.job_id, jobExecution);
        _this3.handleJobExecutionFault(jobExecution);
        return _this3.checkSiteExportWithLimitedAttempts(jobId, jobExecution.id, _this3.interval, _this3.maxAttempts);
      });
    }
  }]);
  return Jobs;
}();
module.exports = Jobs;

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/modal.js":
/*!*******************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/configCheck/modal.js ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Modal
 * @class
 */
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var Modal = /*#__PURE__*/function () {
  /**
   * @param {Object} options - Options for Ext Window component
   */
  function Modal(options) {
    _classCallCheck(this, Modal);
    this.modal = new Ext.Window(options);
  }

  /**
   * Show modal
   * @returns {void}
   */
  _createClass(Modal, [{
    key: "show",
    value: function show() {
      this.modal.show();
    }

    /**
     * Close modal
     * @returns {void}
     */
  }, {
    key: "close",
    value: function close() {
      this.modal.close();
    }

    /**
     * Center modal
     * @returns {void}
     */
  }, {
    key: "center",
    value: function center() {
      var windowWidth = window.innerWidth - 30;
      var windowHeight = window.innerHeight - 30;
      this.modal.setHeight('auto');
      if (this.modal.width > windowWidth) {
        this.modal.setWidth(windowWidth);
      }
      if (this.modal.height > windowHeight) {
        this.modal.setHeight(windowHeight);
      }
      this.modal.center();
    }
  }]);
  return Modal;
}();
module.exports = Modal;

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/ocapi.js":
/*!*******************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/configCheck/ocapi.js ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Open Commerce API (OCAPI)
 */
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var OpenCommerceAPI = /*#__PURE__*/function () {
  /**
   * @constructor
   * @param {Object} options - Options
   */
  function OpenCommerceAPI(options) {
    _classCallCheck(this, OpenCommerceAPI);
    this.options = options;
    this.accessToken = {};
    this.expirationTime = 0;
    this.contentType = {
      json: 'application/json;charset=UTF-8',
      formUrlencoded: 'application/x-www-form-urlencoded;charset=UTF-8'
    };
  }

  /**
   * Convert object To FormData
   * @param {Object} obj - Object
   * @returns {string} - result
   */
  _createClass(OpenCommerceAPI, [{
    key: "objectToFormData",
    value: function objectToFormData(obj) {
      var formData = new URLSearchParams();
      for (var key in obj) {
        formData.append(key, obj[key]);
      }
      return formData.toString();
    }

    /**
     * Authorize in BM
     * @returns {void}
     */
  }, {
    key: "authorizeBM",
    value: (function () {
      var _authorizeBM = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var requestBody, path, auth, requestOptions;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              requestBody = this.objectToFormData({
                grant_type: 'urn:demandware:params:oauth:grant-type:client-id:dwsid:dwsecuretoken'
              });
              path = '/dw/oauth2/access_token?client_id=' + this.options.clientId;
              auth = btoa("".concat(this.options.bmUserLogin, ":").concat(this.options.bmUserPassword, ":").concat(this.options.clientPassword));
              requestOptions = {
                method: 'POST',
                headers: {
                  Authorization: "Basic ".concat(auth),
                  'Content-Type': this.contentType.formUrlencoded
                },
                body: requestBody
              };
              _context.next = 6;
              return this.request(path, requestOptions);
            case 6:
              this.accessToken = _context.sent;
              this.expirationTime = Date.now() + this.accessToken.expires_in * 1000;
            case 8:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
      function authorizeBM() {
        return _authorizeBM.apply(this, arguments);
      }
      return authorizeBM;
    }()
    /**
     * Get result for Authorization header
     * @returns {string} - Authorization
     */
    )
  }, {
    key: "getAuthorizationHeader",
    value: (function () {
      var _getAuthorizationHeader = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              if (!(Date.now() >= this.expirationTime)) {
                _context2.next = 3;
                break;
              }
              _context2.next = 3;
              return this.authorizeBM();
            case 3:
              return _context2.abrupt("return", "".concat(this.accessToken.token_type, " ").concat(this.accessToken.access_token));
            case 4:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
      function getAuthorizationHeader() {
        return _getAuthorizationHeader.apply(this, arguments);
      }
      return getAuthorizationHeader;
    }()
    /**
     * Get Job Execution status
     * @param {string} jobId - Job ID
     * @param {number} executionId - Execution ID
     * @returns {Promise} - Promise
     */
    )
  }, {
    key: "jobStatus",
    value: (function () {
      var _jobStatus = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3(jobId, executionId) {
        var path, requestOptions;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              path = "".concat(this.getDataPath(), "/jobs/").concat(jobId, "/executions/").concat(executionId);
              _context3.next = 3;
              return this.getAuthorizationHeader();
            case 3:
              _context3.t0 = _context3.sent;
              _context3.t1 = {
                Authorization: _context3.t0
              };
              requestOptions = {
                method: 'GET',
                headers: _context3.t1
              };
              return _context3.abrupt("return", this.request(path, requestOptions));
            case 7:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this);
      }));
      function jobStatus(_x, _x2) {
        return _jobStatus.apply(this, arguments);
      }
      return jobStatus;
    }()
    /**
     * Execute Job by Job ID
     * @param {string} jobId - Job ID
     * @param {Object} properties - Request body
     * @returns {Promise} - Promise
     */
    )
  }, {
    key: "runJob",
    value: (function () {
      var _runJob = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4(jobId, properties) {
        var requestBody, path, requestOptions;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              requestBody = properties && Object.keys(properties).length ? JSON.stringify(properties) : null;
              path = "".concat(this.getDataPath(), "/jobs/").concat(jobId, "/executions");
              _context4.next = 4;
              return this.getAuthorizationHeader();
            case 4:
              _context4.t0 = _context4.sent;
              _context4.t1 = this.contentType.json;
              _context4.t2 = {
                Authorization: _context4.t0,
                'Content-Type': _context4.t1
              };
              _context4.t3 = requestBody;
              requestOptions = {
                method: 'POST',
                headers: _context4.t2,
                body: _context4.t3
              };
              return _context4.abrupt("return", this.request(path, requestOptions));
            case 10:
            case "end":
              return _context4.stop();
          }
        }, _callee4, this);
      }));
      function runJob(_x3, _x4) {
        return _runJob.apply(this, arguments);
      }
      return runJob;
    }()
    /**
     * Send the request
     * @param {string} path - URL path
     * @param {Object} options - Request data
     * @returns {Promise<Response>} - Promise
     */
    )
  }, {
    key: "request",
    value: function request(path, options) {
      var url = new URL(path, location.origin);
      return fetch(url, options).then(function (response) {
        return response.json();
      });
    }

    /**
     * Version
     * @returns {string} - Version
     */
  }, {
    key: "getVersion",
    value: function getVersion() {
      return "v".concat(this.options.apiVersion.replace('.', '_'));
    }

    /**
     * Data Path
     * @returns {string} - Data path
     */
  }, {
    key: "getDataPath",
    value: function getDataPath() {
      return "/s/-/dw/data/".concat(this.getVersion());
    }
  }]);
  return OpenCommerceAPI;
}();
module.exports = OpenCommerceAPI;

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/progressBar.js":
/*!*************************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/configCheck/progressBar.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var ProgressBar = /*#__PURE__*/function () {
  function ProgressBar(modal, selector) {
    _classCallCheck(this, ProgressBar);
    this.modal = modal;
    this.progressBar = document.querySelector(selector);
    this.IS_ACTIVE = 'is-active';
    this.IS_DISABLED = 'is-disabled';
  }

  /**
   * Handle Progress Bar Steps
   * @param {string} stepId - progress bar step id
   * @returns {void}
   */
  _createClass(ProgressBar, [{
    key: "handleProgressBarNextStep",
    value: function handleProgressBarNextStep(stepId) {
      var currentStep = document.querySelector("[data-step-id='".concat(stepId, "'"));
      var nextStep = currentStep.nextElementSibling;
      currentStep.classList.remove(this.IS_ACTIVE);
      currentStep.classList.add(this.IS_DISABLED);
      if (nextStep) {
        nextStep.classList.add(this.IS_ACTIVE);
      }
    }

    /**
     * Shows the progress bar
     * @returns {void}
     */
  }, {
    key: "showProgressBar",
    value: function showProgressBar() {
      this.modal.modal.body.update(this.progressBar.innerHTML);
      this.modal.modal.buttons.forEach(function (btn) {
        return btn.hide();
      });
      this.modal.center();
    }
  }]);
  return ProgressBar;
}();
module.exports = ProgressBar;

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/configCheck/webdav.js":
/*!********************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/configCheck/webdav.js ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * WebDAV
 */
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var WebDAV = /*#__PURE__*/function () {
  /**
   * @param {Object} options - Options
   */
  function WebDAV(options) {
    _classCallCheck(this, WebDAV);
    this.options = options;
  }

  /**
   * Get file/list of files and folders
   * @param {string} filePath - File path/Directory path
   * @returns {Promise} - Promise
   */
  _createClass(WebDAV, [{
    key: "get",
    value: (function () {
      var _get = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(filePath) {
        var path, requestOptions;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              path = "".concat(this.getSitesPath(), "/").concat(filePath);
              requestOptions = {
                method: 'GET'
              };
              return _context.abrupt("return", this.request(path, requestOptions));
            case 3:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
      function get(_x) {
        return _get.apply(this, arguments);
      }
      return get;
    }()
    /**
     * Upload file
     * @param {string} filePath - File path
     * @param {Object} requestBody - Request body
     * @returns {Promise} - Promise
     */
    )
  }, {
    key: "uploadFile",
    value: (function () {
      var _uploadFile = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2(filePath, requestBody) {
        var path, requestOptions;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              path = "".concat(this.getSitesPath(), "/").concat(filePath);
              requestOptions = {
                method: 'PUT',
                body: requestBody
              };
              return _context2.abrupt("return", this.request(path, requestOptions));
            case 3:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
      function uploadFile(_x2, _x3) {
        return _uploadFile.apply(this, arguments);
      }
      return uploadFile;
    }()
    /**
     * Felete file
     * @param {string} filePath - File path
     * @returns {Promise} - Promise
     */
    )
  }, {
    key: "deleteFile",
    value: (function () {
      var _deleteFile = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3(filePath) {
        var path, requestOptions;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              path = "".concat(this.getSitesPath(), "/").concat(filePath);
              requestOptions = {
                method: 'DELETE'
              };
              return _context3.abrupt("return", this.request(path, requestOptions));
            case 3:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this);
      }));
      function deleteFile(_x4) {
        return _deleteFile.apply(this, arguments);
      }
      return deleteFile;
    }()
    /**
     * Send Request
     * @param {string} path - URL path
     * @param {Object} options - Request options
     * @returns {Promise} - Promise
     */
    )
  }, {
    key: "request",
    value: function request(path, options) {
      var requestOptions = Object.assign({
        headers: {
          Authorization: this.getAuthorization()
        }
      }, options);
      var url = new URL(path, location.origin);
      return fetch(url, requestOptions);
    }

    /**
     * Basic Path
     * @returns {string} - Basic Path
     */
  }, {
    key: "getSitesPath",
    value: function getSitesPath() {
      return '/on/demandware.servlet/webdav/Sites';
    }

    /**
     * Basic Authorization
     * @returns {string} - Basic authorization value
     */
  }, {
    key: "getAuthorization",
    value: function getAuthorization() {
      var token = btoa("".concat(this.options.username, ":").concat(this.options.password));
      return "Basic ".concat(token);
    }
  }]);
  return WebDAV;
}();
module.exports = WebDAV;

/***/ })

/******/ });
//# sourceMappingURL=bm_paypal_configCheck.js.map