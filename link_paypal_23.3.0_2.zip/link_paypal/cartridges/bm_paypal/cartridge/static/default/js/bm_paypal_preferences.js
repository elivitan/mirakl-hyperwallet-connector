/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./cartridges/bm_paypal/cartridge/client/default/js/preferences.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/components/alertHandler.js":
/*!*************************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/components/alertHandler.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// eslint-disable-next-line no-unused-vars
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var AlertHandlerModel = /*#__PURE__*/function () {
  function AlertHandlerModel() {
    _classCallCheck(this, AlertHandlerModel);
    this.$alertsContainer = document.querySelector('.js-flash-messages-container');
  }

  /**
   * Appends Alerts message
   * Avaible alerts types:
   * primary,  secondary, success, danger, warning, info, alert, dark
   * @param {Object} alert Alerts and type messages
   */
  _createClass(AlertHandlerModel, [{
    key: "showAlertMessage",
    value: function showAlertMessage(alert) {
      var $alertTemplate = document.querySelector('.js-alert-template');
      var $alertContainer = $alertTemplate.cloneNode(true);
      $alertContainer.append(alert.message);
      this.$alertsContainer.append($alertContainer);
      $alertContainer.classList.add("alert-".concat(alert.type), 'show');
      $alertContainer.classList.remove('d-none');
    }

    /**
     * Fades Alerts message
     */
  }, {
    key: "fadeAlerts",
    value: function fadeAlerts() {
      var $alertContainers = document.querySelectorAll('.js-alert-template');
      $alertContainers.forEach(function (alert) {
        return alert.classList.add('d-none');
      });
    }

    /**
     * Closes an alert message
     */
  }, {
    key: "closeAlert",
    value: function closeAlert() {
      this.$alertsContainer.addEventListener('click', function (e) {
        if (e.target.parentElement.type === 'button') {
          var closeBtn = e.target.parentElement;
          closeBtn.parentElement.remove();
        }
      });
    }
  }]);
  return AlertHandlerModel;
}();
module.exports = AlertHandlerModel;

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/preferences.js":
/*!*************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/preferences.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(/*! ./preferences/preferences */ "./cartridges/bm_paypal/cartridge/client/default/js/preferences/preferences.js");

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/preferences/actions.js":
/*!*********************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/preferences/actions.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* eslint-disable no-console */



function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
var AlertHandlerModel = __webpack_require__(/*! ../components/alertHandler */ "./cartridges/bm_paypal/cartridge/client/default/js/components/alertHandler.js");
var alertHandler = new AlertHandlerModel();
var JS_DW_VALUES = '.js-dw-values';
var doc = document;
var csrfToken = doc.querySelector('[name="csrf_token"]');
var instanceTypesObj = {
  0: 'sandbox',
  1: 'staging',
  2: 'production'
};

/**
 * Gets the client ID from the DOM.
 * @returns {string} The client ID, or an empty string if not found.
 */
var getClientId = function getClientId() {
  var element = doc.querySelector('[name="client-id"]');
  return element ? element.value : '';
};

/**
 * Adds semi opaque background on form while instance is being changed
 * @param {string} formId form ID
 * @returns {Object} An object with two methods: show and hide
 */
var transitionAnimation = function transitionAnimation(formId) {
  var form = doc.getElementById(formId);
  return {
    show: function show() {
      return form.classList.add('semi-opaque');
    },
    hide: function hide() {
      return form.classList.remove('semi-opaque');
    }
  };
};

/**
 * Handles the default value for a given field in a row. If a default value is found,
 * it sets the field value and old value to this default (in lowercase). If not, it clears the field.
 *
 * @param {HTMLElement} $row - The row element in which to find the field.
 * @param {HTMLElement} $field - The field element whose default value should be handled.
 */
var handleDefaultValue = function handleDefaultValue($row, $field) {
  var $element = $row.querySelector('.js-default-value');
  if ($element) {
    var defaultValue = $element.dataset.defaultVal.toLowerCase();
    $field.value = defaultValue;
    $field.dataset.oldValue = defaultValue;
  } else {
    $field.value = '';
    $field.dataset.oldValue = '';
  }
};

/**
 * Changes values for preferences of another instance
 * @param {Object} data OCAPI response data
 * @param {Array} prefsWithChangedValues preferences which values have been changed
 * @param {HTMLElement} $row row where the preference is located
 */
var handleValuesChange = function handleValuesChange(data, prefsWithChangedValues, $row) {
  var changedPrefValue = prefsWithChangedValues.find(function (pref) {
    return $row.classList.contains(pref.toLowerCase());
  });
  var $field = $row.querySelector('.js-dw-collection-field').firstElementChild;
  var $setOfStringsValueField = $row.querySelector('[data-value-type-code="23"]');
  var $enumOfIntValueField = $row.querySelector('[data-value-type-code="31"]');
  var $enumOfStringsValueField = $row.querySelector('[data-value-type-code="33"]');
  if ($setOfStringsValueField) {
    var $valuesContainer = $row.querySelector(JS_DW_VALUES);
    Array.from($valuesContainer.children).forEach(function (elem) {
      if (!elem.classList.contains('d-none')) {
        elem.remove();
      }
    });
    $setOfStringsValueField.value = '';
    $field.dataset.oldValue = '';
    if (changedPrefValue) {
      data["c_".concat(changedPrefValue)].forEach(function (prefValue) {
        var $valueContainer = $valuesContainer.firstElementChild.cloneNode(true);
        var $valueText = $valueContainer.firstElementChild;
        var value = $setOfStringsValueField.value.concat("".concat($setOfStringsValueField.value.length ? ',' : ''), prefValue);
        $setOfStringsValueField.value = value;
        $field.dataset.oldValue = value;
        $valueText.append(prefValue);
        $valueContainer.prepend($valueText);
        $valuesContainer.append($valueContainer);
        $valueContainer.classList.remove('d-none');
      });
    }
  } else if ($enumOfIntValueField && !changedPrefValue) {
    $field.value = '-1';
    $field.dataset.oldValue = '-1';
  } else if (changedPrefValue) {
    $field.value = data["c_".concat(changedPrefValue)];
    $field.dataset.oldValue = data["c_".concat(changedPrefValue)];
  } else {
    handleDefaultValue($row, $field);
  }
  if ($enumOfStringsValueField) {
    var $checkboxes = $row.querySelectorAll('.js-input-checkbox');
    var checkedValues = $field.value.split(',');
    $checkboxes.forEach(function ($checkbox) {
      $checkbox.checked = checkedValues.includes($checkbox.value);
    });
  }
};

/**
 * Stores the client ID in local storage and updates the client ID field in the DOM.
 */
var storeClientId = function storeClientId() {
  var key = 'bm-client-id';
  var oneDayInMilliseconds = 24 * 60 * 60 * 1000;
  var value = JSON.parse(localStorage.getItem(key));
  var element = doc.querySelector('[name="client-id"]');
  if (value && value.expires > Date.now()) {
    element.value = value.clientId;
  } else {
    var url = new URL('on/demandware.store/Sites-Site/default/ViewApplication-BM#/?preference#site_preference_groups', location.origin);
    fetch(url, {
      method: 'GET'
    }).then(function (response) {
      return response.text();
    }).then(function (html) {
      var parser = new DOMParser();
      var htmlDocument = parser.parseFromString(html, 'text/html');
      var clientIdElement = htmlDocument.getElementById('dw-ocapi.client-id');
      var clientId = clientIdElement.getAttribute('content');
      localStorage.setItem(key, JSON.stringify({
        clientId: clientId,
        expires: Date.now() + oneDayInMilliseconds
      }));
      element.value = clientId;
    }).catch(function (error) {
      console.error('Error fetching HTML:', error);
    });
  }
};

/**
 * Get Access Token object
 * @returns {void}
 */
var getAccessToken = function getAccessToken() {
  var searchParams = new URLSearchParams();
  var url = new URL('dw/oauth2/access_token', location.origin);
  url.searchParams.append('csrf_token', csrfToken.value);
  searchParams.append('client_id', getClientId());
  searchParams.append('grant_type', 'urn:demandware:params:oauth:grant-type:client-id:dwsid:dwsecuretoken');
  return fetch(url.toString(), {
    method: 'POST',
    body: searchParams
  }).then(function (response) {
    return response.json();
  }).then(function (data) {
    return data;
  }).catch(function (error) {
    alertHandler.showAlertMessage({
      type: 'danger',
      message: error.message
    });
  });
};

/**
 * Send POST request to save preferences
 * @param {Object} event - SubmitEvent
 * @param {Object} data - data sent from apply to other sites popup
 */
var savePreferencesHandler = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(event, data) {
    var $target, groupId, $instanceType, siteId, instanceType, url, searchParams, token, prefIdsWithMultiValueType, prefIdsWithPasswordValueType, prefIdsWithStringValueType, formData, dataToSend;
    return _regeneratorRuntime().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          event.preventDefault();
          $target = data ? event.target.form : event.target;
          groupId = $target.id;
          $instanceType = doc.querySelector(".js-instance-type[data-group-id=\"".concat(groupId, "\"]"));
          siteId = data ? data.siteId : $instanceType.getAttribute('data-site-id');
          instanceType = data ? data.instance : instanceTypesObj[$instanceType.value];
          url = new URL("s/-/dw/data/v99_9/sites/".concat(siteId, "/site_preferences/preference_groups/").concat(groupId, "/").concat(instanceType), location.origin);
          searchParams = url.searchParams;
          searchParams.append('mask_passwords', 'true');
          searchParams.append('display_locale', 'default');
          searchParams.append('csrf_token', csrfToken.value);
          _context.next = 13;
          return getAccessToken();
        case 13:
          token = _context.sent;
          prefIdsWithMultiValueType = Array.from($target.querySelectorAll('.js-multi-value')).map(function (input) {
            return input.name;
          });
          prefIdsWithPasswordValueType = Array.from($target.querySelectorAll('[data-value-type-code="13"]')).map(function (input) {
            return input.name;
          });
          prefIdsWithStringValueType = Array.from($target.querySelectorAll('[data-value-type-code="3"], [data-value-type-code="4"], [data-value-type-code="33"]')).map(function (input) {
            return input.name;
          });
          formData = data ? data.prefs : Object.fromEntries(new FormData($target));
          dataToSend = {};
          Object.keys(formData).forEach(function (key) {
            if (key.includes('PP')) {
              if (prefIdsWithMultiValueType.includes(key)) {
                dataToSend["c_".concat(key)] = formData[key].split(',');
              } else if (prefIdsWithStringValueType.includes(key) || prefIdsWithPasswordValueType.includes(key)) {
                dataToSend["c_".concat(key)] = formData[key];
              } else if (!formData[key]) {
                dataToSend["c_".concat(key)] = null;
              } else {
                dataToSend["c_".concat(key)] = JSON.parse(formData[key]);
              }
            }
          });
          return _context.abrupt("return", fetch(url, {
            method: 'PATCH',
            headers: {
              Authorization: "".concat(token.token_type, " ").concat(token.access_token),
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(dataToSend)
          }).then(function (response) {
            return response.json();
          }).then(function (_data) {
            _data.fault ? alertHandler.showAlertMessage({
              type: 'danger',
              message: _data.fault.message
            }) : alertHandler.showAlertMessage({
              type: 'success',
              message: "The custom preferences were saved for ".concat(instanceType, " instance of ").concat(_data.site.id, ".")
            });
          }).catch(function (error) {
            alertHandler.showAlertMessage({
              type: 'danger',
              message: error.message
            });
          }));
        case 21:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return function savePreferencesHandler(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Fetch Property Description
 * @param {Element} element - DOM element
 */
var fetchPropertyDescription = function fetchPropertyDescription(element) {
  var url = new URL('/on/demandware.store/Sites-Site/default/ViewApplication-GetTooltipJson', location.origin);
  var searchParams = url.searchParams;
  var attrId = element.getAttribute('data-dw-attr-id');
  searchParams.append('attrid', attrId);
  searchParams.append('tooltip', "c_".concat(attrId));
  searchParams.append('attrtype', 'SitePreferences');
  searchParams.append('csrf_token', csrfToken.value);
  fetch(url.toString()).then(function (response) {
    return response.json();
  }).then(function (response) {
    element.innerHTML = response.customText || 'Not set';
  }).catch(function (error) {
    alertHandler.showAlertMessage({
      type: 'danger',
      message: error.message
    });
  });
};

/**
 * Changes preferences values for a specific instance
 * @param {Object} event - SubmitEvent
 * @returns {Promise} - OCAPI call to get preferences with their values for specific site and isntance
 */
var handlerInstanceType = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2(event) {
    var target, siteId, groupId, instanceType, url, searchParams, token;
    return _regeneratorRuntime().wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          target = event.target;
          siteId = target.getAttribute('data-site-id');
          groupId = target.getAttribute('data-group-id');
          instanceType = instanceTypesObj[target.value];
          transitionAnimation(groupId).show();
          url = new URL("s/-/dw/data/v99_9/sites/".concat(siteId, "/site_preferences/preference_groups/").concat(groupId, "/").concat(instanceType), location.origin);
          searchParams = url.searchParams;
          searchParams.append('mask_passwords', 'true');
          searchParams.append('select', '(**)');
          searchParams.append('display_locale', 'default');
          searchParams.append('csrf_token', csrfToken.value);
          _context2.next = 13;
          return getAccessToken();
        case 13:
          token = _context2.sent;
          return _context2.abrupt("return", fetch(url, {
            method: 'GET',
            headers: {
              Authorization: "".concat(token.token_type, " ").concat(token.access_token)
            }
          }).then(function (response) {
            return response.json();
          }).then(function (data) {
            var prefsWithChangedValues = [];
            Object.keys(data).forEach(function (key) {
              if (key.match(/c_/g)) {
                prefsWithChangedValues.push(key.replace(/c_/g, ''));
              }
            });
            var $attributeRows = doc.querySelectorAll("#".concat(groupId, " .js-dw-attr-row"));
            $attributeRows.forEach(function ($row) {
              return handleValuesChange(data, prefsWithChangedValues, $row);
            });
            transitionAnimation(groupId).hide();
          }).catch(function (error) {
            alertHandler.showAlertMessage({
              type: 'danger',
              message: error.message
            });
          }));
        case 15:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return function handlerInstanceType(_x3) {
    return _ref2.apply(this, arguments);
  };
}();
module.exports = {
  storeClientId: storeClientId,
  handlerInstanceType: handlerInstanceType,
  savePreferencesHandler: savePreferencesHandler,
  fetchPropertyDescription: fetchPropertyDescription
};

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/preferences/applyToOtherSitesWizard.js":
/*!*************************************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/preferences/applyToOtherSitesWizard.js ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var TEXT_SELECT_ALL = 'Select all';
var TEXT_UNSELECT_ALL = 'Unselect all';
var DW_ROW_SELECTOR = '.js-dw-row';
var DW_TBODY_SELECTOR = '.js-dw-tbody';
var DW_CHECKBOX_SELECTOR = '.js-dw-checkbox';
var DW_CHECKBOX_CLASSNAME = 'js-dw-checkbox';
var SELECT_ALL_SELECTOR = '.js-select-all';
var ApplyToOtherSitesWizard = /*#__PURE__*/function () {
  function ApplyToOtherSitesWizard() {
    _classCallCheck(this, ApplyToOtherSitesWizard);
    _defineProperty(this, "PREF_SELECTION", 'preferenceSelection');
    _defineProperty(this, "SITE_SELECTION", 'siteSelection');
    _defineProperty(this, "SUMMARY", 'summary');
    _defineProperty(this, "IS_DISABLED", 'is-disabled');
    _defineProperty(this, "IS_ACTIVE", 'is-active');
    _defineProperty(this, "D_NONE", 'd-none');
    _defineProperty(this, "INSTANCES", {
      0: 'Sandbox',
      1: 'Staging',
      2: 'Production'
    });
    this.$wizard = document.querySelector('.js-dw-wizard');
    this.$btnNext = document.querySelector('.js-button-next');
    this.$btnBack = document.querySelector('.js-button-back');
    this.$btnApply = document.querySelector('.js-button-apply');
    this.prefsNames = {};
    this.dataToSend = {
      prefs: {},
      sites: {}
    };
    this.currentStage = null;
    this.currentSite = null;
    this.currentInstance = null;
  }

  /**
   * Handles click on a checkbox having it be checked/unchecked along with its siblings
   * @param {HTMLElement} $checkbox Input
   * @param {boolean} condition Condition that triggers whether cthe checkbox should be checked or not
   */
  _createClass(ApplyToOtherSitesWizard, [{
    key: "handleMultiCheckboxClick",
    value: function handleMultiCheckboxClick($checkbox, condition) {
      if (condition) {
        $checkbox.checked = false;
        $checkbox.click();
      } else {
        $checkbox.checked = true;
        $checkbox.click();
      }
    }

    /**
     * Prepares data
     * @param {HTMLElement} $checkbox Input
     * @param {null} value If present, it means the checkbox was unchecked
     */
  }, {
    key: "prepDataToSend",
    value: function prepDataToSend($checkbox, value) {
      var prefValue = $checkbox.dataset.prefValue || $checkbox.dataset.forInstance;
      if ((value === null || !$checkbox.dataset.prefValue) && $checkbox.dataset.prefId) {
        this.dataToSend.prefs[$checkbox.dataset.prefId] = '';
      } else if ($checkbox.dataset.prefId) {
        this.dataToSend.prefs[$checkbox.dataset.prefId] = prefValue;
      }
      if ($checkbox.closest(DW_ROW_SELECTOR)) {
        var siteId = $checkbox.closest(DW_ROW_SELECTOR).dataset.siteId;
        var siteName = $checkbox.closest(DW_ROW_SELECTOR).dataset.siteName;
        var siteData = this.dataToSend.sites[siteId];
        if (value === null) {
          var index = siteData.indexOf($checkbox.dataset.forInstance);
          siteData.splice(index, 1);
        } else if (siteData && !siteData.includes(prefValue)) {
          siteData.push(prefValue);
        } else if (!siteData) {
          var data = {};
          data[siteId] = [prefValue];
          data[siteId].siteName = siteName;
          Object.assign(this.dataToSend.sites, data);
        }
      }
    }
  }, {
    key: "handleCheckboxTextConditions",
    value: function handleCheckboxTextConditions($checkbox, $selectAllBtn, isAnyNotCheckedStagewide) {
      if (!$checkbox.checked && $selectAllBtn && $selectAllBtn.innerText === TEXT_UNSELECT_ALL) {
        $selectAllBtn.innerText = TEXT_SELECT_ALL;
      }
      if (!isAnyNotCheckedStagewide && $selectAllBtn && $selectAllBtn.innerText === TEXT_SELECT_ALL) {
        $selectAllBtn.innerText = TEXT_UNSELECT_ALL;
      }
    }

    /**
     * Handles checkbox click and how it influences other elements
     * @param {HTMLElement} $checkbox Input
     */
  }, {
    key: "handleCheckboxChangeEvent",
    value: function handleCheckboxChangeEvent($checkbox) {
      var _this = this;
      $checkbox.addEventListener('change', function () {
        var $parentElem = $checkbox.closest('[data-wizard-stage]');
        var $nextStage = $parentElem.nextElementSibling;
        var $stageAfterNext = $nextStage.nextElementSibling;
        var $nextProgressItem = _this.$wizard.querySelector("[data-progress-id=\"".concat($nextStage.dataset.wizardStage, "\"]"));
        var $selectAllBtn = $parentElem.querySelector(SELECT_ALL_SELECTOR);
        var $checkAllBtn = $parentElem.querySelector('.js-dw-check-all');
        var $afterNextProgressItem;
        var isAnyCheckedInNextStage = $nextStage.querySelector('.js-dw-checkbox:checked');
        var isAnyNotCheckedStagewide = $parentElem.querySelector('.js-dw-checkbox:not(:checked)');
        var isAnyCheckedStagewide = $parentElem.querySelector('.js-dw-checkbox:checked');
        var isAnyNotChecked = $parentElem.querySelector('.js-dw-checkbox:not(:checked):not(.js-attr-selection-row.d-none .js-dw-checkbox)');
        if ($checkbox.dataset.forInstance) {
          $checkAllBtn = $parentElem.querySelector(".js-dw-check-all[data-for-instance=\"".concat($checkbox.dataset.forInstance, "\"]"));
          isAnyNotChecked = $parentElem.querySelector(".js-dw-checkbox[data-for-instance=\"".concat($checkbox.dataset.forInstance, "\"]:not(:checked)"));
        }
        if ($stageAfterNext) {
          $afterNextProgressItem = _this.$wizard.querySelector("[data-progress-id=\"".concat($stageAfterNext.dataset.wizardStage, "\"]"));
        }
        if ($checkbox.checked) {
          $nextProgressItem.classList.remove(_this.IS_DISABLED);
          _this.$btnNext.disabled = false;
          _this.prepDataToSend($checkbox);
        } else if (!$checkbox.checked && !isAnyCheckedStagewide) {
          $nextProgressItem.classList.add(_this.IS_DISABLED);
          _this.$btnNext.disabled = true;
        }
        if (!$checkbox.checked && !isAnyCheckedStagewide && $stageAfterNext) {
          $afterNextProgressItem.classList.add(_this.IS_DISABLED);
        } else if ($checkbox.checked && isAnyCheckedInNextStage && $stageAfterNext) {
          $afterNextProgressItem.classList.remove(_this.IS_DISABLED);
        }
        if ($checkbox.checked && !isAnyNotChecked && !$checkAllBtn.checked) {
          $checkAllBtn.checked = true;
        }
        if (!$checkbox.checked) {
          _this.prepDataToSend($checkbox, null);
        }
        if (!$checkbox.checked && $checkAllBtn.checked) {
          $checkAllBtn.checked = false;
        }
        _this.handleCheckboxTextConditions($checkbox, $selectAllBtn, isAnyNotCheckedStagewide);
      });
    }

    /**
     * Handles click on checkbox which should select all other checkboxes
     * @param {HTMLElement} $checkbox Input
     */
  }, {
    key: "handleApplyToAllCheckboxChangeEvent",
    value: function handleApplyToAllCheckboxChangeEvent($checkbox) {
      var _this2 = this;
      $checkbox.addEventListener('change', function () {
        var $parent = $checkbox.closest('[data-wizard-stage]');
        var $checkboxes = $parent.querySelectorAll(DW_CHECKBOX_SELECTOR);
        if ($checkbox.dataset.forInstance) {
          $checkboxes = $parent.querySelectorAll(".js-dw-checkbox[data-for-instance=\"".concat($checkbox.dataset.forInstance, "\"]"));
        }
        $checkboxes.forEach(function ($input) {
          return _this2.handleMultiCheckboxClick($input, $checkbox.checked);
        });
      });
    }

    /**
     * Hides checkbox for the currently chosen site and instance
     */
  }, {
    key: "hideCurrentSiteAndInstanceCheckbox",
    value: function hideCurrentSiteAndInstanceCheckbox() {
      var _this3 = this;
      var $stageSiteSelection = this.$wizard.querySelector("#".concat(this.SITE_SELECTION));
      var $checkboxes = $stageSiteSelection.querySelectorAll(DW_CHECKBOX_SELECTOR);
      $checkboxes.forEach(function ($checkbox) {
        if ($checkbox.dataset.forInstance === _this3.currentInstance && $checkbox.dataset.forSite === _this3.currentSite) {
          $checkbox.classList.add(_this3.D_NONE);
          $checkbox.classList.remove(DW_CHECKBOX_CLASSNAME);
        }
      });
    }

    /**
     * Initializes the popup by generating rows with preferences and its values,
     * Calls methods related to checkboxes
     * @param {string} formId Form ID
     */
  }, {
    key: "initialize",
    value: function initialize(formId) {
      var _this4 = this;
      var $form = document.getElementById(formId);
      var $instanceType = document.querySelector(".js-instance-type[data-group-id=".concat(formId, "]"));
      this.currentInstance = $instanceType.value;
      this.currentSite = $instanceType.dataset.siteId;
      this.$btnApply.setAttribute('form', formId);
      $form.querySelectorAll('.js-dw-attr-row .js-dw-attr-label').forEach(function (label) {
        _this4.prefsNames[label.dataset.attrId] = label.innerText;
      });
      $form.querySelectorAll('[data-old-value]').forEach(function ($field) {
        var $row = _this4.$wizard.querySelector('.js-attr-selection-row').cloneNode(true);
        var fieldValue = $field.dataset.oldValue;
        var value;
        if (fieldValue === 'true') {
          value = 'Yes';
        } else if (fieldValue === 'false') {
          value = 'No';
        } else if ($field.dataset.valueTypeCode === '13') {
          value = fieldValue.replace(/./g, '*');
          $row.querySelector(DW_CHECKBOX_SELECTOR).classList.add(_this4.D_NONE);
          $row.querySelector(DW_CHECKBOX_SELECTOR).classList.remove(DW_CHECKBOX_CLASSNAME);
        } else if ($field.dataset.valueTypeCode === '31') {
          value = $field.children[$field.selectedIndex].dataset.displayValue;
        } else if ($field.dataset.valueTypeCode === '33') {
          value = fieldValue.replaceAll(',', ', ');
        } else {
          value = "".concat(fieldValue.charAt(0).toUpperCase()).concat(fieldValue.slice(1));
        }
        $row.children[0].firstElementChild.dataset.prefId = $field.name;
        $row.children[0].firstElementChild.dataset.prefValue = fieldValue;
        $row.children[1].firstElementChild.append(_this4.prefsNames[$field.name]);
        $row.children[2].firstElementChild.append(value);
        $row.classList.remove(_this4.D_NONE);
        _this4.$wizard.querySelector(DW_TBODY_SELECTOR).append($row);
        _this4.currentStage = _this4.PREF_SELECTION;
      });
      this.$wizard.classList.remove(this.D_NONE);
      this.hideCurrentSiteAndInstanceCheckbox();
      this.$wizard.querySelectorAll('.js-dw-check-all').forEach(function ($checkbox) {
        return _this4.handleApplyToAllCheckboxChangeEvent($checkbox);
      });
      this.$wizard.querySelectorAll(DW_CHECKBOX_SELECTOR).forEach(function ($checkbox) {
        return _this4.handleCheckboxChangeEvent($checkbox);
      });
    }

    /**
     * Creates a row with preference data for summary stage
     * @param {string} prefId Preference ID
     */
  }, {
    key: "createSummaryPrefRow",
    value: function createSummaryPrefRow(prefId) {
      var $template = this.$wizard.querySelector('.js-summary-pref-row');
      var $rowPref = $template.cloneNode(true);
      $rowPref.children[0].firstElementChild.append(this.prefsNames[prefId]);
      $rowPref.children[1].firstElementChild.append(this.dataToSend.prefs[prefId]);
      $rowPref.dataset.prefId = prefId;
      $rowPref.classList.remove(this.D_NONE);
      $template.closest(DW_TBODY_SELECTOR).append($rowPref);
    }

    /**
     * Creates a row with site data for summary stage
     * @param {string} siteId Site ID
     * @param {string} instanceCode Instance code
     */
  }, {
    key: "createSummarySiteRow",
    value: function createSummarySiteRow(siteId, instanceCode) {
      var $template = this.$wizard.querySelector('.js-summary-site-row');
      var $rowSite = $template.cloneNode(true);
      $rowSite.children[0].firstElementChild.append("".concat(this.dataToSend.sites[siteId].siteName, " (").concat(this.INSTANCES[instanceCode], ")"));
      $rowSite.dataset.siteId = siteId;
      $rowSite.dataset.siteInstance = instanceCode;
      $rowSite.classList.remove(this.D_NONE);
      $template.closest(DW_TBODY_SELECTOR).append($rowSite);
    }

    /**
     * Prepares rows for stage summary
     */
  }, {
    key: "prepStageSummary",
    value: function prepStageSummary() {
      var _this5 = this;
      Object.keys(this.dataToSend.prefs).forEach(function (key) {
        return _this5.createSummaryPrefRow(key);
      });
      Object.keys(this.dataToSend.sites).forEach(function (key) {
        _this5.dataToSend.sites[key].forEach(function (value) {
          return _this5.createSummarySiteRow(key, value);
        });
      });
    }

    /**
     * Updates rows for stage summary in case if user goes to previous stages to correct data
     */
  }, {
    key: "updateStageSummary",
    value: function updateStageSummary() {
      var _this6 = this;
      var $prefRows = this.$wizard.querySelectorAll('.js-summary-pref-row:not(.d-none)');
      var $siteRows = this.$wizard.querySelectorAll('.js-summary-site-row:not(.d-none)');
      var prefsInWizard = Array.from($prefRows).map(function ($row) {
        return $row.dataset.prefId;
      });
      var sitesInWizard = Array.from($siteRows).map(function ($row) {
        return [$row.dataset.siteId, $row.dataset.siteInstance];
      });
      var savedPrefs = Object.keys(this.dataToSend.prefs);
      var savedSites = Object.keys(this.dataToSend.sites);
      Array.from($prefRows).filter(function ($row) {
        return !savedPrefs.includes($row.dataset.prefId);
      }).forEach(function ($row) {
        return $row.remove();
      });
      Array.from($siteRows).filter(function ($row) {
        return !_this6.dataToSend.sites[$row.dataset.siteId].includes($row.dataset.siteInstance);
      }).forEach(function ($row) {
        return $row.remove();
      });
      savedPrefs.filter(function (prefId) {
        return !prefsInWizard.includes(prefId);
      }).forEach(function (prefId) {
        return _this6.createSummaryPrefRow(prefId);
      });
      savedSites.forEach(function (siteId) {
        var instancesInWizard = [];
        sitesInWizard.filter(function (pair) {
          return pair[0] === siteId;
        }).forEach(function (pair) {
          return instancesInWizard.push(pair[1]);
        });
        _this6.dataToSend.sites[siteId].forEach(function (instanceCode) {
          if (!instancesInWizard.includes(instanceCode)) {
            _this6.createSummarySiteRow(siteId, instanceCode);
          }
        });
      });
    }

    /**
     * Handles stage switch when next/back buttons or progress items are clicked
     * @param {string} currentStage Current stage
     * @param {string} futureStage Future stage
     */
  }, {
    key: "handleStageSwitch",
    value: function handleStageSwitch(currentStage, futureStage) {
      var $futureStageProgressItem = document.querySelector("[data-progress-id=\"".concat(futureStage, "\"]"));
      var $currentStageProgressItem = document.querySelector("[data-progress-id=\"".concat(currentStage, "\"]"));
      var $summaryStage = this.$wizard.querySelector("#".concat(this.SUMMARY));
      document.getElementById(currentStage).classList.add(this.D_NONE);
      document.getElementById(futureStage).classList.remove(this.D_NONE);
      $currentStageProgressItem.classList.remove(this.IS_ACTIVE);
      $futureStageProgressItem.classList.add(this.IS_ACTIVE);
      if (futureStage === this.SUMMARY && !$summaryStage.dataset.wizardStageStatus) {
        this.prepStageSummary();
        $summaryStage.dataset.wizardStageStatus = 'generated';
      }
      if ($summaryStage.dataset.wizardStageStatus) {
        this.updateStageSummary();
      }
      if (futureStage === this.PREF_SELECTION) {
        this.$btnBack.disabled = true;
        this.$btnNext.disabled = false;
      } else if (futureStage === this.SITE_SELECTION) {
        var isAnyCheckboxChecked = this.$wizard.querySelector("#".concat(this.SITE_SELECTION, " .js-dw-checkbox:checked"));
        if (!isAnyCheckboxChecked) {
          this.$btnNext.disabled = true;
        }
        this.$btnBack.disabled = false;
      } else if (futureStage === this.SUMMARY) {
        this.$btnNext.classList.add('ng-hide');
        this.$btnApply.classList.remove('ng-hide');
        $futureStageProgressItem.classList.remove(this.IS_DISABLED);
      }
      if ((futureStage === this.PREF_SELECTION || futureStage === this.SITE_SELECTION) && !this.$btnApply.classList.contains('ng-hide')) {
        this.$btnApply.classList.add('ng-hide');
        this.$btnNext.classList.remove('ng-hide');
      }
      this.currentStage = futureStage;
    }

    /**
     * Moves to next stage on next button click
     */
  }, {
    key: "toNextStage",
    value: function toNextStage() {
      if (this.currentStage === this.PREF_SELECTION) {
        this.handleStageSwitch(this.currentStage, this.SITE_SELECTION);
      } else if (this.currentStage === this.SITE_SELECTION) {
        this.handleStageSwitch(this.currentStage, this.SUMMARY);
      }
    }

    /**
     * Moves to previous stage on back button click
     */
  }, {
    key: "toPrevStage",
    value: function toPrevStage() {
      if (this.currentStage === this.SITE_SELECTION) {
        this.handleStageSwitch(this.currentStage, this.PREF_SELECTION);
      } else if (this.currentStage === this.SUMMARY) {
        this.handleStageSwitch(this.currentStage, this.SITE_SELECTION);
      }
    }

    /**
     * Shows corresponding stage based on which progress item was clicked
     * @param {HTMLElement} $item Progress item
     */
  }, {
    key: "handleProgressBarClick",
    value: function handleProgressBarClick($item) {
      var $progressBarContainer = document.querySelector('.js-progress-bar');
      var $selectedElem = $progressBarContainer.querySelector('.is-active');
      var currentStage = $selectedElem.dataset.progressId;
      var futureStage = $item.dataset.progressId;
      this.handleStageSwitch(currentStage, futureStage);
    }

    /**
     * Restores next/back/apply buttons classes to their initial state
     */
  }, {
    key: "restoreButtonClasses",
    value: function restoreButtonClasses() {
      if (this.$btnNext.classList.contains('ng-hide')) {
        this.$btnNext.classList.remove('ng-hide');
      }
      if (!this.$btnNext.disabled) {
        this.$btnNext.disabled = true;
      }
      if (!this.$btnBack.disabled) {
        this.$btnBack.disabled = true;
      }
      if (!this.$btnApply.classList.contains('ng-hide')) {
        this.$btnApply.classList.add('ng-hide');
      }
    }

    /**
     * Restores progress items classes to their initial state
     */
  }, {
    key: "restoreProgressBarClasses",
    value: function restoreProgressBarClasses() {
      var $progressPrefSelection = document.querySelector("[data-progress-id=\"".concat(this.PREF_SELECTION, "\"]"));
      var $progressSiteSelection = document.querySelector("[data-progress-id=\"".concat(this.SITE_SELECTION, "\"]"));
      var $progressSummary = document.querySelector("[data-progress-id=\"".concat(this.SUMMARY, "\"]"));
      if (!$progressPrefSelection.classList.contains(this.IS_ACTIVE)) {
        $progressPrefSelection.classList.add(this.IS_ACTIVE);
      }
      if ($progressSiteSelection.classList.contains(this.IS_ACTIVE)) {
        $progressSiteSelection.classList.remove(this.IS_ACTIVE);
      }
      if (!$progressSiteSelection.classList.contains(this.IS_DISABLED)) {
        $progressSiteSelection.classList.add(this.IS_DISABLED);
      }
      if ($progressSummary.classList.contains(this.IS_ACTIVE)) {
        $progressSummary.classList.remove(this.IS_ACTIVE);
      }
      if (!$progressSummary.classList.contains(this.IS_DISABLED)) {
        $progressSummary.classList.add(this.IS_DISABLED);
      }
    }

    /**
     * Restores stages to there initial state
     */
  }, {
    key: "restoreStages",
    value: function restoreStages() {
      var $stagePrefSelection = document.getElementById(this.PREF_SELECTION);
      var $stageSiteSelection = document.getElementById(this.SITE_SELECTION);
      var $stageSummary = document.getElementById(this.SUMMARY);
      if ($stagePrefSelection.classList.contains(this.D_NONE)) {
        $stagePrefSelection.classList.remove(this.D_NONE);
      }
      if (!$stageSiteSelection.classList.contains(this.D_NONE)) {
        $stageSiteSelection.classList.add(this.D_NONE);
      }
      if (!$stageSummary.classList.contains(this.D_NONE)) {
        $stageSummary.classList.add(this.D_NONE);
      }
    }

    /**
     * Cleans stage summary of its rows with data
     */
  }, {
    key: "cleanStageSummary",
    value: function cleanStageSummary() {
      var $summaryStage = this.$wizard.querySelector("#".concat(this.SUMMARY));
      var $summaryStageData = $summaryStage.querySelectorAll('.js-summary-pref-row:not(.d-none), .js-summary-site-row:not(.d-none)');
      $summaryStageData.forEach(function ($row) {
        return $row.remove();
      });
      $summaryStage.removeAttribute('data-wizard-stage-status');
    }

    /**
     * Shows hidden checkbox responsible for currect site and instance
     */
  }, {
    key: "showCurrentSiteAndInstanceCheckbox",
    value: function showCurrentSiteAndInstanceCheckbox() {
      var $stageSiteSelection = this.$wizard.querySelector("#".concat(this.SITE_SELECTION));
      var $checkbox = $stageSiteSelection.querySelector('.d-none[data-for-instance]');
      $checkbox.classList.remove(this.D_NONE);
      $checkbox.classList.add(DW_CHECKBOX_CLASSNAME);
    }

    /**
     * Closes popup on close button
     */
  }, {
    key: "close",
    value: function close() {
      this.$wizard.classList.add(this.D_NONE);
      this.$wizard.querySelectorAll('.js-attr-selection-row:not(.d-none)').forEach(function (elem) {
        return elem.remove();
      });
      this.$wizard.querySelectorAll('.js-dw-check-all:checked, .js-dw-checkbox:checked').forEach(function ($checkbox) {
        $checkbox.checked = false;
      });
      this.$wizard.querySelector(SELECT_ALL_SELECTOR).innerText = TEXT_SELECT_ALL;
      this.restoreButtonClasses();
      this.restoreProgressBarClasses();
      this.restoreStages();
      this.cleanStageSummary();
      this.showCurrentSiteAndInstanceCheckbox();
      this.dataToSend = {
        prefs: {},
        sites: {}
      };
    }

    /**
     * Check checkboxes for all instances and sites
     */
  }, {
    key: "selectAllSites",
    value: function selectAllSites() {
      var _this7 = this;
      var $button = this.$wizard.querySelector(SELECT_ALL_SELECTOR);
      var $checkboxes = this.$wizard.querySelectorAll("#".concat(this.SITE_SELECTION, " .js-dw-check-all"));
      if ($button.innerText === TEXT_SELECT_ALL) {
        $button.innerText = TEXT_UNSELECT_ALL;
      } else {
        $button.innerText = TEXT_SELECT_ALL;
      }
      $checkboxes.forEach(function ($checkbox) {
        return _this7.handleMultiCheckboxClick($checkbox, $button.innerText !== TEXT_SELECT_ALL);
      });
    }

    /**
     * Calls savePreferencesHandler method with given data
     * @param {Object} event Event
     * @param {Function} callback savePreferencesHandler method
     */
  }, {
    key: "apply",
    value: function apply(event, callback) {
      var _this8 = this;
      Object.keys(this.dataToSend.sites).filter(function (siteId) {
        return _this8.dataToSend.sites[siteId].length !== 0;
      }).forEach(function (siteId) {
        _this8.dataToSend.sites[siteId].forEach(function (instance) {
          return callback(event, {
            prefs: _this8.dataToSend.prefs,
            siteId: siteId,
            instance: _this8.INSTANCES[instance].toLowerCase()
          });
        });
      });
      this.close();
    }

    /**
     * Shows popup/alert on Apply to other sites button click
     * @param {string} formId Form ID
     */
  }, {
    key: "show",
    value: function show(formId) {
      var $form = document.getElementById(formId);
      var $formFields = $form.querySelectorAll('[data-old-value]');
      var $unsavedField = Array.from($formFields).some(function ($field) {
        if ($field.dataset.oldValue.includes('.0') && !$field.value.includes('.0')) {
          return $field.dataset.oldValue.replace('.0', '') !== $field.value;
        }
        return $field.dataset.oldValue !== $field.value;
      });
      if ($unsavedField) {
        this.showAlert(formId);
      } else {
        this.initialize(formId);
      }
    }

    /**
     * Shows alert if the form contains unsaved data
     * @param {string} formId Form ID
     */
  }, {
    key: "showAlert",
    value: function showAlert(formId) {
      var _this9 = this;
      var $wizardAlert = document.querySelector('.js-wizard-alert');
      var $okBtn = $wizardAlert.querySelector('.js-wizard-alert-ok');
      var $cancelBtn = $wizardAlert.querySelector('.js-wizard-alert-cancel');
      $wizardAlert.classList.remove(this.D_NONE);
      $okBtn.setAttribute('form', formId);
      $cancelBtn.addEventListener('click', function () {
        return $wizardAlert.classList.add(_this9.D_NONE);
      });
    }

    /**
     * Resets unsaved form data and initializes the wizard poup
     * @param {string} formId Form ID
     */
  }, {
    key: "proceedtoWizard",
    value: function proceedtoWizard(formId) {
      var $wizardAlert = document.querySelector('.js-wizard-alert');
      $wizardAlert.classList.add(this.D_NONE);
      this.initialize(formId);
    }
  }]);
  return ApplyToOtherSitesWizard;
}();
module.exports = ApplyToOtherSitesWizard;

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/preferences/handlers.js":
/*!**********************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/preferences/handlers.js ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

'use script';

var AlertHandlerModel = __webpack_require__(/*! ../components/alertHandler */ "./cartridges/bm_paypal/cartridge/client/default/js/components/alertHandler.js");
var doc = document;
var alertHandler = new AlertHandlerModel();

/**
 * Retrieves the value of an element by its name attribute.
 *
 * @param {string} name - The name attribute of the element to retrieve the value for.
 * @returns {string} The value of the element with the given name attribute, or an empty string if the element was not found.
 */
var getValueByName = function getValueByName(name) {
  var elememnt = doc.querySelector("[name=\"".concat(name, "\"]"));
  return elememnt ? elememnt.value : '';
};

/**
 * Retrieves the value of an element by attribute name.
 *
 * @param {string} name - The name attribute of the element to retrieve the value for.
 * @returns {string} The attribute value of the element with the given name attribute, or an empty string if the element was not found.
 */
var getValueByAttr = function getValueByAttr(name) {
  var elememnt = doc.querySelector("[name=\"".concat(name, "\"]"));
  return elememnt ? elememnt.getAttribute('data-old-value') : '';
};

/**
 * Handles the triggers for a relation.
 *
 * @param {Array<Object>} triggers - An array of trigger objects to handle.
 * @returns {void}
 */
var handlerTriggers = function handlerTriggers(triggers) {
  for (var index = 0; index < triggers.length; index++) {
    var action = triggers[index];
    if (action.type === 'alert') {
      alertHandler.showAlertMessage({
        type: 'primary',
        message: action.message
      });
    }
    if (action.type === 'change') {
      doc.querySelector("[name=\"".concat(action.id, "\"")).value = action.value;
    }
  }
};

/**
 * Handles the conditions for a relation.
 *
 * @param {Array<Object>} conditions - An array of condition objects to handle.
 * @returns {boolean} Whether or not all conditions were met.
 */
var handlerConditions = function handlerConditions(conditions) {
  var conditionMatched = true;
  for (var index = 0; index < conditions.length; index++) {
    var condition = conditions[index];
    var conditionId = condition.id,
      conditionValue = condition.value,
      operator = condition.operator;
    if (operator === 'and') {
      if (conditionValue !== getValueByName(conditionId)) {
        conditionMatched = false;
        break;
      }
    } else if (operator === 'or') {
      if (conditionValue === getValueByName(conditionId)) {
        conditionMatched = true;
        break;
      } else {
        conditionMatched = false;
      }
    }
  }
  return conditionMatched;
};

/**
 * Handles all relations in the document.
 *
 * @returns {void}
 */
var handlerRelations = function handlerRelations() {
  var relations = JSON.parse(doc.querySelector('[data-relations]').getAttribute('data-relations'));
  for (var index = 0; index < relations.length; index++) {
    var relation = relations[index];
    var conditionMatched = handlerConditions(relation.conditions);
    if (conditionMatched && relation.oldValue === getValueByAttr(relation.id) && relation.newValue === getValueByName(relation.id)) {
      handlerTriggers(relation.triggers);
    }
  }
};

/**
 * Data handler before form submission
 * @param {Object} event - ClickEvent
 */
var handlerBeforeSubmit = function handlerBeforeSubmit(event) {
  alertHandler.fadeAlerts();
  var target = event.target;
  var site = target.form.querySelector('[name="site"]');
  site.value = target.name === 'apply-to-sites' ? 'multiple' : 'single';
  handlerRelations();
};
module.exports = {
  handlerBeforeSubmit: handlerBeforeSubmit
};

/***/ }),

/***/ "./cartridges/bm_paypal/cartridge/client/default/js/preferences/preferences.js":
/*!*************************************************************************************!*\
  !*** ./cartridges/bm_paypal/cartridge/client/default/js/preferences/preferences.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* eslint-disable no-console */



var actions = __webpack_require__(/*! ./actions */ "./cartridges/bm_paypal/cartridge/client/default/js/preferences/actions.js");
var handlers = __webpack_require__(/*! ./handlers */ "./cartridges/bm_paypal/cartridge/client/default/js/preferences/handlers.js");
var AlertHandlerModel = __webpack_require__(/*! ../components/alertHandler */ "./cartridges/bm_paypal/cartridge/client/default/js/components/alertHandler.js");
var ApplyToOtherSitesWizard = __webpack_require__(/*! ./applyToOtherSitesWizard */ "./cartridges/bm_paypal/cartridge/client/default/js/preferences/applyToOtherSitesWizard.js");
(function (doc) {
  var alertHandler = new AlertHandlerModel();
  var applyToOtherSitesWizard = new ApplyToOtherSitesWizard();
  var JS_DW_VALUES = '.js-dw-values';
  var savedMultiValues = {};
  alertHandler.closeAlert();

  /**
   * Filters an array of rows based on whether their class name includes the given value.
   * @param {Array<HTMLElement>} rows - An array of row elements to filter.
   * @param {Array<HTMLElement>} messages - An array of messages elements.
   * @param {string} value - The value to filter the rows by.
   * @returns {void}
   */
  var filterRowsByValue = function filterRowsByValue(rows, messages, value) {
    var count = 0;
    rows.forEach(function (row) {
      if (row.className.includes(value)) {
        row.classList.remove('d-none');
      } else {
        row.classList.add('d-none');
        count++;
      }
    });
    messages.forEach(function (element) {
      element.classList[rows.length === count ? 'remove' : 'add']('ng-hide');
    });
  };

  /**
   * Handles filtering of preference attribute grids.
   * @returns {void}
   */
  var handlerFilterPreferences = function handlerFilterPreferences() {
    var inputs = doc.querySelectorAll('.js-search-field');
    var buttons = doc.querySelectorAll('.js-button-search');
    buttons.forEach(function (button) {
      button.addEventListener('click', function () {
        var parent = button.closest('.dw-PreferenceAttributegrid');
        var input = parent.querySelector('.js-search-field');
        var rows = parent.querySelectorAll('.dw-row');
        var messages = parent.querySelectorAll('.grid-message');
        filterRowsByValue(rows, messages, input.value.toLowerCase().trim());
      });
    });
    inputs.forEach(function (input) {
      input.addEventListener('change', function () {
        var parent = input.closest('.dw-PreferenceAttributegrid');
        var rows = parent.querySelectorAll('.dw-row');
        var messages = parent.querySelectorAll('.grid-message');
        filterRowsByValue(rows, messages, input.value.toLowerCase().trim());
      });
    });
  };

  /**
   * Stores saved multi values as serialized HTML fragment
   */
  var storeSavedMultiValues = function storeSavedMultiValues() {
    doc.querySelectorAll(JS_DW_VALUES).forEach(function (elem) {
      savedMultiValues[elem.dataset.attrName] = elem.outerHTML;
    });
  };

  /**
   * Updates fields data attr old-value
   * And stores saved multi values as serialized HTML fragment
   * @returns {void}
   */
  var updateDataAttrOldValue = function updateDataAttrOldValue() {
    var formId = this.form.id;
    doc.querySelectorAll("#".concat(formId, " .js-dw-collection-field")).forEach(function ($elem) {
      var fieldOldValue = $elem.firstElementChild.dataset.oldValue;
      var fieldCurrentValue = $elem.firstElementChild.value;
      if (fieldOldValue !== fieldCurrentValue) {
        var $multiValuesContainer = $elem.querySelector(JS_DW_VALUES);
        if ($multiValuesContainer) {
          savedMultiValues[$multiValuesContainer.dataset.attrName] = $multiValuesContainer.outerHTML;
        }
        $elem.firstElementChild.dataset.oldValue = fieldCurrentValue;
      }
    });
  };

  /**
   * Restores Set of String newly added entries on cancel button click
   * @param {string} formId - Form ID
   * @returns {void}
   */
  var restoreMultiValues = function restoreMultiValues(formId) {
    doc.querySelectorAll("#".concat(formId, " .js-multi-value")).forEach(function ($input) {
      var oldValue = $input.dataset.oldValue;
      var currentValue = $input.value;
      if (oldValue !== currentValue) {
        var $valuesContainer = $input.parentElement.querySelector(JS_DW_VALUES);
        $valuesContainer.outerHTML = savedMultiValues[$valuesContainer.dataset.attrName];
        $input.value = oldValue;
      }
    });
  };

  /**
   * Adds Set of Strings value as a seperate value below the input
   * And stores it in hidden input to further submit it in the form
   * @returns {void}
   */
  var addMultiValue = function addMultiValue() {
    var $storedValuesInput = this.parentElement.previousElementSibling;
    var $valuesContainer = this.parentElement.nextElementSibling;
    var $valueContainer = $valuesContainer.firstElementChild.cloneNode(true);
    var $valueText = $valueContainer.firstElementChild;
    var value = this.previousElementSibling.value.replace(/\s/g, '');
    $valueText.append(value);
    $valueContainer.prepend($valueText);
    $valuesContainer.append($valueContainer);
    $storedValuesInput.value = $storedValuesInput.value.concat("".concat($storedValuesInput.value.length ? ',' : ''), value);
    this.previousElementSibling.value = '';
    this.disabled = true;
    $valueContainer.classList.remove('d-none');
  };

  /**
   * The function adds value from the checkbox to the hidden multi-select input field
   * @returns {void}
   */
  var addValueFromCheckbox = function addValueFromCheckbox() {
    var $checkboxContainer = this.parentElement;
    var $inputField = $checkboxContainer.parentElement.querySelector('.js-multi-value');
    var inputValue = $inputField.value.length ? $inputField.value.split(',') : [];
    if (this.checked) {
      inputValue.push(this.value);
    } else {
      inputValue.splice(inputValue.indexOf(this.value), 1);
    }
    $inputField.value = inputValue.join(',');
  };

  /**
   * Removes Set of String value
   * @returns {void}
   */
  var removeMultiValue = function removeMultiValue() {
    var $storedValuesInput = doc.querySelector("input[name=\"".concat(this.dataset.attrName, "\"]"));
    var value = this.previousElementSibling.innerText;
    $storedValuesInput.value = $storedValuesInput.value.split(',').filter(function (val) {
      return val !== value;
    }).join(',');
    this.parentElement.remove();
  };

  /**
   * Disables the button on input submit
   * @returns {void}
   */
  var enableAddButton = function enableAddButton() {
    this.nextElementSibling.disabled = false;
  };

  /**
   * Submits input value on enter
   * @param {Event} event keydown event
   * @returns {void}
   */
  var submitOnEnter = function submitOnEnter(event) {
    var KEY_ENTER = 13;
    if (event.keyCode === KEY_ENTER) {
      event.preventDefault();
      this.nextElementSibling.click();
    }
  };
  doc.addEventListener('DOMContentLoaded', function () {
    var forms = doc.querySelectorAll('.js-form-preferences');
    var attributes = doc.querySelectorAll('[data-dw-attr-id]');
    var instanceTypes = doc.querySelectorAll('.js-instance-type');
    var multiValueInputs = doc.querySelectorAll('.js-text-field');
    var checkboxInputs = doc.querySelectorAll('.js-input-checkbox');
    var actionSave = doc.querySelectorAll('.js-action-save');
    var actionAdd = doc.querySelectorAll('.js-action-add');
    var actionRemove = doc.querySelectorAll('.js-action-remove');
    var actionCancel = doc.querySelectorAll('.js-action-cancel');
    var actionApplyToSites = doc.querySelectorAll('.js-action-apply-to-sites');
    var wizardActionClose = doc.querySelector('.js-dw-wizard-close');
    var wizardToNextStage = doc.querySelector('.js-button-next');
    var wizardToPrevStage = doc.querySelector('.js-button-back');
    var wizardProgressItems = doc.querySelectorAll('[data-progress-id]');
    var wizardSelectAllSites = doc.querySelector('.js-select-all');
    var wizardActionApply = doc.querySelector('.js-button-apply');
    var wizardAlertActionProceed = doc.querySelector('.js-wizard-alert-ok');
    actions.storeClientId();
    handlerFilterPreferences();
    storeSavedMultiValues();
    forms.forEach(function (form) {
      form.addEventListener('submit', actions.savePreferencesHandler);
    });
    attributes.forEach(function (element) {
      actions.fetchPropertyDescription(element);
    });
    instanceTypes.forEach(function (element) {
      element.addEventListener('change', actions.handlerInstanceType);
    });
    actionSave.forEach(function (button) {
      button.addEventListener('click', handlers.handlerBeforeSubmit);
      button.addEventListener('click', updateDataAttrOldValue);
    });
    actionAdd.forEach(function (button) {
      button.addEventListener('click', addMultiValue);
    });
    actionRemove.forEach(function (button) {
      button.addEventListener('click', removeMultiValue);
    });
    actionCancel.forEach(function (button) {
      button.addEventListener('click', function () {
        restoreMultiValues(this.form.id);
      });
    });
    multiValueInputs.forEach(function (input) {
      input.addEventListener('input', enableAddButton);
      input.addEventListener('keydown', submitOnEnter);
    });
    checkboxInputs.forEach(function (checkbox) {
      checkbox.addEventListener('click', addValueFromCheckbox);
    });
    actionApplyToSites.forEach(function (button) {
      button.addEventListener('click', handlers.handlerBeforeSubmit);
      button.addEventListener('click', function () {
        applyToOtherSitesWizard.show(this.form.id);
      });
    });
    wizardProgressItems.forEach(function ($item) {
      $item.addEventListener('click', function () {
        return applyToOtherSitesWizard.handleProgressBarClick($item);
      });
    });
    wizardAlertActionProceed.addEventListener('click', function () {
      applyToOtherSitesWizard.proceedtoWizard(this.form.id);
      restoreMultiValues(this.form.id);
    });
    wizardActionClose.addEventListener('click', function () {
      return applyToOtherSitesWizard.close();
    });
    wizardToNextStage.addEventListener('click', function () {
      return applyToOtherSitesWizard.toNextStage();
    });
    wizardToPrevStage.addEventListener('click', function () {
      return applyToOtherSitesWizard.toPrevStage();
    });
    wizardSelectAllSites.addEventListener('click', function () {
      return applyToOtherSitesWizard.selectAllSites();
    });
    wizardActionApply.addEventListener('click', function (event) {
      return applyToOtherSitesWizard.apply(event, actions.savePreferencesHandler);
    });
  });
  var observer = new MutationObserver(function (mutationsList) {
    mutationsList.forEach(function (mutation) {
      if (mutation.type === 'childList') {
        mutation.addedNodes.forEach(function (node) {
          if (node.classList && node.classList.contains('js-action-remove')) {
            node.addEventListener('click', removeMultiValue);
          }
        });
      }
    });
  });
  observer.observe(document, {
    childList: true,
    subtree: true
  });
})(document);

/***/ })

/******/ });
//# sourceMappingURL=bm_paypal_preferences.js.map