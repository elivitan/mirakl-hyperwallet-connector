'use strict';

const Locale = require('dw/util/Locale');
const StringUtils = require('dw/util/StringUtils');
const Money = require('dw/value/Money');
const cachePaypalCreditFinancingOptions = require('dw/system/CacheMgr').getCache('paypalCreditFinancingOptions');

const {
    getCalculatedFinancingOptions
} = require('*/cartridge/scripts/financialApi');

const creditFinancialOptionsHelper = {};

/**
 * Push credit financial options into array
 *
 * @param {Object} data - object with data
 * @param {Array} arr - array for receiving result
 */
function parseCreditFinancialOptions(data, arr) {
    data.financing_options.forEach(function(financingOption) {
        Object.keys(financingOption).forEach(function(optionFieldName) {
            if (financingOption[optionFieldName].forEach) {
                financingOption[optionFieldName].forEach(function(option) {
                    if (data.creditType) {
                        if (option.credit_financing && option.credit_financing.credit_type === data.creditType) {
                            arr.push(option);
                        }
                    } else {
                        arr.push(option);
                    }
                });
            }
        });
    });
}

/**
 * Returns all options by a credit type
 *
 * @param {float} cost - Value of cost
 * @param {string} currencyCode - Currency Code
 * @param {countryCode} countryCode - Country code
 * @param {creditType} creditType - Credit type (INST|SAC...)
 * @returns {Object} Object with all options, set of months and set of cost values
 */
creditFinancialOptionsHelper.getAllOptions = function(cost, currencyCode, countryCode, creditType) {
    if (cost instanceof Money) {
        creditType = countryCode;
        countryCode = currencyCode;
        currencyCode = cost.currencyCode;
        cost = cost.value;
    }

    const sessionCacheKey = [creditType, cost, currencyCode, countryCode].join('_');

    let result = cachePaypalCreditFinancingOptions.get(sessionCacheKey);

    if (result) {
        return result;
    }

    result = [];
    const data = getCalculatedFinancingOptions({
        financing_country_code: countryCode,
        transaction_amount: {
            value: cost,
            currency_code: currencyCode
        }
    });

    if (data.financing_options) {
        data.creditType = creditType;
        parseCreditFinancialOptions(data, result);
    }

    cachePaypalCreditFinancingOptions.put(sessionCacheKey, result);

    return result;
};

/**
 * Returns lowest monthly payment cost (INST-type)
 *
 * @param {float} cost - Value of cost
 * @param {string} currencyCode - Currency Code
 * @param {countryCode} countryCode - Country code
 * @returns {Object} Lowest monthly payment cost
 */
creditFinancialOptionsHelper.getLowestPossibleMonthlyCost = function(cost, currencyCode, countryCode) {
    if (cost instanceof Money) {
        countryCode = currencyCode;
        currencyCode = cost.currencyCode;
        cost = cost.value;
    }

    if (!countryCode) {
        countryCode = Locale.getLocale(request.locale).country;
    }

    const allOptions = creditFinancialOptionsHelper.getAllOptions(cost, currencyCode, countryCode, 'INST');
    let lowersCost = null;

    allOptions.forEach(function(option) {
        const optionMonthlyPaymentValue = parseFloat(option.monthly_payment.value);

        if (lowersCost === null || lowersCost > optionMonthlyPaymentValue) {
            lowersCost = optionMonthlyPaymentValue;
        }
    });

    return {
        value: lowersCost,
        currencyCode: currencyCode,
        formatted: lowersCost === null ? 'N/A' : StringUtils.formatMoney(new Money(lowersCost, currencyCode))
    };
};

/**
 * Returns object with all options (INST-type) and other helpful information
 *
 * @param {float} cost - Value of cost
 * @param {string} currencyCode - Currency Code
 * @param {countryCode} countryCode - Country code
 * @returns {Object} Result with all options and other helpful information
 */
creditFinancialOptionsHelper.getDataForAllOptionsBanner = function(cost, currencyCode, countryCode) {
    if (cost instanceof Money) {
        countryCode = currencyCode;
        currencyCode = cost.currencyCode;
        cost = cost.value;
    }

    if (!countryCode) {
        countryCode = Locale.getLocale(request.locale).country;
    }

    const allOptions = creditFinancialOptionsHelper.getAllOptions(cost, currencyCode, countryCode, 'INST');
    const result = {
        options: {},
        monthSet: [],
        monthlyPaymentValueSet: []
    };

    allOptions.forEach(function(option) {
        const term = parseInt(option.credit_financing.term, 10);
        const monthlyPaymentValue = parseFloat(option.monthly_payment.value);
        const totalCostValue = parseFloat(option.total_cost.value);

        result.options[term] = {
            term: term,
            apr: parseFloat(option.credit_financing.apr),
            monthlyPayment: {
                value: monthlyPaymentValue,
                currencyCode: option.monthly_payment.currency_code,
                formatted: StringUtils.formatMoney(new Money(monthlyPaymentValue, option.monthly_payment.currency_code))
            },
            totalCost: {
                value: totalCostValue,
                currencyCode: option.total_cost.currency_code,
                formatted: StringUtils.formatMoney(new Money(totalCostValue, option.total_cost.currency_code))
            },
            purchaseCost: {
                value: cost,
                currencyCode: currencyCode,
                formatted: StringUtils.formatMoney(new Money(cost, currencyCode))
            },
            rawOptionData: option
        };
        result.monthSet.push(term);
        result.monthlyPaymentValueSet.push(monthlyPaymentValue);
    });

    result.monthSet.sort(function(a, b) {
        return a - b;
    });

    result.monthlyPaymentValueSet.sort(function(a, b) {
        return a - b;
    });

    return result;
};

module.exports = creditFinancialOptionsHelper;
