'use strict';

const baseValidationHelper = module.superModule;

/**
 * If the object has any properties, return false, otherwise return true.
 * @param {Object} obj - The object to check.
 * @returns {boolean} false
 */
baseValidationHelper.isEmptyObject = function(obj) {
    return Object.keys(obj).length === 0;
};

module.exports = baseValidationHelper;
