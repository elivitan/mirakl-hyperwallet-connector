'use strict';

const basePreferences = module.superModule;

/**
 * Returns paypal payment method ID
 * @returns {string} active paypal payment method id
 */
function getPaypalPaymentMethodId() {
    const PaymentMgr = require('dw/order/PaymentMgr');
    const paypalConstants = require('*/cartridge/scripts/util/paypalConstants');

    const activePaymentMethods = PaymentMgr.getActivePaymentMethods();
    let paypalPaymentMethodID;

    Array.some(activePaymentMethods, function(paymentMethod) {
        if (paymentMethod.paymentProcessor.ID === paypalConstants.ALLOWED_PROCESSOR_ID) {
            paypalPaymentMethodID = paymentMethod.ID;

            return true;
        }

        return false;
    });

    return paypalPaymentMethodID;
}

/**
 *  Returns PayPal custom and hardcoded preferences
 *
 * @returns {Object} statis preferences
 */
function getPreferences() {
    basePreferences.paypalPaymentMethodId = getPaypalPaymentMethodId();

    return basePreferences;
}

module.exports = getPreferences();
