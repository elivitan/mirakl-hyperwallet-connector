'use strict';

const path = require('path');
const glob = require('glob');
const cwd = process.cwd();

const cartridgeName = process.env.npm_config_cartridgeName;
const cartridges = cartridgeName ? [cartridgeName] : [
    'int_paypal',
    'paypal_credit_messaging',
    'plugin_giftcertificate',
    'bm_paypal'
];

process.noDeprecation = true;

/**
 * Returns a map js object for the some cartridge
 * @param {string} cartridgeName Cartridge name
 * @returns {Object} An object
 */
function createCartridgeJsFiles(cartridgeName) {
    const cartridgesPath = path.resolve(cwd, 'cartridges');
    const clientPath = path.resolve(cartridgesPath, cartridgeName, 'cartridge/client');
    const result = {};

    glob.sync(path.resolve(clientPath, '*', 'js', '*.js')).forEach(f => {
        const fileName = path.basename(f, '.js');
        const regex = new RegExp(`${fileName}`, 'g');
        const key = path.join(path.dirname(path.relative(cwd, f)), fileName)
            .replace('client', 'static')
            .replace(regex, (match, p1, p2) => p2.indexOf('js') < p1 ? `${cartridgeName}_${match}` : match);

        result[key] = f;
    });

    return result;
}

/**
 * Returns a map js object for all cartridges
 * @returns {Object} An object
 */
function createCartridgesJsFiles() {
    return cartridges.reduce((accum, cur) => {
        return Object.assign(accum, createCartridgeJsFiles(cur));
    }, {});
}

module.exports = [{
    mode: 'development',
    devtool: 'source-map',
    name: 'js',
    entry: createCartridgesJsFiles(),
    output: {
        path: path.resolve(__dirname) + '/',
        filename: '[name].js'
    },
    module: {
        rules: [
            {
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: [
                            [
                                '@babel/preset-env',
                                {
                                    targets: {
                                        chrome: '53',
                                        firefox: '49',
                                        edge: '38',
                                        ie: '11',
                                        safari: '10'
                                    }
                                }
                            ]
                        ],
                        plugins: [
                            '@babel/plugin-transform-destructuring',
                            '@babel/plugin-proposal-class-properties',
                            '@babel/plugin-proposal-object-rest-spread'
                        ]
                    }
                },
                exclude: [
                    /tab\.js$/
                ]
            }
        ]
    }
}];
